# UstaTop — yangilanish hisoboti (2026-11-08)

## Asosiy manba
- Asosiy loyiha: `UstaTop-loyiha (2).zip` (original).
- Oldingi tuzatish ZIP: `UstaTop-birinchi-tuzatish.zip` faqat xarita ekranidagi bitta fayl uchun taqqoslash manbasi sifatida ishlatildi.
- Original backup oldindan yaratilgan; ushbu yangilanish original ZIP ustiga emas, alohida ishchi nusxaga kiritildi.

## Kiritilgan o‘zgarishlar
1. `mobile/src/screens/MapListingsScreen.js`
   - Oldingi suhbatda tayyorlangan 350 ms debounce qo‘shildi.
   - Eskirgan API javoblari yangi natijalarni bosib ketmasligi uchun request ID nazorati qo‘shildi.
   - Ekran yopilganda timer tozalanadi va eski so‘rov javobi bekor qilinadi.
2. Expo SDK yangilanishi
   - `expo`: `~51.0.28` → `~58.0.0`.
   - `react`: `18.2.0` → `19.3.0`.
   - `react-native`: `0.74.5` → `0.88.1`.
   - Expo modullari SDK 58 tavsiya etilgan versiyalariga yangilandi: constants, linear-gradient, status-bar, location, notifications, device.
3. Real telefon uchun backend manzili
   - Oldingi suhbatda ishlatilgan kompyuter LAN IP: `172.20.125.60`.
   - `mobile/app.json`, `mobile/src/api/client.js`, `mobile/src/api/socket.js` ichidagi API fallback manzillari `http://172.20.125.60:4000/api` qilindi.
   - Windows uchun `npm run start:lan:windows` skripti qo‘shildi.
4. `README.md`
   - SDK 58, Node.js talabi, LAN ishga tushirish va Expo Doctor tekshiruvi bo‘yicha yo‘riqnoma yangilandi.

## Tekshiruv natijalari
- `package.json` va `app.json`: JSON sintaksisi to‘g‘ri.
- Backend JavaScript fayllari: `node --check` xatosiz.
- Xarita debounce va request ID himoyasi kodda mavjud.
- API va Socket.IO konfiguratsiyasi bir xil LAN IP manzilidan foydalanadi.
- Node.js 22.16.0 mavjud; SDK 58 talab qiladigan 22.13+ chegarasidan yuqori.

## Hali bajarilmagan majburiy tekshiruvlar
Ushbu muhitda tashqi internet/Docker yo‘qligi sabab `npm install`, `npx expo install --fix`, `npx expo-doctor`, Jest testlari, Android qurilmada ishga tushirish va backend ulanishini real sinash bajarilmadi. Shuning uchun SDK 58 migratsiyasi hozircha kod darajasida tayyorlangan, lekin qurilmada to‘liq tasdiqlanmagan.

## Foydalanuvchi kompyuterida bajariladigan keyingi qadam
`mobile` papkasida:

```powershell
npm install
npx expo install --fix
npx expo-doctor
npm run start:lan:windows
```

Alohida terminalda backend ishlayotgan bo‘lishi kerak. Telefon va kompyuter bir xil Wi-Fi/hotspot tarmog‘ida bo‘lsin. `172.20.125.60` IP o‘zgargan bo‘lsa, `mobile/app.json` dagi `expo.extra.apiUrl` va start skriptidagi IP yangilanadi.

## Eslatmalar
- Expo SDK 58 rasmiy ravishda React Native 0.88 va React 19.3 bilan keladi.
- Expo SDK upgrade hujjatlari SDK versiyalarini bosqichma-bosqich yangilashni tavsiya qiladi. 51 dan 58 ga bevosita o‘tish sababli `expo install --fix` va `expo-doctor` natijalarini ko‘rmasdan ilovani ishlaydi deb hisoblamaslik kerak.
- Android Expo Go ichida remote push notification funksiyasi SDK 53 dan boshlab ishlamaydi; push xabarlarni to‘liq sinash uchun development build kerak. Local notification imkoniyatlari qoladi.
- EAS `projectId` placeholder qiymati ataylab o‘zgartirilmadi: haqiqiy loyiha ID foydalanuvchi EAS loyihasidan olinishi kerak.
- Komissiya, to‘lovlar, bekor qilingan buyurtma va admin kirishiga oid auditda aniqlangan masalalar keyingi alohida bosqichlarda tuzatiladi; bu yangilanishda ularning biznes logikasi o‘zgartirilmadi.


## 2026-11-09 — keyingi yangilanish bosqichlari

### 1. Buyurtma/taklif xavfsizligi
- `offer.controller.js`: taklifni qabul qilishdan oldin listing va offer qatorlarini tranzaksiyada `FOR UPDATE` bilan qulflash qo'shildi.
- `order.controller.js`: buyurtma holatlari tranzaksiyaga va `FOR UPDATE` himoyasiga ko'chirildi.
- `003_order_lifecycle_safety.sql`: bekor qilingan buyurtma tarixini saqlagan holda e'lonni qayta buyurtmaga berish uchun faol buyurtmalarga partial UNIQUE index qo'shildi.
- `smokeTestOrderLifecycle.js` qo'shildi; bekor qilishdan keyin qayta buyurtma, takror yakunlash va to'lov tasdig'i controller darajasida tekshiriladi.

### 2. Xarita va chat
- Android xarita ekranlariga OpenStreetMap tile qatlami qo'shildi; Android'da Google Maps API kalitisiz ko'rsatish uchun `mapType="none"` ishlatiladi.
- Xarita, joy tanlash va e'lon tafsilotidagi mini-xaritada OpenStreetMap attribution ko'rsatiladi.
- Joy tanlanganda `expo-location` reverse geocoding orqali manzilni ham olishga harakat qiladi; koordinatalar asosiy ma'lumot bo'lib qoladi.
- Chat ekrani Android klaviaturasi bilan moslashtirildi; `android.softwareKeyboardLayoutMode="resize"`.
- Usta taklif yuborganda chat ham yaratiladi; mijoz taklifni qabul qilishdan oldin chatda kelishishi mumkin.
- Chatlar ro'yxati bir xil suhbatdosh profilini guruhlaydi, alohida e'lon chatlari esa ichki ro'yxatda saqlanadi.

### 3. E'lonni tahrirlash
- `CreateListingScreen` yaratish va tahrirlash uchun qayta ishlatildi.
- E'lon egasi ochiq/bekor qilingan e'lonni tafsilot ekranidan tahrirlashi mumkin.
- Backend update API kategoriya, shahar, manzil va koordinatalarni ham saqlaydi.
- Jarayondagi yoki yakunlangan e'lonni tahrirlash rad etiladi.

### 4. Bevosita xizmat to'lovi
- Mijoz va usta ikki bosqichli tasdiqlash oqimi qo'shildi.
- `004_direct_service_payment_confirmation.sql` ikkala tasdiq vaqtini saqlaydi.
- Usta mijoz tasdig'isiz "to'lovni oldim" deb belgilay olmaydi.
- Payme/Click checkout va webhooklari mijozning xizmat haqini UstaTop orqali o'tkazmaydi; eski checkout endpointi 410 qaytaradi.
- `MyOrdersScreen`da eski Payme/Click to'lov tugmasi o'rniga mijoz va usta uchun alohida tasdiqlash amallari qo'shildi.

### Tekshiruv
- Barcha JavaScript fayllari `node --check` bilan sintaksisdan o'tdi.
- Barcha JSON konfiguratsiyalari parse qilindi.
- `npm run verify`: fake DB/controller smoke testlari muvaffaqiyatli o'tdi (buyurtma lifecycle 24 assertion; admin, xarita, to'lov siyosati, push testlari ham o'tdi).
- Jest suite va haqiqiy PostgreSQL migratsiyalari bu muhitda ishga tushirilmadi: arxivda `node_modules` yo'q va foydalanuvchining lokal Docker bazasiga bevosita ulanish imkoni yo'q.
- OSM public tile serveri ishlab chiqish/test uchun ishlatiladi; katta trafik yoki production uchun tile provayderi/hosting siyosatini alohida tanlash kerak.

### 5. Bitta buyruq bilan ishga tushirish
- `mobile/app.config.js` orqali `EXPO_PUBLIC_API_URL` dinamik o'qiladi.
- `mobile/package.json` LAN start skripti endi oldindan yozilgan IP'ni majburlamaydi.
- `RUN_USTATOP.bat` Wi-Fi/Ethernet IP'ni aniqlaydi, Docker Compose backendini qayta quradi, `/health`ni kutadi va Expo Go'ni ishga tushiradi.
