@echo off
setlocal
cd /d "%~dp0"
title UstaTop - test admin yaratish

echo Bu skript faqat ustatop_test test bazasida admin yaratadi.
echo Eski asosiy baza va uning foydalanuvchilariga tegmaydi.
echo.
set /p ADMIN_PHONE=Admin telefon raqami (+998XXXXXXXXX): 
if "%ADMIN_PHONE%"=="" goto invalid
set /p ADMIN_PASSWORD=Yangi admin paroli (kamida 8 belgi, harf va raqam): 
if "%ADMIN_PASSWORD%"=="" goto invalid
set /p ADMIN_NAME=Admin ismi (Enter - Administrator): 
if "%ADMIN_NAME%"=="" set "ADMIN_NAME=Administrator"

echo.
echo Test backend orqali admin yaratilmoqda...
docker compose -p ustatop_test -f docker-compose.test.yml exec -T backend node src/scripts/createAdmin.js "%ADMIN_PHONE%" "%ADMIN_PASSWORD%" "%ADMIN_NAME%"
if errorlevel 1 (
  echo.
  echo Admin yaratilmadi. Telefon/parol formatini va test backend holatini tekshiring.
  pause
  exit /b 1
)
echo.
echo Admin test bazasida tayyor. Kirish uchun telefon va kiritgan parolingizdan foydalaning.
pause
exit /b 0

:invalid
echo Telefon va parol majburiy.
pause
exit /b 1
