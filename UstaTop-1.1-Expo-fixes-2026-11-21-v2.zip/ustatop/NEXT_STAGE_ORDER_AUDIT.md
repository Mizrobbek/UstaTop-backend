# UstaTop — keyingi bosqich: buyurtma va takliflar auditi

Sana: 2026-11-08
Holat: diagnostika; bu bosqichda buyurtma backend kodi hali o‘zgartirilmadi.

## 1. Tasdiqlangan muammolar

### A. Bekor qilingan e'lonni qayta buyurtmaga berish
- `backend/migrations/001_init.sql` ichida `orders.listing_id UUID NOT NULL UNIQUE`.
- `backend/src/controllers/order.controller.js` buyurtma bekor qilinganda listing holatini yana `open` qiladi.
- Keyin boshqa usta taklifi qabul qilinsa, `offer.controller.js` yana shu `listing_id` bilan order yaratadi.
- Oldingi order yozuvi saqlanib turgani uchun UNIQUE cheklovi yangi order INSERT'ini rad etadi.
- Natija: mijoz bekor qilingan e'lonni qayta ishlata olmasligi mumkin.

Tavsiya etilgan yechim: tarixiy buyurtmalarni saqlash, `orders.listing_id` dagi to‘liq UNIQUE cheklovini olib tashlash va faqat faol holatlar (`confirmed`, `in_progress`) uchun partial UNIQUE index qo‘yish. Buni yangi migratsiya orqali, mavjud ma'lumotlarni tekshirib bajarish kerak.

### B. Bir e'lon uchun ikki taklifni bir vaqtda qabul qilish xavfi
- `offer.controller.js` avval offer/listing holatini oddiy SELECT bilan tekshiradi.
- `BEGIN` faqat keyin boshlanadi.
- Listing qatori `FOR UPDATE` bilan qulflanmagan.
- Ikki parallel so‘rov bir xil `open` holatini ko‘rib, ikkalasi ham buyurtma yaratishga urinish ehtimoli bor.

Tavsiya etilgan yechim: tranzaksiyani avval boshlash, listing qatorini `SELECT ... FOR UPDATE` bilan qulflash, offer qatorini qayta tekshirish va faqat listing hali `open` bo‘lsa qabul qilish. Partial UNIQUE index qo‘shimcha himoya bo‘ladi.

### C. Buyurtma holatini parallel yangilash xavfi
- `updateOrderStatus` buyurtmani tranzaksiyadan tashqarida o‘qiydi.
- Keyin `in_progress` holati tranzaksiyasiz yangilanadi.
- `completed` va `cancelled` uchun ham dastlabki holat tekshiruvi UPDATE bilan atomar bog‘lanmagan.
- Parallel so‘rovlar noto‘g‘ri holat o‘tishiga yoki bajarilgan ishlar hisoblagichining takror oshishiga olib kelishi mumkin.

Tavsiya etilgan yechim: buyurtmani tranzaksiya ichida `FOR UPDATE` bilan o‘qish va UPDATE'ni ruxsat etilgan oldingi status sharti bilan bajarish. `completed_orders_count` faqat status birinchi marta `completed` ga o‘tganda oshishi kerak.

## 2. Keyingi kod o‘zgarishidan oldin
- Mavjud testlarning `fakeDb` tranzaksiya/lock xatti-harakatini tekshirish.
- Bekor qilingan e'lonni qayta buyurtmaga berish uchun regression test qo‘shish.
- Bir listing uchun ikki taklif parallel qabul qilinishiga regression test qo‘shish.
- Bir order ikki marta yakunlanishiga regression test qo‘shish.
- Yangi SQL migratsiyani avval test bazasida tekshirish.

## 3. Hozircha o‘zgartirilmagan biznes qoidalari
- Mijoz xizmat haqini bevosita ustaga to‘laydi.
- UstaTop komissiyasi alohida hisoblanadi; mijozning xizmat to‘lovi bilan aralashtirilmaydi.
- Mijoz va usta uchun mavjud xizmat to‘lovi holati o‘chirilmaydi.
- Komissiya stavkasi qabul qilingan buyurtmaga keyin admin o‘zgartirsa ham ta'sir qilmaydi.
