# UstaTop — keyingi bosqich yangilanishi

Sana: 2026-11-18
Asos: foydalanuvchi yuklagan `UstaTop-audit-patch-2026-11-17.zip`.

## Kiritilgan tuzatishlar

1. **Sessiyani tiklash**
   - `mobile/src/api/client.js`: access token yo'qolganda refresh vaqtida tarmoq/server xatosi yuz bersa, saqlangan refresh token va foydalanuvchi ma'lumotlari endi o'chirilmaydi.
   - Refresh token server tomonidan 401/403 bilan rad etilsa yoki saqlangan user JSON buzilgan bo'lsa, sessiya xavfsiz tozalanadi.
   - Bu vaqtinchalik internet uzilishi sabab foydalanuvchining sessiyasini yo'qotish xavfini kamaytiradi.

2. **Chat oynasi**
   - `mobile/src/screens/ChatScreen.js`: user ma'lumoti va xabarlar tarixi parallel yuklanadi.
   - Ekran yopilgandan keyin Socket.IO ulanishi kechikib tugasa, listener noto'g'ri o'rnatilmaydi.
   - Socket.IO vaqtincha ishlamasa ham REST orqali chatdan foydalanish davom etadi.
   - Android'da `softwareKeyboardLayoutMode: resize` bilan birga `KeyboardAvoidingView`ning ikkinchi marta `height` hisoblashiga yo'l qo'ymaslik uchun Android behavior olib tashlandi; iOS padding saqlandi.

3. **Suhbatlar ro'yxati**
   - `mobile/src/screens/ChatsListScreen.js`: birinchi ochilishda `useFocusEffect` va alohida `useEffect` orqali takror yuborilgan ikkita API so'rovi bitta so'rovga birlashtirildi.
   - Ekranga qaytilganda ro'yxat qayta yuklanishi saqlandi.
   - Pull-to-refresh yakunida indikator xato holatida ham yopiladi.

4. **Taklif va muzokara UX**
   - `mobile/src/screens/ListingOffersScreen.js`: mijozga avval chatda narx va ish shartlarini kelishish kerakligi aniq yoziladi.
   - Qabul qilish tugmasi “Kelishuvdan so'ng qabul qilish” deb nomlandi.
   - Qabul qilish tasdiqlash oynasida buyurtma ochilishi va qolgan takliflar rad etilishi tushuntiriladi.
   - Backenddagi taklifni qabul qilish qoidasi o'zgartirilmadi.

5. **Xavfsiz ishga tushirish**
   - `RUN_USTATOP.bat` endi port 4001 dagi alohida test backendni tekshiradi va mobil ilovaga shu manzilni beradi.
   - Skript `docker compose up --build` chaqirmaydi; shu sabab eski 4000-port stack, eski PostgreSQL konteyneri va uning volume'iga tegmaydi.
   - Test backend ishlamayotgan bo'lsa, Expo ishga tushishidan oldin aniq xabar beradi.

## Tekshiruvlar

- 116 ta JavaScript fayli `node --check` orqali tekshirildi: sintaksis xatosi topilmadi.
- `mobile/package.json`, `mobile/app.json`, `mobile/package-lock.json` JSON parse tekshiruvidan o'tdi.
- `npm run verify` ishga tushirildi, ammo bu muhitda `backend/node_modules` yo'qligi sabab `uuid` moduli topilmadi va smoke testlar bajarilmadi.
- Docker va PostgreSQL CLI ushbu ish muhitida mavjud emas/ruxsat berilmagan; haqiqiy DB migratsiyalari, parallel tranzaksiya va qurilma testi bajarilmadi.

## Ochiq qolgan masalalar

- OpenStreetMap public tile serverining telefonda qaytargan 403 javobi ushbu bosqichda hal qilinmadi. Tile provayderini tanlash va xarita ekranlarini birgalikda almashtirish alohida ish.
- Expo SDK 58 paketlarining `expo-doctor` tavsiya qilgan aniq patch versiyalariga mosligi to'liq tasdiqlanmadi; lockfile ataylab qo'lda qayta yaratilmagan.
- EAS `projectId` hali placeholder; real EAS loyihasi yaratilganda almashtiriladi.
- `npm run verify`, Jest, PostgreSQL integration test, Expo Doctor va haqiqiy Android telefon sinovi foydalanuvchi kompyuterida birgalikda bajarilishi kerak.

## Xavfsizlik eslatmasi

Bu arxiv ishlab chiqish/test nusxasidir. Eski production ma'lumotlar bazasiga migratsiya bajarilmadi va eski konteynerlar/volume'lar o'chirilmadi.
