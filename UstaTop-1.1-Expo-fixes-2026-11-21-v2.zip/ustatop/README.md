# UstaTop — Usta/Ish topish platformasi (O'zbekiston uchun)

Loyiha React Native + Expo SDK 58 asosida yangilanmoqda. README’dagi eski bosqich tavsiflari tarixiy bo‘lishi mumkin; amaldagi funksiyalarni audit va testlar orqali tasdiqlash kerak.

Dastlabki tavsif:
email yoki telefon raqam + parol orqali ro'yxatdan o'tish va kirish, telefon raqami
orqali parolni tiklash, parol maydonida ko'rsatish/yashirish tugmasi, va o'ziga xos
"UstaTop" brendi/logotipi bilan.

Loyihaning to'liq arxitekturasi (baza sxemasi, backend tuzilishi) kelajakdagi
bosqichlar — e'lonlar, chat, buyurtmalar, sharhlar — uchun ham tayyorlab qo'yilgan,
shunda ular ustiga qurish tez va oson bo'ladi.

---

## 1. Loyiha tuzilishi

```
uz-usta-app/
├── backend/                  # Node.js + Express + PostgreSQL API
│   ├── admin/                # Admin panel (statik HTML/CSS/JS) — /admin manzilida ochiladi
│   ├── migrations/           # SQL sxema va boshlang'ich ma'lumotlar
│   ├── src/
│   │   ├── config/db.js      # PostgreSQL ulanish
│   │   ├── controllers/      # Biznes-logika (auth.controller.js)
│   │   ├── middleware/       # auth, validate, errorHandler
│   │   ├── routes/           # API yo'nalishlari
│   │   ├── utils/            # JWT, OTP, SMS yordamchilari
│   │   └── validators/       # Joi orqali kiruvchi ma'lumotlarni tekshirish
│   ├── tests/                # Jest + Supertest testlari (soxta baza bilan)
│   └── Dockerfile
├── mobile/                   # React Native (Expo) - Android va iOS uchun bitta kod
│   └── src/
│       ├── api/client.js     # Backend bilan bog'lanish, token boshqaruvi
│       ├── components/       # Logo, TextField, PasswordInput, PrimaryButton
│       ├── screens/          # Login, Register, ForgotPassword, Home
│       └── theme/colors.js   # Rang palitrasi
└── docker-compose.yml        # PostgreSQL + backend'ni bir buyruq bilan ko'tarish
```

---

## 2. Backend'ni ishga tushirish

### Xavfsiz test rejimi (tavsiya etiladi)

Ushbu arxivdagi `RUN_USTATOP.bat` `docker-compose.test.yml` orqali alohida test backend va PostgreSQL bazasini avtomatik yaratadi/ishga tushiradi, so'ng Expo Go'ni ishga tushiradi. U eski `docker-compose.yml`, `ustatop_backend` konteyneri yoki eski PostgreSQL volume'iga tegmaydi. Oldingi noto'g'ri test bazasi volume'i ham o'chirilmaydi: tuzatilgan konfiguratsiya yangi `ustatop_test_db_data_v2` volume'dan foydalanadi. PostgreSQL healthcheck endi shunchaki server javobini emas, login/parol orqali haqiqiy ulanishni ham tekshiradi.

Talablar:
- Docker Desktop'da alohida `ustatop_test` backend va baza oldindan ishga tushirilgan bo'lishi;
- test backend host kompyuterda `http://127.0.0.1:4001/health` manzilida `status: ok` qaytarishi;
- telefon va kompyuter bir xil Wi-Fi/hotspot tarmog'ida bo'lishi.

Loyiha ildizidagi `RUN_USTATOP.bat` faylini ishga tushiring. Skript faqat `ustatop_test` nomli alohida Compose loyihasini ko'taradi, Wi-Fi/Ethernet IP'ni topadi,
API manzilini `http://<LAN-IP>:4001/api` qilib beradi va Expo Go'ni ochadi.

### Backend portlari

- Test backend: host `4001` → container `4000`.
- Test PostgreSQL: host `5433` → container `5432`.
- Eski/ishlab turgan stack: alohida saqlanadi; ushbu test launcher uni qayta qurmaydi yoki o'chirmaydi.

**Eslatma:** `docker-compose.yml` tarixiy lokal stack konfiguratsiyasi bo'lib qolmoqda.
Uni mavjud eski konteynerlar ustida `up --build` bilan ishga tushirmang. Avval test stack
konfiguratsiyasi va Docker loyihasi aniq ajratilganini tekshirish kerak.

### Testlarni ishga tushirish

```bash
cd backend
npm install
npm run verify
npm test
```

`npm run verify` fake DB/controller smoke testlarini, `npm test` esa Jest testlarini bajaradi.
Haqiqiy PostgreSQL migratsiyalarini faqat alohida bo'sh test bazasida sinang; ishlab turgan
ma'lumotlar bazasida tajriba o'tkazmang.

## 3. Mobil ilovani ishga tushirish

Talab qilinadi: Node.js 22.13+ (SDK 58 talabi), [Expo Go](https://expo.dev/client) ilovasi yoki Android Studio / Xcode. SDK 58 React Native 0.88 va React 19.3 bilan ishlaydi.

```bash
cd mobile
npm install
npx expo install --fix
npx expo-doctor
```

SDK 58 moslik tekshiruvidan so‘ng telefonni LAN orqali ishga tushirish (Windows):

```powershell
npm run start:lan:windows
```

Yoki: `npx expo start --lan --clear --go` (kompyuter IP manzili `172.20.125.60` bo‘lsa, `REACT_NATIVE_PACKAGER_HOSTNAME` ni ham shu IP ga sozlang).

Terminalda chiqqan QR kodni telefoningizdagi **Expo Go** ilovasi orqali skanerlang —
ilova to'g'ridan-to'g'ri telefoningizda ochiladi, hech qanday build kerak emas.

### Backend manzilini sozlash

`mobile/app.json` faylidagi `expo.extra.apiUrl` qiymatini o'zgartiring:

| Holat | apiUrl qiymati |
|---|---|
| Android emulyator (kompyuterdagi backend) | `http://10.0.2.2:4000/api` |
| Real Android telefon (Expo Go, alohida test backend) | `http://<LAN-IP>:4001/api` |
| Ishlab chiqarish (production) | `https://api.ustatop.uz/api` (haqiqiy domen) |

---

## 4. SDK 58 bo‘yicha muhim eslatmalar

- Expo SDK 58 uchun Node.js kamida 22.13 talab qilinadi.
- `npm install` dan keyin `npx expo install --fix` SDK bilan mos Expo paketlarini tekislaydi.
- `npx expo-doctor` konfiguratsiya va dependency nomuvofiqliklarini tekshiradi.
- Android Expo Go’da remote push notifications ishlamaydi; push xabarlarni real qurilmada sinash uchun development build kerak. Local notification imkoniyatlari Expo Go’da qoladi.
- `172.20.125.60` oldingi suhbatda ishlatilgan lokal IP. Router/hotspot o‘zgarsa IP ham o‘zgarishi mumkin; telefon va kompyuter bir tarmoqda bo‘lishi, test backend host kompyuterda 4001-portda ishga tushgan bo‘lishi kerak.

## 5. API hujjatlari (Auth)

Barcha manzillar `http://localhost:4000/api/auth/...` bazasida.

### `POST /register`
```json
// So'rov
{ "fullName": "Aziz Karimov", "phone": "+998901234567", "email": "aziz@mail.com", "password": "Parol1234" }
// email ixtiyoriy, olib tashlash mumkin

// Javob (201)
{ "message": "...", "user": {...}, "accessToken": "...", "refreshToken": "..." }
```

### `POST /login`
```json
// So'rov - identifier email yoki telefon bo'lishi mumkin
{ "identifier": "+998901234567", "password": "Parol1234" }
// yoki
{ "identifier": "aziz@mail.com", "password": "Parol1234" }

// Javob (200)
{ "message": "Xush kelibsiz!", "user": {...}, "accessToken": "...", "refreshToken": "..." }
```

### `POST /forgot-password/send-code`
```json
{ "phone": "+998901234567" }
// Javob: SMS orqali 5 xonali kod yuboriladi (dev muhitda server logiga chiqadi)
```

### `POST /forgot-password/reset`
```json
{ "phone": "+998901234567", "code": "48213", "newPassword": "YangiParol1" }
// Muvaffaqiyatli bo'lsa, barcha eski sessiyalar (refresh tokenlar) bekor qilinadi
```

### `POST /refresh`
```json
{ "refreshToken": "..." }
// Javob: yangi accessToken + refreshToken juftligi
```

### `POST /logout`
```json
{ "refreshToken": "..." }
```

**Parol talablari:** kamida 8 belgi, kamida bitta harf va bitta raqam.
**Telefon formati:** qat'iy `+998XXXXXXXXX` (9 ta raqam, boshida +998).

---

## 5. Xavfsizlik choralari (allaqachon amalga oshirilgan)

- Parollar **bcrypt** bilan (12 round) xeshlanadi, hech qachon ochiq holda saqlanmaydi
- JWT access token (15 daqiqa) + refresh token (30 kun), **token rotation** bilan
- Parol o'zgartirilganda barcha eski sessiyalar avtomatik bekor qilinadi
- Login/register/OTP so'rovlari **rate-limit** qilingan (brute-force va SMS-bombardimon hujumlaridan himoya)
- "Login yoki parol noto'g'ri" xabari ataylab umumiy qilingan (xakerlar qaysi telefon/email ro'yxatdan o'tganini bilib ololmasligi uchun)
- SQL in'eksiyasidan himoya — barcha so'rovlar parametrlangan (`$1, $2...`)
- Helmet middleware orqali HTTP header xavfsizligi

---

## 6. SMS integratsiyasi (production uchun)

Hozircha `.env` faylida `SMS_PROVIDER=console` — kodlar SMS orqali yuborilmaydi,
faqat server konsoliga chiqadi (bepul test qilish uchun qulay).

Haqiqiy SMS yuborish uchun (`src/utils/sms.js` faylida tayyor):
1. [Eskiz.uz](https://eskiz.uz)'da hisob oching (O'zbekistonda eng ko'p ishlatiladigan SMS-shlyuz)
2. `.env` faylida `SMS_PROVIDER=eskiz`, `ESKIZ_EMAIL` va `ESKIZ_PASSWORD` ni to'ldiring

---

## 7. Google Play va App Store'ga chiqarish (keyingi bosqichlar uchun eslatma)

Ilova to'liq tayyor bo'lgach:

1. **Android:** `eas build --platform android` (Expo Application Services) →
   `.aab` fayl oling → [Google Play Console](https://play.google.com/console)'ga yuklang ($25 bir martalik to'lov)
2. **iOS:** `eas build --platform ios` → Apple Developer hisobingiz orqali
   ([developer.apple.com](https://developer.apple.com), $99/yil) App Store Connect'ga yuklang
3. Backend'ni haqiqiy serverga joylashtiring (masalan: Timeweb, Beget, DigitalOcean,
   yoki O'zbekiston ichida joylashgan hosting — GDPR/mahalliy qonunchilik va tezlik uchun tavsiya etiladi)

---

## 8. Kategoriyalar, E'lonlar va Takliflar API'si (yangi qo'shildi)

### `GET /api/categories`
Login shart emas. Barcha faol kategoriyalarni qaytaradi.

### `POST /api/listings` *(login kerak, rol: client/both)*
```json
{ "categoryId": 1, "title": "Kranni tamirlash kerak", "description": "...",
  "priceType": "negotiable", "city": "Toshkent", "address": "Chilonzor" }
```

### `GET /api/listings` — filtrlash bilan
Query parametrlar: `categoryId`, `city`, `status`, `search`, `lat`, `lng`, `radiusKm`, `page`, `limit`

### `GET /api/listings/:id` — bitta e'lon (ko'rishlar soni avtomatik oshadi)
### `PATCH /api/listings/:id` / `DELETE /api/listings/:id` — faqat e'lon egasi
### `GET /api/listings/mine` — o'z e'lonlarim

### `POST /api/listings/:id/offers` *(rol: provider/both)*
```json
{ "price": 150000, "message": "Bugun kela olaman" }
```
### `GET /api/listings/:id/offers` — faqat e'lon egasi ko'radi
### `PATCH /api/offers/:id` — `{ "status": "accepted" | "rejected" }`. Qabul qilinsa: buyurtma (order) va chat avtomatik yaratiladi, boshqa takliflar rad etiladi.
### `GET /api/offers/mine` — usta o'z takliflarini ko'radi

**Muhim eslatma - qo'shimcha tekshiruv:** `src/scripts/smokeTestFakeDb.js` skripti fakeDb'ning
eng murakkab qismini (dinamik WHERE filtri, offer→order→chat zanjiri) **haqiqatan
ishga tushirib** 11 ta holatni tekshiradi (`npm run verify` — hech qanday tashqi
paket kerak emas, faqat Node.js). Bu `npm test`ning o'rnini bosmaydi, lekin
qo'shimcha ishonch beradi.

---

## 9. Chat API'si (yangi qo'shildi)

### `GET /api/chats` — mening suhbatlarim (so'nggi xabar + o'qilmaganlar soni bilan)
### `GET /api/chats/:id/messages?before=&limit=` — xabarlar tarixi (eskisidan yangisiga)
### `POST /api/chats/:id/messages` — `{ "content": "...", "mediaUrl": "..." }` (ikkitasidan kamida bittasi shart)

**Real vaqtli ulanish (Socket.io):** mobil ilova quyidagicha ulanadi:
```js
io('https://api.ustatop.uz', { auth: { token: accessToken } })
socket.emit('chat:join', { chatId })
socket.on('message:new', (message) => { /* UI'ga qo'shish */ })
```
Xabar REST orqali yuborilganda (`POST /messages`), server avtomatik ravishda
xuddi shu suhbatdagi barcha ulangan foydalanuvchilarga `message:new` eventini yuboradi.

---

## 10. Foydalanuvchi/Buyurtma/Sharh API'si (yangi qo'shildi)

### `GET /api/users/me` — profil (usta bo'lsa, reyting va statistika bilan)
### `PATCH /api/users/me` — `{ fullName?, city?, avatarUrl? }`
### `POST /api/users/me/become-provider` — `{ bio?, experienceYears?, categoryIds: [1,2] }`

### `GET /api/orders?role=client|provider` — buyurtmalarim
### `GET /api/orders/:id`
### `PATCH /api/orders/:id/status` — `{ status: 'in_progress'|'completed'|'cancelled', cancelReason? }`
Qoidalar: `in_progress`/`completed` — faqat usta; `cancelled` — ikkala taraf ham (sabab bilan). Yakunlanganda e'lon holati va ustaning statistikasi avtomatik yangilanadi.

### `POST /api/orders/:id/review` — `{ rating: 1-5, comment? }` (faqat mijoz, faqat yakunlangan buyurtma uchun, bir marta)
### `GET /api/providers/:id` — usta ommaviy profili (reyting, tajriba, kategoriyalar)
### `GET /api/providers/:id/reviews` — usta sharhlari

**Diqqat, muhim topilma:** Ushbu bosqichda soxta bazani kengaytirish jarayonida
`myOffers` va `listMyOrders` so'rovlari bir xil SQL prefiksi bilan boshlanib qolgani
aniqlandi va **haqiqiy xato sifatida ushlab qolindi** (`npm run verify` orqali) —
bu aynan shu sabab bilan "faqat sintaksis tekshiruvi emas, real ishga tushirish"
talab qilinganining isboti. Xato darhol tuzatildi va endi ikkala so'rov ham
to'g'ri ishlaydi.

---

## 11. Admin panel (yangi qo'shildi)

Veb-interfeys backend bilan birga ishga tushadi: **http://localhost:4000/admin**

**1-qadam — birinchi administratorni yarating** (admin rolini API orqali olib bo'lmaydi, bu ataylab qilingan):
```bash
# Docker bilan:
docker compose exec backend node src/scripts/createAdmin.js +998901234567 "Kuchli_Parol_123" "Admin Ismi"
# Docker'siz:
cd backend && npm run create-admin -- +998901234567 "Kuchli_Parol_123" "Admin Ismi"
```
**2-qadam** — `/admin` sahifasida shu telefon raqam va parol bilan kiring.

**Imkoniyatlar:**
- **Bosh panel:** foydalanuvchilar/e'lonlar/buyurtmalar/sharhlar soni, yakunlangan buyurtmalar summasi, holatlar bo'yicha diagrammalar
- **Foydalanuvchilar:** qidiruv (ism/telefon/email), rol bo'yicha filtr, sahifalash; **bloklash/blokdan chiqarish** (bloklanganda barcha sessiyalari bekor qilinadi va tokeni darhol yaroqsiz bo'ladi); ustani **tasdiqlash** (✓ belgisi)
- **E'lonlar moderatsiyasi:** qidiruv, holat bo'yicha filtr; qoidabuzarlik qilgan ochiq e'lonni bekor qilish (egasiga bildirishnoma yuboriladi)
- **Kategoriyalar:** qo'shish, jadval ichida tahrirlash, yashirish/faollashtirish (yashirin kategoriya mobil ilovada ko'rinmaydi)

**Admin API** (`/api/admin/*`, faqat `admin` roli): `GET /stats`, `GET /users`, `PATCH /users/:id/active`,
`PATCH /providers/:id/verify`, `GET /listings`, `PATCH /listings/:id/cancel`, `GET|POST /categories`, `PATCH /categories/:id`.

**Xavfsizlik:** admin bo'lmagan hisob bilan kirishga urinilsa, u rad etiladi va berilgan sessiya darhol bekor qilinadi;
admin o'zini yoki boshqa adminni bloklay olmaydi; foydalanuvchi kiritgan barcha matnlar faqat `textContent` orqali
ko'rsatiladi (XSS'dan himoya, brauzer testida tekshirilgan); Helmet CSP inline skriptlarni bloklaydi. **Productionda
admin panelni albatta HTTPS orqali (Nginx/Caddy) oching** va admin parolini kuchli qiling.

**Tekshiruv natijalari (bu muhitda haqiqatan ishga tushirilgan):**
- `npm run verify` — admin controller'ning HAQIQIY kodi soxta baza bilan: 24 ta tekshiruv (huquqlar, bloklash, sahifalash, kategoriya CRUD) + avvalgi 19 ta
- `npm run test:admin-ui` — haqiqiy Chromium'da, qat'iy CSP bilan, 15 ta stsenariy (kirish, XSS, bloklash, kategoriya tahriri, mobil kenglik, konsol xatolari); bir marta `npx playwright install chromium` kerak
- `tests/admin.test.js` — route darajasidagi jest testi (401/403, validatsiya, bloklangan foydalanuvchi tokeni); `npm test` bilan ishlaydi

**Migratsiyalar endi qayta ishga tushirishga chidamli:** `schema_migrations` jadvali qaysi SQL fayllar qo'llanganini
saqlaydi, shuning uchun Docker konteyner qayta ishga tushganda yoki `npm run seed` ikkinchi marta bajarilganda xato bermaydi
(avvalgi versiyada `type already exists` xatosi bilan yiqilardi — bu topilib tuzatildi).

---

## 12. Xarita (yangi qo'shildi)

**Backend:**
- `GET /api/listings/map?minLat=&maxLat=&minLng=&maxLng=&categoryId=&userLat=&userLng=&limit=` —
  ekranda ko'rinib turgan hudud ichidagi ochiq e'lonlarni yengil ko'rinishda qaytaradi.
  Hudud markaziga eng yaqinlari birinchi olinadi; agar hududda `limit`dan ko'p e'lon bo'lsa,
  `truncated: true` qaytadi (mobil ilova "yaqinlashtiring" deb ko'rsatadi).
- **Dastur faqat O'zbekiston hududida ishlashi** talabi shu bosqichda backend darajasida
  mustahkamlandi: e'lon yaratishda koordinata `utils/geo.js`dagi `UZ_BOUNDS`
  (bounding box) ichida bo'lishi majburiy — bundan tashqarida bo'lsa 400 xato qaytadi.
  Bu aniq davlat chegarasi emas, balki uni o'rab turuvchi to'rtburchak: O'zbekiston ichidagi
  hech qanday nuqta noto'g'ri rad etilmaydi, faqat chegara bo'yidagi ba'zi qo'shni hudud
  nuqtalari ham "ichida" hisoblanishi mumkin. Kerak bo'lsa, `utils/geo.js`dagi bitta funksiyani
  GeoJSON ko'pburchagiga almashtirib, aniqlikni oshirish mumkin.
- Koordinata ixtiyoriy, lekin berilsa — kenglik va uzunlik albatta birga kelishi shart
  (faqat bittasi berilsa, 400 xato).

**Mobil ilova:**
- **Xarita ekrani** — butun O'zbekiston bo'ylab e'lonlar narx bilan (masalan "150ming", "2.5mln")
  belgilangan holda, kategoriya bo'yicha filtr chiplari, "joylashuvimni aniqlash" tugmasi
- **Joylashuvni tanlash** — e'lon berishda xaritadan bosib yoki GPS orqali aniq nuqta belgilash;
  O'zbekistondan tashqari joy bosilsa, ogohlantirish chiqadi
- **E'lon tafsilotida mini-xarita** — koordinata berilgan bo'lsa, kichik xarita va "Yo'nalishni
  ko'rish" tugmasi (qurilmadagi Apple Maps/Google Maps ilovasini ochadi)
- Bosh sahifada "Xaritada ko'rish" tezkor tugmasi va yuqori panelda xarita ikonkasi

**Sozlash (production uchun muhim):** `react-native-maps` Android'da ishlashi uchun
[Google Maps API kalitini](https://developers.google.com/maps/documentation/android-sdk/get-api-key)
olib, `mobile/app.json`dagi `android.config.googleMaps.apiKey`ga qo'shishingiz kerak bo'ladi
(iOS'da qo'shimcha kalit shart emas — Apple Maps ishlatiladi). Bepul sinov (Expo Go) uchun kalitsiz
ham asosiy funksiyalar ishlaydi, lekin ishlab chiqarish (production) build'ida kalit talab qilinadi.

**Tekshiruv natijalari (bu muhitda haqiqatan ishga tushirilgan):**
- `npm run verify` — geo yordamchilari (`isInUzbekistanBounds`, `haversineKm`) va xarita
  endpoint'ining HAQIQIY kodi soxta baza bilan: 11 ta tekshiruv (Toshkent/Nukus/Termiz ichida,
  Moskva/Almaty/Dehli tashqarida, masofa hisoblash Toshkent-Samarqand ~267 km, markazga
  yaqinlik bo'yicha saralash, `truncated` bayrog'i) — jami endi 54 ta tekshiruv
- `tests/map.test.js` — route darajasidagi jest testi (chegara validatsiyasi, `/map` yo'li
  `/:id`dan to'g'ri ustunlik qilishi, bo'sh hudud, limit cheklovi)

---

## 13. Xizmat haqi — mijoz va usta o'rtasida bevosita

**Asosiy qoida:** UstaTop mijozning xizmat haqini qabul qilmaydi. Mijoz xizmat haqini ustaga bevosita (naqd yoki karta orqali) to'laydi. Platforma faqat xizmat bajarilganini va ikki tomon to'lovni tasdiqlaganini qayd qiladi.

### Tasdiqlash oqimi
1. Mijoz xizmat haqini ustaga bergach, buyurtmada **"To'lovni ustaga berdim"** tugmasini bosadi.
2. Usta pulni olganidan keyin **"To'lovni oldim"** tugmasini bosadi.
3. Faqat ikkala tasdiqdan keyin buyurtma `is_paid=true` va **"To'langan"** bo'ladi.
4. Usta mijoz tasdiqlashidan oldin o'z tomonini tasdiqlay olmaydi. Har ikki tasdiq takror yuborilsa, holat buzilmaydi.

### Backend API
- `PATCH /api/orders/:id/payment-confirmation` — buyurtma ishtirokchilari o'z tomonidagi tasdiqni yuboradi.
- `GET /api/orders/:id/payment-status` — `isPaid` va `paidAt` holatini qaytaradi.
- Eski `POST /api/orders/:id/pay` checkout endpointi `410` qaytaradi.
- Payme/Click webhooklari ham xizmat haqini qabul qilmaydi; avvalgi integratsiya kodi hozircha saqlangan, ammo yangi xizmat to'lovlari uchun o'chirilgan.

### Ma'lumotlar bazasi
- `004_direct_service_payment_confirmation.sql` migratsiyasi `client_payment_confirmed_at` va `provider_payment_confirmed_at` maydonlarini qo'shadi.
- Buyurtma faqat ikki maydon ham to'lgandan keyin `is_paid=true` bo'ladi.
- Bu maydonlar UstaTop komissiyasidan alohida: mijozga platforma komissiyasi ko'rsatilmaydi.

**Eslatma:** `003_order_lifecycle_safety.sql` va `004_direct_service_payment_confirmation.sql` migratsiyalarini yangi kodni joylashdan oldin mavjud PostgreSQL bazasiga qo'llash kerak. Ular bu arxivni tayyorlash jarayonida foydalanuvchining ishlayotgan bazasiga qo'llanmagan.

---

## 14. Push-bildirishnomalar (yangi qo'shildi)

**Nima uchun Firebase emas, Expo Push xizmati:** mobil ilova Expo (managed workflow)
asosida qurilgan, shuning uchun qurilma tokeni Expo'ning o'z formatida
(`ExponentPushToken[...]`). Expo'ning push xizmati buni o'zi FCM (Android) yoki
APNs (iOS)'ga yo'naltiradi — Firebase hisob ma'lumotlarini (service account JSON)
sozlash shart emas. Agar kelajakda ilova Expo'dan "eject" qilinsa, faqat
`backend/src/utils/pushNotifications.js` faylini xom `firebase-admin` SDK bilan
almashtirish kifoya (qolgan hamma narsa — `notifyUser()` chaqiruvlari — o'zgarmaydi).

### Backend API
- `POST /api/users/me/push-token` — `{ "pushToken": "ExponentPushToken[...]" | null }`
- `GET /api/notifications?page=&limit=` — `{ notifications, unreadCount }`
- `PATCH /api/notifications/:id/read`, `PATCH /api/notifications/read-all`

### Qanday ishlaydi
Har qanday muhim voqea (yangi taklif, taklif qabul/rad qilindi, yangi xabar, buyurtma
yakunlandi/bekor qilindi, yangi sharh, admin tomonidan e'lon bekor qilindi) markazlashtirilgan
`backend/src/utils/notify.js` dagi `notifyUser()` funksiyasi orqali yuboriladi — bu funksiya
(1) bazaga yozadi (ilova ichidagi "Bildirishnomalar" ro'yxati uchun) va (2) agar foydalanuvchi
push tokenini ro'yxatdan o'tkazgan bo'lsa, Expo orqali push ham yuboradi. Push yuborishda
xato (tarmoq, eskirgan token) bo'lsa ham, asosiy amal (masalan, taklifni qabul qilish)
hech qachon shu sababli muvaffaqiyatsiz bo'lmaydi.

Mobil ilovada: kirgandan so'ng `registerForPushNotifications()` avtomatik chaqiriladi,
ruxsat so'raydi va tokenni backend'ga yuboradi. Bildirishnomaga bosilganda (ilova fonda
yoki yopiq bo'lsa ham) tegishli ekranga avtomatik o'tiladi. Bosh sahifada qo'ng'iroq
ikonkasi o'qilmagan sonini ko'rsatadi.

### Sozlash
`.env`ga qo'shimcha narsa shart emas (Expo xizmati standart holatda ochiq), lekin
ixtiyoriy ravishda yuqori so'rov chegarasi uchun `EXPO_ACCESS_TOKEN` qo'shishingiz mumkin
(business.expo.dev'dan olinadi). Mobil tomonda `mobile/app.json`dagi
`expo.extra.eas.projectId`ni haqiqiy EAS loyiha ID'ingiz bilan almashtiring
(`eas init` buyrug'i avtomatik to'ldiradi) — aks holda push token olish ishlamaydi.

**Tekshiruv natijalari (bu muhitda haqiqatan ishga tushirilgan):** `npm run verify` —
`notifyUser()`ning to'liq oqimi (bazaga yozish + Expo'ga to'g'ri formatda so'rov,
eskirgan token avtomatik tozalanishi, tarmoq xatosida ham funksiya yiqilmasligi) va
`notification.controller.js`ning barcha endpoint'lari uchun 13 ta tekshiruv. Bu jarayonda
yana bir real kamchilik topildi: taklif **rad etilganda** ustaga hech qanday bildirishnoma
yuborilmas edi (faqat qabul qilinganda yuborilardi) — bu tuzatildi va alohida tekshiruv
bilan mustahkamlandi.

---

## 15. Keyingi bosqich — nima qo'shilishi rejalashtirilgan

- [x] ~~Kirish/ro'yxatdan o'tish (email/telefon + parol, parolni tiklash)~~
- [x] ~~Kategoriyalar va e'lonlar (yaratish, qidirish, filtrlash)~~
- [x] ~~Ustalar javob beradi (offers), buyurtma tasdiqlanadi~~
- [x] ~~Real vaqtli chat (Socket.io)~~
- [x] ~~Buyurtma holatini boshqarish (boshlash/yakunlash/bekor qilish)~~
- [x] ~~Sharh va reyting tizimi~~
- [x] ~~"Usta bo'lish" endpoint'i va ekrani~~
- [x] ~~Xarita ko'rinishi~~
- [x] ~~Payme/Click to'lov integratsiyasi~~
- [x] ~~Admin panel (foydalanuvchi/kategoriya boshqaruvi, moderatsiya)~~
- [x] ~~Push-bildirishnomalar (Expo Push xizmati)~~
- [ ] Android uchun "bekor qilish sababi" maxsus modali (hozir `Alert.prompt` faqat iOS'da ishlaydi)

Har birini alohida so'rasangiz, xuddi shu sifat darajasida (backend + test + hujjat) tayyorlab beraman.

## 6. So‘nggi yangilanish

2026-11-08 dagi xarita, Expo SDK 58 va LAN IP yangilanishlari tafsilotlari `CHANGELOG_USTATOP_2026-11-08.md` faylida qayd etilgan. SDK migratsiyasining yakuniy tasdig‘i uchun `mobile` ichida `npm install`, `npx expo install --fix` va `npx expo-doctor` bajarilishi shart.

## UstaTop 1.1 — media storage va profil

- `MEDIA_STORAGE_DRIVER=local` (standart) hozircha media fayllarni backend `uploads/` katalogida saqlaydi.
- Docker Compose'da `ustatop_uploads` named volume ishlatiladi; konteyner qayta yaratilganda fayllar saqlanadi.
- Fayl yuklash: `POST /api/media/upload` (Bearer token, multipart `files`, ko'pi bilan 10 fayl; rasm/video 50 MB gacha).
- Portfolio: `GET/POST /api/portfolio/me`, `DELETE /api/portfolio/me/:id`.
- Usta ommaviy profili portfolio elementlarini ham qaytaradi.
- `backend/src/storage/index.js` storage adapter chegarasi. Keyinchalik S3-compatible adapter shu interfeys orqali ulanadi; controller va API o'zgarmaydi.
- Profil tahriri: `PATCH /api/users/me`; usta ma'lumotlari: `PATCH /api/users/me/provider-profile`.
- Telefon raqamini o'zgartirish SMS OTP bilan alohida tasdiqlash oqimiga ulanmaguncha ataylab tahrirlanmaydi.
- Migration `007_media_portfolio.sql` mavjud portfolio yozuvlarini saqlagan holda media_type/media_url maydonlarini qo'shadi.
