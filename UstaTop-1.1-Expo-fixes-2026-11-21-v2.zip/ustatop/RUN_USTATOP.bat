@echo off
setlocal
cd /d "%~dp0"
title UstaTop - xavfsiz test ishga tushirish

echo [1/4] Docker Desktop tekshirilmoqda...
docker info >nul 2>&1
if errorlevel 1 (
  echo XATOLIK: Docker Desktop ishga tushmagan. Uni oching va qayta urinib ko'ring.
  pause
  exit /b 1
)

echo [2/4] Alohida test backend va bazasi ishga tushirilmoqda...
echo Bu buyruq faqat docker-compose.test.yml dagi ustatop_test resurslariga tegadi.
docker compose -p ustatop_test -f docker-compose.test.yml up -d --build
if errorlevel 1 (
  echo XATOLIK: Test backendni yaratib bo'lmadi. Docker xabarini tekshiring.
  pause
  exit /b 1
)

echo [3/4] Test backend sog'ligi tekshirilmoqda (90 soniyagacha)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; for($i=0;$i -lt 30;$i++){ try { $r=Invoke-RestMethod 'http://127.0.0.1:4001/health' -TimeoutSec 2; if($r.status -eq 'ok'){$ok=$true;break} } catch {}; Start-Sleep -Seconds 3 }; if(-not $ok){ Write-Host 'Test backend hali tayyor emas. Docker loglarini tekshirish kerak.'; exit 1 }"
if errorlevel 1 (
  echo XATOLIK: Backend sog'lom holatga kelmadi. Eski 4000-port va eski baza o'zgartirilmadi.
  echo Tekshirish uchun: docker compose -p ustatop_test -f docker-compose.test.yml logs --tail=80 backend
  pause
  exit /b 1
)

for /f "usebackq delims=" %%I in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$ip=$null; $routes=Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | Sort-Object RouteMetric,InterfaceMetric; foreach($route in $routes){ $a=Get-NetIPAddress -AddressFamily IPv4 -InterfaceIndex $route.InterfaceIndex -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' }; $a=$a | Where-Object { (Get-NetAdapter -InterfaceIndex $_.InterfaceIndex -ErrorAction SilentlyContinue).Name -notmatch 'vEthernet|WSL|Docker|Loopback|Virtual|VPN|TAP|TUN' } | Select-Object -First 1; if($a){$ip=$a.IPAddress;break} }; if(-not $ip){$ip=Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.InterfaceAlias -match 'Wi-Fi|Wireless' -and $_.IPAddress -notlike '169.254.*' } | Select-Object -First 1 -ExpandProperty IPAddress}; if($ip){Write-Output $ip}"`) do set "LAN_IP=%%I"
if "%LAN_IP%"=="" (
  echo XATOLIK: Telefon bilan bog'lanish uchun LAN IP topilmadi.
  pause
  exit /b 1
)
set "EXPO_PUBLIC_API_URL=http://%LAN_IP%:4001/api"
set "REACT_NATIVE_PACKAGER_HOSTNAME=%LAN_IP%"
echo Kompyuter LAN IP: %LAN_IP%
echo API: %EXPO_PUBLIC_API_URL%

echo [4/4] Mobil ilova Expo Go uchun ishga tushirilmoqda...
cd /d "%~dp0mobile"
where npm >nul 2>&1
if errorlevel 1 (
  echo XATOLIK: Node.js va npm topilmadi. Node.js LTS o'rnatilganini tekshiring.
  pause
  exit /b 1
)

if not exist "node_modules\expo\package.json" (
  set "INSTALL_MOBILE=1"
) else if not exist "node_modules\expo-image-picker\package.json" (
  set "INSTALL_MOBILE=1"
) else if not exist "node_modules\expo-document-picker\package.json" (
  set "INSTALL_MOBILE=1"
) else (
  set "INSTALL_MOBILE=0"
)
if "%INSTALL_MOBILE%"=="1" (
  echo Mobil paketlar birinchi marta o'rnatilmoqda. Bu bir necha daqiqa vaqt olishi mumkin...
  if exist "package-lock.json" (
    findstr /C:"expo-image-picker" package-lock.json >nul
    if errorlevel 1 (
      echo Yangi Expo Image Picker paketi aniqlangan. Paketlar yangilanmoqda...
      call npm.cmd install
    ) else (
      call npm.cmd ci
    )
  ) else (
    call npm.cmd install
  )
  if errorlevel 1 (
    echo XATOLIK: Mobil paketlarni o'rnatib bo'lmadi. Internet aloqasi va npm xabarlarini tekshiring.
    pause
    exit /b 1
  )
)

echo Mobil ilova ishga tushirilmoqda...
rem Expo login talab qilmasdan anonim rejimda ishga tushsin.
rem CI rejimini tozalash: interaktiv terminal va QR-kod ko'rinishi uchun kerak.
set "CI="
call npm.cmd run start:lan:windows
if errorlevel 1 (
  echo XATOLIK: Expo ishga tushmadi.
  pause
  exit /b 1
)
