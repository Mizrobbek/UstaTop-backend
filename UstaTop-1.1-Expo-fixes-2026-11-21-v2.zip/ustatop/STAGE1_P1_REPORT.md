# 1-bosqich (P1) — o'zgarishlar qaydi

Asos: `UstaTop-yangilangan-2026-11-09.zip` (SHA-256 046ec697…58e8). Asl fayllar xeshlari: `BASELINE.sha256`.

- Yangi migratsiya: `backend/migrations/005_p1_security_integrity.sql` (qaytarish: `migrations/rollback/005_p1_security_integrity.down.sql`, qo'lda).
- Haqiqiy PostgreSQL testlari: `TEST_DATABASE_URL=... npm run test:pg` (faqat bo'sh test bazasi — ma'lumotlarni tozalaydi).
- Xulq o'zgarishi: admin bloklagan foydalanuvchining eski tokenlari blokdan chiqarilgandan keyin qayta tiklanmaydi — qaytadan kirish kerak.
- Production'da server quyidagilarda ishga tushmaydi: standart/qisqa JWT kalitlar, `usta_pass` paroli, `SMS_PROVIDER=console`, `CORS_ORIGINS=*`.
