# UstaTop 1.1 — Auth / MyID update test report

## Tekshiruvdan o'tganlar
- Backend `backend/src` va `backend/tests` ichidagi 83 ta CommonJS JavaScript fayli `node --check` bilan sintaksis tekshiruvidan o'tdi.
- `auth.controller.js`, `auth.routes.js`, `auth.validator.js`, `otp.js`, `auth.js` va MyID gate qo'shilgan controllerlar qo'lda qayta ko'rib chiqildi.
- Mobil ro'yxatdan o'tish/kirish ekranlarida email maydoni olib tashlangani va OTP bosqichi qo'shilgani tekshirildi.
- Docker Compose ishga tushganda Dockerfile `node src/scripts/migrate.js --seed` bajaradi; yangi 008 migratsiya shu tartibda qo'llanadi.

## Bajarilmagan sinovlar
- `npm ci --ignore-scripts --no-audit --no-fund` backend va mobile papkalarida bajarishga urinish vaqt tugashi bilan yakunlandi. Shu sabab Jest, Expo Metro bundling va React Native JSX parser sinovi bajarilmadi.
- Docker va PostgreSQL ushbu muhitda mavjud emas; 008 migratsiya haqiqiy PostgreSQL 16 bazasida bajarilmadi.
- SMS_PROVIDER=console bo'lgan test rejimida API javobiga `debugCode` qaytariladi; bu faqat production bo'lmagan muhitda. Haqiqiy SMS yuborish uchun Eskiz yoki boshqa SMS provayder hisob ma'lumotlari zarur.
- MyID SDK/API hali ulanmagan. Usta taklif yuborishi `myid_verified=TRUE` bo'lmaguncha bloklanadi. Haqiqiy MyID callback/SDK test access va texnik hujjatlar bilan keyingi bosqichda ulanadi.
- Android qurilmada yangi OTP ekranlari sinovdan o'tkazilmadi.

## Xavfsizlik eslatmalari
- OTP 5 daqiqa amal qiladi, 5 marta xato urinishdan keyin yaroqsiz bo'ladi, qayta yuborish uchun 60 soniya kutish mavjud.
- Yangi foydalanuvchi `users` jadvaliga faqat OTP to'g'ri tasdiqlangach kiritiladi.
- Eski tasdiqlanmagan foydalanuvchilar login vaqtida OTP oladi; tasdiqlanmaguncha access-token va refresh orqali himoyalangan API'ga kira olmaydi.
- Production muhitida `SMS_PROVIDER=console` ishlatilmaydi; `debugCode` faqat production bo'lmagan va console provider ishlayotgan holatda qaytariladi.
- Test muhiti uchun eski `/auth/register` endpoint saqlangan; u faqat `NODE_ENV=test` bo'lganda route qilinadi. Development/production foydalanuvchilari `/register/request-code` va `/register/verify-code` oqimidan foydalanadi.
- MyID uchun JSHSHIR, pasport yoki biometrik ma'lumotlar UstaTop bazasida saqlanmaydi; hozircha faqat MyID tasdiq holati va tranzaksiya identifikatori uchun maydonlar qo'shilgan.
