# UstaTop 1.1 — Telefon OTP va MyID bosqichi

## Qabul qilingan talab
- Barcha foydalanuvchilar telefon raqamini SMS OTP orqali tasdiqlaydi.
- Mijoz telefon tasdig‘idan keyin mijoz sifatida foydalanadi.
- Usta sifatida taklif yuborish uchun qo‘shimcha MyID tasdig‘i shart.
- Ro‘yxatdan o‘tish va kirish mobil interfeysida email ishlatilmaydi. Eski `users.email` ustuni va mavjud qiymatlar migratsiyada o‘chirilmaydi.

## Kodga kiritilgan o‘zgarishlar
- Ro‘yxatdan o‘tish ikki bosqichga ajratildi: SMS kod so‘rash va kodni tasdiqlash. Hisob faqat OTP to‘g‘ri kiritilgandan keyin yaratiladi.
- Eski, hali telefonini tasdiqlamagan hisoblar login vaqtida SMS OTP challenge oladi.
- Login validatori endi faqat O‘zbekiston telefon raqamini qabul qiladi.
- Mobil ro‘yxatdan o‘tish va kirish ekranlaridan email maydoni olib tashlandi; OTP kiritish bosqichi qo‘shildi.
- `008_phone_otp_myid_gate.sql` migratsiyasi `signup_verify` OTP maqsadini, vaqtinchalik ro‘yxatdan o‘tish jadvalini va usta profilidagi MyID holati maydonlarini qo‘shadi.
- Usta taklif yuborishidan oldin `provider_profiles.myid_verified = TRUE` tekshiriladi.

## MyID integratsiyasi bo‘yicha muhim cheklov
Hozircha haqiqiy MyID SDK/API ulanishi yo‘q. Rasmiy MyID ulanish jarayonida loyiha bo‘yicha so‘rov yuborish, NDA va shartnoma jarayoni, so‘ng test kirish ma’lumotlarini olish ko‘rsatilgan. MyID test `client_id`/`client_secret`, tanlangan mahsulot/SDK va callback hujjatlari berilmaguncha haqiqiy identifikatsiya oqimini xavfsiz yakunlab bo‘lmaydi. Rasmiy ulanish sahifasi: https://myid.uz/en/connect-myid/ ; texnik hujjatlar: https://docs.myid.uz/ . Hozirgi kod MyID tasdig‘isiz ustaning taklif yuborishini bloklaydi; bu MyID integratsiyasi tayyor degani emas.

## Migratsiya va test holati
- Yangi migratsiya qo‘shildi, ammo foydalanuvchining Docker/PostgreSQL bazasida hali bajarilgani yo‘q.
- JavaScript sintaksis va statik tekshiruvlar keyingi tekshiruv bosqichida bajariladi.
- Haqiqiy SMS yuborish `SMS_PROVIDER=console` bo‘lsa ishlamaydi; production uchun Eskiz yoki boshqa tasdiqlangan provayder hisob ma’lumotlari zarur.
- Android qurilmada ro‘yxatdan o‘tish/login OTP oqimi hali real SMS bilan sinalmagan.
