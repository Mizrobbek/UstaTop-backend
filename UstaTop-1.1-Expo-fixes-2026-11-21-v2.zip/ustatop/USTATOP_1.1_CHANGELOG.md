# UstaTop 1.1 — yangilanishlar

## Kiritilgan kod o'zgarishlari

1. **Profil rasmi:** Expo Image Picker orqali galereyadan profil rasmi tanlash, backend `/api/media/upload` orqali serverga yuklash va profilga biriktirish.
2. **Profil ma'lumotlari:** ism-familiya, shahar/tuman, usta bio va tajribasini tahrirlash saqlanadi.
3. **Telefonni almashtirish:** `+998` formatidagi yangi raqam uchun OTP so'rash va OTP tasdiqlangandan keyin almashtirish endpointlari qo'shildi. `SMS_PROVIDER=console` test muhitida kod backend logida ko'rinadi; haqiqiy SMS uchun Eskiz yoki boshqa provayder sozlanishi kerak. Tasdiqlashdan keyin token_version oshadi va qayta login talab qilinadi.
4. **Usta portfoliomi:** mobil Portfolio ekrani, galereyadan 10 tagacha rasm/video tanlash, yuklash, izoh biriktirish va o'chirish qo'shildi.
5. **Rasmli e'lon:** e'lon yaratish/tahrirlash ekranida 10 tagacha rasm tanlash, oldindan ko'rish va olib tashlash qo'shildi. E'lon kartasi va tafsilotida rasmlar ko'rsatiladi.
6. **Media saqlash:** mavjud local storage adapter va Docker uploads volume ishlatiladi; controller'lar storage adapter interfeysidan foydalanadi. Cloud adapter hali ulanmagan.
7. **Mobil paketlar:** `expo-image-picker ~58.0.10` qo'shildi. Launcher paket yo'q bo'lsa `npm install` ishga tushiradi va eski lock fayl bilan `npm ci` xatosiga tushmaslikka harakat qiladi.
8. **Backend himoyasi:** portfolio va e'lon media URL'lari server uploads yo'liga cheklanadi; e'lonni tahrirlashda media ro'yxati yangilanadi.
9. **Login:** `ipKeyGenerator` import/chaqirig'i ishlatilmaydi; mavjud login limiter IP + identifier kaliti va muvaffaqiyatli loginni limitdan chiqarish bilan qoladi.

## Hali real qurilmada tekshirilishi shart

- Android Expo Go'da galereya ruxsatlari va rasm/video yuklash.
- Katta video fayllar, mobil internet va 50 MB upload chegarasi.
- SMS provayderi bilan haqiqiy OTP yetkazilishi (test compose hozir console rejimida).
- Xarita tile 403, Android klaviatura/Chat input va push notification xatolari — qurilmada qayta sinov talab qiladi; ushbu ZIP ularning barchasi tuzatilganini tasdiqlamaydi.
- To'liq backend Jest/integration va Expo Doctor sinovlari bajarilmagan: bu ishchi muhitda node_modules o'rnatilmagan, npm install vaqt chegarasidan oshgan.

## Ishga tushirish

`RUN_USTATOP.bat` test backendni va Expo Go'ni ishga tushiradi. Yangi `expo-image-picker` paketi yo'q bo'lsa launcher uni `npm install` orqali o'rnatadi. Test muhitidagi media fayllar `ustatop_test_uploads_v1` Docker volume'da saqlanadi. Eski production/test bazalari yoki volume'larni qo'lda o'chirmang.


## 2026-11-18 — Telefon OTP va MyID tayyorgarligi
- Mobil ro‘yxatdan o‘tish va kirish ekranlarida email olib tashlandi.
- Yangi hisob SMS OTP tasdiqlangandan keyin yaratiladi; tasdiqlanmagan eski hisoblar ham login paytida OTP challenge oladi.
- MyID tasdig‘i uchun DB maydonlari va usta taklif yuborishidagi majburiy tekshiruv qo‘shildi.
- Haqiqiy MyID SDK/API ulanishi test credentials va rasmiy integratsiya ma’lumotlari olinmaguncha yakunlanmagan.


## 2026-11-19 — Media upload and map tile hotfix
- Fixed Docker cross-filesystem upload failures (`EXDEV`) by staging uploads inside the persistent media volume before atomic rename; temporary files are cleaned up.
- Replaced CARTO raster tiles that rendered an `API KEY REQUIRED` watermark with OpenStreetMap raster tiles in both listing map and location picker.
- Added backend storage regression tests for upload, source cleanup, and media deletion.
- Note: the public OpenStreetMap tile service is suitable for development/light testing; production traffic should use a compliant tile provider or self-hosted tiles and retain attribution.

## 2026-11-21 — demo diagnostika va qisman frontend tuzatishlari
- Usta profilida mijoz sharhlarini ko'rsatish qo'shildi.
- Chatga galereyadan rasm/video yuborish qo'shildi (audio va hujjat tanlash hali yo'q).
- Android chat klaviaturasida `resize` bilan takroriy `height` hisoblash olib tashlandi.
- To'liq diagnostika va cheklovlar: `USTATOP_DEMO_DIAGNOSTIC_REPORT_2026-11-21.md`.
