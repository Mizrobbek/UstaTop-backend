# UstaTop 1.1 — implementation report

## Implemented in this archive
- Local media storage adapter (`backend/src/storage/index.js`) with a `put/remove` interface intended to allow a future cloud adapter.
- Persistent Docker named volumes for uploads in regular and isolated test Compose environments.
- Authenticated multipart upload endpoint `POST /api/media/upload` (up to 10 files, 50 MB/file; JPG/PNG/WEBP/HEIC/MP4/MOV MIME allowlist).
- Provider portfolio list/create/delete endpoints and public provider-profile portfolio data.
- Migration `007_media_portfolio.sql` adds media URL/type/description/storage-key metadata and preserves existing `image_url` values.
- Mobile profile editor, avatar picker, provider bio/experience fields, and phone-number change flow using OTP request/confirmation endpoints.
- Mobile portfolio screen with image/video picker and upload.
- Listing creation screen with image selection/upload.
- Uzbekistan `+998` phone prefix in login/registration flows.
- Android Expo Go push registration guard and guarded notification-channel setup.
- Login rate limiter keyed by client IP plus login identifier, with successful attempts skipped.

## Changes made during this maintenance pass
- `backend/src/controllers/media.controller.js`: if a multi-file upload fails partway through, previously stored files are removed; remaining temporary upload files are cleaned in `finally`.
- `backend/src/controllers/portfolio.controller.js`: portfolio inserts now persist `storage_key`; deleting a portfolio item also attempts to remove its corresponding local media file. URL parsing rejects non-`/uploads/` paths and unsafe path components.
- The earlier statements that the native media picker, phone change, and listing picker were missing were stale and incorrect for this archive; the corresponding mobile screens and APIs are present in the source.

## Validation performed in this environment
- ZIP integrity check passed before edits.
- `node --check` passed for 104 `.js` files under `backend/src` and `mobile/src` after edits.
- YAML parsing passed for `docker-compose.yml` and `docker-compose.test.yml`.

## Not verified / still requires runtime testing
- `npm ci --ignore-scripts --no-audit --no-fund` timed out in this environment; Jest and backend smoke tests were not run.
- Docker build, PostgreSQL migrations, and database-backed integration tests were not run here.
- Android device tests for map tiles, keyboard resizing, image/video picking, push notifications, OTP, and full chat/offer lifecycle were not run here.
- Map tiles use the CARTO Voyager public tile endpoint in the current mobile source; a 403 observed on a real device must still be confirmed against that device/network and provider policy. No claim of universal map availability is made.
- SMS delivery requires a configured SMS provider; development/test OTP behavior is not equivalent to production SMS delivery.
- Cloud storage is not enabled; local persistent disk storage remains active.

## Data safety
- No production database migration was executed by this maintenance pass.
- No Docker containers or volumes were removed or reset.
- Keep the previous archive as a backup before replacing the saved active project archive.
