# UstaTop 1.1 maintenance log — 2026-11-18

## Source
`UstaTop-1.1-full-stage-update.zip` supplied by the project owner.

## Applied source changes
1. Media upload controller now cleans up previously stored media if any file in a batch fails, and always removes leftover temporary files.
2. Portfolio creation persists the storage key using the existing `storage_key` column from migration 007.
3. Portfolio deletion removes its associated local media file after deleting the owned database record.
4. Portfolio media URLs are validated as `/uploads/` resources and path traversal components are rejected.
5. Implementation report corrected to reflect existing native image/video picker, profile phone OTP flow, and listing image picker in this archive.

## Checks
- 104 backend/mobile source `.js` files passed `node --check`.
- Both Docker Compose YAML files parsed successfully.
- npm dependency installation timed out; automated Jest/smoke tests were not run.
- Docker/PostgreSQL/Android runtime validation was not available in this build environment.

## Remaining device/runtime verification
Map tile HTTP 403, keyboard/chat layout, push channel behavior, OTP delivery, and full offer-to-order lifecycle must be exercised on the user's test backend and Android device before public release.
