# UstaTop 1.1 — media/map hotfix report (2026-11-19)

## Changes
1. `backend/src/storage/index.js`: uploads no longer call `rename()` directly from the OS temp directory into `/app/uploads`. The file is copied into a staging file inside the persistent storage directory, atomically renamed within that directory, then the OS temp file is removed. This addresses the observed `EXDEV: cross-device link not permitted` error.
2. `mobile/src/screens/MapListingsScreen.js` and `LocationPickerScreen.js`: replaced the CARTO raster tile URL that visibly returned the `API KEY REQUIRED` watermark with OpenStreetMap raster tiles. Attribution now names OpenStreetMap contributors.
3. Added `backend/tests/storage.test.js` covering persisted upload, temp-file cleanup, and delete.

## Verification performed
- Node syntax check passed for the changed backend storage module and both changed mobile screen files.
- Direct Node smoke test passed for storing a file from a separate temporary directory, removing the source file, and deleting the stored file.
- Full Jest/Expo build and on-device verification were not run in this environment. Real-device verification is still required after rebuilding/restarting the app.

## Operational notes
- Existing PostgreSQL data and Docker volumes are not modified by this patch.
- No SMS provider credentials or MyID credentials were changed.
- OpenStreetMap public tile service is for development/light testing; production-scale traffic should use a compliant tile provider or self-hosted tiles. Keep attribution visible.
