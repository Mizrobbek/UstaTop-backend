# UstaTop 1.1 — Expo qayta tuzatish hisoboti
Sana: 2026-11-21

## Foydalanuvchi bildirgan muammolar bo‘yicha tuzatishlar

1. **Usta kategoriyalari:** `HomeScreen` mijoz/usta rolini tekshiradi. `provider` va `both` rollarida Kategoriyalar bo‘limi ko‘rsatiladi; `client` rolida yashiriladi. Kategoriya tanlash tegishli e’lonlar ro‘yxatiga olib boradi.
2. **Sharhlar uchun alohida ekran:** `ProviderReviews` navigatsiya marshruti saqlangan. Usta o‘z profilidan ham, boshqa foydalanuvchi ko‘radigan usta profilidan ham barcha sharhlar ekraniga o‘ta oladi. Profil menyusiga ham alohida “Mijozlar sharhlari” bandi qo‘shildi.
3. **Chat dizayni:** yuqori gradient sarlavha, avatar, suhbat konteksti, yumshoq fon, yangilangan xabar pufakchalari va yozuv paneli qo‘shildi. Xabar yuborish, Socket.IO, fayl biriktirish API chaqiruvlari saqlandi.
4. **Android xarita:** MapLibre 5.24.1 (klassik UMD skript usuliga mos) tanlandi; jsDelivr → unpkg zaxira yuklash qo‘shildi; WebView uchun HTTPS base URL berildi; xarita muvaffaqiyatli ochilgandan keyingi alohida tile/glyph xatolari butun xarita ustiga xato oynasini chiqarib yubormasligi ta’minlandi; asosiy sahifa HTTP xatosi alohida tekshiriladi. Qayta yuklash tugmasi saqlandi.
5. **Expo ishga tushirish:** `RUN_USTATOP.bat` `expo-document-picker` ham o‘rnatilganini tekshiradi.

## Kod tekshiruvlari

- O‘zgartirilgan 4 ta JSX/JS fayl TypeScript parser orqali sintaksis tekshiruvi: **4/4 PASS**.
- Android xarita HTML ichidagi JavaScript sintaksisi: **PASS**.
- Expo Go’da, haqiqiy Android qurilmada, real tarmoq orqali xarita/marker/joylashuv tekshiruvi: **hali bajarilmagan**.
- APK/EAS build: **hali bajarilmagan**.

## Cheklovlar va keyingi shartlar

- Ushbu muhitda npm paketlarini to‘liq o‘rnatish va Expo bundling bajarilmagani sababli runtime test o‘tkazilmadi.
- Xarita OpenFreeMap va CDN serverlariga bog‘liq; koddagi fallbacklar yaxshilandi, lekin foydalanuvchi qurilmasida internet orqali tekshirilishi kerak.
- API manzili hali ham lokal/private IP bo‘lib turibdi. Internet orqali tarqatiladigan APK uchun HTTPS backend kerak.
- Ushbu hisobot APK tayyorligini yoki barcha muammolar qurilmada bartaraf bo‘lganini anglatmaydi.
