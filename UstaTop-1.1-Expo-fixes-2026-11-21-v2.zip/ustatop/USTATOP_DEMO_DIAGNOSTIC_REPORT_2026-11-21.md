# UstaTop 1.1 — demo diagnostika va qisman tuzatish hisoboti

Sana: 2026-11-21  
Asosiy arxiv: `UstaTop-1.1-yangilangan-2026-11-19.zip`  
Holat: diagnostika bajarildi; ayrim frontend tuzatishlari kiritildi; APK va real qurilma tasdig'i olinmadi.

## 1. Arxiv va zaxira

- ZIP CRC/integrity tekshiruvi: PASS.
- Arxiv tarkibi: 165 fayl, taxminan 1.82 MB ochilgan hajm.
- Ishchi nusxa: `UstaTop_work/ustatop` (ish muhiti yo'li).
- Asl arxiv nusxasi: `UstaTop-1.1-original-backup.zip`.
- Asl arxiv ichidagi fayllar o'zgartirilmadi.

## 2. Tuzilma va konfiguratsiya auditi

- Mobil: Expo SDK 58, React Native 0.88.1, `react-native-maps`, `expo-image-picker`.
- Backend: Express, PostgreSQL (`pg`), Socket.IO, Multer, Jest.
- DB: 001–008 migratsiyalar, jumladan media/portfolio, commission ledger va MyID gate.
- Mobil API default manzili `http://172.20.125.60:4001/api`/`app.json` dagi statik LAN manziliga bog'liq; bu boshqa tashkilotdagi qurilmadan foydalanish uchun yaroqli server manzili emas. Demo APK uchun `EXPO_PUBLIC_API_URL` orqali haqiqiy, tashqaridan ochiladigan HTTPS backend manzili berilishi shart.
- EAS `projectId` hali `YOUR-EAS-PROJECT-ID-BUNI-ALMASHTIRING` placeholder.
- Arxivda `.env` yo'q. DB URL, JWT, SMS, CORS, media storage va production secrets holati real deploy muhitisiz tasdiqlanmaydi.
- Docker, Android SDK va ADB ish muhitida mavjud emas.

## 3. Birinchi navbatdagi muammolar auditi

### Xarita

- Ikkala xarita ekrani `https://tile.openstreetmap.org/{z}/{x}/{y}.png` dan foydalanadi va Android'da `mapType="none"` bilan native base mapni yashiradi.
- React Native Maps rasmiy tiles hujjati Android'da OSM free tile serverlarining ortiqcha ishlatilish sababli ishlamasligini, public OSM tileserverni Android uchun tavsiya qilmasligini aytadi.
- OSM tile policy ilova identifikatsiyasiga ega aniq User-Agent va cache talab qiladi; RN Maps `UrlTile` hujjatida Android uchun sozlanadigan User-Agent prop ko'rsatilmagan.
- Shu sababli URL'ni boshqa tasodifiy public tile serverga almashtirish xavfsiz yoki ishonchli yechim emas. Demo uchun Google Maps API key bilan native Google provider yoki shartlari mos, API-key'li tile provider/self-hosted tile server kerak. Kalit/hosting berilmagani sabab xarita 403 muammosi hal qilingan deb belgilanmadi.

### Chat media

- Backendda autentifikatsiyalangan `/api/media/upload` umumiy media endpointi mavjud; hozirgi MIME allowlist faqat JPG/PNG/WEBP/HEIC va MP4/MOV.
- Chat xabarida `mediaUrl` saqlash qo'llab-quvvatlangan.
- Chat oynasiga galereyadan rasm/video tanlab yuklash va yuborish UI'si qo'shildi.
- Audio va hujjat (PDF/DOC/XLS va boshqalar) uchun backend MIME allowlist hamda mobil document/audio picker hali qo'shilmagan. Bu qism tugallanmagan.

### Usta sharhlari

- Backend `GET /api/providers/:id/reviews` mavjud.
- Ustaning o'z profilida hamda mijoz takliflar ro'yxatidan ochiladigan alohida ommaviy `ProviderProfileScreen` ekranida sharhlar, yulduzlar, muallif, sana va izoh ko'rsatiladi. Ommaviy ekran profil ma'lumoti, kategoriyalar va portfolioni ham ko'rsatadi.

### Klaviatura

- `app.json` da Android `softwareKeyboardLayoutMode: "resize"` bor.
- Chat oynasida Android uchun ikkinchi `KeyboardAvoidingView` `height` hisoblash olib tashlandi; iOS uchun `padding` saqlandi.
- Bu statik tuzatish; haqiqiy Android qurilmada klaviatura sinovi bajarilmadi.

### Takroriy chatlar

- `chats` jadvalida `(listing_id, client_id, provider_id)` unique cheklovi mavjud.
- Taklif yuborishda va qabul qilishda bir xil kalit bo'yicha `ON CONFLICT ... DO UPDATE` ishlatiladi. Shu e'lon/mijoz/usta uchligi uchun takroriy chat yaratilmasligi kerak.
- Turli e'lonlar bo'yicha bir mijoz va usta o'rtasida alohida chatlar bo'lishi mumkin; bu buyurtma kontekstini ajratadi. Buni global juftlik bo'yicha bitta chatga birlashtirish hozirgi listing/order chat modelini buzishi mumkin, shuning uchun o'zgartirilmadi.
- `listing_id IS NULL` holatida PostgreSQL unique semantikasi takroriy qatorlarga ruxsat berishi mumkin; hozirgi taklif oqimi listing_id bilan chat yaratadi.

### Muzokara

- Taklif yaratilganda chat ham yaratiladi.
- Mijoz taklifni qabul qilishdan oldin chatda muzokara qilishi mumkin.
- Taklif qabul qilinganda listing va offer qatorlari tranzaksiya ichida qulflanadi; faqat bitta taklif qabul qilinadi, qolgan pending takliflar rad etiladi va order yaratiladi.

## 4. Biznes qoidalari bo'yicha kod auditi

- Mijozning xizmat haqi ustaga bevosita to'lanishi uchun order/payment oqimi saqlangan; UstaTop mijozning xizmat haqini o'z hisobiga yig'ishi ko'rinmadi.
- `006_platform_commission.sql` order yaratilganda commission snapshot triggeri orqali komissiya hisobini yaratadi. Order esa taklif qabul qilingandan keyin yaratiladi.
- Komissiya endpointlari joriy foydalanuvchining `provider_id` si bo'yicha cheklangan; mijoz uchun komissiya tarixi endpointi yo'q.
- Taklifni yuborishda `provider_profiles.myid_verified = TRUE` sharti bor.
- MyID haqiqiy SDK/API/callback integratsiyasi arxiv hisobotida hali ulanmagan deb ko'rsatilgan. Shuning uchun bu faqat backend flag gate, haqiqiy shaxsni tekshirish emas.
- Taklif/public provider javoblarida telefon raqami qaytarilmaydi; qabuldan oldin telefon yashirilganligi kod darajasida saqlanadi.

## 5. Ushbu bosqichda kiritilgan o'zgarishlar

1. `mobile/src/screens/ProfileScreen.js`: usta profiliga mijoz sharhlari ko'rinishi qo'shildi; mavjud reviews API ishlatiladi.
2. `mobile/src/screens/ChatScreen.js`: galereyadan rasm/video tanlash, upload va chatga media URL yuborish qo'shildi.
3. `mobile/src/screens/ChatScreen.js`: Android `KeyboardAvoidingView` `height` olib tashlandi; `resize` rejimiga tayanadi.

## 6. Tekshiruv natijalari

- ZIP integrity: PASS.
- Backend/mobile JavaScript fayllarining `node --check` sintaksis tekshiruvi: PASS.
- O'zgartirilgan `App.js`, `ChatScreen.js`, `ProfileScreen.js`, `ListingOffersScreen.js` va yangi `ProviderProfileScreen.js` TypeScript transpile/parser diagnostikasi: 0 ta xato.
- `mobile/app.json`, `mobile/package.json`, `backend/package.json` JSON parse: PASS.
- `docker-compose.yml` va `docker-compose.test.yml` YAML parse: oldingi arxiv hisobotida PASS deb qayd etilgan; ushbu muhitda Docker mavjud emas.
- Backend Jest: NOT RUN — `jest: not found`.
- `npm ci`: NOT COMPLETED — ish muhitida DNS/network yo'q, o'rnatish vaqt tugashi bilan to'xtadi.
- PostgreSQL migrations/integration tests: NOT RUN — Docker/DB mavjud emas.
- Expo bundling/Expo Doctor/EAS build/APK: NOT RUN — dependency install va Android SDK mavjud emas.
- Android qurilmada chat, media, klaviatura, xarita, push, OTP va buyurtma lifecycle: NOT RUN.

## 7. Demo topshirishdan oldingi bloklovchi ishlar

1. Tashkilot uchun HTTPS backend domeni, `.env`, PostgreSQL va media storage tayyorlash; `EXPO_PUBLIC_API_URL` ni o'rnatish.
2. Xarita providerini tanlash va Android'da real tile/API key bilan tekshirish.
3. Chat audio/fayl yuborish uchun document/audio picker va server MIME/size/security qoidalarini qo'shish.
4. MyID provayderining haqiqiy test credentials va callback/API hujjatlari bilan integratsiya qilish.
5. Backend Jest/smoke/integration testlarini va Expo Doctor/bundle'ni bajarish.
6. EAS projectId yoki lokal Android SDK bilan APK build qilish.
7. Kamida bitta real Android qurilmada mijoz va usta to'liq oqimini sinash.

## 8. Yakuniy holat

Bu ZIP — diagnostika va qisman frontend tuzatishlari kiritilgan ishlab chiqish nusxasi. U demo topshirishga tayyor deb tasdiqlanmaydi. APK ishlab chiqarilmagan; haqiqiy qurilma va backend bilan end-to-end test bajarilmagan. Yuqoridagi bloklovchi ishlar tugamaguncha “tayyor” yoki “testdan o'tgan” deb e'lon qilinmasin.
