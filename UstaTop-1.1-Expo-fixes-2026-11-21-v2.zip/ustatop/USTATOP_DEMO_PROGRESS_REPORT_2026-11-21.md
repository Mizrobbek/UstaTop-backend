# UstaTop 1.1 — internet-demo 2-bosqich hisoboti

Sana: 2026-11-21  
Asosiy manba: `UstaTop-1.1-yangilangan-2026-11-19.zip`  
Holat: Android xarita va chat media bo'yicha kod o'zgarishlari kiritildi; statik va maqsadli testlar o'tdi; build va real qurilma tekshiruvlari hali bajarilmadi.

## 1. Zaxira yaxlitligi

- Original arxiv: `UstaTop-1.1-original-backup.zip`.
- Original arxiv SHA-256: `92f55ef74f896d10e6cbfb5acac0bbe372a88090fd120cba3abafe16ab1469f6`.
- Manba ZIP va zaxira ZIP SHA-256 bir xil; originalga tegilmagan.
- Yangilangan ishchi nusxa originaldan alohida saqlandi.

## 2. Ushbu bosqichdagi o'zgarishlar

### Android xarita — API kalitisiz variant

- Android'dagi `react-native-maps` + `tile.openstreetmap.org` raster tile yo'li MapLibre GL JS WebView komponentiga almashtirildi.
- Basemap: OpenFreeMap Liberty (`https://tiles.openfreemap.org/styles/liberty`). API key va ro'yxatdan o'tish talab qilinmaydi.
- UstaTop e'lon markerlari, marker bosilganda e'lon tafsilotiga o'tish, xaritada bosib joy tanlash, xarita hududi o'zgarganda listinglarni qayta yuklash va GPS orqali xaritani markazlash ko'zda tutilgan.
- MapLibre attribution control yoqilgan.
- iOS native MapView yo'li saqlandi.
- Muhim cheklov: OpenFreeMap public instance SLA/uptime kafolati bermaydi; xarita uchun internet zarur. Haqiqiy Android qurilmada 403 yo'qligi va render ishlashi hali tekshirilmagan.

### Chat media

- Chatdagi biriktirish menyusiga rasm/video hamda audio/hujjat tanlash yo'llari qo'shildi.
- `expo-document-picker ~58.0.4` qo'shildi; Expo SDK 58 bilan mosligi rasmiy Expo SDK bundled module ro'yxatiga tayangan.
- Backend MIME allowlist kengaytirildi: audio (MP3/M4A/AAC/WAV/OGG/AMR/WebM), PDF, DOC/DOCX, XLS/XLSX, PPT/PPTX, TXT va CSV.
- MIME bo'yicha `image`/`video`/`audio`/`file` klassifikatsiyasi alohida modulga ajratildi.
- Yuklash limiti 50 MB/fayl va 10 fayl/so'rov bo'lib qoldi; nomaqbul MIME 415, hajm limiti 413 qaytaradi.
- Audio/hujjat chatda fayl havolasi sifatida ochiladi; audio ilova ichida player sifatida ijro etilmaydi.

### Konfiguratsiya

- `backend/.env.example` va `mobile/.env.example` qo'shildi.
- `USTATOP_FREE_DEMO_DEPLOYMENT.md` bepul demo infratuzilmasi va qolgan bloklovchi ma'lumotlarni hujjatlashtiradi.
- Production APK uchun `EXPO_PUBLIC_API_URL` tashqi HTTPS backend URL bilan berilishi kerak.

## 3. Test natijalari

| Tekshiruv | Natija |
|---|---|
| 41 ta mobil JS/JSX fayl parser tekshiruvi | PASS — 0 sintaksis xatosi |
| Backend `src` va `tests` JavaScript `node --check` | PASS |
| Media MIME allowlist Node testlari | PASS — 3/3 |
| MapLibre HTML ichki JavaScript parser tekshiruvi | PASS |
| `mobile/package.json`, `mobile/package-lock.json`, `backend/package.json` JSON parse | PASS |
| Mobile package.json / lock root dependency versiyalari | PASS |

## 4. Bajarilmagan / tasdiqlanmagan

- `npm ci` va Expo bundling: bajarilmadi. npm registry DNS so'rovi `EAI_AGAIN` bilan tugadi; mobile `node_modules` mavjud emas.
- To'liq Jest backend suite: bajarilmadi. Ushbu ish muhitida backend `node_modules` to'liq emas (masalan, `multer` va Jest executable mavjud emas).
- PostgreSQL migratsiya va integration: bajarilmadi; ishga tushgan DB yo'q.
- Android SDK/ADB: `ANDROID_HOME` va `ANDROID_SDK_ROOT` o'rnatilmagan, `adb`/`sdkmanager` yo'q.
- EAS build/APK: bajarilmadi; EAS project ID placeholder, EAS hisob/project mavjudligi tasdiqlanmagan.
- Real Android qurilma: xarita, chat attachment, keyboard, GPS, login, order lifecycle end-to-end sinovi bajarilmadi.
- Tashqi HTTPS backend, DB, SMS credentials, MyID integratsiyasi va persistent media storage yo'q.

## 5. Xavfsizlik va demo cheklovlari

- Hozirgi backend media adapteri local diskka saqlaydi va `/uploads` statik public yo'l orqali fayllarni beradi. Demak, chat fayl URL manzilini bilgan kishi faylni autentifikatsiyasiz ochishi mumkin. Hozircha faqat soxta/demo ma'lumotlardan foydalanish kerak; maxfiy hujjatlarni yubormang. Production oldidan private object storage va qisqa muddatli signed URL/access control talab qilinadi.
- `SMS_PROVIDER=console` faqat development uchun; production validator uni rad etadi. Haqiqiy SMS provayder ma'lumotlari yo'q.
- MyID haqiqiy identity verification integratsiyasi hali yo'q; mavjud flag gate haqiqiy shaxsni tekshirish o'rnini bosmaydi.
- Bepul xarita provayderi API key talab qilmaydi, lekin bu backend/DB/media/SMS infratuzilmasini avtomatik bepul yoki tayyor qilib bermaydi.

## 6. Keyingi bloklovchi qadamlar

1. `npm ci` bajariladigan internetli build muhitida dependency/lockfile reconciliation va `expo-doctor`.
2. Backend uchun HTTPS hosting, PostgreSQL va production secretlar.
3. Chat fayllari uchun private persistent object storage va signed URL/access control.
4. SMS provider test credentials; MyID test credentials va callback/API hujjatlari.
5. Android SDK yoki EAS project bilan APK build.
6. Real Android qurilmada mijoz/usta asosiy oqimlari, xarita, chat media, klaviatura va order/payment business rules end-to-end testi.

## 7. Yakuniy status

Ushbu arxiv — internet-demo uchun keyingi ishlab chiqish nusxasi. Xarita va chat media kod yo'llari qo'shildi, lekin Android APK build qilinmagan va real qurilmada tasdiqlanmagan. Uni hozircha tashkilotga tayyor demo deb e'lon qilish mumkin emas.
