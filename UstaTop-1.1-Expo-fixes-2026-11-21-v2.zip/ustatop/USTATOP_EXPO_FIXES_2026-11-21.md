# UstaTop — yangi Expo tuzatishlari (2026-11-21)

Bu arxiv oldingi `android-demo-fixes` arxividan keyingi tuzatishlarni o'z ichiga oladi.

## Muhim: aynan shu papkadan ishga tushiring
1. Arxivni yangi, alohida papkaga chiqaring (oldingi loyiha papkasining ustiga yozmang).
2. Shu yangi papkadagi `RUN_USTATOP.bat` faylini ishga tushiring.
3. Terminalda chiqqan QR kodni Expo Go bilan skanerlang.
4. Expo Go avvalgi loyiha keshini ochsa, ilovani yoping va yangi terminaldagi QR kodni qayta skanerlang. Terminalni `mobile` papkasi ichidan emas, arxiv ildizidagi BAT fayli orqali ishga tushiring.

## Tuzatilganlar
- Kategoriyalar bo'limi faqat `provider` va `both` rollariga ko'rsatiladi; `client` rolida yashiriladi.
- Usta profilida va profil menyusida alohida sharhlar ekraniga kirish bor.
- Chat sarlavhasi, xabarlar maydoni va yozuv paneli qayta dizayn qilindi.
- Android xarita uchun CDN zaxira manbasi va xatolarni boshqarish yaxshilandi.

## Sinov holati
JS/JSX parser tekshiruvlari va xarita ichki JavaScript sintaksisi o'tdi. Ushbu arxivni Expo Go'da real telefonda qayta ishga tushirib tekshirish hali talab qilinadi; APK yig'ilmagan.
