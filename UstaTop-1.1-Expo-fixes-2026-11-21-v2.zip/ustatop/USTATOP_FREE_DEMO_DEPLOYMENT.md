# UstaTop — bepul internet-demo infratuzilmasi

## Tanlangan yo'l

- Android xarita: MapLibre GL JS + OpenFreeMap Liberty style (`https://tiles.openfreemap.org/styles/liberty`). API key va ro'yxatdan o'tish talab qilinmaydi. OpenFreeMap public serveri bepul, lekin SLA/uptime kafolati yo'q; ishlab chiqarish yuklamasidan oldin foydalanish shartlarini qayta tekshirish kerak.
- Xarita faqat Android'da WebView ichida chiziladi; iOS mavjud native MapView yo'lida qoladi.
- Chat media: mavjud local storage adapteri saqlanadi; backend rasm/video bilan birga audio va keng tarqalgan hujjat MIME turlarini qabul qiladi.
- API URL: APK build vaqtida `EXPO_PUBLIC_API_URL` orqali HTTPS backend URL beriladi.

## Hozircha to'xtab turgan deployment ishlari

1. Tashqi HTTPS backend domeni va hosting hisobi yo'q.
2. PostgreSQL server/connection string yo'q.
3. Production SMS provayder credentials yo'q. `SMS_PROVIDER=console` faqat lokal development uchun; production config validator buni rad etadi.
4. Hostingning doimiy disk yoki object storage xizmati tanlanmagan. Hozirgi `MEDIA_STORAGE_DRIVER=local` serverning local fayl tizimiga yozadi; ephemeral/free serverda qayta ishga tushganda media yo'qolishi mumkin.
5. Haqiqiy MyID credentials/integratsiya yo'q.

Shu sabab hozir internetga ochiq backendni yoki production APK'ni taxminiy URL/soxta credential bilan yaratish mumkin emas. Keyingi deployment bosqichida bepul Postgres va persistent object storage imkoniyatlari tanlanib, ularning real free-tier cheklovlari tekshiriladi. Tashkilotga demo berishdan oldin SMS va shaxsni tasdiqlash talablari alohida hal qilinadi.

## Ishga tushirish uchun konfiguratsiya

- Backend: `backend/.env.example` ni `.env` ga nusxalab, real PostgreSQL va alohida 32+ belgili JWT secretlar bilan to'ldirish.
- Mobil: `mobile/.env.example` dagi `EXPO_PUBLIC_API_URL` ni tashqi HTTPS backend manziliga almashtirish.
- APK: EAS project ID yoki Android SDK/ADB mavjud build muhiti talab qilinadi.

## Xarita provayderi eslatmasi

OpenFreeMap public instance bepul va API key talab qilmaydi. Biroq public instance uchun SLA berilmaydi; muhim ishlab chiqarish tizimida provider uzilishi ehtimoli va fallback rejasi bo'lishi kerak. MapLibre attribution control xarita litsenziya ma'lumotini ko'rsatadi.
