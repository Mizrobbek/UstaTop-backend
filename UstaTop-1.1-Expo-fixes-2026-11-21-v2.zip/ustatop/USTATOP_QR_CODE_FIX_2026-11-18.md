# UstaTop QR-kod hotfix — 2026-11-18

`RUN_USTATOP.bat` faylida Expo ishga tushishidan oldin `CI=1` o'rnatilishi olib tashlandi (`CI` tozalandi). `CI=true` Metro'ni CI rejimiga o'tkazib, interaktiv terminal va QR-kod ko'rsatishni cheklayotgan edi.

Expo login talab qilinmaydi; `--go` parametri Expo Go rejimini saqlaydi. Expo terminali interaktiv holatda QR-kodni ko'rsatishi kerak.

Tekshiruv: skript matnidagi CI o'zgarishi tekshirildi; ZIP yaxlitligi alohida tekshirilsin. Haqiqiy Windows/Android ishga tushirish ushbu muhitda bajarilmadi.
