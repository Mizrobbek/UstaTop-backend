/* UstaTop admin paneli.
 *
 * Xavfsizlik: foydalanuvchilar kiritgan barcha matnlar (ism, e'lon sarlavhasi va h.k.)
 * DOM'ga FAQAT textContent orqali qo'yiladi (h() yordamchisi shuni ta'minlaydi) —
 * innerHTML faqat qat'iy statik logotip uchun ishlatiladi. Server tomonda Helmet CSP
 * inline skriptlarga ruxsat bermaydi, shuning uchun hodisalar addEventListener orqali ulanadi.
 */
(function () {
  'use strict';

  var API = '/api';
  var PAGE_SIZE = 15;

  var LABELS = {
    role: { client: 'Mijoz', provider: 'Usta', both: 'Mijoz + Usta', admin: 'Admin' },
    listing: { open: 'Ochiq', in_progress: 'Jarayonda', completed: 'Yakunlangan', cancelled: 'Bekor qilingan' },
    order: { confirmed: 'Tasdiqlangan', in_progress: 'Jarayonda', completed: 'Yakunlangan', cancelled: 'Bekor qilingan' },
  };
  var BADGE = { open: 'b-green', in_progress: 'b-yellow', completed: 'b-blue', cancelled: 'b-red', confirmed: 'b-teal' };

  var LOGO_SVG =
    '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#14B8A6"/><stop offset="1" stop-color="#0B4F49"/></linearGradient>' +
    '<linearGradient id="pin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#FFE8D6"/></linearGradient></defs>' +
    '<rect width="100" height="100" rx="24" fill="url(#bg)"/>' +
    '<path d="M50 18C36 18 25 29 25 43c0 19 25 39 25 39s25-20 25-39C75 29 64 18 50 18z" fill="url(#pin)"/>' +
    '<rect x="34" y="41.5" width="32" height="6" rx="3" fill="#FF7A30" transform="rotate(45 50 44.5)"/>' +
    '<rect x="34" y="41.5" width="32" height="6" rx="3" fill="#0B4F49" transform="rotate(-45 50 44.5)"/>' +
    '<circle cx="38" cy="33" r="5.5" fill="#FF7A30"/><circle cx="38" cy="33" r="2.2" fill="#fff"/>' +
    '<circle cx="62" cy="33" r="5.5" fill="#0B4F49"/><circle cx="62" cy="33" r="2.2" fill="#fff"/></svg>';

  var S = {
    access: sessionStorage.getItem('ut_access'),
    refresh: sessionStorage.getItem('ut_refresh'),
    user: parseJson(sessionStorage.getItem('ut_user')),
    tab: 'dashboard',
  };

  var root = document.getElementById('app');
  var toastEl = document.getElementById('toast');
  var toastTimer = null;

  /* ---------------- Yordamchilar ---------------- */

  function parseJson(text) {
    try { return text ? JSON.parse(text) : null; } catch (e) { return null; }
  }

  /** Xavfsiz DOM yaratuvchi: matnlar har doim textNode sifatida qo'shiladi. */
  function h(tag, attrs) {
    var el = document.createElement(tag);
    var rest = Array.prototype.slice.call(arguments, 2);
    Object.keys(attrs || {}).forEach(function (k) {
      var v = attrs[k];
      if (v === false || v === null || v === undefined) return;
      if (k === 'class') el.className = v;
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    });
    flatten(rest).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      el.appendChild(c && c.nodeType ? c : document.createTextNode(String(c)));
    });
    return el;
  }

  function flatten(arr) {
    return arr.reduce(function (acc, x) { return acc.concat(Array.isArray(x) ? flatten(x) : [x]); }, []);
  }

  function svgLogo() {
    var wrap = document.createElement('span');
    wrap.innerHTML = LOGO_SVG; // qat'iy statik matn, foydalanuvchi ma'lumoti emas
    return wrap.firstChild;
  }

  function fmtDate(d) {
    if (!d) return '—';
    return new Date(d).toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' });
  }
  function fmtNum(n) { return Number(n || 0).toLocaleString('ru-RU'); }

  function qs(obj) {
    var parts = [];
    Object.keys(obj).forEach(function (k) {
      if (obj[k] !== '' && obj[k] !== null && obj[k] !== undefined) {
        parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(obj[k]));
      }
    });
    return parts.length ? '?' + parts.join('&') : '';
  }

  function toast(message, isError) {
    toastEl.textContent = message;
    toastEl.className = 'toast' + (isError ? ' error' : '');
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.hidden = true; }, 3800);
  }

  function badge(text, cls) { return h('span', { class: 'badge ' + (cls || 'b-gray') }, text); }

  /* ---------------- API ---------------- */

  function saveSession(data) {
    S.access = data.accessToken;
    S.refresh = data.refreshToken;
    sessionStorage.setItem('ut_access', S.access);
    sessionStorage.setItem('ut_refresh', S.refresh);
  }

  function clearSession() {
    S.access = S.refresh = S.user = null;
    sessionStorage.removeItem('ut_access');
    sessionStorage.removeItem('ut_refresh');
    sessionStorage.removeItem('ut_user');
  }

  function refreshTokens() {
    if (!S.refresh) return Promise.resolve(false);
    return fetch(API + '/auth/refresh', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken: S.refresh }),
    })
      .then(function (res) { return res.ok ? res.json() : null; })
      .then(function (data) {
        if (!data) return false;
        saveSession(data);
        return true;
      })
      .catch(function () { return false; });
  }

  function api(path, opts, retried) {
    opts = opts || {};
    var headers = { 'Content-Type': 'application/json' };
    if (S.access) headers.Authorization = 'Bearer ' + S.access;

    return fetch(API + path, {
      method: opts.method || 'GET',
      headers: headers,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    }).then(function (res) {
      return res.json().catch(function () { return null; }).then(function (data) {
        if (res.status === 401 && path.indexOf('/auth/') !== 0) {
          if (data && data.code === 'TOKEN_EXPIRED' && !retried) {
            return refreshTokens().then(function (ok) {
              if (ok) return api(path, opts, true);
              forceLogout();
              throw new Error('Sessiya tugadi, qayta kiring');
            });
          }
          forceLogout();
          throw new Error('Sessiya tugadi, qayta kiring');
        }
        if (!res.ok) {
          var msg = (data && (data.error || (data.details && data.details[0]))) || 'Xatolik (' + res.status + ')';
          var err = new Error(msg);
          err.status = res.status;
          throw err;
        }
        return data;
      });
    });
  }

  function forceLogout() {
    clearSession();
    render();
  }

  function logout() {
    var token = S.refresh;
    var done = function () { clearSession(); render(); };
    if (!token) return done();
    fetch(API + '/auth/logout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken: token }),
    }).then(done, done);
  }

  /* ---------------- Kirish ---------------- */

  function renderLogin() {
    var errorBox = h('div', { class: 'error-box', hidden: true });
    var idInput = h('input', { class: 'input', type: 'text', autocomplete: 'username', placeholder: '+998 90 123 45 67', required: true });
    var passInput = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', placeholder: 'Parol', required: true });
    var toggle = h('button', { type: 'button', class: 'toggle-pass', 'aria-label': 'Parolni ko\'rsatish yoki yashirish' }, 'Ko\'rsatish');
    var submit = h('button', { type: 'submit', class: 'btn btn-primary btn-lg' }, 'Kirish');

    toggle.addEventListener('click', function () {
      var show = passInput.type === 'password';
      passInput.type = show ? 'text' : 'password';
      toggle.textContent = show ? 'Yashirish' : 'Ko\'rsatish';
    });

    function showError(msg) {
      errorBox.textContent = msg;
      errorBox.hidden = false;
    }

    var form = h('form', { novalidate: true },
      errorBox,
      h('div', { class: 'field' }, h('label', {}, 'Telefon yoki email'), idInput),
      h('div', { class: 'field' }, h('label', {}, 'Parol'), h('div', { class: 'input-row' }, passInput, toggle)),
      submit
    );

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      errorBox.hidden = true;
      var identifier = idInput.value.trim().replace(/\s+/g, '');
      if (!identifier || !passInput.value) return showError('Telefon/email va parolni kiriting');

      submit.disabled = true;
      submit.textContent = 'Kirilmoqda…';
      api('/auth/login', { method: 'POST', body: { identifier: identifier, password: passInput.value } })
        .then(function (data) {
          if (data.user.role !== 'admin') {
            // Admin bo'lmagan hisob uchun berilgan sessiyani darhol bekor qilamiz
            fetch(API + '/auth/logout', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ refreshToken: data.refreshToken }),
            });
            throw new Error('Bu panel faqat administratorlar uchun');
          }
          saveSession(data);
          S.user = data.user;
          sessionStorage.setItem('ut_user', JSON.stringify(data.user));
          S.tab = 'dashboard';
          render();
        })
        .catch(function (err) {
          showError(err.message);
          submit.disabled = false;
          submit.textContent = 'Kirish';
        });
    });

    return h('div', { class: 'login-wrap' },
      h('div', { class: 'login-card' },
        h('div', { class: 'login-brand' },
          svgLogo(),
          h('div', { class: 'brand-name' }, 'Usta', h('span', {}, 'Top')),
          h('div', { class: 'brand-sub' }, 'Administrator paneli')
        ),
        form
      )
    );
  }

  /* ---------------- Umumiy qobiq ---------------- */

  var TABS = [
    ['dashboard', 'Bosh panel'],
    ['users', 'Foydalanuvchilar'],
    ['listings', 'E\'lonlar'],
    ['categories', 'Kategoriyalar'],
    ['commission', 'Komissiya'],
  ];

  function renderShell() {
    var content = h('main', { class: 'content' });

    var tabs = h('nav', { class: 'tabs' }, TABS.map(function (t) {
      return h('button', {
        class: 'tab' + (S.tab === t[0] ? ' active' : ''),
        type: 'button',
        onclick: function () { S.tab = t[0]; render(); },
      }, t[1]);
    }));

    var shell = h('div', {},
      h('header', { class: 'topbar' },
        h('div', { class: 'topbar-brand' }, svgLogo(), h('span', {}, 'Usta', h('span', {}, 'Top'))),
        h('div', { class: 'topbar-user' },
          h('span', {}, S.user.fullName),
          h('button', { class: 'btn btn-sm', type: 'button', onclick: logout }, 'Chiqish')
        )
      ),
      tabs,
      content
    );

    content.appendChild(h('div', { class: 'loading' }, 'Yuklanmoqda…'));
    var views = { dashboard: viewDashboard, users: viewUsers, listings: viewListings, categories: viewCategories, commission: viewCommission };
    var tabAtStart = S.tab;
    views[S.tab](content, function () { return S.tab === tabAtStart; });
    return shell;
  }

  function setContent(container, nodes) {
    container.textContent = '';
    flatten([nodes]).forEach(function (n) { if (n) container.appendChild(n); });
  }

  function showViewError(container, err) {
    setContent(container, h('div', { class: 'card empty' }, 'Yuklab bo\'lmadi: ' + err.message));
  }

  /* ---------------- Bosh panel ---------------- */

  function statCard(label, value, sub, cls) {
    return h('div', { class: 'card' },
      h('div', { class: 'stat-label' }, label),
      h('div', { class: 'stat-value ' + (cls || '') }, value),
      sub ? h('div', { class: 'stat-sub' }, sub) : null
    );
  }

  function barList(title, map, labels) {
    var keys = Object.keys(map);
    var max = keys.reduce(function (m, k) { return Math.max(m, map[k]); }, 1);
    return h('div', { class: 'card' },
      h('h3', {}, title),
      keys.length ? keys.map(function (k) {
        return h('div', { class: 'bar-row' },
          h('span', {}, labels[k] || k),
          h('div', { class: 'bar-track' }, h('div', { class: 'bar-fill', style: 'width:' + Math.round((map[k] / max) * 100) + '%' })),
          h('strong', {}, map[k])
        );
      }) : h('div', { class: 'muted' }, 'Ma\'lumot yo\'q')
    );
  }

  function viewDashboard(container, isCurrent) {
    api('/admin/stats').then(function (data) {
      if (!isCurrent()) return;
      var s = data.stats;
      var providers = (s.users.byRole.provider || 0) + (s.users.byRole.both || 0);
      setContent(container, [
        h('h2', { class: 'page-title' }, 'Bosh panel'),
        h('div', { class: 'cards' },
          statCard('Foydalanuvchilar', fmtNum(s.users.total), 'shundan ustalar: ' + fmtNum(providers)),
          statCard('E\'lonlar', fmtNum(s.listings.total), 'ochiq: ' + fmtNum(s.listings.byStatus.open || 0)),
          statCard('Buyurtmalar', fmtNum(s.orders.total), 'yakunlangan: ' + fmtNum(s.orders.byStatus.completed || 0)),
          statCard('Sharhlar', fmtNum(s.reviews.total)),
          statCard('Yakunlangan buyurtmalar summasi', fmtNum(s.orders.completedVolume) + ' so\'m', null, 'money')
        ),
        h('div', { class: 'two-col' },
          barList('E\'lonlar holati bo\'yicha', s.listings.byStatus, LABELS.listing),
          barList('Buyurtmalar holati bo\'yicha', s.orders.byStatus, LABELS.order),
          barList('Foydalanuvchilar rollari', s.users.byRole, LABELS.role)
        ),
      ]);
    }).catch(function (err) { if (isCurrent()) showViewError(container, err); });
  }

  /* ---------------- Sahifalash ---------------- */

  function pager(p, onPage) {
    return h('div', { class: 'pager' },
      h('span', {}, 'Jami: ' + fmtNum(p.total)),
      h('button', { class: 'btn btn-outline btn-sm', type: 'button', disabled: p.page <= 1, onclick: function () { onPage(p.page - 1); } }, '‹ Oldingi'),
      h('span', {}, p.page + ' / ' + p.totalPages),
      h('button', { class: 'btn btn-outline btn-sm', type: 'button', disabled: p.page >= p.totalPages, onclick: function () { onPage(p.page + 1); } }, 'Keyingi ›')
    );
  }

  function tableOf(headers, rows, emptyText) {
    if (!rows.length) return h('div', { class: 'card empty' }, emptyText);
    return h('div', { class: 'table-wrap' },
      h('table', {},
        h('thead', {}, h('tr', {}, headers.map(function (t) { return h('th', {}, t); }))),
        h('tbody', {}, rows)
      )
    );
  }

  /* ---------------- Foydalanuvchilar ---------------- */

  function viewUsers(container, isCurrent) {
    var f = { search: '', role: '', page: 1 };

    var searchInput = h('input', { class: 'input', type: 'search', placeholder: 'Ism, telefon yoki email…' });
    var roleSelect = h('select', { class: 'select' },
      h('option', { value: '' }, 'Barcha rollar'),
      Object.keys(LABELS.role).map(function (k) { return h('option', { value: k }, LABELS.role[k]); })
    );
    var results = h('div', {}, h('div', { class: 'loading' }, 'Yuklanmoqda…'));

    function apply() { f.search = searchInput.value.trim(); f.role = roleSelect.value; f.page = 1; load(); }
    searchInput.addEventListener('keydown', function (e) { if (e.key === 'Enter') apply(); });
    roleSelect.addEventListener('change', apply);

    setContent(container, [
      h('h2', { class: 'page-title' }, 'Foydalanuvchilar'),
      h('div', { class: 'toolbar' }, searchInput, roleSelect, h('button', { class: 'btn btn-outline', type: 'button', onclick: apply }, 'Qidirish')),
      results,
    ]);

    function act(promise, okMsg) {
      promise.then(function () { toast(okMsg); load(); }).catch(function (err) { toast(err.message, true); });
    }

    function load() {
      api('/admin/users' + qs({ search: f.search, role: f.role, page: f.page, limit: PAGE_SIZE })).then(function (data) {
        if (!isCurrent()) return;
        var rows = data.users.map(function (u) {
          var isSelf = S.user && u.id === S.user.id;
          var canModerate = u.role !== 'admin' && !isSelf;
          var isProvider = u.role === 'provider' || u.role === 'both';
          return h('tr', {},
            h('td', {}, u.fullName, h('span', { class: 'sub' }, u.email || '—')),
            h('td', {}, u.phone),
            h('td', {}, badge(LABELS.role[u.role] || u.role, u.role === 'admin' ? 'b-teal' : 'b-gray'),
              isProvider && u.providerVerified ? [' ', badge('Tasdiqlangan', 'b-green')] : null),
            h('td', {}, u.isActive ? badge('Faol', 'b-green') : badge('Bloklangan', 'b-red')),
            h('td', { class: 'muted' }, fmtDate(u.createdAt)),
            h('td', { class: 'actions' },
              canModerate ? h('button', {
                class: 'btn btn-sm ' + (u.isActive ? 'btn-danger' : 'btn-success'),
                type: 'button',
                onclick: function () {
                  if (u.isActive && !window.confirm(u.fullName + ' bloklansinmi? U tizimdan darhol chiqib ketadi.')) return;
                  act(api('/admin/users/' + u.id + '/active', { method: 'PATCH', body: { isActive: !u.isActive } }),
                    u.isActive ? 'Foydalanuvchi bloklandi' : 'Foydalanuvchi blokdan chiqarildi');
                },
              }, u.isActive ? 'Bloklash' : 'Blokdan chiqarish') : null,
              isProvider ? h('button', {
                class: 'btn btn-outline btn-sm',
                type: 'button',
                onclick: function () {
                  act(api('/admin/providers/' + u.id + '/verify', { method: 'PATCH', body: { isVerified: !u.providerVerified } }),
                    u.providerVerified ? 'Tasdiq olib tashlandi' : 'Usta tasdiqlandi');
                },
              }, u.providerVerified ? 'Tasdiqni olib tashlash' : 'Tasdiqlash') : null
            )
          );
        });
        setContent(results, [
          tableOf(['Ism', 'Telefon', 'Rol', 'Holat', 'Ro\'yxatdan o\'tgan', 'Amallar'], rows, 'Foydalanuvchilar topilmadi'),
          pager(data.pagination, function (p) { f.page = p; load(); }),
        ]);
      }).catch(function (err) { if (isCurrent()) showViewError(results, err); });
    }
    load();
  }

  /* ---------------- E'lonlar ---------------- */

  function viewListings(container, isCurrent) {
    var f = { search: '', status: '', page: 1 };

    var searchInput = h('input', { class: 'input', type: 'search', placeholder: 'Sarlavha bo\'yicha qidirish…' });
    var statusSelect = h('select', { class: 'select' },
      h('option', { value: '' }, 'Barcha holatlar'),
      Object.keys(LABELS.listing).map(function (k) { return h('option', { value: k }, LABELS.listing[k]); })
    );
    var results = h('div', {}, h('div', { class: 'loading' }, 'Yuklanmoqda…'));

    function apply() { f.search = searchInput.value.trim(); f.status = statusSelect.value; f.page = 1; load(); }
    searchInput.addEventListener('keydown', function (e) { if (e.key === 'Enter') apply(); });
    statusSelect.addEventListener('change', apply);

    setContent(container, [
      h('h2', { class: 'page-title' }, 'E\'lonlar moderatsiyasi'),
      h('div', { class: 'toolbar' }, searchInput, statusSelect, h('button', { class: 'btn btn-outline', type: 'button', onclick: apply }, 'Qidirish')),
      results,
    ]);

    function load() {
      api('/admin/listings' + qs({ search: f.search, status: f.status, page: f.page, limit: PAGE_SIZE })).then(function (data) {
        if (!isCurrent()) return;
        var rows = data.listings.map(function (l) {
          return h('tr', {},
            h('td', {}, l.title, h('span', { class: 'sub' }, l.categoryName + ' · ' + l.city)),
            h('td', {}, l.clientName),
            h('td', {}, l.price === null ? h('span', { class: 'muted' }, 'Kelishiladi') : fmtNum(l.price) + ' so\'m'),
            h('td', {}, badge(LABELS.listing[l.status] || l.status, BADGE[l.status])),
            h('td', {}, fmtNum(l.viewsCount)),
            h('td', { class: 'muted' }, fmtDate(l.createdAt)),
            h('td', { class: 'actions' },
              l.status === 'open' ? h('button', {
                class: 'btn btn-danger btn-sm',
                type: 'button',
                onclick: function () {
                  if (!window.confirm('"' + l.title + '" e\'loni bekor qilinsinmi? Egasiga xabar yuboriladi.')) return;
                  api('/admin/listings/' + l.id + '/cancel', { method: 'PATCH' })
                    .then(function () { toast('E\'lon bekor qilindi'); load(); })
                    .catch(function (err) { toast(err.message, true); });
                },
              }, 'Bekor qilish') : null
            )
          );
        });
        setContent(results, [
          tableOf(['E\'lon', 'Egasi', 'Narx', 'Holat', 'Ko\'rishlar', 'Sana', 'Amallar'], rows, 'E\'lonlar topilmadi'),
          pager(data.pagination, function (p) { f.page = p; load(); }),
        ]);
      }).catch(function (err) { if (isCurrent()) showViewError(results, err); });
    }
    load();
  }

  /* ---------------- Kategoriyalar ---------------- */

  function viewCategories(container, isCurrent) {
    var editingId = null;
    var list = h('div', {}, h('div', { class: 'loading' }, 'Yuklanmoqda…'));

    var fUz = h('input', { class: 'input', type: 'text', placeholder: 'Santexnik', maxlength: '100' });
    var fRu = h('input', { class: 'input', type: 'text', placeholder: 'Сантехник', maxlength: '100' });
    var fIcon = h('input', { class: 'input', type: 'text', placeholder: 'plumbing', maxlength: '60' });
    var fSort = h('input', { class: 'input', type: 'number', min: '0', max: '9999', value: '0' });
    var addBtn = h('button', { class: 'btn btn-primary', type: 'button' }, 'Qo\'shish');

    addBtn.addEventListener('click', function () {
      if (fUz.value.trim().length < 2) return toast('Nom kamida 2 ta belgidan iborat bo\'lishi kerak', true);
      addBtn.disabled = true;
      api('/admin/categories', {
        method: 'POST',
        body: { nameUz: fUz.value.trim(), nameRu: fRu.value.trim(), icon: fIcon.value.trim(), sortOrder: Number(fSort.value) || 0 },
      }).then(function () {
        toast('Kategoriya qo\'shildi');
        fUz.value = fRu.value = fIcon.value = '';
        fSort.value = '0';
        load();
      }).catch(function (err) { toast(err.message, true); })
        .then(function () { addBtn.disabled = false; });
    });

    setContent(container, [
      h('h2', { class: 'page-title' }, 'Kategoriyalar'),
      h('div', { class: 'card form-card' },
        h('div', { class: 'form-grid' },
          h('div', { class: 'field' }, h('label', {}, 'Nomi (o\'zbekcha)'), fUz),
          h('div', { class: 'field' }, h('label', {}, 'Nomi (ruscha)'), fRu),
          h('div', { class: 'field' }, h('label', {}, 'Ikonka kodi'), fIcon),
          h('div', { class: 'field' }, h('label', {}, 'Tartib raqami'), fSort),
          addBtn
        )
      ),
      list,
    ]);

    function save(c, inputs) {
      api('/admin/categories/' + c.id, {
        method: 'PATCH',
        body: {
          nameUz: inputs.uz.value.trim(),
          nameRu: inputs.ru.value.trim(),
          icon: inputs.icon.value.trim(),
          sortOrder: Number(inputs.sort.value) || 0,
        },
      }).then(function () { editingId = null; toast('Saqlandi'); load(); })
        .catch(function (err) { toast(err.message, true); });
    }

    function toggleActive(c) {
      api('/admin/categories/' + c.id, { method: 'PATCH', body: { isActive: !c.isActive } })
        .then(function () { toast(c.isActive ? 'Kategoriya yashirildi' : 'Kategoriya faollashtirildi'); load(); })
        .catch(function (err) { toast(err.message, true); });
    }

    function load() {
      api('/admin/categories').then(function (data) {
        if (!isCurrent()) return;
        var rows = data.categories.map(function (c) {
          if (editingId === c.id) {
            var inputs = {
              uz: h('input', { class: 'input', type: 'text', value: c.nameUz || '' }),
              ru: h('input', { class: 'input', type: 'text', value: c.nameRu || '' }),
              icon: h('input', { class: 'input', type: 'text', value: c.icon || '' }),
              sort: h('input', { class: 'input', type: 'number', value: String(c.sortOrder), style: 'max-width:90px' }),
            };
            return h('tr', {},
              h('td', {}, String(c.id)),
              h('td', {}, inputs.uz), h('td', {}, inputs.ru), h('td', {}, inputs.icon), h('td', {}, inputs.sort),
              h('td', {}, c.isActive ? badge('Faol', 'b-green') : badge('Yashirin', 'b-gray')),
              h('td', { class: 'actions' },
                h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: function () { save(c, inputs); } }, 'Saqlash'),
                h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: function () { editingId = null; load(); } }, 'Bekor')
              )
            );
          }
          return h('tr', {},
            h('td', { class: 'muted' }, String(c.id)),
            h('td', {}, c.nameUz),
            h('td', {}, c.nameRu || h('span', { class: 'muted' }, '—')),
            h('td', {}, c.icon || h('span', { class: 'muted' }, '—')),
            h('td', {}, String(c.sortOrder)),
            h('td', {}, c.isActive ? badge('Faol', 'b-green') : badge('Yashirin', 'b-gray')),
            h('td', { class: 'actions' },
              h('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: function () { editingId = c.id; load(); } }, 'Tahrirlash'),
              h('button', { class: 'btn btn-sm ' + (c.isActive ? 'btn-danger' : 'btn-success'), type: 'button', onclick: function () { toggleActive(c); } },
                c.isActive ? 'Yashirish' : 'Faollashtirish')
            )
          );
        });
        setContent(list, tableOf(['ID', 'Nomi (uz)', 'Nomi (ru)', 'Ikonka', 'Tartib', 'Holat', 'Amallar'], rows, 'Kategoriyalar yo\'q'));
      }).catch(function (err) { if (isCurrent()) showViewError(list, err); });
    }
    load();
  }

  function viewCommission(container, isCurrent) {
    Promise.all([api('/admin/commission/tariffs'), api('/admin/categories'), api('/admin/commission/history')]).then(function (all) {
      if (!isCurrent()) return;
      var data = all[0];
      var scopes = [{ id: 0, nameUz: 'Umumiy tarif' }].concat(all[1].categories);
      var rows = scopes.map(function (c) {
        var current = data.tariffs.find(function (t) { return t.scope_key === c.id; });
        var input = h('input', { class: 'input', type: 'number', min: '0', max: '100', step: '0.01', value: current && current.rate !== null ? current.rate : '', 'aria-label': c.nameUz + ' foiz' });
        var save = h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: function () {
          save.disabled = true;
          api('/admin/commission/tariffs/' + (c.id || 'global'), { method: 'PATCH', body: { rate: input.value === '' ? null : Number(input.value) } })
            .then(function () { toast('Saqlandi'); viewCommission(container, isCurrent); })
            .catch(function (err) { toast(err.message, true); save.disabled = false; });
        } }, 'Saqlash');
        return h('tr', {}, h('td', {}, c.nameUz), h('td', {}, input), h('td', {}, current && current.rate !== null ? current.rate + '%' : 'Umumiy tarif'), h('td', {}, save));
      });
      setContent(container, [h('h2', { class: 'page-title' }, 'Komissiya tariflari'),
        tableOf(['Kategoriya', 'Foiz', 'Amaldagi tarif', 'Amal'], rows, 'Tariflar yo‘q'),
        h('h3', {}, 'Komissiyalar'), tableOf(['Usta', 'Buyurtma', 'Foiz', 'Summa', 'Qarz', 'Holat'], all[2].commissions.map(function (c) {
          return h('tr', {}, h('td', {}, c.providerName), h('td', {}, c.orderId), h('td', {}, c.rate + '%'), h('td', {}, fmtNum(c.amount)), h('td', {}, fmtNum(c.balance)), h('td', {}, c.status));
        }), 'Komissiyalar yo‘q'),
        h('h3', {}, 'Tarif o‘zgarishlari'), tableOf(['Kim', 'Qachon', 'Kategoriya', 'Oldingi %', 'Yangi %'], data.audit.map(function (a) {
          return h('tr', {}, h('td', {}, a.actor_name), h('td', {}, fmtDate(a.created_at)), h('td', {}, a.scope_key || 'Umumiy'), h('td', {}, a.old_rate === null ? 'Umumiy tarif' : a.old_rate), h('td', {}, a.new_rate === null ? 'Umumiy tarif' : a.new_rate));
        }), 'O‘zgarishlar yo‘q')]);
    }).catch(function (err) { if (isCurrent()) showViewError(container, err); });
  }

  /* ---------------- Ishga tushirish ---------------- */

  function render() {
    root.textContent = '';
    root.appendChild(S.user && S.access ? renderShell() : renderLogin());
  }

  render();
})();
