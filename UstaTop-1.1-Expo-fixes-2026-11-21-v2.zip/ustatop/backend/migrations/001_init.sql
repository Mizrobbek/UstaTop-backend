-- ============================================================
-- Ish/Usta topish platformasi — asosiy baza sxemasi (PostgreSQL)
-- O'zbekiston bozori uchun mo'ljallangan
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- ---------- ENUM turlari ----------
CREATE TYPE user_role AS ENUM ('client', 'provider', 'both', 'admin');
CREATE TYPE listing_status AS ENUM ('open', 'in_progress', 'completed', 'cancelled');
CREATE TYPE price_type AS ENUM ('fixed', 'negotiable');
CREATE TYPE offer_status AS ENUM ('pending', 'accepted', 'rejected', 'withdrawn');
CREATE TYPE order_status AS ENUM ('confirmed', 'in_progress', 'completed', 'cancelled');
CREATE TYPE media_type AS ENUM ('image', 'video');
CREATE TYPE payment_provider AS ENUM ('payme', 'click');
CREATE TYPE payment_status AS ENUM ('pending', 'paid', 'cancelled');
CREATE TYPE notification_type AS ENUM (
  'new_offer', 'offer_accepted', 'offer_rejected', 'new_message',
  'order_status_changed', 'new_review', 'system'
);

-- ---------- Foydalanuvchilar ----------
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone           VARCHAR(20) UNIQUE NOT NULL,          -- +998901234567 formatida, majburiy (parol tiklash uchun ishlatiladi)
  email           CITEXT UNIQUE,                         -- ixtiyoriy, lekin berilsa noyob bo'lishi kerak (katta/kichik harf farqsiz)
  password_hash   TEXT NOT NULL,
  full_name       VARCHAR(120) NOT NULL,
  role            user_role NOT NULL DEFAULT 'client',
  avatar_url      TEXT,
  city            VARCHAR(80) DEFAULT 'Toshkent',
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  is_phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
  is_email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  push_token      TEXT,                                  -- FCM/APNs push token
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- ---------- SMS bir martalik kodlar (OTP) ----------
CREATE TYPE otp_purpose AS ENUM ('password_reset', 'phone_verify');

CREATE TABLE otp_codes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone       VARCHAR(20) NOT NULL,
  purpose     otp_purpose NOT NULL DEFAULT 'password_reset',
  code_hash   TEXT NOT NULL,
  attempts    INT NOT NULL DEFAULT 0,
  expires_at  TIMESTAMPTZ NOT NULL,
  verified    BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_otp_phone ON otp_codes(phone, purpose, expires_at);

-- ---------- Refresh tokenlar (sessiyalar) ----------
CREATE TABLE refresh_tokens (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL,
  device_info TEXT,
  expires_at  TIMESTAMPTZ NOT NULL,
  revoked     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_refresh_user ON refresh_tokens(user_id);

-- ---------- Usta (provider) profili ----------
CREATE TABLE provider_profiles (
  user_id             UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  bio                 TEXT,
  experience_years    SMALLINT DEFAULT 0,
  rating_avg          NUMERIC(2,1) NOT NULL DEFAULT 0,
  rating_count        INT NOT NULL DEFAULT 0,
  completed_orders_count INT NOT NULL DEFAULT 0,
  is_verified         BOOLEAN NOT NULL DEFAULT FALSE,     -- pasport/litsenziya tekshiruvi
  latitude            DOUBLE PRECISION,
  longitude           DOUBLE PRECISION,
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Kategoriyalar (Santexnik, Elektrik va h.k.) ----------
CREATE TABLE categories (
  id          SERIAL PRIMARY KEY,
  parent_id   INT REFERENCES categories(id) ON DELETE SET NULL,
  name_uz     VARCHAR(100) NOT NULL,
  name_ru     VARCHAR(100),
  icon        VARCHAR(60),                                -- ikon kod nomi (frontendda map qilinadi)
  sort_order  INT DEFAULT 0,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE INDEX idx_categories_parent ON categories(parent_id);

-- ---------- Usta qaysi kategoriyalarda ishlaydi ----------
CREATE TABLE provider_categories (
  provider_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  PRIMARY KEY (provider_id, category_id)
);

-- ---------- Usta portfoliosi (oldingi ishlar) ----------
CREATE TABLE provider_portfolio (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  provider_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  image_url   TEXT NOT NULL,
  description TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_portfolio_provider ON provider_portfolio(provider_id);

-- ---------- E'lonlar (mijoz tomonidan yaratilgan buyurtma so'rovi) ----------
CREATE TABLE listings (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id     INT NOT NULL REFERENCES categories(id),
  title           VARCHAR(160) NOT NULL,
  description     TEXT NOT NULL,
  price           NUMERIC(12,2),                          -- NULL bo'lsa "Kelishamiz"
  price_type      price_type NOT NULL DEFAULT 'negotiable',
  address         VARCHAR(255),
  city            VARCHAR(80) DEFAULT 'Toshkent',
  latitude        DOUBLE PRECISION,
  longitude       DOUBLE PRECISION,
  status          listing_status NOT NULL DEFAULT 'open',
  views_count     INT NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_listings_category ON listings(category_id);
CREATE INDEX idx_listings_status ON listings(status);
CREATE INDEX idx_listings_client ON listings(client_id);
CREATE INDEX idx_listings_city ON listings(city);
CREATE INDEX idx_listings_created ON listings(created_at DESC);
-- Oddiy geografik qidiruv uchun (keyinchalik PostGIS'ga o'tkazish mumkin)
CREATE INDEX idx_listings_geo ON listings(latitude, longitude);

CREATE TABLE listing_media (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  listing_id  UUID NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  type        media_type NOT NULL DEFAULT 'image',
  sort_order  INT DEFAULT 0
);
CREATE INDEX idx_media_listing ON listing_media(listing_id);

-- ---------- Takliflar (usta e'longa javob beradi) ----------
CREATE TABLE offers (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  listing_id  UUID NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  price       NUMERIC(12,2) NOT NULL,
  message     TEXT,
  status      offer_status NOT NULL DEFAULT 'pending',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (listing_id, provider_id)
);
CREATE INDEX idx_offers_listing ON offers(listing_id);
CREATE INDEX idx_offers_provider ON offers(provider_id);

-- ---------- Buyurtmalar (taklif qabul qilingandan keyin) ----------
CREATE TABLE orders (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  listing_id      UUID NOT NULL UNIQUE REFERENCES listings(id) ON DELETE CASCADE,
  offer_id        UUID NOT NULL REFERENCES offers(id),
  client_id       UUID NOT NULL REFERENCES users(id),
  provider_id     UUID NOT NULL REFERENCES users(id),
  agreed_price    NUMERIC(12,2) NOT NULL,
  status          order_status NOT NULL DEFAULT 'confirmed',
  started_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  cancelled_at    TIMESTAMPTZ,
  cancel_reason   TEXT,
  is_paid         BOOLEAN NOT NULL DEFAULT FALSE,
  paid_at         TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_orders_client ON orders(client_id);
CREATE INDEX idx_orders_provider ON orders(provider_id);
CREATE INDEX idx_orders_status ON orders(status);

-- ---------- To'lovlar (Payme / Click) ----------
CREATE TABLE payments (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  provider        payment_provider NOT NULL,
  external_id     TEXT,                                  -- Payme "transaction id" yoki Click "click_trans_id"
  amount          NUMERIC(12,2) NOT NULL,                 -- so'mda (Payme/Click tiyinda ishlaydi, controller'da o'giriladi)
  status          payment_status NOT NULL DEFAULT 'pending',
  -- Payme uchun: 1=yaratilgan, 2=o'tkazilgan(to'langan), -1=to'lovdan oldin bekor, -2=to'lovdan keyin bekor(qaytarilgan)
  payme_state     SMALLINT,
  payme_reason    SMALLINT,                               -- Payme yuborgan bekor qilish sababi kodi
  -- Click uchun: qadamlar orasidagi bog'lanish uchun (Complete so'rovida kerak bo'ladi)
  click_prepare_id BIGINT,
  create_time     TIMESTAMPTZ NOT NULL DEFAULT now(),      -- Payme so'ragan "create_time" - biznikida yaratilgan payt
  perform_time    TIMESTAMPTZ,
  cancel_time     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Payme/Click bir xil tranzaksiya ID orqali qayta so'rov yuborsa (tarmoq uzilishi va h.k.),
-- shu yozuvni topib, natijani IDEMPOTENT qaytarish uchun (xuddi shu amalni ikki marta bajarmaslik)
CREATE UNIQUE INDEX idx_payments_external ON payments(provider, external_id) WHERE external_id IS NOT NULL;
CREATE INDEX idx_payments_order ON payments(order_id);
-- Bitta buyurtma uchun bir vaqtning o'zida faqat bitta FAOL (kutilayotgan) tranzaksiya bo'lishi kerak
CREATE UNIQUE INDEX idx_payments_order_pending ON payments(order_id) WHERE status = 'pending';

-- ---------- Chat va xabarlar ----------
CREATE TABLE chats (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  listing_id  UUID REFERENCES listings(id) ON DELETE SET NULL,
  client_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (listing_id, client_id, provider_id)
);
CREATE INDEX idx_chats_client ON chats(client_id);
CREATE INDEX idx_chats_provider ON chats(provider_id);

CREATE TABLE messages (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  chat_id     UUID NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  sender_id   UUID NOT NULL REFERENCES users(id),
  content     TEXT,
  media_url   TEXT,
  is_read     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_messages_chat ON messages(chat_id, created_at);

-- ---------- Sharhlar va reytinglar ----------
CREATE TABLE reviews (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id    UUID NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES users(id),
  reviewee_id UUID NOT NULL REFERENCES users(id),
  rating      SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment     TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_reviews_reviewee ON reviews(reviewee_id);

-- ---------- Bildirishnomalar ----------
CREATE TABLE notifications (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type        notification_type NOT NULL,
  title       VARCHAR(160) NOT NULL,
  body        TEXT,
  data        JSONB,
  is_read     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);

-- ---------- Saqlanganlar (Favorites) ----------
CREATE TABLE favorites (
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  listing_id  UUID NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, listing_id)
);

-- ---------- updated_at avtomatik yangilanishi uchun trigger ----------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_listings_updated BEFORE UPDATE ON listings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
