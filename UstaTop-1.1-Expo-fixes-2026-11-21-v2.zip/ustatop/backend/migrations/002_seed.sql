-- ============================================================
-- Boshlang'ich kategoriyalar (rasmlardagi Profi24 asosida)
-- ============================================================

INSERT INTO categories (name_uz, name_ru, icon, sort_order) VALUES
  ('Santexnik',            'Сантехник',        'plumbing',      1),
  ('Elektrik',             'Электрик',         'electrical',    2),
  ('Konditsioner o''rnatish va ta''mirlash', 'Кондиционеры', 'ac',       3),
  ('Malyar / Bo''yoqchi',  'Маляр',            'paint_roller',  4),
  ('Mebel yig''ish',       'Сборка мебели',    'furniture',     5),
  ('Uy tozalash',          'Уборка',           'cleaning',      6),
  ('Ko''chirish xizmati',  'Грузоперевозки',   'moving_box',    7),
  ('Deraza va eshik ta''miri', 'Окна и двери', 'window',        8),
  ('Maishiy texnika ta''miri', 'Ремонт техники','appliance',     9),
  ('Repetitorlik',         'Репетиторство',    'tutor',        10),
  ('Go''zallik xizmatlari','Красота',          'beauty',       11),
  ('IT va kompyuter ustasi','IT-специалист',   'computer',     12);
