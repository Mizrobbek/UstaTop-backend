-- Buyurtmalar tarixi saqlanadi, lekin bir e'lon uchun bir vaqtning o'zida
-- faqat bitta faol (confirmed/in_progress) buyurtma bo'lishiga ruxsat beriladi.
-- Bekor qilingan buyurtmadan keyin e'lon qayta ochilib, yangi buyurtma yarata oladi.

DO $$
BEGIN
  IF EXISTS (
    SELECT listing_id
    FROM orders
    WHERE status IN ('confirmed', 'in_progress')
    GROUP BY listing_id
    HAVING COUNT(*) > 1
  ) THEN
    RAISE EXCEPTION
      'Migratsiya to''xtatildi: bir e''lon uchun bir nechta faol buyurtma mavjud. Avval ma''lumotlarni tekshiring.';
  END IF;
END
$$;

ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS orders_listing_id_key;

CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_one_active_per_listing
  ON orders (listing_id)
  WHERE status IN ('confirmed', 'in_progress');
