-- Mijoz xizmat haqini bevosita ustaga to'laydi.
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'service_payment_confirmation';
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'service_payment_confirmed';

-- To'lov faqat mijoz va usta ikkisi ham tasdiqlagandan keyin "paid" bo'ladi.
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS client_payment_confirmed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS provider_payment_confirmed_at TIMESTAMPTZ;
