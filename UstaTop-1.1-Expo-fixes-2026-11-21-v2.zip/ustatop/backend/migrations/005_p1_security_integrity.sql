-- 005: P1 xavfsizlik va ma'lumotlar yaxlitligi
-- Qaytarish: migrations/rollback/005_p1_security_integrity.down.sql
-- Hech qanday ma'lumot o'chirilmaydi yoki o'zgartirilmaydi; faqat ustunlar va FK amallari.

-- 1) Yetim yozuvlar tekshiruvi. FK'lar mavjud bo'lgani uchun odatda 0 bo'ladi;
--    agar biror sabab bilan yetim yozuv bo'lsa, migratsiya to'xtaydi (hech narsa o'zgarmaydi).
DO $$
DECLARE
  orphan_orders   INT;
  orphan_payments INT;
  orphan_reviews  INT;
BEGIN
  SELECT COUNT(*) INTO orphan_orders FROM orders o
    WHERE NOT EXISTS (SELECT 1 FROM listings l WHERE l.id = o.listing_id);
  SELECT COUNT(*) INTO orphan_payments FROM payments p
    WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.id = p.order_id);
  SELECT COUNT(*) INTO orphan_reviews FROM reviews r
    WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.id = r.order_id);
  IF orphan_orders + orphan_payments + orphan_reviews > 0 THEN
    RAISE EXCEPTION 'Migratsiya to''xtatildi: yetim yozuvlar topildi (orders=%, payments=%, reviews=%)',
      orphan_orders, orphan_payments, orphan_reviews;
  END IF;
END
$$;

-- 2) Buyurtma / to'lov / sharh tarixini e'lon o'chirilganda CASCADE bilan yo'qotmaslik.
ALTER TABLE orders   DROP CONSTRAINT orders_listing_id_fkey;
ALTER TABLE orders   ADD  CONSTRAINT orders_listing_id_fkey
  FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE RESTRICT;

ALTER TABLE payments DROP CONSTRAINT payments_order_id_fkey;
ALTER TABLE payments ADD  CONSTRAINT payments_order_id_fkey
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE RESTRICT;

ALTER TABLE reviews  DROP CONSTRAINT reviews_order_id_fkey;
ALTER TABLE reviews  ADD  CONSTRAINT reviews_order_id_fkey
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE RESTRICT;

-- 3) Access tokenlarni bekor qilish uchun versiya. Mavjud foydalanuvchilar 0 oladi;
--    "ver" maydoni bo'lmagan eski tokenlar 0 deb hisoblanadi, ya'ni ular muddati
--    tugaguncha (odatda 15 daqiqa) ishlashda davom etadi — majburiy chiqarib yuborish yo'q.
ALTER TABLE users ADD COLUMN IF NOT EXISTS token_version INT NOT NULL DEFAULT 0;

-- 4) Refresh token rotatsiyasi: almashtirilgan tokenni (replay) logout bilan
--    bekor qilingandan ajratish uchun.
ALTER TABLE refresh_tokens ADD COLUMN IF NOT EXISTS rotated_at TIMESTAMPTZ;
