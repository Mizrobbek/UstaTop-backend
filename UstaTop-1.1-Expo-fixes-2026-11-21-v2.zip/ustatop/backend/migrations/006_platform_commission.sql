-- Stage 2: private platform debt, separate from service payments.
-- Apply with psql -v ON_ERROR_STOP=1 to a reviewed deployment only.
BEGIN;
LOCK TABLE orders, offers IN SHARE ROW EXCLUSIVE MODE;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='users' AND column_name='token_version')
     OR NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='provider_payment_confirmed_at') THEN
    RAISE EXCEPTION '006 requires migrations 001-005';
  END IF;
  IF EXISTS (SELECT 1 FROM orders o LEFT JOIN users u ON u.id=o.provider_id
    LEFT JOIN listings l ON l.id=o.listing_id LEFT JOIN offers f ON f.id=o.offer_id
    WHERE u.id IS NULL OR l.id IS NULL OR f.id IS NULL OR f.provider_id<>o.provider_id
      OR f.listing_id<>o.listing_id OR l.client_id<>o.client_id OR o.agreed_price<0)
    OR EXISTS (SELECT 1 FROM offers f LEFT JOIN users u ON u.id=f.provider_id
      LEFT JOIN listings l ON l.id=f.listing_id WHERE u.id IS NULL OR l.id IS NULL)
    OR EXISTS (SELECT 1 FROM listings l LEFT JOIN categories c ON c.id=l.category_id WHERE c.id IS NULL) THEN
    RAISE EXCEPTION '006 stopped: orphan/inconsistent order, offer or category; no data changed';
  END IF;
END $$;

CREATE TABLE public.commission_tariffs (
  scope_key INT PRIMARY KEY CHECK(scope_key>=0), -- 0 = global; otherwise category id
  category_id INT UNIQUE REFERENCES categories(id) ON DELETE RESTRICT,
  rate NUMERIC(5,2) CHECK(rate BETWEEN 0 AND 100),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((scope_key=0 AND category_id IS NULL AND rate IS NOT NULL) OR
         (scope_key>0 AND category_id=scope_key))
);
-- Private tables: no anon/authenticated Data API grant. Express uses the DB owner.
GRANT ALL ON public.commission_tariffs TO CURRENT_USER;
ALTER TABLE public.commission_tariffs ENABLE ROW LEVEL SECURITY;
INSERT INTO commission_tariffs(scope_key,rate) VALUES(0,0);

CREATE TABLE public.commission_tariff_audit (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scope_key INT NOT NULL REFERENCES commission_tariffs(scope_key) ON DELETE RESTRICT,
  actor_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  old_rate NUMERIC(5,2), new_rate NUMERIC(5,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.commission_tariff_audit TO CURRENT_USER;
ALTER TABLE public.commission_tariff_audit ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.commission_charges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL UNIQUE REFERENCES orders(id) ON DELETE RESTRICT,
  provider_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  tariff_scope INT NOT NULL REFERENCES commission_tariffs(scope_key) ON DELETE RESTRICT,
  rate NUMERIC(5,2) NOT NULL CHECK(rate BETWEEN 0 AND 100),
  base_amount NUMERIC(12,2) NOT NULL CHECK(base_amount>=0),
  amount NUMERIC(14,2) NOT NULL CHECK(amount=round(base_amount*rate/100,2)),
  currency TEXT NOT NULL DEFAULT 'UZS' CHECK(currency='UZS'),
  calculated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.commission_charges TO CURRENT_USER;
ALTER TABLE public.commission_charges ENABLE ROW LEVEL SECURITY;
CREATE INDEX commission_charges_provider ON commission_charges(provider_id);

CREATE TABLE public.commission_adjustments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  charge_id UUID NOT NULL REFERENCES commission_charges(id) ON DELETE RESTRICT,
  actor_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  amount NUMERIC(14,2) NOT NULL CHECK(amount>0), -- no waiver/negative credits; settlement only
  reason TEXT NOT NULL CHECK(length(trim(reason))>=5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.commission_adjustments TO CURRENT_USER;
ALTER TABLE public.commission_adjustments ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.commission_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  charge_id UUID NOT NULL REFERENCES commission_charges(id) ON DELETE RESTRICT,
  provider TEXT NOT NULL CHECK(provider IN ('payme','click')),
  provider_transaction_id TEXT NOT NULL CHECK(length(trim(provider_transaction_id))>0),
  amount NUMERIC(14,2) NOT NULL CHECK(amount>0), currency TEXT NOT NULL DEFAULT 'UZS' CHECK(currency='UZS'),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid','failed','cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), settled_at TIMESTAMPTZ,
  UNIQUE(provider,provider_transaction_id)
);
GRANT ALL ON public.commission_payments TO CURRENT_USER;
ALTER TABLE public.commission_payments ENABLE ROW LEVEL SECURITY;
CREATE UNIQUE INDEX commission_one_pending ON commission_payments(charge_id) WHERE status='pending';

CREATE TABLE public.commission_settlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id UUID NOT NULL UNIQUE REFERENCES commission_payments(id) ON DELETE RESTRICT,
  provider TEXT NOT NULL CHECK(provider IN ('payme','click')),
  provider_transaction_id TEXT NOT NULL,
  amount NUMERIC(14,2) NOT NULL CHECK(amount>0), currency TEXT NOT NULL CHECK(currency='UZS'),
  verification_reference TEXT NOT NULL CHECK(length(trim(verification_reference))>=8),
  settled_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider,provider_transaction_id)
);
GRANT ALL ON public.commission_settlements TO CURRENT_USER;
ALTER TABLE public.commission_settlements ENABLE ROW LEVEL SECURITY;
DO $$ DECLARE t TEXT; BEGIN
  IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname='service_role') THEN
    FOREACH t IN ARRAY ARRAY['commission_tariffs','commission_tariff_audit','commission_charges',
      'commission_adjustments','commission_payments','commission_settlements'] LOOP
      EXECUTE format('GRANT ALL ON public.%I TO service_role',t);
    END LOOP;
  END IF;
END $$;

CREATE VIEW commission_balances AS
 SELECT c.*, c.amount + COALESCE(a.total,0) AS total_amount,
   c.amount + COALESCE(a.total,0) - COALESCE(s.total,0) AS balance
 FROM commission_charges c
 LEFT JOIN LATERAL (SELECT SUM(amount) AS total FROM commission_adjustments WHERE charge_id=c.id) a ON TRUE
 LEFT JOIN LATERAL (SELECT SUM(s.amount) AS total FROM commission_settlements s
   JOIN commission_payments p ON p.id=s.payment_id WHERE p.charge_id=c.id) s ON TRUE;
REVOKE ALL ON commission_balances FROM PUBLIC;
GRANT SELECT ON commission_balances TO CURRENT_USER;

CREATE FUNCTION commission_immutable() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 RAISE EXCEPTION 'Commission ledger is append-only'; END $$;
CREATE TRIGGER commission_charges_immutable BEFORE UPDATE OR DELETE ON commission_charges
 FOR EACH ROW EXECUTE FUNCTION commission_immutable();
CREATE TRIGGER commission_adjustments_immutable BEFORE UPDATE OR DELETE ON commission_adjustments
 FOR EACH ROW EXECUTE FUNCTION commission_immutable();
CREATE TRIGGER commission_audit_immutable BEFORE UPDATE OR DELETE ON commission_tariff_audit
 FOR EACH ROW EXECUTE FUNCTION commission_immutable();
CREATE TRIGGER commission_settlements_immutable BEFORE UPDATE OR DELETE ON commission_settlements
 FOR EACH ROW EXECUTE FUNCTION commission_immutable();

CREATE FUNCTION commission_assert_clear(worker UUID) RETURNS void LANGUAGE plpgsql AS $$ BEGIN
 PERFORM id FROM users WHERE id=worker FOR UPDATE;
 IF EXISTS(SELECT 1 FROM commission_balances WHERE provider_id=worker AND balance>0) THEN
   RAISE EXCEPTION USING ERRCODE='P0001', MESSAGE='COMMISSION_DEBT';
 END IF;
END $$;
CREATE FUNCTION commission_offer_guard() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF TG_OP='INSERT' OR (NEW.status='accepted' AND OLD.status IS DISTINCT FROM NEW.status) THEN
   PERFORM commission_assert_clear(NEW.provider_id);
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER commission_offer_guard BEFORE INSERT OR UPDATE OF status ON offers
 FOR EACH ROW EXECUTE FUNCTION commission_offer_guard();

CREATE FUNCTION commission_order_snapshot() RETURNS trigger LANGUAGE plpgsql AS $$
 DECLARE category INT; selected_scope INT; selected_rate NUMERIC;
 BEGIN
 PERFORM commission_assert_clear(NEW.provider_id);
 -- Rate edits and category overrides share this global lock to avoid mixed snapshots.
 PERFORM scope_key FROM commission_tariffs WHERE scope_key=0 FOR SHARE;
 SELECT category_id INTO category FROM listings WHERE id=NEW.listing_id;
 SELECT scope_key,rate INTO selected_scope,selected_rate FROM commission_tariffs
   WHERE scope_key IN (0,category) AND rate IS NOT NULL ORDER BY scope_key DESC LIMIT 1;
 INSERT INTO commission_charges(order_id,provider_id,tariff_scope,rate,base_amount,amount)
 VALUES(NEW.id,NEW.provider_id,selected_scope,selected_rate,NEW.agreed_price,round(NEW.agreed_price*selected_rate/100,2));
 RETURN NEW;
 END $$;
CREATE TRIGGER commission_order_snapshot AFTER INSERT ON orders
 FOR EACH ROW EXECUTE FUNCTION commission_order_snapshot();
-- Historical orders are NOT charged retroactively. No backfill of debt.

CREATE FUNCTION commission_adjustment_check() RETURNS trigger LANGUAGE plpgsql AS $$
 DECLARE worker UUID;
 BEGIN
 IF NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.actor_id AND role='admin' AND is_active) THEN
  RAISE EXCEPTION 'Active admin required'; END IF;
 SELECT provider_id INTO worker FROM commission_charges WHERE id=NEW.charge_id;
 PERFORM id FROM users WHERE id=worker FOR UPDATE;
 RETURN NEW;
 END $$;
CREATE TRIGGER commission_adjustment_check BEFORE INSERT ON commission_adjustments
 FOR EACH ROW EXECUTE FUNCTION commission_adjustment_check();

CREATE FUNCTION commission_payment_check() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Payment history cannot be deleted'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.status<>'pending' OR NEW.settled_at IS NOT NULL THEN RAISE EXCEPTION 'New payment must be pending'; END IF;
 ELSE
  IF (NEW.id,NEW.charge_id,NEW.provider,NEW.provider_transaction_id,NEW.amount,NEW.currency,NEW.created_at)
    IS DISTINCT FROM (OLD.id,OLD.charge_id,OLD.provider,OLD.provider_transaction_id,OLD.amount,OLD.currency,OLD.created_at)
    OR OLD.status<>'pending' THEN RAISE EXCEPTION 'Immutable payment / terminal state'; END IF;
  IF NEW.status='paid' AND NOT EXISTS(SELECT 1 FROM commission_settlements WHERE payment_id=NEW.id) THEN
    RAISE EXCEPTION 'Verified settlement required'; END IF;
  IF NEW.status<>'paid' AND NEW.settled_at IS NOT NULL THEN RAISE EXCEPTION 'Settlement time requires paid state'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER commission_payment_check BEFORE INSERT OR UPDATE OR DELETE ON commission_payments
 FOR EACH ROW EXECUTE FUNCTION commission_payment_check();

CREATE FUNCTION commission_settlement_check() RETURNS trigger LANGUAGE plpgsql AS $$
 DECLARE p commission_payments; worker UUID; debt NUMERIC;
 BEGIN
 SELECT c.provider_id INTO worker FROM commission_payments x JOIN commission_charges c ON c.id=x.charge_id WHERE x.id=NEW.payment_id;
 PERFORM id FROM users WHERE id=worker FOR UPDATE;
 SELECT * INTO p FROM commission_payments WHERE id=NEW.payment_id FOR UPDATE;
 SELECT balance INTO debt FROM commission_balances WHERE id=p.charge_id;
 IF p.id IS NULL OR p.status<>'pending' OR p.provider<>NEW.provider
   OR p.provider_transaction_id<>NEW.provider_transaction_id OR p.amount<>NEW.amount
   OR p.currency<>NEW.currency OR NEW.amount<>debt THEN
  RAISE EXCEPTION 'Invalid commission settlement'; END IF;
 RETURN NEW;
 END $$;
CREATE TRIGGER commission_settlement_check BEFORE INSERT ON commission_settlements
 FOR EACH ROW EXECUTE FUNCTION commission_settlement_check();
CREATE FUNCTION commission_settlement_apply() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 UPDATE commission_payments SET status='paid',settled_at=NEW.settled_at WHERE id=NEW.payment_id;
 RETURN NEW; END $$;
CREATE TRIGGER commission_settlement_apply AFTER INSERT ON commission_settlements
 FOR EACH ROW EXECUTE FUNCTION commission_settlement_apply();
COMMIT;
