-- UstaTop 1.1: portfolio media metadata. Keep legacy image_url rows intact.
ALTER TABLE provider_portfolio ADD COLUMN IF NOT EXISTS media_url TEXT;
ALTER TABLE provider_portfolio ADD COLUMN IF NOT EXISTS media_type VARCHAR(10) NOT NULL DEFAULT 'image';
ALTER TABLE provider_portfolio ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE provider_portfolio ADD COLUMN IF NOT EXISTS storage_key TEXT;
UPDATE provider_portfolio SET media_url = image_url WHERE media_url IS NULL;
ALTER TABLE provider_portfolio ALTER COLUMN image_url DROP NOT NULL;
DO $$ BEGIN
  ALTER TABLE provider_portfolio ADD CONSTRAINT provider_portfolio_media_type_check CHECK (media_type IN ('image','video'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
