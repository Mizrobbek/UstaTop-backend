-- 008: Telefon OTP majburiyligi va MyID ustalar uchun alohida tasdiq holati.
-- Mavjud foydalanuvchilar va ma'lumotlar o'chirilmaydi.

ALTER TYPE otp_purpose ADD VALUE IF NOT EXISTS 'signup_verify';

CREATE TABLE IF NOT EXISTS pending_registrations (
  phone VARCHAR(20) PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  password_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_pending_registrations_expiry ON pending_registrations(expires_at);

ALTER TABLE provider_profiles
  ADD COLUMN IF NOT EXISTS myid_verified BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS myid_verified_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS myid_transaction_id VARCHAR(160);

-- Avvalgi telefonlari SMS orqali tasdiqlanmagan akkauntlar keyingi login vaqtida OTP challenge oladi.
-- Bu migratsiya ularni avtomatik tasdiqlamaydi.
