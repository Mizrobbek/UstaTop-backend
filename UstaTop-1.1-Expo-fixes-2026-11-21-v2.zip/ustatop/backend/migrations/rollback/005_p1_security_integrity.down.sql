-- 005 ni qaytarish (qo'lda ishga tushiriladi). Ma'lumot yo'qotmaydi:
-- faqat qo'shilgan ustunlar olib tashlanadi va FK'lar asl CASCADE holatiga qaytadi.
BEGIN;
ALTER TABLE refresh_tokens DROP COLUMN IF EXISTS rotated_at;
ALTER TABLE users DROP COLUMN IF EXISTS token_version;

ALTER TABLE reviews  DROP CONSTRAINT reviews_order_id_fkey;
ALTER TABLE reviews  ADD  CONSTRAINT reviews_order_id_fkey
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE;
ALTER TABLE payments DROP CONSTRAINT payments_order_id_fkey;
ALTER TABLE payments ADD  CONSTRAINT payments_order_id_fkey
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE;
ALTER TABLE orders   DROP CONSTRAINT orders_listing_id_fkey;
ALTER TABLE orders   ADD  CONSTRAINT orders_listing_id_fkey
  FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE;

DELETE FROM schema_migrations WHERE filename = '005_p1_security_integrity.sql';
COMMIT;
