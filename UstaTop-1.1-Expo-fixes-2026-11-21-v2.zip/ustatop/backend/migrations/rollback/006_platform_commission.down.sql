-- Safe only before any financial/audit activity. Never delete live ledger history.
BEGIN;
LOCK TABLE commission_charges, commission_tariff_audit, commission_adjustments,
 commission_payments, commission_settlements IN ACCESS EXCLUSIVE MODE;
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM commission_charges) OR EXISTS(SELECT 1 FROM commission_tariff_audit)
 OR EXISTS(SELECT 1 FROM commission_adjustments) OR EXISTS(SELECT 1 FROM commission_payments)
 OR EXISTS(SELECT 1 FROM commission_settlements) THEN
  RAISE EXCEPTION 'Rollback refused: retain financial/audit data; forward migration required';
 END IF;
END $$;
DROP TRIGGER commission_offer_guard ON offers;
DROP TRIGGER commission_order_snapshot ON orders;
DROP TABLE commission_settlements;
DROP TABLE commission_payments;
DROP VIEW commission_balances;
DROP TABLE commission_adjustments;
DROP TABLE commission_charges;
DROP TABLE commission_tariff_audit;
DROP TABLE commission_tariffs;
DROP FUNCTION commission_settlement_apply(),commission_settlement_check(),commission_payment_check(),
 commission_adjustment_check(),commission_order_snapshot(),commission_offer_guard(),commission_assert_clear(UUID),commission_immutable();
COMMIT;
