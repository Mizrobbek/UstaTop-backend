const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
require('dotenv').config();

const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const categoryRoutes = require('./routes/category.routes');
const listingRoutes = require('./routes/listing.routes');
const offerRoutes = require('./routes/offer.routes');
const chatRoutes = require('./routes/chat.routes');
const orderRoutes = require('./routes/order.routes');
const providerRoutes = require('./routes/provider.routes');
const adminRoutes = require('./routes/admin.routes');
const paymentRoutes = require('./routes/payment.routes');
const notificationRoutes = require('./routes/notification.routes');
const commissionRoutes = require('./routes/commission.routes');
const mediaRoutes = require('./routes/media.routes');
const portfolioRoutes = require('./routes/portfolio.routes');
const { errorHandler, notFoundHandler } = require('./middleware/errorHandler');

const app = express();

// Helmet standart CSP'sidagi "upgrade-insecure-requests" o'chirildi: u http://localhost (va HTTPS'siz
// test serverlarda) admin panelning skript/uslub fayllarini https'ga majburan almashtirib, yuklanmay
// qolishiga sabab bo'ladi. Production'da HTTPS'ni reverse-proxy (Nginx/Caddy) ta'minlaydi.
app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: { 'upgrade-insecure-requests': null },
    },
  })
);
app.use(
  cors({
    origin: (process.env.CORS_ORIGINS || '*').split(','),
    credentials: true,
  })
);
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'usta-topamiz-backend', time: new Date().toISOString() });
});

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/listings', listingRoutes);
app.use('/api/offers', offerRoutes);
app.use('/api/chats', chatRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/providers', providerRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/commissions', commissionRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/portfolio', portfolioRoutes);
app.use('/uploads', express.static(path.resolve(process.env.MEDIA_STORAGE_DIR || path.join(__dirname, '../uploads')), { fallthrough: false, maxAge: '7d' }));

// Admin panel (statik fayllar): http://localhost:4000/admin
app.use('/admin', express.static(path.join(__dirname, '..', 'admin')));

app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
