const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  // Kutilmagan xatolik (masalan, ulanish uzilib qolganda) — serverni yiqitmaydi, faqat log qiladi
  console.error('[DB] Kutilmagan xatolik ulanish poolida:', err.message);
});

/**
 * Oddiy so'rov bajarish (tranzaksiyasiz)
 */
async function query(text, params) {
  const start = Date.now();
  const res = await pool.query(text, params);
  if (process.env.NODE_ENV === 'development') {
    const duration = Date.now() - start;
    console.log('[DB]', text.slice(0, 80).replace(/\s+/g, ' '), `${duration}ms`, `rows=${res.rowCount}`);
  }
  return res;
}

/**
 * Tranzaksiya bilan ishlash uchun client olish.
 * Foydalanish: const client = await getClient(); try { await client.query(...); await client.query('COMMIT'); } finally { client.release(); }
 */
async function getClient() {
  const client = await pool.connect();
  const originalRelease = client.release.bind(client);
  client.release = () => originalRelease();
  return client;
}

module.exports = { pool, query, getClient };
