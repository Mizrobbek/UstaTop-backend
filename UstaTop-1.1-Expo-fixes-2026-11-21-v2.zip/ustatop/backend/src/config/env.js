/**
 * Production muhitida xavfsiz bo'lmagan sozlamalar bilan serverni ishga tushirmaslik.
 * Qiymatlarning o'zi hech qachon log qilinmaydi — faqat qaysi o'zgaruvchi muammoli ekani.
 */
const KNOWN_WEAK_SECRETS = [
  'change_this_access_secret',
  'change_this_refresh_secret',
  'secret',
  'test_access_secret',
  'test_refresh_secret',
];
const KNOWN_WEAK_DB_PASSWORDS = ['usta_pass', 'postgres', 'password'];
const MIN_SECRET_LENGTH = 32;

function validateProductionEnv(env = process.env) {
  if (env.NODE_ENV !== 'production') return [];
  const problems = [];

  for (const name of ['JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET']) {
    const value = env[name];
    if (!value) problems.push(`${name} o'rnatilmagan`);
    else if (value.length < MIN_SECRET_LENGTH) problems.push(`${name} kamida ${MIN_SECRET_LENGTH} belgi bo'lishi kerak`);
    else if (KNOWN_WEAK_SECRETS.includes(value) || /change_this/i.test(value)) problems.push(`${name} standart (namuna) qiymatda`);
  }
  if (env.JWT_ACCESS_SECRET && env.JWT_ACCESS_SECRET === env.JWT_REFRESH_SECRET) {
    problems.push('JWT_ACCESS_SECRET va JWT_REFRESH_SECRET bir xil bo\'lmasligi kerak');
  }

  if (!env.DATABASE_URL) {
    problems.push('DATABASE_URL o\'rnatilmagan');
  } else {
    try {
      const url = new URL(env.DATABASE_URL);
      const password = decodeURIComponent(url.password || '');
      if (!password || KNOWN_WEAK_DB_PASSWORDS.includes(password)) {
        problems.push('DATABASE_URL bo\'sh yoki standart parol ishlatmoqda');
      }
    } catch {
      problems.push('DATABASE_URL noto\'g\'ri formatda');
    }
  }

  const sms = env.SMS_PROVIDER || 'console';
  if (sms === 'console') {
    problems.push('SMS_PROVIDER=console production\'da taqiqlangan (kodlar SMS o\'rniga logga yoziladi)');
  }

  if (!env.CORS_ORIGINS || env.CORS_ORIGINS.split(',').map((s) => s.trim()).includes('*')) {
    problems.push('CORS_ORIGINS aniq domenlar ro\'yxati bo\'lishi kerak ("*" emas)');
  }

  return problems;
}

function assertSafeEnv(env = process.env) {
  const problems = validateProductionEnv(env);
  if (problems.length > 0) {
    const err = new Error(`Xavfsiz bo'lmagan production sozlamalari:\n - ${problems.join('\n - ')}`);
    err.problems = problems;
    throw err;
  }
}

module.exports = { validateProductionEnv, assertSafeEnv };
