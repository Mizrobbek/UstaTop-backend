const { Server } = require('socket.io');
const { resolveAccessToken } = require('../middleware/auth');
const { query } = require('./db');

/**
 * Socket.io serverini HTTP serveriga ulaydi va JWT orqali autentifikatsiya qiladi.
 * Mobil ilova ulanish paytida shu accessToken'ni yuboradi:
 *   io('https://api.ustatop.uz', { auth: { token: accessToken } })
 *
 * Har bir ulanish "user:<id>" va (bo'lsa) "session:<sid>" xonalariga qo'shiladi —
 * logout yoki parol tiklashda server shu xonalardagi ulanishlarni uzadi.
 */
function initSocket(httpServer, corsOrigins) {
  const io = new Server(httpServer, {
    cors: { origin: corsOrigins, credentials: true },
  });
  attachSocketHandlers(io);
  return io;
}

async function isChatParticipant(chatId, userId) {
  if (typeof chatId !== 'string' || !chatId) return { ok: false, reason: 'Suhbat topilmadi' };
  const chatResult = await query('SELECT client_id, provider_id FROM chats WHERE id = $1', [chatId]);
  const chat = chatResult.rows[0];
  if (!chat) return { ok: false, reason: 'Suhbat topilmadi' };
  if (chat.client_id !== userId && chat.provider_id !== userId) {
    return { ok: false, reason: 'Bu suhbatga kirish huquqingiz yo\'q' };
  }
  return { ok: true };
}

function attachSocketHandlers(io) {
  // Har bir ulanishni JWT bilan tekshiramiz: yaroqsiz, bekor qilingan token yoki
  // bloklangan foydalanuvchi bo'lsa ulanish rad etiladi.
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('Token topilmadi'));
      const resolved = await resolveAccessToken(token);
      if (resolved.error) return next(new Error(resolved.error.body.error));
      socket.user = resolved.user;
      socket.sessionId = resolved.payload.sid || null;
      next();
    } catch (err) {
      next(new Error('Autentifikatsiya muvaffaqiyatsiz'));
    }
  });

  io.on('connection', (socket) => {
    socket.join(`user:${socket.user.id}`);
    if (socket.sessionId) socket.join(`session:${socket.sessionId}`);

    socket.on('chat:join', async (payload) => {
      try {
        const chatId = payload?.chatId;
        const check = await isChatParticipant(chatId, socket.user.id);
        if (!check.ok) return socket.emit('error', { message: check.reason });
        socket.join(`chat:${chatId}`);
      } catch (err) {
        socket.emit('error', { message: 'Suhbatga ulanib bo\'lmadi' });
      }
    });

    socket.on('chat:leave', (payload) => {
      if (payload?.chatId) socket.leave(`chat:${payload.chatId}`);
    });

    // "yozmoqda..." — faqat ishtirokchilik tekshiruvidan o'tib xonaga qo'shilganlar yubora oladi
    socket.on('chat:typing', (payload) => {
      const chatId = payload?.chatId;
      const room = `chat:${chatId}`;
      if (!chatId || !socket.rooms.has(room)) {
        return socket.emit('error', { message: 'Bu suhbatga kirish huquqingiz yo\'q' });
      }
      socket.to(room).emit('chat:typing', { chatId, userId: socket.user.id });
    });
  });
}

/**
 * Logout / parol tiklash / replay aniqlanganda ochiq socket ulanishlarini uzadi.
 * io bo'lmasa (masalan, testlarda) jim o'tadi.
 */
function disconnectSockets(io, { userId, sessionId } = {}) {
  if (!io) return;
  if (sessionId) io.in(`session:${sessionId}`).disconnectSockets(true);
  if (userId) io.in(`user:${userId}`).disconnectSockets(true);
}

module.exports = { initSocket, attachSocketHandlers, disconnectSockets, isChatParticipant };
