const { query } = require('../config/db');
const { notifyUser } = require('../utils/notify');

function countsToMap(rows, key) {
  const map = {};
  let total = 0;
  for (const row of rows) {
    map[row[key]] = Number(row.count);
    total += Number(row.count);
  }
  return { map, total };
}

function pageInfo(page, limit, total) {
  return { page, limit, total, totalPages: Math.max(1, Math.ceil(total / limit)) };
}

function toAdminCategory(row) {
  return {
    id: row.id,
    nameUz: row.name_uz,
    nameRu: row.name_ru,
    icon: row.icon,
    sortOrder: row.sort_order,
    isActive: row.is_active,
  };
}

/**
 * GET /api/admin/stats
 * Bosh panel uchun umumiy ko'rsatkichlar.
 */
async function getStats(req, res, next) {
  try {
    const [users, listings, orders, reviews, volume] = await Promise.all([
      query('SELECT role, COUNT(*) AS count FROM users GROUP BY role'),
      query('SELECT status, COUNT(*) AS count FROM listings GROUP BY status'),
      query('SELECT status, COUNT(*) AS count FROM orders GROUP BY status'),
      query('SELECT COUNT(*) AS count FROM reviews'),
      query(`SELECT COALESCE(SUM(agreed_price), 0) AS total FROM orders WHERE status = 'completed'`),
    ]);

    const u = countsToMap(users.rows, 'role');
    const l = countsToMap(listings.rows, 'status');
    const o = countsToMap(orders.rows, 'status');

    res.json({
      stats: {
        users: { total: u.total, byRole: u.map },
        listings: { total: l.total, byStatus: l.map },
        orders: { total: o.total, byStatus: o.map, completedVolume: Number(volume.rows[0].total) },
        reviews: { total: Number(reviews.rows[0].count) },
      },
    });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/admin/users?role=&search=&page=&limit=
 */
async function listUsers(req, res, next) {
  try {
    const { role, search, page, limit } = req.query;
    const roleParam = role || null;
    const searchParam = search ? `%${search}%` : null;
    const offset = (page - 1) * limit;

    const [rows, count] = await Promise.all([
      query(
        `SELECT u.id, u.phone, u.email, u.full_name, u.role, u.is_active, u.created_at,
                pp.is_verified AS provider_verified
         FROM users u LEFT JOIN provider_profiles pp ON pp.user_id = u.id
         WHERE ($1::text IS NULL OR u.role::text = $1)
           AND ($2::text IS NULL OR u.full_name ILIKE $2 OR u.phone ILIKE $2 OR u.email::text ILIKE $2)
         ORDER BY u.created_at DESC LIMIT $3 OFFSET $4`,
        [roleParam, searchParam, limit, offset]
      ),
      query(
        `SELECT COUNT(*) AS total FROM users u
         WHERE ($1::text IS NULL OR u.role::text = $1)
           AND ($2::text IS NULL OR u.full_name ILIKE $2 OR u.phone ILIKE $2 OR u.email::text ILIKE $2)`,
        [roleParam, searchParam]
      ),
    ]);

    res.json({
      users: rows.rows.map((r) => ({
        id: r.id,
        phone: r.phone,
        email: r.email,
        fullName: r.full_name,
        role: r.role,
        isActive: r.is_active,
        providerVerified: r.provider_verified === null || r.provider_verified === undefined ? null : r.provider_verified,
        createdAt: r.created_at,
      })),
      pagination: pageInfo(page, limit, Number(count.rows[0].total)),
    });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/admin/users/:id/active   body: { isActive }
 * Foydalanuvchini bloklash/blokdan chiqarish. Bloklanganda barcha sessiyalari bekor qilinadi.
 */
async function setUserActive(req, res, next) {
  try {
    const { id } = req.params;
    const { isActive } = req.body;

    const target = (await query('SELECT id, role FROM users WHERE id = $1', [id])).rows[0];
    if (!target) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
    if (target.id === req.user.id) return res.status(400).json({ error: 'O\'zingizni bloklab bo\'lmaydi' });
    if (target.role === 'admin') return res.status(403).json({ error: 'Boshqa administratorni bloklab bo\'lmaydi' });

    await query('UPDATE users SET is_active = $1 WHERE id = $2', [isActive, id]);
    if (!isActive) {
      await query('UPDATE refresh_tokens SET revoked = TRUE WHERE user_id = $1', [id]);
    }

    res.json({ message: isActive ? 'Foydalanuvchi blokdan chiqarildi' : 'Foydalanuvchi bloklandi' });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/admin/providers/:id/verify   body: { isVerified }
 * Ustani "tasdiqlangan" (pasport/hujjatlari tekshirilgan) deb belgilash.
 */
async function verifyProvider(req, res, next) {
  try {
    const { id } = req.params;
    const { isVerified } = req.body;
    const result = await query(
      'UPDATE provider_profiles SET is_verified = $1 WHERE user_id = $2 RETURNING user_id',
      [isVerified, id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Usta profili topilmadi' });
    res.json({ message: isVerified ? 'Usta tasdiqlandi' : 'Usta tasdig\'i olib tashlandi' });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/admin/listings?status=&search=&page=&limit=
 */
async function listListings(req, res, next) {
  try {
    const { status, search, page, limit } = req.query;
    const statusParam = status || null;
    const searchParam = search ? `%${search}%` : null;
    const offset = (page - 1) * limit;

    const [rows, count] = await Promise.all([
      query(
        `SELECT l.id, l.title, l.status, l.city, l.price, l.views_count, l.created_at,
                c.name_uz AS category_name, u.full_name AS client_name
         FROM listings l
         JOIN categories c ON c.id = l.category_id
         JOIN users u ON u.id = l.client_id
         WHERE ($1::text IS NULL OR l.status::text = $1) AND ($2::text IS NULL OR l.title ILIKE $2)
         ORDER BY l.created_at DESC LIMIT $3 OFFSET $4`,
        [statusParam, searchParam, limit, offset]
      ),
      query(
        `SELECT COUNT(*) AS total FROM listings l
         WHERE ($1::text IS NULL OR l.status::text = $1) AND ($2::text IS NULL OR l.title ILIKE $2)`,
        [statusParam, searchParam]
      ),
    ]);

    res.json({
      listings: rows.rows.map((r) => ({
        id: r.id,
        title: r.title,
        status: r.status,
        city: r.city,
        price: r.price !== null ? Number(r.price) : null,
        viewsCount: r.views_count,
        categoryName: r.category_name,
        clientName: r.client_name,
        createdAt: r.created_at,
      })),
      pagination: pageInfo(page, limit, Number(count.rows[0].total)),
    });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/admin/listings/:id/cancel
 * Qoidabuzarlik qilgan e'lonni bekor qiladi (moderatsiya). Faqat "open" holatdagi e'lon uchun —
 * jarayondagi/yakunlangan e'lonlar buyurtma tarixi bilan bog'liq, shuning uchun tegilmaydi.
 */
async function cancelListing(req, res, next) {
  try {
    const { id } = req.params;
    const listing = (await query('SELECT * FROM listings WHERE id = $1', [id])).rows[0];
    if (!listing) return res.status(404).json({ error: 'E\'lon topilmadi' });
    if (listing.status !== 'open') {
      return res.status(400).json({ error: 'Faqat ochiq e\'lonni bekor qilish mumkin' });
    }

    await query(`UPDATE listings SET status = 'cancelled' WHERE id = $1`, [id]);
    await notifyUser(listing.client_id, {
      type: 'system',
      title: 'E\'loningiz bekor qilindi',
      body: `"${listing.title}" e'loni moderator tomonidan qoidalarga zid deb topilib, bekor qilindi`,
      data: { listingId: id },
    });

    res.json({ message: 'E\'lon bekor qilindi' });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/admin/categories — nofaol kategoriyalar bilan birga
 */
async function listCategories(req, res, next) {
  try {
    const result = await query(
      `SELECT id, name_uz, name_ru, icon, sort_order, is_active, parent_id
       FROM categories ORDER BY sort_order ASC, id ASC`
    );
    res.json({ categories: result.rows.map(toAdminCategory) });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/admin/categories
 */
async function createCategory(req, res, next) {
  try {
    const { nameUz, nameRu, icon, sortOrder } = req.body;
    const result = await query(
      `INSERT INTO categories (name_uz, name_ru, icon, sort_order) VALUES ($1, $2, $3, $4) RETURNING *`,
      [nameUz, nameRu || null, icon || null, sortOrder]
    );
    res.status(201).json({ message: 'Kategoriya qo\'shildi', category: toAdminCategory(result.rows[0]) });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/admin/categories/:id
 */
async function updateCategory(req, res, next) {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error: 'Kategoriya ID noto\'g\'ri' });

    const map = { nameUz: 'name_uz', nameRu: 'name_ru', icon: 'icon', sortOrder: 'sort_order', isActive: 'is_active' };
    const fields = [];
    const params = [];
    let idx = 1;
    for (const [key, column] of Object.entries(map)) {
      if (req.body[key] !== undefined) {
        fields.push(`${column} = $${idx++}`);
        params.push(req.body[key] === '' ? null : req.body[key]);
      }
    }
    params.push(id);

    const result = await query(`UPDATE categories SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`, params);
    if (!result.rows[0]) return res.status(404).json({ error: 'Kategoriya topilmadi' });

    res.json({ message: 'Kategoriya yangilandi', category: toAdminCategory(result.rows[0]) });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getStats,
  listUsers,
  setUserActive,
  verifyProvider,
  listListings,
  cancelListing,
  listCategories,
  createCategory,
  updateCategory,
};
