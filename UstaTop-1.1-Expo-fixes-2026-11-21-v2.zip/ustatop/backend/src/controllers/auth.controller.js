const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { query, getClient } = require('../config/db');
const { createOtp, consumeOtp } = require('../utils/otp');
const { disconnectSockets } = require('../config/socket');
const { sendSms } = require('../utils/sms');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');

const PASSWORD_SALT_ROUNDS = 12;

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function developmentOtpField(code) {
  return process.env.NODE_ENV !== 'production' && (process.env.SMS_PROVIDER || 'console') === 'console'
    ? { debugCode: code }
    : {};
}

function toPublicUser(user) {
  return {
    id: user.id,
    phone: user.phone,
    email: user.email,
    fullName: user.full_name,
    role: user.role,
    avatarUrl: user.avatar_url,
    city: user.city,
    isPhoneVerified: user.is_phone_verified,
    isEmailVerified: user.is_email_verified,
  };
}

/**
 * Yangi sessiya ochadi: refresh_tokens qatorining id'si (sid) ikkala tokenga ham yoziladi,
 * shunda logout qilingan sessiyaning access tokeni ham darhol ishlamay qoladi.
 * db — tranzaksiya ichida chaqirilsa client, aks holda umumiy pool.
 */
async function issueTokenPair(user, deviceInfo, db = { query }) {
  const sessionId = crypto.randomUUID();
  const accessToken = signAccessToken({
    sub: user.id,
    role: user.role,
    sid: sessionId,
    ver: user.token_version ?? 0,
  });
  const refreshToken = signRefreshToken({ sub: user.id, sid: sessionId });

  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 kun
  await db.query(
    `INSERT INTO refresh_tokens (id, user_id, token_hash, device_info, expires_at) VALUES ($1, $2, $3, $4, $5)`,
    [sessionId, user.id, hashToken(refreshToken), deviceInfo || null, expiresAt]
  );

  return { accessToken, refreshToken };
}


// Faqat avtomatlashtirilgan eski testlar uchun. Ishlab chiqarish va development muhitida
// bu endpoint hisob yaratmaydi; real foydalanuvchilar OTP oqimidan o'tishi shart.
async function registerTestOnly(req, res, next) {
  if (process.env.NODE_ENV !== 'test') return res.status(410).json({ error: 'Eski ro\'yxatdan o\'tish API o\'chirilgan. SMS OTP oqimidan foydalaning.' });
  try {
    const { fullName, phone, email, password } = req.body;
    const existingPhone = await query('SELECT id FROM users WHERE phone = $1', [phone]);
    if (existingPhone.rows[0]) return res.status(409).json({ error: 'Bu telefon raqam bilan foydalanuvchi allaqachon ro\'yxatdan o\'tgan' });
    if (email) {
      const existingEmail = await query('SELECT id FROM users WHERE email = $1', [email]);
      if (existingEmail.rows[0]) return res.status(409).json({ error: 'Bu email bilan foydalanuvchi allaqachon ro\'yxatdan o\'tgan' });
    }
    const passwordHash = await bcrypt.hash(password, PASSWORD_SALT_ROUNDS);
    const result = await query(
      `INSERT INTO users (phone, email, password_hash, full_name, is_phone_verified) VALUES ($1, $2, $3, $4, TRUE) RETURNING *`,
      [phone, email || null, passwordHash, fullName.trim()]
    );
    const user = result.rows[0];
    const tokens = await issueTokenPair(user, req.headers['user-agent']);
    res.status(201).json({ message: 'Test foydalanuvchisi yaratildi', user: toPublicUser(user), ...tokens });
  } catch (err) { next(err); }
}

/**
 * Ro'yxatdan o'tishning birinchi bosqichi: vaqtinchalik ma'lumotlarni saqlab, SMS OTP yuboradi.
 * Foydalanuvchi OTP tasdiqlamaguncha users jadvalida hisob yaratilmaydi.
 */
async function requestRegistrationCode(req, res, next) {
  try {
    const { fullName, phone, password } = req.body;
    await query('DELETE FROM pending_registrations WHERE expires_at < now()');
    const existing = await query('SELECT id FROM users WHERE phone = $1', [phone]);
    if (existing.rows[0]) return res.status(409).json({ error: 'Bu telefon raqam allaqachon ro\'yxatdan o\'tgan' });

    const { code, expiresInMinutes } = await createOtp(phone, 'signup_verify');
    await sendSms(phone, `UstaTop ro\'yxatdan o\'tish kodi: ${code}. Kod ${expiresInMinutes} daqiqa amal qiladi.`);
    const passwordHash = await bcrypt.hash(password, PASSWORD_SALT_ROUNDS);
    await query(
      `INSERT INTO pending_registrations (phone, full_name, password_hash, expires_at)
       VALUES ($1, $2, $3, now() + interval '15 minutes')
       ON CONFLICT (phone) DO UPDATE SET full_name = EXCLUDED.full_name, password_hash = EXCLUDED.password_hash,
         expires_at = EXCLUDED.expires_at, created_at = now()`,
      [phone, fullName.trim(), passwordHash]
    );
    res.status(200).json({ message: 'SMS tasdiqlash kodi yuborildi', requiresPhoneVerification: true, phone, expiresInMinutes, ...developmentOtpField(code) });
  } catch (err) { next(err); }
}

/** OTP tasdiqlangandan keyingina doimiy foydalanuvchi hisobi yaratiladi. */
async function verifyRegistrationCode(req, res, next) {
  const client = await getClient();
  let inTransaction = false;
  try {
    const { phone, code } = req.body;
    await client.query('BEGIN');
    inTransaction = true;
    const verified = await consumeOtp(client, phone, code, 'signup_verify');
    if (!verified.valid) {
      await client.query('COMMIT'); inTransaction = false;
      return res.status(400).json({ error: verified.reason });
    }
    const pendingResult = await client.query(
      'SELECT * FROM pending_registrations WHERE phone = $1 AND expires_at > now() FOR UPDATE', [phone]
    );
    const pending = pendingResult.rows[0];
    if (!pending) {
      await client.query('ROLLBACK'); inTransaction = false;
      return res.status(400).json({ error: 'Ro\'yxatdan o\'tish muddati tugagan. Yangi kod so\'rang.' });
    }
    const inserted = await client.query(
      `INSERT INTO users (phone, email, password_hash, full_name, is_phone_verified)
       VALUES ($1, NULL, $2, $3, TRUE) RETURNING *`,
      [phone, pending.password_hash, pending.full_name]
    );
    await client.query('DELETE FROM pending_registrations WHERE phone = $1', [phone]);
    const user = inserted.rows[0];
    const tokens = await issueTokenPair(user, req.headers['user-agent'], client);
    await client.query('COMMIT'); inTransaction = false;
    res.status(201).json({ message: 'Telefon raqami tasdiqlandi. Ro\'yxatdan muvaffaqiyatli o\'tdingiz.', user: toPublicUser(user), ...tokens });
  } catch (err) {
    if (inTransaction) { try { await client.query('ROLLBACK'); } catch (_) {} }
    if (err.code === '23505') return res.status(409).json({ error: 'Bu telefon raqam allaqachon ro\'yxatdan o\'tgan' });
    next(err);
  } finally { client.release(); }
}

/**
 * POST /api/auth/login
 * body: { identifier, password }
 * identifier — faqat +998 formatidagi telefon raqami.
 */
async function login(req, res, next) {
  try {
    const { identifier, password } = req.body;
    const isEmailTestOnly = process.env.NODE_ENV === 'test' && identifier.includes('@');
    const phone = identifier;
    const result = await query(isEmailTestOnly ? 'SELECT * FROM users WHERE email = $1' : 'SELECT * FROM users WHERE phone = $1', [phone]);
    const user = result.rows[0];
    const genericError = () => res.status(401).json({ error: 'Telefon raqam yoki parol noto\'g\'ri' });
    if (!user) return genericError();
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return genericError();
    if (!user.is_active) return res.status(403).json({ error: 'Hisobingiz bloklangan. Qo\'llab-quvvatlash xizmatiga murojaat qiling.' });

    // Eski hisoblar ham bir martalik SMS tasdig'idan o'tmaguncha sessiya olmaydi.
    if (!user.is_phone_verified) {
      const { code, expiresInMinutes } = await createOtp(phone, 'phone_verify');
      await sendSms(phone, `UstaTop telefon tasdiqlash kodi: ${code}. Kod ${expiresInMinutes} daqiqa amal qiladi.`);
      return res.status(202).json({ requiresPhoneVerification: true, phone, expiresInMinutes, message: 'Kirishni yakunlash uchun SMS kodni kiriting', ...developmentOtpField(code) });
    }

    const tokens = await issueTokenPair(user, req.headers['user-agent']);
    res.json({ message: 'Xush kelibsiz!', user: toPublicUser(user), ...tokens });
  } catch (err) { next(err); }
}

async function verifyLoginPhone(req, res, next) {
  const client = await getClient();
  let inTransaction = false;
  try {
    const { phone, code } = req.body;
    await client.query('BEGIN'); inTransaction = true;
    const verified = await consumeOtp(client, phone, code, 'phone_verify');
    if (!verified.valid) { await client.query('COMMIT'); inTransaction = false; return res.status(400).json({ error: verified.reason }); }
    const result = await client.query('UPDATE users SET is_phone_verified = TRUE WHERE phone = $1 AND is_active = TRUE RETURNING *', [phone]);
    const user = result.rows[0];
    if (!user) { await client.query('ROLLBACK'); inTransaction = false; return res.status(400).json({ error: 'Hisob topilmadi yoki faol emas' }); }
    const tokens = await issueTokenPair(user, req.headers['user-agent'], client);
    await client.query('COMMIT'); inTransaction = false;
    res.json({ message: 'Telefon raqami tasdiqlandi', user: toPublicUser(user), ...tokens });
  } catch (err) {
    if (inTransaction) { try { await client.query('ROLLBACK'); } catch (_) {} }
    next(err);
  } finally { client.release(); }
}

const FORGOT_PASSWORD_GENERIC_MESSAGE = 'Agar bu raqam ro\'yxatdan o\'tgan bo\'lsa, tasdiqlash kodi yuborildi';
const OTP_EXPIRES_MINUTES = 5;
// Mavjud bo'lmagan raqamda ham bcrypt ishlatiladi — javob vaqti farqi kamayadi
const DUMMY_HASH = bcrypt.hashSync('ustatop-dummy-otp', 10);

/**
 * POST /api/auth/forgot-password/send-code
 * body: { phone }
 * Javob raqam ro'yxatdan o'tgan-o'tmaganidan qat'i nazar bir xil bo'ladi (status, matn, maydonlar).
 */
async function forgotPasswordSendCode(req, res, next) {
  try {
    const { phone } = req.body;

    const userResult = await query('SELECT id FROM users WHERE phone = $1', [phone]);
    if (!userResult.rows[0]) {
      await bcrypt.compare('00000', DUMMY_HASH);
    } else {
      try {
        const { code } = await createOtp(phone, 'password_reset');
        await sendSms(phone, `UstaTop: parolni tiklash kodi — ${code}. Kodni hech kimga bermang.`);
      } catch (err) {
        // Qayta yuborish cheklovi (429) yoki SMS xatosi tashqariga boshqacha javob bo'lib chiqmasligi kerak
        if (err.status !== 429) console.error('[AUTH] Parol tiklash kodi yuborilmadi:', err.message);
      }
    }

    res.json({ message: FORGOT_PASSWORD_GENERIC_MESSAGE, expiresInMinutes: OTP_EXPIRES_MINUTES });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/forgot-password/reset
 * body: { phone, code, newPassword }
 * Kod tekshiruvi, kodni "ishlatilgan" deb belgilash, parolni yangilash va barcha
 * sessiyalarni bekor qilish BITTA tranzaksiyada bajariladi.
 */
async function forgotPasswordReset(req, res, next) {
  const client = await getClient();
  let inTransaction = false;
  try {
    const { phone, code, newPassword } = req.body;

    await client.query('BEGIN');
    inTransaction = true;

    const result = await consumeOtp(client, phone, code, 'password_reset');
    if (!result.valid) {
      await client.query('COMMIT'); // noto'g'ri urinishlar hisobi saqlanadi
      inTransaction = false;
      return res.status(400).json({ error: result.reason });
    }

    const userResult = await client.query('SELECT id FROM users WHERE phone = $1', [phone]);
    const user = userResult.rows[0];
    if (!user) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(400).json({ error: 'Kod noto\'g\'ri yoki muddati tugagan' });
    }

    const passwordHash = await bcrypt.hash(newPassword, PASSWORD_SALT_ROUNDS);
    await client.query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, user.id]);
    // Barcha refresh tokenlar va (token_version orqali) barcha access tokenlar bekor qilinadi
    await client.query('UPDATE refresh_tokens SET revoked = TRUE WHERE user_id = $1', [user.id]);
    await client.query('UPDATE users SET token_version = token_version + 1 WHERE id = $1', [user.id]);
    await client.query('COMMIT');
    inTransaction = false;

    disconnectSockets(req.app.get('io'), { userId: user.id });

    res.json({ message: 'Parolingiz muvaffaqiyatli yangilandi. Endi yangi parol bilan kiring.' });
  } catch (err) {
    if (inTransaction) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    next(err);
  } finally {
    client.release();
  }
}

/**
 * POST /api/auth/refresh
 * body: { refreshToken }
 * Rotatsiya atomik: eski token faqat bitta so'rovda "almashtirilgan" deb belgilanadi.
 * Allaqachon almashtirilgan token qayta kelsa (replay) — foydalanuvchining barcha
 * sessiyalari va access tokenlari bekor qilinadi.
 */
async function refresh(req, res, next) {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken talab qilinadi' });

  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    return res.status(401).json({ error: 'Refresh token yaroqsiz yoki muddati tugagan' });
  }

  const tokenHash = hashToken(refreshToken);
  const client = await getClient();
  let inTransaction = false;
  try {
    await client.query('BEGIN');
    inTransaction = true;

    const rotated = await client.query(
      `UPDATE refresh_tokens SET revoked = TRUE, rotated_at = now()
       WHERE user_id = $1 AND token_hash = $2 AND revoked = FALSE AND expires_at > now()
       RETURNING id`,
      [payload.sub, tokenHash]
    );

    if (!rotated.rows[0]) {
      const reused = await client.query(
        'SELECT id FROM refresh_tokens WHERE user_id = $1 AND token_hash = $2 AND rotated_at IS NOT NULL',
        [payload.sub, tokenHash]
      );
      if (reused.rows[0]) {
        await client.query('UPDATE refresh_tokens SET revoked = TRUE WHERE user_id = $1', [payload.sub]);
        await client.query('UPDATE users SET token_version = token_version + 1 WHERE id = $1', [payload.sub]);
        await client.query('COMMIT');
        inTransaction = false;
        disconnectSockets(req.app.get('io'), { userId: payload.sub });
        return res.status(401).json({ error: 'Sessiya xavfsizlik sababli yopildi, qaytadan kiring', code: 'REFRESH_REUSED' });
      }
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(401).json({ error: 'Sessiya tugagan, qaytadan kiring' });
    }

    const userResult = await client.query('SELECT * FROM users WHERE id = $1', [payload.sub]);
    const user = userResult.rows[0];
    if (!user || !user.is_active) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(401).json({ error: 'Foydalanuvchi topilmadi' });
    }
    if (!user.is_phone_verified) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(401).json({ error: 'Telefon raqamingizni SMS orqali tasdiqlang va qayta kiring', code: 'PHONE_VERIFICATION_REQUIRED' });
    }

    const tokens = await issueTokenPair(user, req.headers['user-agent'], client);
    await client.query('COMMIT');
    inTransaction = false;

    res.json(tokens);
  } catch (err) {
    if (inTransaction) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    next(err);
  } finally {
    client.release();
  }
}

/**
 * POST /api/auth/logout
 * body: { refreshToken }
 * Shu qurilma sessiyasi bekor qilinadi: refresh token, unga bog'langan access token
 * (sid orqali) va shu sessiyaning ochiq socket ulanishlari.
 */
async function logout(req, res, next) {
  try {
    const { refreshToken } = req.body || {};
    if (refreshToken) {
      const revoked = await query(
        'UPDATE refresh_tokens SET revoked = TRUE WHERE token_hash = $1 RETURNING id, user_id',
        [hashToken(refreshToken)]
      );
      for (const row of revoked.rows) {
        disconnectSockets(req.app.get('io'), { sessionId: row.id });
      }
    }
    res.json({ message: 'Chiqildi' });
  } catch (err) {
    next(err);
  }
}

module.exports = { registerTestOnly, requestRegistrationCode, verifyRegistrationCode, login, verifyLoginPhone, forgotPasswordSendCode, forgotPasswordReset, refresh, logout };
