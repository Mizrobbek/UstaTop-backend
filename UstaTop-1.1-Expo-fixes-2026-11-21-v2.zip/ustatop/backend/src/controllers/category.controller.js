const { query } = require('../config/db');

/**
 * GET /api/categories
 * Barcha faol kategoriyalarni qaytaradi (tekis ro'yxat - frontend kerak bo'lsa
 * parent_id orqali daraxtga yig'ib oladi).
 */
async function listCategories(req, res, next) {
  try {
    const result = await query(
      `SELECT id, parent_id, name_uz, name_ru, icon, sort_order
       FROM categories WHERE is_active = TRUE ORDER BY sort_order ASC, id ASC`
    );
    res.json({ categories: result.rows });
  } catch (err) {
    next(err);
  }
}

module.exports = { listCategories };
