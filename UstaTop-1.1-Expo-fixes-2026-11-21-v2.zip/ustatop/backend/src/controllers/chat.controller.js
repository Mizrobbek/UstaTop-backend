const { query } = require('../config/db');
const { notifyUser } = require('../utils/notify');

function toPublicChat(row, currentUserId) {
  const isClient = row.client_id === currentUserId;
  return {
    id: row.id,
    listingId: row.listing_id,
    listingTitle: row.listing_title,
    otherUser: {
      id: isClient ? row.provider_id : row.client_id,
      fullName: isClient ? row.provider_name : row.client_name,
      avatarUrl: isClient ? row.provider_avatar : row.client_avatar,
    },
    lastMessage: row.last_message_content,
    lastMessageAt: row.last_message_at,
    unreadCount: Number(row.unread_count || 0),
    createdAt: row.created_at,
  };
}

function toPublicMessage(row) {
  return {
    id: row.id,
    chatId: row.chat_id,
    senderId: row.sender_id,
    content: row.content,
    mediaUrl: row.media_url,
    isRead: row.is_read,
    createdAt: row.created_at,
  };
}

/**
 * GET /api/chats
 * Kirgan foydalanuvchining barcha suhbatlari (mijoz yoki usta sifatida), so'nggi
 * xabar va o'qilmagan xabarlar soni bilan.
 */
async function listChats(req, res, next) {
  try {
    const result = await query(
      `SELECT c.*, l.title AS listing_title,
              cu.full_name AS client_name, cu.avatar_url AS client_avatar,
              pu.full_name AS provider_name, pu.avatar_url AS provider_avatar,
              lm.content AS last_message_content, lm.created_at AS last_message_at,
              (SELECT COUNT(*) FROM messages m WHERE m.chat_id = c.id AND m.sender_id != $1 AND m.is_read = FALSE) AS unread_count
       FROM chats c
       LEFT JOIN listings l ON l.id = c.listing_id
       JOIN users cu ON cu.id = c.client_id
       JOIN users pu ON pu.id = c.provider_id
       LEFT JOIN LATERAL (
         SELECT content, created_at FROM messages WHERE chat_id = c.id ORDER BY created_at DESC LIMIT 1
       ) lm ON TRUE
       WHERE c.client_id = $1 OR c.provider_id = $1
       ORDER BY COALESCE(lm.created_at, c.created_at) DESC`,
      [req.user.id]
    );

    res.json({ chats: result.rows.map((row) => toPublicChat(row, req.user.id)) });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/chats/:id/messages?before=&limit=
 * Xabarlar tarixi, eskisidan yangisiga saralangan (frontend'da to'g'ridan-to'g'ri
 * ro'yxat qilib chizish uchun qulay). "before" berilsa, shu sanadan OLDINGI
 * xabarlarni qaytaradi (yuqoriga scroll qilib eski xabarlarni yuklash uchun).
 */
async function getMessages(req, res, next) {
  try {
    const { id: chatId } = req.params;
    const { before, limit } = req.query;

    const chatResult = await query('SELECT * FROM chats WHERE id = $1', [chatId]);
    const chat = chatResult.rows[0];
    if (!chat) return res.status(404).json({ error: 'Suhbat topilmadi' });
    if (chat.client_id !== req.user.id && chat.provider_id !== req.user.id) {
      return res.status(403).json({ error: 'Bu suhbatga kirish huquqingiz yo\'q' });
    }

    const params = [chatId];
    let whereExtra = '';
    if (before) {
      params.push(before);
      whereExtra = 'AND created_at < $2';
    }
    params.push(limit);

    const result = await query(
      `SELECT * FROM messages WHERE chat_id = $1 ${whereExtra} ORDER BY created_at DESC LIMIT $${params.length}`,
      params
    );

    // O'qilmagan (boshqa tomondan kelgan) xabarlarni "o'qilgan" deb belgilaymiz
    await query(`UPDATE messages SET is_read = TRUE WHERE chat_id = $1 AND sender_id != $2 AND is_read = FALSE`, [
      chatId,
      req.user.id,
    ]);

    res.json({
      messages: result.rows.reverse().map(toPublicMessage), // eskisidan yangisiga
      chat: {
        id: chat.id,
        listingId: chat.listing_id,
        clientId: chat.client_id,
        providerId: chat.provider_id,
      },
    });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/chats/:id/messages
 * Xabar yuboradi (REST orqali - Socket.io ulanmagan holatlarda ham ishlashi uchun
 * zaxira yo'l; asosiy real-vaqt yetkazish socket.js orqali amalga oshadi).
 */
async function sendMessage(req, res, next) {
  try {
    const { id: chatId } = req.params;
    const { content, mediaUrl } = req.body;

    const chatResult = await query('SELECT * FROM chats WHERE id = $1', [chatId]);
    const chat = chatResult.rows[0];
    if (!chat) return res.status(404).json({ error: 'Suhbat topilmadi' });
    if (chat.client_id !== req.user.id && chat.provider_id !== req.user.id) {
      return res.status(403).json({ error: 'Bu suhbatga xabar yubora olmaysiz' });
    }

    const result = await query(
      `INSERT INTO messages (chat_id, sender_id, content, media_url) VALUES ($1, $2, $3, $4) RETURNING *`,
      [chatId, req.user.id, content || null, mediaUrl || null]
    );
    const message = toPublicMessage(result.rows[0]);

    const recipientId = chat.client_id === req.user.id ? chat.provider_id : chat.client_id;
    await notifyUser(recipientId, {
      type: 'new_message',
      title: 'Yangi xabar',
      body: content ? content.slice(0, 100) : 'Fayl yubordi',
      data: { chatId },
    });

    // Socket.io orqali real vaqtda ikkala tomonga ham yetkazamiz (agar ulangan bo'lsa)
    const io = req.app.get('io');
    if (io) {
      io.to(`chat:${chatId}`).emit('message:new', message);
    }

    res.status(201).json({ message });
  } catch (err) {
    next(err);
  }
}

module.exports = { listChats, getMessages, sendMessage };
