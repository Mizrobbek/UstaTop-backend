const { query } = require('../config/db');
const { transaction } = require('../services/commission');
function page(req) {
  const p = Number(req.query.page || 1);
  if (!Number.isInteger(p) || p<1 || p>100000) { const e=new Error('Sahifa noto‘g‘ri'); e.status=400; throw e; }
  return p;
}
function publicCharge(r) {
  return { id:r.id,orderId:r.order_id,rate:r.rate,baseAmount:r.base_amount,amount:r.amount,
    totalAmount:r.total_amount,balance:r.balance,currency:r.currency,calculatedAt:r.calculated_at,
    status:Number(r.balance)>0?'pending':'paid' };
}
async function mySummary(req,res,next) {
 try {
  const r=(await query(`SELECT COALESCE(SUM(balance),0)::text AS debt,
    COUNT(*) FILTER(WHERE balance>0)::int AS unpaid_count FROM commission_balances WHERE provider_id=$1`,[req.user.id])).rows[0];
  res.json({debt:r.debt,currency:'UZS',unpaidCount:r.unpaid_count,blocked:Number(r.debt)>0});
 } catch(e){next(e);}
}
async function myHistory(req,res,next) {
 try {
  const p=page(req);
  const r=await query(`SELECT * FROM commission_balances WHERE provider_id=$1 ORDER BY calculated_at DESC,id DESC LIMIT 50 OFFSET $2`,[req.user.id,(p-1)*50]);
  res.json({commissions:r.rows.map(publicCharge),page:p});
 } catch(e){next(e);}
}
async function tariffs(req,res,next) {
 try {
  const [t,a]=await Promise.all([
   query(`SELECT t.*,c.name_uz AS category_name FROM commission_tariffs t LEFT JOIN categories c ON c.id=t.category_id ORDER BY scope_key`),
   query(`SELECT a.*,u.full_name AS actor_name FROM commission_tariff_audit a JOIN users u ON u.id=a.actor_id ORDER BY created_at DESC,id DESC LIMIT 100`)
  ]);
  res.json({tariffs:t.rows,audit:a.rows});
 } catch(e){next(e);}
}
async function updateTariff(req,res,next) {
 try {
  const key=req.params.scope==='global'?0:Number(req.params.scope);
  const rate=req.body.rate;
  if (!Number.isInteger(key)||key<0|| (rate===null?key===0:typeof rate!=='number'||!Number.isFinite(rate)||rate<0||rate>100||Math.round(rate*100)!==rate*100)
    ||Object.keys(req.body).some(k=>k!=='rate')) return res.status(400).json({error:'Stavka 0–100%, ko‘pi bilan 2 kasr xonasi; kategoriya uchun null — umumiy tarif'});
  const t=await transaction(async client=>{
   await client.query('SELECT scope_key FROM commission_tariffs WHERE scope_key=0 FOR UPDATE');
   if(key>0 && !(await client.query('SELECT id FROM categories WHERE id=$1',[key])).rows[0]) {const e=new Error('Kategoriya topilmadi');e.status=404;throw e;}
   const old=(await client.query('SELECT rate FROM commission_tariffs WHERE scope_key=$1',[key])).rows[0];
   const saved=(await client.query(`INSERT INTO commission_tariffs(scope_key,category_id,rate) VALUES($1,$2,$3)
    ON CONFLICT(scope_key) DO UPDATE SET rate=EXCLUDED.rate,updated_at=now() RETURNING *`,[key,key||null,rate])).rows[0];
   await client.query('INSERT INTO commission_tariff_audit(scope_key,actor_id,old_rate,new_rate) VALUES($1,$2,$3,$4)',[key,req.user.id,old?.rate??null,rate]);
   return saved;
  });
  res.json({tariff:t});
 } catch(e){next(e);}
}
async function adminHistory(req,res,next) {
 try {
  const p=page(req);
  const r=await query(`SELECT b.*,u.full_name AS provider_name FROM commission_balances b JOIN users u ON u.id=b.provider_id
   ORDER BY b.calculated_at DESC,b.id DESC LIMIT 50 OFFSET $1`,[(p-1)*50]);
  res.json({commissions:r.rows.map(r=>({...publicCharge(r),providerId:r.provider_id,providerName:r.provider_name})),page:p});
 } catch(e){next(e);}
}
module.exports={mySummary,myHistory,tariffs,updateTariff,adminHistory};
