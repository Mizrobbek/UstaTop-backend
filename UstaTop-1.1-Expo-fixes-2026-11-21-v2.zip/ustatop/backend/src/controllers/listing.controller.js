const { query, getClient } = require('../config/db');
const { haversineKm } = require('../utils/geo');

function toPublicListing(row) {
  return {
    id: row.id,
    clientId: row.client_id,
    categoryId: row.category_id,
    categoryName: row.category_name,
    title: row.title,
    description: row.description,
    price: row.price !== null ? Number(row.price) : null,
    priceType: row.price_type,
    address: row.address,
    city: row.city,
    latitude: row.latitude,
    longitude: row.longitude,
    status: row.status,
    viewsCount: row.views_count,
    offersCount: row.offers_count !== undefined ? Number(row.offers_count) : undefined,
    media: row.media || [],
    clientName: row.client_name,
    clientAvatar: row.client_avatar,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

/**
 * POST /api/listings
 * Mijoz yangi e'lon (buyurtma so'rovi) yaratadi.
 */
async function createListing(req, res, next) {
  const client = await getClient();
  try {
    const { categoryId, title, description, price, priceType, address, city, latitude, longitude, mediaUrls } =
      req.body;

    if (Array.isArray(mediaUrls) && (mediaUrls.length > 10 || mediaUrls.some((url) => typeof url !== 'string' || !url.includes('/uploads/')))) return res.status(400).json({ error: 'E’lon uchun 10 tagacha serverga yuklangan rasm biriktirish mumkin' });

    if (priceType === 'fixed' && (price === undefined || price === null)) {
      return res.status(400).json({ error: 'Narx turi "belgilangan" bo\'lsa, narx kiritilishi shart' });
    }

    const categoryCheck = await query('SELECT id FROM categories WHERE id = $1 AND is_active = TRUE', [categoryId]);
    if (!categoryCheck.rows[0]) {
      return res.status(400).json({ error: 'Bunday kategoriya topilmadi' });
    }

    await client.query('BEGIN');

    const insertResult = await client.query(
      `INSERT INTO listings (client_id, category_id, title, description, price, price_type, address, city, latitude, longitude)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [
        req.user.id,
        categoryId,
        title.trim(),
        description.trim(),
        price ?? null,
        priceType || 'negotiable',
        address || null,
        city || 'Toshkent',
        latitude ?? null,
        longitude ?? null,
      ]
    );
    const listing = insertResult.rows[0];

    if (Array.isArray(mediaUrls) && mediaUrls.length > 0) {
      for (let i = 0; i < mediaUrls.length; i++) {
        await client.query(
          `INSERT INTO listing_media (listing_id, url, type, sort_order) VALUES ($1, $2, 'image', $3)`,
          [listing.id, mediaUrls[i], i]
        );
      }
    }

    await client.query('COMMIT');

    res.status(201).json({
      message: 'E\'lon muvaffaqiyatli yaratildi',
      listing: toPublicListing({ ...listing, media: mediaUrls || [] }),
    });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
}

/**
 * GET /api/listings
 * Filtrlash: categoryId, city, status, search (sarlavha/tavsif bo'yicha),
 * lat/lng+radiusKm (yaqin atrofdagilar), sahifalash (page, limit).
 */
async function listListings(req, res, next) {
  try {
    const { categoryId, city, status, search, lat, lng, radiusKm, page, limit } = req.query;

    const conditions = [];
    const params = [];
    let idx = 1;

    if (categoryId) {
      conditions.push(`l.category_id = $${idx++}`);
      params.push(categoryId);
    }
    if (city) {
      conditions.push(`l.city ILIKE $${idx++}`);
      params.push(city);
    }
    conditions.push(`l.status = $${idx++}`);
    params.push(status || 'open');

    if (search) {
      conditions.push(`(l.title ILIKE $${idx} OR l.description ILIKE $${idx})`);
      params.push(`%${search}%`);
      idx++;
    }

    // Oddiy "bounding box" orqali geografik masofa filtri (PostGIS ishlatilmagan,
    // chunki hozircha aniqlik darajasi shaharda yetarli; keyinchalik PostGIS'ga o'tish mumkin)
    if (lat !== undefined && lng !== undefined) {
      const latDelta = radiusKm / 111; // taxminan 1 gradus ≈ 111 km
      const lngDelta = radiusKm / (111 * Math.cos((lat * Math.PI) / 180));
      conditions.push(`l.latitude BETWEEN $${idx++} AND $${idx++}`);
      params.push(lat - latDelta, lat + latDelta);
      conditions.push(`l.longitude BETWEEN $${idx++} AND $${idx++}`);
      params.push(lng - lngDelta, lng + lngDelta);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (page - 1) * limit;

    const listResult = await query(
      `SELECT l.*, c.name_uz AS category_name, u.full_name AS client_name, u.avatar_url AS client_avatar,
              (SELECT COUNT(*) FROM offers o WHERE o.listing_id = l.id) AS offers_count,
              COALESCE(
                (SELECT json_agg(m.url ORDER BY m.sort_order) FROM listing_media m WHERE m.listing_id = l.id),
                '[]'
              ) AS media
       FROM listings l
       JOIN categories c ON c.id = l.category_id
       JOIN users u ON u.id = l.client_id
       ${whereClause}
       ORDER BY l.created_at DESC
       LIMIT $${idx++} OFFSET $${idx++}`,
      [...params, limit, offset]
    );

    const countResult = await query(`SELECT COUNT(*) FROM listings l ${whereClause}`, params);

    res.json({
      listings: listResult.rows.map(toPublicListing),
      pagination: {
        page,
        limit,
        total: Number(countResult.rows[0].count),
        totalPages: Math.ceil(Number(countResult.rows[0].count) / limit),
      },
    });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/listings/:id
 * Bitta e'lonni to'liq ma'lumotlar bilan qaytaradi, ko'rishlar sonini oshiradi.
 */
async function getListing(req, res, next) {
  try {
    const { id } = req.params;

    const result = await query(
      `SELECT l.*, c.name_uz AS category_name, u.full_name AS client_name, u.avatar_url AS client_avatar,
              (SELECT COUNT(*) FROM offers o WHERE o.listing_id = l.id) AS offers_count,
              COALESCE(
                (SELECT json_agg(m.url ORDER BY m.sort_order) FROM listing_media m WHERE m.listing_id = l.id),
                '[]'
              ) AS media
       FROM listings l
       JOIN categories c ON c.id = l.category_id
       JOIN users u ON u.id = l.client_id
       WHERE l.id = $1`,
      [id]
    );

    const listing = result.rows[0];
    if (!listing) return res.status(404).json({ error: 'E\'lon topilmadi' });

    // Ko'rishlar sonini oshiramiz (e'lon egasi o'ziniki ko'rsa hisoblanmaydi)
    if (!req.user || req.user.id !== listing.client_id) {
      await query('UPDATE listings SET views_count = views_count + 1 WHERE id = $1', [id]);
      listing.views_count += 1;
    }

    res.json({ listing: toPublicListing(listing) });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/listings/:id
 * Faqat e'lon egasi tahrirlashi mumkin.
 */
async function updateListing(req, res, next) {
  try {
    const { id } = req.params;
    const existing = await query('SELECT * FROM listings WHERE id = $1', [id]);
    const current = existing.rows[0];
    if (!current) return res.status(404).json({ error: 'E\'lon topilmadi' });
    if (current.client_id !== req.user.id) {
      return res.status(403).json({ error: 'Faqat o\'z e\'loningizni tahrirlay olasiz' });
    }
    if (!['open', 'cancelled'].includes(current.status)) {
      return res.status(400).json({ error: 'Jarayondagi yoki yakunlangan e\'lonni tahrirlab bo\'lmaydi' });
    }

    if (req.body.categoryId !== undefined) {
      const category = await query('SELECT id FROM categories WHERE id = $1 AND is_active = TRUE', [req.body.categoryId]);
      if (!category.rows[0]) return res.status(400).json({ error: 'Bunday kategoriya topilmadi' });
    }

    const nextPriceType = req.body.priceType ?? current.price_type;
    const nextPrice = req.body.price !== undefined ? req.body.price : current.price;
    if (nextPriceType === 'fixed' && (nextPrice === undefined || nextPrice === null)) {
      return res.status(400).json({ error: 'Narx turi "belgilangan" bo\'lsa, narx kiritilishi shart' });
    }

    const fields = [];
    const params = [];
    let idx = 1;
    const map = {
      categoryId: 'category_id',
      title: 'title',
      description: 'description',
      price: 'price',
      priceType: 'price_type',
      address: 'address',
      city: 'city',
      latitude: 'latitude',
      longitude: 'longitude',
      status: 'status',
    };
    for (const [key, column] of Object.entries(map)) {
      if (req.body[key] !== undefined) {
        fields.push(`${column} = $${idx++}`);
        params.push(req.body[key]);
      }
    }
    if (Array.isArray(req.body.mediaUrls) && (req.body.mediaUrls.length > 10 || req.body.mediaUrls.some((url) => typeof url !== 'string' || !url.includes('/uploads/')))) return res.status(400).json({ error: 'E’lon uchun 10 tagacha serverga yuklangan rasm biriktirish mumkin' });
    if (fields.length === 0 && !Array.isArray(req.body.mediaUrls)) return res.status(400).json({ error: 'Yangilash uchun hech qanday maydon berilmadi' });
    if (fields.length === 0) fields.push('updated_at = now()');

    params.push(id);
    // Holat sharti UPDATE'ning o'zida qayta tekshiriladi: parallel ravishda taklif qabul
    // qilinib e'lon "in_progress" bo'lgan bo'lsa (qabul qilish e'lon qatorini FOR UPDATE bilan
    // qulflaydi), bu UPDATE hech qaysi qatorga tegmaydi va holat qaytarib yozilmaydi.
    const result = await query(
      `UPDATE listings SET ${fields.join(', ')} WHERE id = $${idx} AND client_id = $${idx + 1} AND status IN ('open', 'cancelled') RETURNING *`,
      [...params, req.user.id]
    );
    if (!result.rows[0]) {
      return res.status(409).json({ error: 'E\'lon holati o\'zgargan (masalan, taklif qabul qilingan). Sahifani yangilang.' });
    }
    if (Array.isArray(req.body.mediaUrls)) {
      await query('DELETE FROM listing_media WHERE listing_id=$1', [id]);
      for (let i=0; i<req.body.mediaUrls.length; i++) await query("INSERT INTO listing_media(listing_id,url,type,sort_order) VALUES($1,$2,'image',$3)", [id, req.body.mediaUrls[i], i]);
    }
    const mediaResult = await query('SELECT url FROM listing_media WHERE listing_id=$1 ORDER BY sort_order', [id]);
    const categoryResult = await query('SELECT name_uz FROM categories WHERE id = $1', [result.rows[0].category_id]);

    res.json({
      message: 'E\'lon yangilandi',
      listing: toPublicListing({ ...result.rows[0], category_name: categoryResult.rows[0]?.name_uz, media: mediaResult.rows.map((r) => r.url) }),
    });
  } catch (err) {
    next(err);
  }
}

/**
 * DELETE /api/listings/:id
 */
async function deleteListing(req, res, next) {
  const client = await getClient();
  let inTransaction = false;
  try {
    const { id } = req.params;
    await client.query('BEGIN');
    inTransaction = true;

    // E'lon qatori qulflanadi — parallel taklif qabul qilish bilan to'qnashmaydi
    const existing = await client.query('SELECT client_id FROM listings WHERE id = $1 FOR UPDATE', [id]);
    if (!existing.rows[0]) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(404).json({ error: 'E\'lon topilmadi' });
    }
    if (existing.rows[0].client_id !== req.user.id) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(403).json({ error: 'Faqat o\'z e\'loningizni o\'chira olasiz' });
    }

    // Buyurtma tarixi (va unga bog'liq to'lov/sharh) bor e'lon o'chirilmaydi
    const history = await client.query('SELECT COUNT(*)::int AS count FROM orders WHERE listing_id = $1', [id]);
    if (Number(history.rows[0].count) > 0) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(409).json({
        error: 'Bu e\'lon bo\'yicha buyurtma tarixi bor, uni o\'chirib bo\'lmaydi. Uning o\'rniga e\'lonni bekor qilishingiz mumkin.',
        code: 'LISTING_HAS_ORDERS',
      });
    }

    await client.query('DELETE FROM listings WHERE id = $1', [id]);
    await client.query('COMMIT');
    inTransaction = false;
    res.json({ message: 'E\'lon o\'chirildi' });
  } catch (err) {
    if (inTransaction) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    next(err);
  } finally {
    client.release();
  }
}

/**
 * GET /api/listings/mine
 * Kirgan foydalanuvchining o'z e'lonlari (mijoz sifatida yaratganlari).
 */
async function myListings(req, res, next) {
  try {
    const result = await query(
      `SELECT l.*, c.name_uz AS category_name,
              (SELECT COUNT(*) FROM offers o WHERE o.listing_id = l.id) AS offers_count,
              COALESCE((SELECT json_agg(m.url ORDER BY m.sort_order) FROM listing_media m WHERE m.listing_id = l.id), '[]') AS media
       FROM listings l JOIN categories c ON c.id = l.category_id
       WHERE l.client_id = $1 ORDER BY l.created_at DESC`,
      [req.user.id]
    );
    res.json({ listings: result.rows.map(toPublicListing) });
  } catch (err) {
    next(err);
  }
}


/**
 * GET /api/listings/map?minLat=&maxLat=&minLng=&maxLng=&categoryId=&userLat=&userLng=&limit=
 * Xarita ekranida ko'rinib turgan hudud (bounding box) ichidagi OCHIQ e'lonlarni yengil
 * (faqat marker uchun kerakli maydonlar) ko'rinishda qaytaradi.
 *
 * Hudud ichida e'lon ko'p bo'lsa, hudud MARKAZIGA eng yaqinlari birinchi olinadi va
 * `truncated: true` qaytadi — mobil ilova "yaqinlashtiring" degan maslahat ko'rsatadi.
 * userLat/userLng berilsa, har bir e'lon uchun `distanceKm` ham hisoblanadi.
 */
async function getMapListings(req, res, next) {
  try {
    const { minLat, maxLat, minLng, maxLng, categoryId, userLat, userLng, limit } = req.query;
    const categoryParam = categoryId || null;
    const centerLat = (minLat + maxLat) / 2;
    const centerLng = (minLng + maxLng) / 2;

    const [rows, count] = await Promise.all([
      query(
        `SELECT l.id, l.title, l.price, l.price_type, l.latitude, l.longitude, l.category_id, l.city, l.created_at,
                c.name_uz AS category_name, c.icon AS category_icon
         FROM listings l JOIN categories c ON c.id = l.category_id
         WHERE l.status = 'open' AND l.latitude BETWEEN $1 AND $2 AND l.longitude BETWEEN $3 AND $4
           AND ($5::int IS NULL OR l.category_id = $5)
         ORDER BY ((l.latitude - $7) * (l.latitude - $7) + (l.longitude - $8) * (l.longitude - $8)) ASC
         LIMIT $6`,
        [minLat, maxLat, minLng, maxLng, categoryParam, limit, centerLat, centerLng]
      ),
      query(
        `SELECT COUNT(*) AS in_view FROM listings l
         WHERE l.status = 'open' AND l.latitude BETWEEN $1 AND $2 AND l.longitude BETWEEN $3 AND $4
           AND ($5::int IS NULL OR l.category_id = $5)`,
        [minLat, maxLat, minLng, maxLng, categoryParam]
      ),
    ]);

    const total = Number(count.rows[0].in_view);
    const hasUser = userLat !== undefined && userLng !== undefined;

    res.json({
      listings: rows.rows.map((r) => ({
        id: r.id,
        title: r.title,
        price: r.price !== null ? Number(r.price) : null,
        priceType: r.price_type,
        latitude: r.latitude,
        longitude: r.longitude,
        categoryId: r.category_id,
        categoryName: r.category_name,
        categoryIcon: r.category_icon,
        city: r.city,
        createdAt: r.created_at,
        distanceKm: hasUser
          ? Math.round(haversineKm(userLat, userLng, r.latitude, r.longitude) * 10) / 10
          : undefined,
      })),
      total,
      truncated: total > rows.rows.length,
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { createListing, listListings, getMapListings, getListing, updateListing, deleteListing, myListings };
