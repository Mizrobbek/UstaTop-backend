const storage = require('../storage');
const fs = require('fs');
const { classifyMimeType } = require('../middleware/mediaTypes');

async function uploadMedia(req, res, next) {
  const files = req.files || (req.file ? [req.file] : []);
  if (!files.length) return res.status(400).json({ error: 'Yuklash uchun fayl tanlanmadi' });

  const uploaded = [];
  try {
    for (const file of files) {
      const saved = await storage.put(file);
      uploaded.push({
        ...saved,
        url: `${req.protocol}://${req.get('host')}${saved.url}`,
        type: classifyMimeType(file.mimetype),
      });
    }
    return res.status(201).json({ files: uploaded });
  } catch (err) {
    // Bir nechta fayldan biri xato bo'lsa, avval saqlangan fayllarni ham tozalaymiz.
    await Promise.all(uploaded.map((file) => storage.remove(file.key).catch(() => {})));
    next(err);
  } finally {
    // storage.put rename qilgan fayllar endi mavjud bo'lmaydi; qolgan vaqtinchalik
    // fayllarni esa har qanday holatda tozalaymiz.
    await Promise.all(files.map((file) => fs.promises.rm(file.path, { force: true }).catch(() => {})));
  }
}

module.exports = { uploadMedia };
