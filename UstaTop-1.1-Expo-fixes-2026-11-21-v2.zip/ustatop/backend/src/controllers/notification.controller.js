const { query } = require('../config/db');
const { isExpoPushToken } = require('../utils/pushNotifications');

function toPublicNotification(row) {
  return {
    id: row.id,
    type: row.type,
    title: row.title,
    body: row.body,
    data: row.data || null,
    isRead: row.is_read,
    createdAt: row.created_at,
  };
}

/**
 * GET /api/notifications?page=&limit=
 */
async function listNotifications(req, res, next) {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20));
    const offset = (page - 1) * limit;

    const [rows, unread] = await Promise.all([
      query(
        `SELECT * FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
        [req.user.id, limit, offset]
      ),
      query(`SELECT COUNT(*) AS count FROM notifications WHERE user_id = $1 AND is_read = FALSE`, [req.user.id]),
    ]);

    res.json({
      notifications: rows.rows.map(toPublicNotification),
      unreadCount: Number(unread.rows[0].count),
    });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/notifications/:id/read
 */
async function markRead(req, res, next) {
  try {
    const { id } = req.params;
    const result = await query(
      `UPDATE notifications SET is_read = TRUE WHERE id = $1 AND user_id = $2 RETURNING id`,
      [id, req.user.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Bildirishnoma topilmadi' });
    res.json({ message: 'Belgilandi' });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/notifications/read-all
 */
async function markAllRead(req, res, next) {
  try {
    await query(`UPDATE notifications SET is_read = TRUE WHERE user_id = $1 AND is_read = FALSE`, [req.user.id]);
    res.json({ message: 'Barchasi o\'qilgan deb belgilandi' });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/users/me/push-token   body: { pushToken: "ExponentPushToken[...]" | null }
 * Mobil ilova har safar ishga tushganda (yoki tokeni yangilanganda) shu yerga yuboradi.
 * `null` yuborilsa, token o'chiriladi (masalan, foydalanuvchi logout qilganda).
 */
async function registerPushToken(req, res, next) {
  try {
    const { pushToken } = req.body;
    if (pushToken && !isExpoPushToken(pushToken)) {
      return res.status(400).json({ error: 'Noto\'g\'ri push token formati' });
    }
    await query('UPDATE users SET push_token = $1 WHERE id = $2', [pushToken || null, req.user.id]);
    res.json({ message: 'Saqlandi' });
  } catch (err) {
    next(err);
  }
}

module.exports = { listNotifications, markRead, markAllRead, registerPushToken };
