const { query, getClient } = require('../config/db');
const { notifyUser } = require('../utils/notify');
const { assertWorkerClear, debtError } = require('../services/commission');

function toPublicOffer(row) {
  return {
    id: row.id,
    listingId: row.listing_id,
    providerId: row.provider_id,
    providerName: row.provider_name,
    providerAvatar: row.provider_avatar,
    providerRating: row.provider_rating !== undefined ? Number(row.provider_rating) : undefined,
    price: Number(row.price),
    message: row.message,
    status: row.status,
    createdAt: row.created_at,
    chatId: row.chat_id,
  };
}

/**
 * POST /api/listings/:id/offers
 * Usta (provider/both) e'longa taklif yuboradi.
 */
async function createOffer(req, res, next) {
  const client = await getClient();
  let inTransaction = false;
  try {
    const { id: listingId } = req.params;
    const { price, message } = req.body;

    await client.query('BEGIN');
    inTransaction = true;

    // E'lon holati tekshiruvi va taklif/chat yaratish bitta tranzaksiyada.
    const listingResult = await client.query('SELECT * FROM listings WHERE id = $1 FOR UPDATE', [listingId]);
    const listing = listingResult.rows[0];
    if (!listing) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(404).json({ error: 'E\'lon topilmadi' });
    }
    if (listing.status !== 'open') {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(400).json({ error: 'Bu e\'lon uchun endi taklif qabul qilinmaydi' });
    }
    if (listing.client_id === req.user.id) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(400).json({ error: 'O\'zingizning e\'loningizga taklif bera olmaysiz' });
    }

    const identityResult = await client.query(
      'SELECT myid_verified FROM provider_profiles WHERE user_id = $1', [req.user.id]
    );
    if (!identityResult.rows[0] || identityResult.rows[0].myid_verified !== true) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(403).json({ error: 'Usta sifatida taklif yuborish uchun MyID orqali shaxsingizni tasdiqlashingiz kerak', code: 'MYID_VERIFICATION_REQUIRED' });
    }

    await assertWorkerClear(client, req.user.id);
    const result = await client.query(
      `INSERT INTO offers (listing_id, provider_id, price, message) VALUES ($1, $2, $3, $4) RETURNING *`,
      [listingId, req.user.id, price, message || null]
    );

    // Muzokara qabul qilishdan OLDIN boshlanishi uchun chat taklif bilan birga ochiladi.
    const chatResult = await client.query(
      `INSERT INTO chats (listing_id, client_id, provider_id) VALUES ($1, $2, $3)
       ON CONFLICT (listing_id, client_id, provider_id) DO UPDATE SET listing_id = EXCLUDED.listing_id
       RETURNING *`,
      [listingId, listing.client_id, req.user.id]
    );

    await client.query('COMMIT');
    inTransaction = false;

    await notifyUser(listing.client_id, {
      type: 'new_offer',
      title: 'Yangi taklif',
      body: `"${listing.title}" e'loningizga yangi taklif keldi. Usta bilan chatda narxni kelishishingiz mumkin.`,
      data: { listingId, offerId: result.rows[0].id, chatId: chatResult.rows[0].id },
    });

    res.status(201).json({
      message: 'Taklif yuborildi',
      offer: toPublicOffer(result.rows[0]),
      chatId: chatResult.rows[0].id,
    });
  } catch (err) {
    if (inTransaction) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    if (debtError(err, res, true)) return;
    if (err.code === '23505') {
      return res.status(409).json({ error: 'Bu e’lon uchun avval taklif yuborgansiz' });
    }
    next(err);
  } finally {
    client.release();
  }
}

/**
 * GET /api/listings/:id/offers
 * E'lon egasi barcha takliflarni (usta reytingi bilan) ko'radi.
 */
async function listOffersForListing(req, res, next) {
  try {
    const { id: listingId } = req.params;

    const listingResult = await query('SELECT client_id FROM listings WHERE id = $1', [listingId]);
    if (!listingResult.rows[0]) return res.status(404).json({ error: 'E\'lon topilmadi' });
    if (listingResult.rows[0].client_id !== req.user.id) {
      return res.status(403).json({ error: 'Faqat e\'lon egasi takliflarni ko\'ra oladi' });
    }

    const result = await query(
      `SELECT o.*, u.full_name AS provider_name, u.avatar_url AS provider_avatar,
              COALESCE(pp.rating_avg, 0) AS provider_rating,
              ch.id AS chat_id
       FROM offers o
       JOIN users u ON u.id = o.provider_id
       LEFT JOIN provider_profiles pp ON pp.user_id = o.provider_id
       LEFT JOIN chats ch ON ch.listing_id = o.listing_id
                         AND ch.client_id = (SELECT client_id FROM listings WHERE id = o.listing_id)
                         AND ch.provider_id = o.provider_id
       WHERE o.listing_id = $1
       ORDER BY o.created_at ASC`,
      [listingId]
    );

    res.json({ offers: result.rows.map(toPublicOffer) });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/offers/:id
 * E'lon egasi taklifni qabul qiladi yoki rad etadi.
 *
 * Parallel qabul qilishdan himoya: avval tranzaksiya ochiladi, so'ng listing va offer
 * qatorlari birgalikda qulflanadi. Shu listing uchun ikkinchi qabul so'rovi birinchisi
 * COMMIT bo'lguncha kutadi va keyin listing statusini qayta tekshiradi.
 */
async function updateOfferStatus(req, res, next) {
  const { id: offerId } = req.params;
  const { status } = req.body;
  if (!['accepted', 'rejected'].includes(status)) {
    return res.status(400).json({ error: 'status "accepted" yoki "rejected" bo\'lishi kerak' });
  }

  const client = await getClient();
  let inTransaction = false;

  try {
    await client.query('BEGIN');
    inTransaction = true;

    // Listing locki bitta e'lon uchun bir vaqtning o'zida faqat bitta taklif qabul
    // qilinishini ta'minlaydi. Offer ham qulflanadi, shunda status parallel o'zgarmaydi.
    const offerResult = await client.query(
      `SELECT o.*, l.client_id, l.title, l.status AS listing_status
       FROM offers o
       JOIN listings l ON l.id = o.listing_id
       WHERE o.id = $1
       FOR UPDATE OF l, o`,
      [offerId]
    );
    const offer = offerResult.rows[0];

    if (!offer) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(404).json({ error: 'Taklif topilmadi' });
    }
    if (offer.client_id !== req.user.id) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(403).json({ error: 'Faqat e\'lon egasi javob bera oladi' });
    }
    if (offer.status !== 'pending') {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(400).json({ error: 'Bu taklif allaqachon ko\'rib chiqilgan' });
    }

    if (status === 'rejected') {
      await client.query('UPDATE offers SET status = $1 WHERE id = $2', ['rejected', offerId]);
      await client.query('COMMIT');
      inTransaction = false;

      await notifyUser(offer.provider_id, {
        type: 'offer_rejected',
        title: 'Taklifingiz rad etildi',
        body: `"${offer.title}" e'loni uchun taklifingiz, afsuski, qabul qilinmadi`,
        data: { listingId: offer.listing_id },
      });
      return res.json({ message: 'Taklif rad etildi' });
    }

    if (offer.listing_status !== 'open') {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(400).json({ error: 'Bu e\'lon uchun boshqa taklif allaqachon qabul qilingan' });
    }

    await assertWorkerClear(client, offer.provider_id);
    await client.query('UPDATE offers SET status = $1 WHERE id = $2', ['accepted', offerId]);
    await client.query(
      `UPDATE offers SET status = 'rejected' WHERE listing_id = $1 AND id != $2 AND status = 'pending'`,
      [offer.listing_id, offerId]
    );
    await client.query(`UPDATE listings SET status = 'in_progress' WHERE id = $1`, [offer.listing_id]);

    const orderResult = await client.query(
      `INSERT INTO orders (listing_id, offer_id, client_id, provider_id, agreed_price)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [offer.listing_id, offerId, offer.client_id, offer.provider_id, offer.price]
    );

    const chatResult = await client.query(
      `INSERT INTO chats (listing_id, client_id, provider_id) VALUES ($1, $2, $3)
       ON CONFLICT (listing_id, client_id, provider_id) DO UPDATE SET listing_id = EXCLUDED.listing_id
       RETURNING *`,
      [offer.listing_id, offer.client_id, offer.provider_id]
    );

    await client.query('COMMIT');
    inTransaction = false;

    // Bildirishnoma faqat tranzaksiya muvaffaqiyatli COMMIT bo'lgandan keyin yuboriladi.
    await notifyUser(offer.provider_id, {
      type: 'offer_accepted',
      title: 'Taklifingiz qabul qilindi!',
      body: `"${offer.title}" bo'yicha taklifingiz qabul qilindi`,
      data: { orderId: orderResult.rows[0].id },
    });

    return res.json({
      message: 'Taklif qabul qilindi, buyurtma yaratildi',
      order: orderResult.rows[0],
      chatId: chatResult.rows[0].id,
    });
  } catch (err) {
    if (inTransaction) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    if (debtError(err, res, false)) return;
    next(err);
  } finally {
    client.release();
  }
}

/**
 * GET /api/offers/mine
 * Ustaning o'zi yuborgan takliflari.
 */
async function myOffers(req, res, next) {
  try {
    const result = await query(
      `SELECT o.*, l.title AS listing_title, l.status AS listing_status
       FROM offers o JOIN listings l ON l.id = o.listing_id
       WHERE o.provider_id = $1 ORDER BY o.created_at DESC`,
      [req.user.id]
    );
    res.json({
      offers: result.rows.map((r) => ({ ...toPublicOffer(r), listingTitle: r.listing_title, listingStatus: r.listing_status })),
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { createOffer, listOffersForListing, updateOfferStatus, myOffers };
