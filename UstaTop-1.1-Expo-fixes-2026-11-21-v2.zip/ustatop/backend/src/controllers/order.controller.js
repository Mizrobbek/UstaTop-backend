const { query, getClient } = require('../config/db');
const { notifyUser } = require('../utils/notify');

function toPublicOrder(row) {
  return {
    id: row.id,
    listingId: row.listing_id,
    listingTitle: row.listing_title,
    clientId: row.client_id,
    clientName: row.client_name,
    providerId: row.provider_id,
    providerName: row.provider_name,
    agreedPrice: Number(row.agreed_price),
    status: row.status,
    isPaid: Boolean(row.is_paid),
    paidAt: row.paid_at || null,
    clientPaymentConfirmedAt: row.client_payment_confirmed_at || null,
    providerPaymentConfirmedAt: row.provider_payment_confirmed_at || null,
    hasReview: row.has_review !== undefined ? Boolean(row.has_review) : undefined,
    startedAt: row.started_at,
    completedAt: row.completed_at,
    cancelledAt: row.cancelled_at,
    cancelReason: row.cancel_reason,
    createdAt: row.created_at,
  };
}

const ORDER_SELECT = `
  SELECT o.*, l.title AS listing_title,
         cu.full_name AS client_name, pu.full_name AS provider_name,
         EXISTS(SELECT 1 FROM reviews r WHERE r.order_id = o.id) AS has_review
  FROM orders o
  JOIN listings l ON l.id = o.listing_id
  JOIN users cu ON cu.id = o.client_id
  JOIN users pu ON pu.id = o.provider_id
`;

/**
 * GET /api/orders
 * Kirgan foydalanuvchining barcha buyurtmalari - mijoz sifatida ham, usta sifatida ham.
 * ?role=client yoki ?role=provider bilan filtrlash mumkin.
 */
async function listMyOrders(req, res, next) {
  try {
    const { role } = req.query;
    let whereClause = 'WHERE (o.client_id = $1 OR o.provider_id = $1)';
    if (role === 'client') whereClause = 'WHERE o.client_id = $1';
    if (role === 'provider') whereClause = 'WHERE o.provider_id = $1';

    const result = await query(`${ORDER_SELECT} ${whereClause} ORDER BY o.created_at DESC`, [req.user.id]);
    res.json({ orders: result.rows.map(toPublicOrder) });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/orders/:id
 */
async function getOrder(req, res, next) {
  try {
    const { id } = req.params;
    const result = await query(`${ORDER_SELECT} WHERE o.id = $1`, [id]);
    const order = result.rows[0];
    if (!order) return res.status(404).json({ error: 'Buyurtma topilmadi' });
    if (order.client_id !== req.user.id && order.provider_id !== req.user.id) {
      return res.status(403).json({ error: 'Bu buyurtmani ko\'rish huquqingiz yo\'q' });
    }
    res.json({ order: toPublicOrder(order) });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/orders/:id/status
 *
 * Barcha holat o'zgarishlari bitta tranzaksiyada bajariladi. Order qatori FOR UPDATE
 * bilan qulflanadi; shu sababli parallel so'rovlar eski statusni ko'rib, bir xil
 * amallarni ikki marta bajarolmaydi (masalan, completed_orders_count ikki marta oshmaydi).
 */
async function updateOrderStatus(req, res, next) {
  const { id } = req.params;
  const { status, cancelReason } = req.body;
  if (!['in_progress', 'completed', 'cancelled'].includes(status)) {
    return res.status(400).json({ error: 'Noto\'g\'ri buyurtma holati' });
  }

  const client = await getClient();
  let inTransaction = false;

  try {
    await client.query('BEGIN');
    inTransaction = true;

    const orderResult = await client.query('SELECT * FROM orders WHERE id = $1 FOR UPDATE', [id]);
    const order = orderResult.rows[0];
    if (!order) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(404).json({ error: 'Buyurtma topilmadi' });
    }

    const isClient = order.client_id === req.user.id;
    const isProvider = order.provider_id === req.user.id;
    if (!isClient && !isProvider) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(403).json({ error: 'Bu buyurtmaga ruxsatingiz yo\'q' });
    }

    if (status === 'in_progress') {
      if (!isProvider) {
        await client.query('ROLLBACK');
        inTransaction = false;
        return res.status(403).json({ error: 'Faqat usta ishni boshlagan deb belgilay oladi' });
      }
      if (order.status !== 'confirmed') {
        await client.query('ROLLBACK');
        inTransaction = false;
        return res.status(400).json({ error: 'Faqat tasdiqlangan buyurtmani boshlash mumkin' });
      }

      await client.query(`UPDATE orders SET status = 'in_progress', started_at = now() WHERE id = $1`, [id]);
      await client.query('COMMIT');
      inTransaction = false;
      return res.json({ message: 'Ish boshlandi deb belgilandi' });
    }

    if (status === 'completed') {
      if (!isProvider) {
        await client.query('ROLLBACK');
        inTransaction = false;
        return res.status(403).json({ error: 'Faqat usta ishni yakunlangan deb belgilay oladi' });
      }
      if (!['confirmed', 'in_progress'].includes(order.status)) {
        await client.query('ROLLBACK');
        inTransaction = false;
        return res.status(400).json({ error: 'Bu buyurtma allaqachon yakunlangan yoki bekor qilingan' });
      }

      await client.query(`UPDATE orders SET status = 'completed', completed_at = now() WHERE id = $1`, [id]);
      await client.query(`UPDATE listings SET status = 'completed' WHERE id = $1`, [order.listing_id]);
      // Bu qator faqat status birinchi marta completed ga o'tgan tranzaksiyada bajariladi.
      await client.query(
        `UPDATE provider_profiles SET completed_orders_count = completed_orders_count + 1 WHERE user_id = $1`,
        [order.provider_id]
      );
      await client.query('COMMIT');
      inTransaction = false;

      await notifyUser(order.client_id, {
        type: 'order_status_changed',
        title: 'Ish yakunlandi',
        body: 'Usta ishni tugallandi deb belgiladi. Sharh qoldirishni unutmang!',
        data: { orderId: id },
      });
      return res.json({ message: 'Buyurtma yakunlandi. Mijoz endi sharh qoldirishi mumkin.' });
    }

    if (status === 'cancelled') {
      if (!['confirmed', 'in_progress'].includes(order.status)) {
        await client.query('ROLLBACK');
        inTransaction = false;
        return res.status(400).json({ error: 'Bu buyurtmani endi bekor qilib bo\'lmaydi' });
      }

      await client.query(
        `UPDATE orders SET status = 'cancelled', cancelled_at = now(), cancel_reason = $1 WHERE id = $2`,
        [cancelReason || null, id]
      );
      await client.query(`UPDATE listings SET status = 'open' WHERE id = $1`, [order.listing_id]);
      await client.query('COMMIT');
      inTransaction = false;

      const otherUserId = isClient ? order.provider_id : order.client_id;
      await notifyUser(otherUserId, {
        type: 'order_status_changed',
        title: 'Buyurtma bekor qilindi',
        body: cancelReason || 'Buyurtma bekor qilindi',
        data: { orderId: id },
      });
      return res.json({ message: 'Buyurtma bekor qilindi' });
    }
  } catch (err) {
    if (inTransaction) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    next(err);
  } finally {
    client.release();
  }
}

/**
 * PATCH /api/orders/:id/payment-confirmation
 * Xizmat haqini mijoz ustaga bevosita to'laganini mijoz tasdiqlaydi,
 * keyin usta pulni olganini tasdiqlaydi. Platforma xizmat haqini qabul qilmaydi.
 */
async function confirmServicePayment(req, res, next) {
  const { id } = req.params;
  const client = await getClient();
  let inTransaction = false;
  let notify = null;

  try {
    await client.query('BEGIN');
    inTransaction = true;

    const result = await client.query('SELECT * FROM orders WHERE id = $1 FOR UPDATE', [id]);
    const order = result.rows[0];
    if (!order) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(404).json({ error: 'Buyurtma topilmadi' });
    }

    const isClient = order.client_id === req.user.id;
    const isProvider = order.provider_id === req.user.id;
    if (!isClient && !isProvider) {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(403).json({ error: 'Bu buyurtmaga ruxsatingiz yo\'q' });
    }
    if (order.status === 'cancelled') {
      await client.query('ROLLBACK');
      inTransaction = false;
      return res.status(400).json({ error: 'Bekor qilingan buyurtma uchun to\'lovni tasdiqlab bo\'lmaydi' });
    }

    if (order.is_paid) {
      await client.query('COMMIT');
      inTransaction = false;
      return res.json({
        message: 'Xizmat haqi avval tasdiqlangan',
        isPaid: true,
        clientPaymentConfirmedAt: order.client_payment_confirmed_at || null,
        providerPaymentConfirmedAt: order.provider_payment_confirmed_at || null,
      });
    }

    if (isClient) {
      if (!order.client_payment_confirmed_at) {
        await client.query(
          'UPDATE orders SET client_payment_confirmed_at = now() WHERE id = $1',
          [id]
        );
        notify = {
          userId: order.provider_id,
          payload: {
            type: 'service_payment_confirmation',
            title: 'Mijoz to\'lovni tasdiqladi',
            body: 'Mijoz xizmat haqini sizga to\'laganini tasdiqladi. Pulni olgan bo\'lsangiz, tasdiqlang.',
            data: { orderId: id },
          },
        };
      }
    } else {
      if (!order.client_payment_confirmed_at) {
        await client.query('ROLLBACK');
        inTransaction = false;
        return res.status(400).json({ error: 'Avval mijoz xizmat haqini to\'laganini tasdiqlashi kerak' });
      }
      if (!order.provider_payment_confirmed_at) {
        await client.query(
          `UPDATE orders
           SET provider_payment_confirmed_at = now(), is_paid = TRUE, paid_at = now()
           WHERE id = $1`,
          [id]
        );
        notify = {
          userId: order.client_id,
          payload: {
            type: 'service_payment_confirmed',
            title: 'Usta to\'lovni tasdiqladi',
            body: 'Usta xizmat haqini olganini tasdiqladi. To\'lov yakunlandi.',
            data: { orderId: id },
          },
        };
      }
    }

    const updated = await client.query('SELECT * FROM orders WHERE id = $1', [id]);
    await client.query('COMMIT');
    inTransaction = false;

    if (notify) await notifyUser(notify.userId, notify.payload);
    const saved = updated.rows[0];
    return res.json({
      message: saved.is_paid ? 'Xizmat haqi tasdiqlandi' : 'Tasdiq saqlandi',
      isPaid: Boolean(saved.is_paid),
      clientPaymentConfirmedAt: saved.client_payment_confirmed_at || null,
      providerPaymentConfirmedAt: saved.provider_payment_confirmed_at || null,
    });
  } catch (err) {
    if (inTransaction) {
      try { await client.query('ROLLBACK'); } catch (_) {}
    }
    next(err);
  } finally {
    client.release();
  }
}

module.exports = { listMyOrders, getOrder, updateOrderStatus, confirmServicePayment };
