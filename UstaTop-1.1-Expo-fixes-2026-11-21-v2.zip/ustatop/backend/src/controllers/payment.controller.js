const { query, getClient } = require('../config/db');
const {
  PAYME_ERRORS,
  PAYME_STATE,
  somToTiyin,
  tiyinToSom,
  paymeError,
  paymeResult,
  buildPaymeCheckoutUrl,
} = require('../utils/payme');
const { CLICK_ERRORS, CLICK_ACTION, verifyPrepareSign, verifyCompleteSign, buildClickCheckoutUrl } = require('../utils/click');

// ============================================================================
// Mijoz uchun: to'lov havolasini boshlash
// ============================================================================

/**
 * POST /api/orders/:id/pay   body: { provider: 'payme' | 'click' }
 * Faqat buyurtma egasi (mijoz), faqat hali to'lanmagan buyurtma uchun.
 * Checkout URL qaytaradi - mobil ilova shu URL'ni brauzer/WebView'da ochadi.
 */
async function initiatePayment(req, res) {
  // UstaTop mijozning xizmat haqini qabul qilmaydi. Mijoz ustaga bevosita
  // naqd yoki karta orqali to'laydi; ikki tomon tasdig'i order.controller'da.
  return res.status(410).json({
    error: 'UstaTop xizmat haqini qabul qilmaydi. To\'lovni bevosita ustaga amalga oshiring va ilovada tasdiqlang.',
  });
}

/**
 * GET /api/orders/:id/payment-status
 * Mobil ilova to'lov sahifasidan qaytgach, holatni so'rash uchun (polling).
 */
async function getPaymentStatus(req, res, next) {
  try {
    const { id: orderId } = req.params;
    const order = (await query('SELECT client_id, provider_id, is_paid, paid_at FROM orders WHERE id = $1', [orderId])).rows[0];
    if (!order) return res.status(404).json({ error: 'Buyurtma topilmadi' });
    if (order.client_id !== req.user.id && order.provider_id !== req.user.id) {
      return res.status(403).json({ error: 'Ruxsat yo\'q' });
    }
    res.json({ isPaid: order.is_paid, paidAt: order.paid_at });
  } catch (err) {
    next(err);
  }
}

// ============================================================================
// PAYME — JSON-RPC 2.0 dispatcher (bitta endpoint, method nomi orqali tarmoqlanadi)
// ============================================================================

async function findOrderForAccount(account) {
  const orderId = account?.order_id;
  if (!orderId || typeof orderId !== 'string') return null;
  const result = await query('SELECT * FROM orders WHERE id = $1', [orderId]);
  return result.rows[0] || null;
}

async function payme_CheckPerformTransaction(id, params) {
  const order = await findOrderForAccount(params.account);
  if (!order) {
    return paymeError(id, PAYME_ERRORS.ACCOUNT_ERROR_MIN, 'Buyurtma topilmadi', { order_id: 'Bunday buyurtma yo\'q' });
  }
  if (order.is_paid) {
    return paymeError(id, PAYME_ERRORS.ACCOUNT_ERROR_MIN, 'Buyurtma allaqachon to\'langan', { order_id: 'To\'langan' });
  }
  if (somToTiyin(order.agreed_price) !== Number(params.amount)) {
    return paymeError(id, PAYME_ERRORS.INVALID_AMOUNT, 'Noto\'g\'ri summa');
  }
  return paymeResult(id, { allow: true });
}

async function payme_CreateTransaction(id, params) {
  // Idempotentlik: bu Payme ID bilan tranzaksiya allaqachon yaratilgan bo'lsa, xuddi shu natijani qaytaramiz
  const existing = (
    await query('SELECT * FROM payments WHERE provider = $1 AND external_id = $2', ['payme', params.id])
  ).rows[0];
  if (existing) {
    return paymeResult(id, {
      create_time: new Date(existing.create_time).getTime(),
      transaction: existing.id,
      state: existing.payme_state,
    });
  }

  const order = await findOrderForAccount(params.account);
  if (!order) {
    return paymeError(id, PAYME_ERRORS.ACCOUNT_ERROR_MIN, 'Buyurtma topilmadi', { order_id: 'Bunday buyurtma yo\'q' });
  }
  if (order.is_paid) {
    return paymeError(id, PAYME_ERRORS.ACCOUNT_ERROR_MIN, 'Buyurtma allaqachon to\'langan', { order_id: 'To\'langan' });
  }
  if (somToTiyin(order.agreed_price) !== Number(params.amount)) {
    return paymeError(id, PAYME_ERRORS.INVALID_AMOUNT, 'Noto\'g\'ri summa');
  }

  // Bitta buyurtma uchun bir vaqtda faqat bitta FAOL (pending) tranzaksiya bo'lishi kerak
  const pending = (await query(`SELECT id FROM payments WHERE order_id = $1 AND status = 'pending'`, [order.id])).rows[0];
  if (pending) {
    return paymeError(id, PAYME_ERRORS.UNABLE_TO_PERFORM_OPERATION, 'Bu buyurtma uchun kutilayotgan tranzaksiya bor');
  }

  const createTime = new Date();
  const insertResult = await query(
    `INSERT INTO payments (order_id, provider, external_id, amount, status, payme_state, create_time)
     VALUES ($1, 'payme', $2, $3, 'pending', $4, $5) RETURNING *`,
    [order.id, params.id, tiyinToSom(params.amount), PAYME_STATE.CREATED, createTime]
  );
  const payment = insertResult.rows[0];

  return paymeResult(id, { create_time: createTime.getTime(), transaction: payment.id, state: PAYME_STATE.CREATED });
}

async function payme_PerformTransaction(id, params) {
  const payment = (
    await query('SELECT * FROM payments WHERE provider = $1 AND external_id = $2', ['payme', params.id])
  ).rows[0];
  if (!payment) return paymeError(id, PAYME_ERRORS.TRANSACTION_NOT_FOUND, 'Tranzaksiya topilmadi');

  if (payment.payme_state === PAYME_STATE.COMPLETED) {
    // Idempotentlik: allaqachon o'tkazilgan bo'lsa, xuddi shu natijani qaytaramiz
    return paymeResult(id, {
      transaction: payment.id,
      perform_time: new Date(payment.perform_time).getTime(),
      state: PAYME_STATE.COMPLETED,
    });
  }
  if (payment.payme_state !== PAYME_STATE.CREATED) {
    return paymeError(id, PAYME_ERRORS.UNABLE_TO_PERFORM_OPERATION, 'Bu tranzaksiyani o\'tkazib bo\'lmaydi');
  }

  const performTime = new Date();
  const client = await getClient();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE payments SET status = 'paid', payme_state = $1, perform_time = $2 WHERE id = $3`,
      [PAYME_STATE.COMPLETED, performTime, payment.id]
    );
    await client.query(`UPDATE orders SET is_paid = TRUE, paid_at = $1 WHERE id = $2`, [performTime, payment.order_id]);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }

  return paymeResult(id, { transaction: payment.id, perform_time: performTime.getTime(), state: PAYME_STATE.COMPLETED });
}

async function payme_CancelTransaction(id, params) {
  const payment = (
    await query('SELECT * FROM payments WHERE provider = $1 AND external_id = $2', ['payme', params.id])
  ).rows[0];
  if (!payment) return paymeError(id, PAYME_ERRORS.TRANSACTION_NOT_FOUND, 'Tranzaksiya topilmadi');

  // Idempotentlik: allaqachon bekor qilingan bo'lsa, xuddi shu natijani qaytaramiz
  if (payment.payme_state === PAYME_STATE.CANCELLED_BEFORE_COMPLETE || payment.payme_state === PAYME_STATE.CANCELLED_AFTER_COMPLETE) {
    return paymeResult(id, {
      transaction: payment.id,
      cancel_time: new Date(payment.cancel_time).getTime(),
      state: payment.payme_state,
    });
  }

  if (payment.payme_state === PAYME_STATE.COMPLETED) {
    const order = (await query('SELECT status FROM orders WHERE id = $1', [payment.order_id])).rows[0];
    if (order?.status === 'completed') {
      return paymeError(id, PAYME_ERRORS.UNABLE_TO_CANCEL_COMPLETED, 'Buyurtma bajarilgan, bekor qilib bo\'lmaydi');
    }
  }

  const newState = payment.payme_state === PAYME_STATE.COMPLETED ? PAYME_STATE.CANCELLED_AFTER_COMPLETE : PAYME_STATE.CANCELLED_BEFORE_COMPLETE;
  const cancelTime = new Date();

  const client = await getClient();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE payments SET status = 'cancelled', payme_state = $1, payme_reason = $2, cancel_time = $3 WHERE id = $4`,
      [newState, params.reason ?? null, cancelTime, payment.id]
    );
    if (newState === PAYME_STATE.CANCELLED_AFTER_COMPLETE) {
      // Avval to'langan edi - bekor qilinganda buyurtmani "to'lanmagan"ga qaytaramiz
      await client.query(`UPDATE orders SET is_paid = FALSE, paid_at = NULL WHERE id = $1`, [payment.order_id]);
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }

  return paymeResult(id, { transaction: payment.id, cancel_time: cancelTime.getTime(), state: newState });
}

async function payme_CheckTransaction(id, params) {
  const payment = (
    await query('SELECT * FROM payments WHERE provider = $1 AND external_id = $2', ['payme', params.id])
  ).rows[0];
  if (!payment) return paymeError(id, PAYME_ERRORS.TRANSACTION_NOT_FOUND, 'Tranzaksiya topilmadi');

  return paymeResult(id, {
    create_time: new Date(payment.create_time).getTime(),
    perform_time: payment.perform_time ? new Date(payment.perform_time).getTime() : 0,
    cancel_time: payment.cancel_time ? new Date(payment.cancel_time).getTime() : 0,
    transaction: payment.id,
    state: payment.payme_state,
    reason: payment.payme_reason ?? null,
  });
}

async function payme_GetStatement(id, params) {
  const from = new Date(Number(params.from));
  const to = new Date(Number(params.to));
  const result = await query(
    `SELECT p.*, o.id AS order_id FROM payments p JOIN orders o ON o.id = p.order_id
     WHERE p.provider = 'payme' AND p.create_time BETWEEN $1 AND $2
     ORDER BY p.create_time ASC`,
    [from, to]
  );

  const transactions = result.rows.map((p) => ({
    id: p.external_id,
    time: new Date(p.create_time).getTime(),
    amount: somToTiyin(p.amount),
    account: { order_id: p.order_id },
    create_time: new Date(p.create_time).getTime(),
    perform_time: p.perform_time ? new Date(p.perform_time).getTime() : 0,
    cancel_time: p.cancel_time ? new Date(p.cancel_time).getTime() : 0,
    transaction: p.id,
    state: p.payme_state,
    reason: p.payme_reason ?? null,
  }));

  return paymeResult(id, { transactions });
}

const PAYME_METHODS = {
  CheckPerformTransaction: payme_CheckPerformTransaction,
  CreateTransaction: payme_CreateTransaction,
  PerformTransaction: payme_PerformTransaction,
  CancelTransaction: payme_CancelTransaction,
  CheckTransaction: payme_CheckTransaction,
  GetStatement: payme_GetStatement,
};

/**
 * POST /api/payments/payme
 * Payme Business shu bitta manzilga barcha metodlarni "method" maydoni orqali yuboradi.
 * paymeAuth middleware'i bu funksiyadan OLDIN Basic Auth'ni tekshiradi.
 */
async function paymeWebhook(req, res) {
  const { id } = req.body || {};
  // Xizmat narxi UstaTop orqali o'tkazilmaydi. Payme webhooki saqlangan, ammo
  // bu endpoint endi mijozning xizmat haqini qabul qilmaydi.
  return res.status(200).json(
    paymeError(
      id,
      PAYME_ERRORS.UNABLE_TO_PERFORM_OPERATION,
      'UstaTop xizmat haqini qabul qilmaydi. Mijoz xizmat haqini bevosita ustaga to‘laydi.'
    )
  );
}

// ============================================================================
// CLICK — Prepare / Complete webhook'lari
// ============================================================================

/**
 * POST /api/payments/click/prepare
 */
async function clickPrepare(req, res) {
  const p = req.body || {};
  return res.json({
    click_trans_id: p.click_trans_id,
    merchant_trans_id: p.merchant_trans_id,
    error: CLICK_ERRORS.BAD_REQUEST,
    error_note: 'UstaTop xizmat haqini qabul qilmaydi. Mijoz xizmat haqini bevosita ustaga to‘laydi.',
  });
}

/**
 * POST /api/payments/click/complete
 */
async function clickComplete(req, res) {
  const p = req.body || {};
  return res.json({
    click_trans_id: p.click_trans_id,
    merchant_trans_id: p.merchant_trans_id,
    error: CLICK_ERRORS.BAD_REQUEST,
    error_note: 'UstaTop xizmat haqini qabul qilmaydi. Mijoz xizmat haqini bevosita ustaga to‘laydi.',
  });
}

module.exports = { initiatePayment, getPaymentStatus, paymeWebhook, clickPrepare, clickComplete };
