const { query } = require('../config/db');
const storage = require('../storage');
const path = require('path');

function storageKeyFromUrl(mediaUrl) {
  if (typeof mediaUrl !== 'string') return null;
  try {
    const parsed = new URL(mediaUrl, 'http://localhost');
    if (!parsed.pathname.startsWith('/uploads/')) return null;
    const key = decodeURIComponent(parsed.pathname.slice('/uploads/'.length));
    return key && path.basename(key) === key ? key : null;
  } catch (_) {
    return null;
  }
}

async function listMine(req, res, next) {
  try {
    const result = await query(
      'SELECT id, media_url AS "mediaUrl", media_type AS type, description, created_at AS "createdAt" FROM provider_portfolio WHERE provider_id=$1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json({ items: result.rows });
  } catch (e) { next(e); }
}

async function addMine(req, res, next) {
  try {
    const { mediaUrl, type = 'image', description = '' } = req.body;
    const storageKey = storageKeyFromUrl(mediaUrl);
    if (!storageKey || !['image', 'video'].includes(type)) {
      return res.status(400).json({ error: 'Faqat serverga yuklangan rasm yoki video qo‘shish mumkin' });
    }
    if (typeof description !== 'string' || description.length > 500) {
      return res.status(400).json({ error: 'Izoh 500 belgidan oshmasligi kerak' });
    }
    const result = await query(
      'INSERT INTO provider_portfolio(provider_id, media_url, media_type, description, storage_key) VALUES($1,$2,$3,$4,$5) RETURNING id, media_url AS "mediaUrl", media_type AS type, description, created_at AS "createdAt"',
      [req.user.id, mediaUrl, type, description, storageKey]
    );
    res.status(201).json({ item: result.rows[0] });
  } catch (e) { next(e); }
}

async function deleteMine(req, res, next) {
  try {
    const result = await query(
      'DELETE FROM provider_portfolio WHERE id=$1 AND provider_id=$2 RETURNING id, storage_key',
      [req.params.id, req.user.id]
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Portfolio elementi topilmadi' });
    if (result.rows[0].storage_key) {
      await storage.remove(result.rows[0].storage_key).catch((err) => {
        // DB yozuvi o'chgan bo'lsa ham, storage xatosi API javobini buzmaydi.
        console.error('Portfolio media faylini o‘chirishda xato:', err.message);
      });
    }
    res.json({ message: 'Portfolio elementi o‘chirildi' });
  } catch (e) { next(e); }
}

module.exports = { listMine, addMine, deleteMine };
