const { query } = require('../config/db');

/**
 * GET /api/providers/:id
 * Ustaning ommaviy profili - reyting, tajriba, ishlaydigan kategoriyalari.
 * Har kim (login qilmasdan ham) ko'ra oladi - ustani tanlashdan oldin baholash uchun.
 */
async function getProviderProfile(req, res, next) {
  try {
    const { id } = req.params;

    const userResult = await query(
      `SELECT u.id, u.full_name, u.avatar_url, u.city, u.created_at,
              pp.bio, pp.experience_years, pp.rating_avg, pp.rating_count, pp.completed_orders_count, pp.is_verified, pp.myid_verified
       FROM users u JOIN provider_profiles pp ON pp.user_id = u.id
       WHERE u.id = $1`,
      [id]
    );
    const user = userResult.rows[0];
    if (!user) return res.status(404).json({ error: 'Usta topilmadi' });

    const portfolioResult = await query(
      `SELECT id, COALESCE(media_url, image_url) AS media_url, media_type, description, created_at FROM provider_portfolio WHERE provider_id = $1 ORDER BY created_at DESC`,
      [id]
    );

    const categoriesResult = await query(
      `SELECT c.id, c.name_uz, c.icon FROM provider_categories pc
       JOIN categories c ON c.id = pc.category_id WHERE pc.provider_id = $1`,
      [id]
    );

    res.json({
      provider: {
        id: user.id,
        fullName: user.full_name,
        avatarUrl: user.avatar_url,
        city: user.city,
        bio: user.bio,
        experienceYears: user.experience_years,
        ratingAvg: Number(user.rating_avg),
        ratingCount: user.rating_count,
        completedOrdersCount: user.completed_orders_count,
        isVerified: user.myid_verified,
        myIdVerified: user.myid_verified,
        adminVerified: user.is_verified,
        categories: categoriesResult.rows.map((c) => ({ id: c.id, nameUz: c.name_uz, icon: c.icon })),
        portfolio: portfolioResult.rows.map((item) => ({ id: item.id, mediaUrl: item.media_url, type: item.media_type, description: item.description, createdAt: item.created_at })),
        memberSince: user.created_at,
      },
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { getProviderProfile };
