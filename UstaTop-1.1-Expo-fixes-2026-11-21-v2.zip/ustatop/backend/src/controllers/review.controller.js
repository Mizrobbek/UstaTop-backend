const { query, getClient } = require('../config/db');
const { notifyUser } = require('../utils/notify');

function toPublicReview(row) {
  return {
    id: row.id,
    orderId: row.order_id,
    reviewerId: row.reviewer_id,
    reviewerName: row.reviewer_name,
    reviewerAvatar: row.reviewer_avatar,
    revieweeId: row.reviewee_id,
    rating: row.rating,
    comment: row.comment,
    createdAt: row.created_at,
  };
}

/**
 * POST /api/orders/:id/review
 * body: { rating: 1-5, comment? }
 * Faqat mijoz, faqat "completed" holatidagi buyurtma uchun, faqat bir marta.
 * Sharh qo'shilgach, ustaning provider_profiles.rating_avg qayta hisoblanadi.
 */
async function createReview(req, res, next) {
  const client = await getClient();
  try {
    const { id: orderId } = req.params;
    const { rating, comment } = req.body;

    const orderResult = await query('SELECT * FROM orders WHERE id = $1', [orderId]);
    const order = orderResult.rows[0];
    if (!order) return res.status(404).json({ error: 'Buyurtma topilmadi' });
    if (order.client_id !== req.user.id) {
      return res.status(403).json({ error: 'Faqat mijoz sharh qoldira oladi' });
    }
    if (order.status !== 'completed') {
      return res.status(400).json({ error: 'Sharh faqat yakunlangan buyurtma uchun qoldiriladi' });
    }

    const existing = await query('SELECT id FROM reviews WHERE order_id = $1', [orderId]);
    if (existing.rows[0]) {
      return res.status(409).json({ error: 'Siz bu buyurtma uchun allaqachon sharh qoldirgansiz' });
    }

    await client.query('BEGIN');

    const insertResult = await client.query(
      `INSERT INTO reviews (order_id, reviewer_id, reviewee_id, rating, comment)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [orderId, req.user.id, order.provider_id, rating, comment || null]
    );

    // Ustaning o'rtacha reytingini qayta hisoblaymiz (barcha sharhlar bo'yicha)
    const aggResult = await client.query(
      `SELECT COUNT(*) AS count, COALESCE(AVG(rating), 0) AS avg FROM reviews WHERE reviewee_id = $1`,
      [order.provider_id]
    );
    const { count, avg } = aggResult.rows[0];
    await client.query(
      `UPDATE provider_profiles SET rating_count = $1, rating_avg = $2 WHERE user_id = $3`,
      [count, Number(avg).toFixed(1), order.provider_id]
    );

    await client.query('COMMIT');

    await notifyUser(order.provider_id, {
      type: 'new_review',
      title: 'Yangi sharh oldingiz',
      body: `${rating} yulduzli sharh qoldirishdi`,
      data: { orderId },
    });

    res.status(201).json({ message: 'Sharh muvaffaqiyatli qo\'shildi', review: toPublicReview(insertResult.rows[0]) });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
}

/**
 * GET /api/providers/:id/reviews
 * Ustaning barcha sharhlarini (sharh yozuvchining ismi bilan) qaytaradi.
 */
async function listProviderReviews(req, res, next) {
  try {
    const { id: providerId } = req.params;
    const result = await query(
      `SELECT r.*, u.full_name AS reviewer_name, u.avatar_url AS reviewer_avatar
       FROM reviews r JOIN users u ON u.id = r.reviewer_id
       WHERE r.reviewee_id = $1 ORDER BY r.created_at DESC`,
      [providerId]
    );
    res.json({ reviews: result.rows.map(toPublicReview) });
  } catch (err) {
    next(err);
  }
}

module.exports = { createReview, listProviderReviews };
