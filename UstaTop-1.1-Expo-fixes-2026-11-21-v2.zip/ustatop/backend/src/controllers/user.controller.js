const { query, getClient } = require('../config/db');

function toPublicUser(user) {
  return {
    id: user.id,
    phone: user.phone,
    email: user.email,
    fullName: user.full_name,
    role: user.role,
    avatarUrl: user.avatar_url,
    city: user.city,
    isPhoneVerified: user.is_phone_verified,
    isEmailVerified: user.is_email_verified,
    createdAt: user.created_at,
  };
}

/**
 * GET /api/users/me
 */
async function getMe(req, res, next) {
  try {
    const result = await query('SELECT * FROM users WHERE id = $1', [req.user.id]);
    const user = result.rows[0];

    let providerProfile = null;
    if (user.role === 'provider' || user.role === 'both') {
      const ppResult = await query('SELECT * FROM provider_profiles WHERE user_id = $1', [user.id]);
      const pp = ppResult.rows[0];
      if (pp) {
        providerProfile = {
          bio: pp.bio,
          experienceYears: pp.experience_years,
          ratingAvg: Number(pp.rating_avg),
          ratingCount: pp.rating_count,
          completedOrdersCount: pp.completed_orders_count,
          isVerified: pp.myid_verified,
          myIdVerified: pp.myid_verified,
          adminVerified: pp.is_verified,
        };
      }
    }

    res.json({ user: { ...toPublicUser(user), providerProfile } });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/users/me
 */
async function updateMe(req, res, next) {
  try {
    const fields = [];
    const params = [];
    let idx = 1;
    const map = { fullName: 'full_name', city: 'city', avatarUrl: 'avatar_url' };
    for (const [key, column] of Object.entries(map)) {
      if (req.body[key] !== undefined) {
        fields.push(`${column} = $${idx++}`);
        params.push(req.body[key]);
      }
    }
    if (fields.length === 0) return res.status(400).json({ error: 'Yangilash uchun hech qanday maydon berilmadi' });

    params.push(req.user.id);
    const result = await query(`UPDATE users SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`, params);

    res.json({ message: 'Profil yangilandi', user: toPublicUser(result.rows[0]) });
  } catch (err) {
    next(err);
  }
}


async function updateProviderProfile(req, res, next) {
  try {
    if (!['provider', 'both'].includes(req.user.role)) return res.status(403).json({ error: 'Faqat ustalar uchun' });
    const fields = []; const params = []; let i = 1;
    for (const [key, column] of [['bio', 'bio'], ['experienceYears', 'experience_years']]) {
      if (req.body[key] !== undefined) { fields.push(`${column}=$${i++}`); params.push(req.body[key]); }
    }
    if (!fields.length) return res.status(400).json({ error: 'Yangilash uchun maydon berilmadi' });
    fields.push('updated_at=now()'); params.push(req.user.id);
    const result = await query(`UPDATE provider_profiles SET ${fields.join(', ')} WHERE user_id=$${i} RETURNING bio, experience_years`, params);
    if (!result.rowCount) return res.status(404).json({ error: 'Usta profili topilmadi' });
    res.json({ message: 'Usta profili yangilandi', providerProfile: { bio: result.rows[0].bio, experienceYears: result.rows[0].experience_years } });
  } catch (err) { next(err); }
}

/**
 * POST /api/users/me/become-provider
 * Mijoz sifatida ro'yxatdan o'tgan foydalanuvchi usta sifatida ham ishlashni xohlasa
 * shu endpoint orqali rolini "both"ga o'zgartiradi va provider_profiles yozuvini yaratadi.
 */
async function becomeProvider(req, res, next) {
  const client = await getClient();
  try {
    const { bio, experienceYears, categoryIds } = req.body;

    const userResult = await query('SELECT * FROM users WHERE id = $1', [req.user.id]);
    const user = userResult.rows[0];
    if (!user.is_phone_verified) return res.status(403).json({ error: 'Avval telefon raqamingizni SMS orqali tasdiqlang' });
    if (user.role === 'provider' || user.role === 'both') {
      return res.status(400).json({ error: 'Siz allaqachon usta sifatida ro\'yxatdan o\'tgansiz' });
    }

    const categoriesCheck = await query('SELECT id FROM categories WHERE id = ANY($1) AND is_active = TRUE', [
      categoryIds,
    ]);
    if (categoriesCheck.rows.length !== categoryIds.length) {
      return res.status(400).json({ error: 'Kategoriyalardan biri yoki bir nechtasi topilmadi' });
    }

    await client.query('BEGIN');

    await client.query(`UPDATE users SET role = 'both' WHERE id = $1`, [user.id]);
    await client.query(
      `INSERT INTO provider_profiles (user_id, bio, experience_years) VALUES ($1, $2, $3)
       ON CONFLICT (user_id) DO UPDATE SET bio = EXCLUDED.bio, experience_years = EXCLUDED.experience_years`,
      [user.id, bio || null, experienceYears || 0]
    );
    for (const categoryId of categoryIds) {
      await client.query(
        `INSERT INTO provider_categories (provider_id, category_id) VALUES ($1, $2)
         ON CONFLICT DO NOTHING`,
        [user.id, categoryId]
      );
    }

    // Faqat izolyatsiyalangan test muhitida MyID tasdig'i test fixture sifatida belgilanadi.
    // Development/production'da bu ustun faqat tasdiqlangan MyID callback orqali o'zgarishi kerak.
    if (process.env.NODE_ENV === 'test') {
      await client.query('UPDATE provider_profiles SET myid_verified = TRUE WHERE user_id = $1', [user.id]);
    }

    await client.query('COMMIT');

    res.json({ message: 'Usta profili yaratildi. Taklif yuborishdan oldin MyID orqali shaxsni tasdiqlash talab qilinadi.', myIdVerificationRequired: true });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
}


async function requestPhoneChange(req, res, next) {
  try {
    const phone = String(req.body.phone || '').trim();
    if (!/^\+998\d{9}$/.test(phone)) return res.status(400).json({ error: 'Telefon raqam +998 va 9 ta raqamdan iborat bo‘lishi kerak' });
    const exists = await query('SELECT id FROM users WHERE phone=$1 AND id<>$2', [phone, req.user.id]);
    if (exists.rows[0]) return res.status(409).json({ error: 'Bu telefon raqami boshqa hisobga biriktirilgan' });
    const { createOtp } = require('../utils/otp'); const { sendSms } = require('../utils/sms');
    const { code, expiresInMinutes } = await createOtp(phone, 'phone_verify');
    await sendSms(phone, `UstaTop telefon raqamini tasdiqlash kodi: ${code}. Kod ${expiresInMinutes} daqiqa amal qiladi.`);
    res.json({ message: 'Tasdiqlash kodi yuborildi', expiresInMinutes });
  } catch (err) { next(err); }
}

async function confirmPhoneChange(req, res, next) {
  const client = await getClient();
  try {
    const phone = String(req.body.phone || '').trim(); const code = String(req.body.code || '').trim();
    if (!/^\+998\d{9}$/.test(phone) || !/^\d{5}$/.test(code)) return res.status(400).json({ error: 'Telefon yoki SMS kodi formati noto‘g‘ri' });
    await client.query('BEGIN');
    const { consumeOtp } = require('../utils/otp');
    const verified = await consumeOtp(client, phone, code, 'phone_verify');
    if (!verified.valid) { await client.query('COMMIT'); return res.status(400).json({ error: verified.reason }); }
    const changed = await client.query('UPDATE users SET phone=$1, is_phone_verified=TRUE, token_version=token_version+1 WHERE id=$2 AND NOT EXISTS (SELECT 1 FROM users WHERE phone=$1 AND id<>$2) RETURNING id, phone', [phone, req.user.id]);
    if (!changed.rows[0]) { await client.query('ROLLBACK'); return res.status(409).json({ error: 'Bu telefon raqami boshqa hisobga biriktirilgan' }); }
    await client.query('COMMIT');
    res.json({ message: 'Telefon raqami yangilandi. Xavfsizlik uchun qayta kiring.', phone: changed.rows[0].phone });
  } catch (err) { try { await client.query('ROLLBACK'); } catch (_) {} next(err); } finally { client.release(); }
}

module.exports = { getMe, updateMe, updateProviderProfile, becomeProvider, requestPhoneChange, confirmPhoneChange, toPublicUser };
