const { verifyAccessToken } = require('../utils/jwt');
const { query } = require('../config/db');

/**
 * Access tokenni tekshiradi va foydalanuvchini bazadan oladi.
 * Token bekor qilingan hisoblanadi, agar:
 *  - telefon raqami hali SMS orqali tasdiqlanmagan bo'lsa;
 *  - foydalanuvchining token_version'i tokendagi "ver"dan farq qilsa (parol tiklash / replay);
 *  - token biriktirilgan sessiya (sid = refresh_tokens.id) bekor qilingan yoki o'chirilgan bo'lsa (logout).
 * "ver"/"sid"siz eski tokenlar ver=0 deb qabul qilinadi va o'z muddatigacha ishlaydi.
 * Qaytaradi: { user, payload } yoki { error: { status, body } }
 */
async function resolveAccessToken(token) {
  const payload = verifyAccessToken(token); // xato bo'lsa throw qiladi
  const result = await query(
    `SELECT u.id, u.phone, u.full_name, u.role, u.is_active, u.is_phone_verified, u.token_version, s.revoked AS session_revoked
     FROM users u LEFT JOIN refresh_tokens s ON s.id = $2 AND s.user_id = u.id
     WHERE u.id = $1`,
    [payload.sub, payload.sid || null]
  );
  const row = result.rows[0];
  if (!row) return { error: { status: 401, body: { error: 'Foydalanuvchi topilmadi' } } };

  if (!row.is_active) return { error: { status: 403, body: { error: 'Hisobingiz bloklangan' } } };
  if (!row.is_phone_verified) return { error: { status: 403, body: { error: 'Telefon raqamingizni SMS orqali tasdiqlang', code: 'PHONE_VERIFICATION_REQUIRED' } } };
  const revokedBody = { error: 'Sessiya bekor qilingan. Qaytadan kiring.', code: 'TOKEN_REVOKED' };
  if ((payload.ver ?? 0) !== (row.token_version ?? 0)) return { error: { status: 401, body: revokedBody } };
  if (payload.sid && row.session_revoked !== false) return { error: { status: 401, body: revokedBody } };

  const { session_revoked, ...user } = row; // eslint-disable-line no-unused-vars
  return { user, payload };
}

/**
 * Har bir himoyalangan endpoint uchun: Authorization: Bearer <token> talab qiladi.
 */
async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) {
      return res.status(401).json({ error: 'Token topilmadi. Tizimga kiring.' });
    }

    const resolved = await resolveAccessToken(token);
    if (resolved.error) return res.status(resolved.error.status).json(resolved.error.body);

    req.user = resolved.user;
    req.auth = { sessionId: resolved.payload.sid || null };
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token muddati tugagan', code: 'TOKEN_EXPIRED' });
    }
    if (err.name === 'JsonWebTokenError' || err.name === 'NotBeforeError') {
      return res.status(401).json({ error: 'Token yaroqsiz' });
    }
    return next(err);
  }
}

/**
 * Faqat berilgan rollarga ruxsat beradi. authenticate'dan keyin ishlatiladi.
 * Masalan: requireRole('admin') yoki requireRole('provider', 'both')
 */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Avval tizimga kiring' });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Bu amal uchun ruxsatingiz yo\'q' });
    }
    next();
  };
}

/**
 * Token bo'lsa foydalanuvchini biriktiradi, bo'lmasa xato bermay davom etadi.
 * Bekor qilingan yoki bloklangan foydalanuvchi tokeni "mehmon" sifatida qabul qilinadi.
 */
async function optionalAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next();
  try {
    const resolved = await resolveAccessToken(token);
    req.user = resolved.error
      ? null
      : { id: resolved.user.id, phone: resolved.user.phone, full_name: resolved.user.full_name, role: resolved.user.role };
  } catch {
    req.user = null;
  }
  next();
}

module.exports = { authenticate, requireRole, optionalAuth, resolveAccessToken };
