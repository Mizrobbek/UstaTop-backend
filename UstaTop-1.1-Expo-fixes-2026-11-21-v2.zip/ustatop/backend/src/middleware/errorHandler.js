/**
 * Barcha route'lardan keyin qo'shiladigan yakuniy xatolik ushlagich.
 * controller'lar `next(err)` chaqirsa yoki throw qilsa, shu yerga tushadi.
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  console.error('[ERROR]', err);

  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: 'Fayl hajmi 50 MB dan oshmasligi kerak' });
  }
  if (typeof err.code === 'string' && err.code.startsWith('LIMIT_')) {
    return res.status(400).json({ error: 'Fayl yuklash cheklovlari buzildi' });
  }

  const status = err.status || 500;

  // Postgres unique constraint xatosi (masalan, ikki marta bir xil offer)
  if (err.code === '23505') {
    return res.status(409).json({ error: 'Bu amal allaqachon bajarilgan (takroriy yozuv)' });
  }
  // Postgres foreign key xatosi
  if (err.code === '23503') {
    return res.status(400).json({ error: 'Bog\'liq ma\'lumot topilmadi' });
  }

  res.status(status).json({
    error: err.publicMessage || err.message || 'Server xatoligi yuz berdi',
  });
}

function notFoundHandler(req, res) {
  res.status(404).json({ error: `Manzil topilmadi: ${req.method} ${req.originalUrl}` });
}

module.exports = { errorHandler, notFoundHandler };
