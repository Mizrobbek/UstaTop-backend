const { PAYME_ERRORS, paymeError } = require('../utils/payme');

/**
 * Payme Business har bir so'rovga "Authorization: Basic base64(Paycom:<KEY>)" header'ini
 * qo'shadi. Bu middleware shuni tekshiradi; mos kelmasa, Payme kutgan JSON-RPC xato
 * formatida (-32504) javob qaytaradi (oddiy HTTP 401 emas — Payme buni tushunmaydi).
 */
function paymeAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const expectedKey = process.env.PAYME_MERCHANT_KEY;

  if (!expectedKey) {
    // .env sozlanmagan bo'lsa, aniq server xatosi (ishlab chiquvchiga signal)
    return res.status(200).json(paymeError(req.body?.id, PAYME_ERRORS.INTERNAL_ERROR, 'PAYME_MERCHANT_KEY sozlanmagan'));
  }

  const expected = `Basic ${Buffer.from(`Paycom:${expectedKey}`).toString('base64')}`;
  if (header !== expected) {
    return res
      .status(200)
      .json(paymeError(req.body?.id, PAYME_ERRORS.INSUFFICIENT_PRIVILEGE, 'Avtorizatsiya xatosi'));
  }

  next();
}

module.exports = { paymeAuth };
