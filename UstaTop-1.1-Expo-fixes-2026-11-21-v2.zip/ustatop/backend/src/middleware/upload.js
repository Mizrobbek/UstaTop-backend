const multer = require('multer');
const fs = require('fs');
const os = require('os');
const path = require('path');
const tempDir = path.join(os.tmpdir(), 'ustatop-uploads');
fs.mkdirSync(tempDir, { recursive: true });

const { allowedMimeTypes, classifyMimeType } = require('./mediaTypes');

const upload = multer({
  dest: tempDir,
  limits: { fileSize: 50 * 1024 * 1024, files: 10 },
  fileFilter(_req, file, cb) {
    if (!allowedMimeTypes.has(file.mimetype)) {
      const error = new Error('Rasm, video, audio, PDF, Office yoki matn fayli qabul qilinadi');
      error.status = 415;
      error.publicMessage = error.message;
      return cb(error);
    }
    cb(null, true);
  },
});

module.exports = upload;
