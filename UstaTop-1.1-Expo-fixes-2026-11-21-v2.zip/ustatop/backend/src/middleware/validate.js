/**
 * Joi sxemasi bilan req.body / req.query ni tekshiradigan umumiy middleware.
 * Foydalanish: router.post('/x', validate(schema), controller)
 */
function validate(schema, property = 'body') {
  return (req, res, next) => {
    const { error, value } = schema.validate(req[property], {
      abortEarly: false,
      stripUnknown: true,
    });
    if (error) {
      return res.status(400).json({
        error: 'Ma\'lumotlar noto\'g\'ri',
        details: error.details.map((d) => d.message),
      });
    }
    req[property] = value;
    next();
  };
}

module.exports = { validate };
