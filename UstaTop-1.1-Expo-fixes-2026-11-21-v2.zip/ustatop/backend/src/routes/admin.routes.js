const express = require('express');
const router = express.Router();

const ctrl = require('../controllers/admin.controller');
const commission = require('../controllers/commission.controller');
const { authenticate, requireRole } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const {
  listUsersQuerySchema,
  listListingsQuerySchema,
  setUserActiveSchema,
  verifyProviderSchema,
  createCategorySchema,
  updateCategorySchema,
} = require('../validators/admin.validator');

// Bu yerdagi barcha endpoint'lar faqat administratorlar uchun
router.use(authenticate, requireRole('admin'));

router.get('/stats', ctrl.getStats);
router.get('/commission/tariffs', commission.tariffs);
router.patch('/commission/tariffs/:scope', commission.updateTariff);
router.get('/commission/history', commission.adminHistory);

router.get('/users', validate(listUsersQuerySchema, 'query'), ctrl.listUsers);
router.patch('/users/:id/active', validate(setUserActiveSchema), ctrl.setUserActive);
router.patch('/providers/:id/verify', validate(verifyProviderSchema), ctrl.verifyProvider);

router.get('/listings', validate(listListingsQuerySchema, 'query'), ctrl.listListings);
router.patch('/listings/:id/cancel', ctrl.cancelListing);

router.get('/categories', ctrl.listCategories);
router.post('/categories', validate(createCategorySchema), ctrl.createCategory);
router.patch('/categories/:id', validate(updateCategorySchema), ctrl.updateCategory);

module.exports = router;
