const express = require('express');
const rateLimit = require('express-rate-limit');
const router = express.Router();

const ctrl = require('../controllers/auth.controller');
const { validate } = require('../middleware/validate');
const {
  registerSchema,
  verifyPhoneOtpSchema,
  loginSchema,
  forgotPasswordSendCodeSchema,
  forgotPasswordResetSchema,
  refreshSchema,
} = require('../validators/auth.validator');

// Login muvaffaqiyatli bo'lsa limit hisoblanmaydi. Docker/LAN ortida ko'p
// foydalanuvchi bitta IP ko'rinishi mumkin, shu sabab identifier ham kalitga qo'shiladi.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  keyGenerator: (req) => {
    const ip = req.ip || req.socket?.remoteAddress || '127.0.0.1';
    const identifier = String(req.body?.identifier || '').trim().toLowerCase();
    return `${ip}:${identifier || 'missing-identifier'}`;
  },
  skipSuccessfulRequests: true,
  message: { error: "Parol yoki login bir necha marta notoʻgʻri kiritildi. 15 daqiqadan keyin qayta urinib koʻring." },
  standardHeaders: true,
  legacyHeaders: false,
});

const registerLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  skipSuccessfulRequests: true,
  message: { error: "Roʻyxatdan oʻtish urinishlari koʻpaydi. Birozdan keyin qayta urinib koʻring." },
  standardHeaders: true,
  legacyHeaders: false,
});

// SMS kod so'rovlarini yanada qattiqroq cheklash - SMS-bomber hujumlaridan himoya
const otpLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 daqiqa
  max: 5,
  message: { error: 'Juda ko\'p urinish. Birozdan keyin qayta urinib ko\'ring.' },
  standardHeaders: true,
  legacyHeaders: false,
});

if (process.env.NODE_ENV === 'test') {
  router.post('/register', registerLimiter, validate(registerSchema), ctrl.registerTestOnly);
}
router.post('/register/request-code', registerLimiter, validate(registerSchema), ctrl.requestRegistrationCode);
router.post('/register/verify-code', otpLimiter, validate(verifyPhoneOtpSchema), ctrl.verifyRegistrationCode);
router.post('/login', loginLimiter, validate(loginSchema), ctrl.login);
router.post('/login/verify-phone', otpLimiter, validate(verifyPhoneOtpSchema), ctrl.verifyLoginPhone);
router.post(
  '/forgot-password/send-code',
  otpLimiter,
  validate(forgotPasswordSendCodeSchema),
  ctrl.forgotPasswordSendCode
);
router.post(
  '/forgot-password/reset',
  otpLimiter,
  validate(forgotPasswordResetSchema),
  ctrl.forgotPasswordReset
);
router.post('/refresh', validate(refreshSchema), ctrl.refresh);
router.post('/logout', ctrl.logout);

module.exports = router;
