const express = require('express');
const router = express.Router();

const ctrl = require('../controllers/chat.controller');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { sendMessageSchema, paginationSchema } = require('../validators/chat.validator');

router.use(authenticate);

router.get('/', ctrl.listChats);
router.get('/:id/messages', validate(paginationSchema, 'query'), ctrl.getMessages);
router.post('/:id/messages', validate(sendMessageSchema), ctrl.sendMessage);

module.exports = router;
