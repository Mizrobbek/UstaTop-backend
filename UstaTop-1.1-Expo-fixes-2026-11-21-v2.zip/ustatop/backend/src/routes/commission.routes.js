const router = require('express').Router();
const { authenticate, requireRole } = require('../middleware/auth');
const ctrl = require('../controllers/commission.controller');
router.use(authenticate,requireRole('provider','both'));
router.get('/summary',ctrl.mySummary);
router.get('/history',ctrl.myHistory);
module.exports=router;
