const express = require('express');
const router = express.Router();

const listingCtrl = require('../controllers/listing.controller');
const offerCtrl = require('../controllers/offer.controller');
const { authenticate, requireRole, optionalAuth } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { createListingSchema, updateListingSchema, listQuerySchema, mapQuerySchema } = require('../validators/listing.validator');
const { createOfferSchema } = require('../validators/listing.validator');

// Ommaviy (login shart emas, lekin bo'lsa ham foydalaniladi)
router.get('/', validate(listQuerySchema, 'query'), listListingsPublic);
// DIQQAT: '/map' va '/mine' albatta '/:id'dan OLDIN turishi kerak, aks holda "map" ID deb tushunilib qoladi
router.get('/map', validate(mapQuerySchema, 'query'), listingCtrl.getMapListings);
router.get('/mine', authenticate, listingCtrl.myListings);
router.get('/:id', optionalAuth, listingCtrl.getListing);

// Himoyalangan (faqat mijoz/both rolidagi foydalanuvchi e'lon yarata oladi)
router.post('/', authenticate, requireRole('client', 'both'), validate(createListingSchema), listingCtrl.createListing);
router.patch('/:id', authenticate, validate(updateListingSchema), listingCtrl.updateListing);
router.delete('/:id', authenticate, listingCtrl.deleteListing);

// Shu e'longa tegishli takliflar
router.post(
  '/:id/offers',
  authenticate,
  requireRole('provider', 'both'),
  validate(createOfferSchema),
  offerCtrl.createOffer
);
router.get('/:id/offers', authenticate, offerCtrl.listOffersForListing);

// optionalAuth bilan GET / ni to'g'ridan-to'g'ri bog'lash uchun kichik wrapper
function listListingsPublic(req, res, next) {
  return optionalAuth(req, res, () => listingCtrl.listListings(req, res, next));
}

module.exports = router;
