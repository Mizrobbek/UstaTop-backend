const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');
const ctrl = require('../controllers/media.controller');
router.post('/upload', authenticate, upload.array('files', 10), ctrl.uploadMedia);
module.exports = router;
