const express = require('express');
const router = express.Router();

const ctrl = require('../controllers/notification.controller');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { listNotificationsQuerySchema } = require('../validators/notification.validator');

router.use(authenticate);

router.get('/', validate(listNotificationsQuerySchema, 'query'), ctrl.listNotifications);
router.patch('/read-all', ctrl.markAllRead);
router.patch('/:id/read', ctrl.markRead);

module.exports = router;
