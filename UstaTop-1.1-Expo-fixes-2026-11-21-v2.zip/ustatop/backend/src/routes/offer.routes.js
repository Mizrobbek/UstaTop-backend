const express = require('express');
const router = express.Router();

const offerCtrl = require('../controllers/offer.controller');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { offerStatusSchema } = require('../validators/offer.validator');

router.get('/mine', authenticate, offerCtrl.myOffers);
router.patch('/:id', authenticate, validate(offerStatusSchema), offerCtrl.updateOfferStatus);

module.exports = router;
