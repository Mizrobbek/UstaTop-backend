const express = require('express');
const router = express.Router();

const ctrl = require('../controllers/order.controller');
const reviewCtrl = require('../controllers/review.controller');
const paymentCtrl = require('../controllers/payment.controller');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { updateOrderStatusSchema } = require('../validators/order.validator');
const { createReviewSchema } = require('../validators/review.validator');
const { initiatePaymentSchema } = require('../validators/payment.validator');

router.use(authenticate);

router.get('/', ctrl.listMyOrders);
router.get('/:id', ctrl.getOrder);
router.patch('/:id/status', validate(updateOrderStatusSchema), ctrl.updateOrderStatus);
router.patch('/:id/payment-confirmation', ctrl.confirmServicePayment);
router.post('/:id/review', validate(createReviewSchema), reviewCtrl.createReview);
router.post('/:id/pay', validate(initiatePaymentSchema), paymentCtrl.initiatePayment);
router.get('/:id/payment-status', paymentCtrl.getPaymentStatus);

module.exports = router;
