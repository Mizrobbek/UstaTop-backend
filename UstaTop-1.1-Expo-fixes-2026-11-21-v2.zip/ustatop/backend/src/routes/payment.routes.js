const express = require('express');
const router = express.Router();

const ctrl = require('../controllers/payment.controller');
const { paymeAuth } = require('../middleware/paymeAuth');

// Payme Business va Click.uz bu endpoint'larga TASHQARIDAN (ularning serverlaridan) so'rov
// yuboradi - shuning uchun bu yerda authenticate (JWT) middleware YO'Q. Xavfsizlik Payme uchun
// Basic Auth (paymeAuth) orqali, Click uchun esa MD5 imzo tekshiruvi orqali ta'minlanadi.
router.post('/payme', paymeAuth, ctrl.paymeWebhook);
router.post('/click/prepare', ctrl.clickPrepare);
router.post('/click/complete', ctrl.clickComplete);

module.exports = router;
