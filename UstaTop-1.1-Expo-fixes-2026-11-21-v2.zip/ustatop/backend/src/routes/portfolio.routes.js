const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { listMine, addMine, deleteMine } = require('../controllers/portfolio.controller');
router.use(authenticate, requireRole('provider', 'both'));
router.get('/me', listMine);
router.post('/me', addMine);
router.delete('/me/:id', deleteMine);
module.exports = router;
