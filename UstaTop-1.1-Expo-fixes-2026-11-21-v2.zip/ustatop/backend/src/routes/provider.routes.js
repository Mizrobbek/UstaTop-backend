const express = require('express');
const router = express.Router();

const providerCtrl = require('../controllers/provider.controller');
const reviewCtrl = require('../controllers/review.controller');

router.get('/:id', providerCtrl.getProviderProfile);
router.get('/:id/reviews', reviewCtrl.listProviderReviews);

module.exports = router;
