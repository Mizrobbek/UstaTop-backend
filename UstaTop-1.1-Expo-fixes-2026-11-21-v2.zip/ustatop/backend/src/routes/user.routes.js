const express = require('express');
const router = express.Router();

const ctrl = require('../controllers/user.controller');
const notificationCtrl = require('../controllers/notification.controller');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { updateProfileSchema, becomeProviderSchema } = require('../validators/user.validator');
const { pushTokenSchema } = require('../validators/notification.validator');

router.use(authenticate);

router.get('/me', ctrl.getMe);
router.patch('/me', validate(updateProfileSchema), ctrl.updateMe);
router.post('/me/phone/change/request', ctrl.requestPhoneChange);
router.post('/me/phone/change/confirm', ctrl.confirmPhoneChange);
router.patch('/me/provider-profile', validate(require('../validators/user.validator').updateProviderProfileSchema), ctrl.updateProviderProfile);
router.post('/me/become-provider', validate(becomeProviderSchema), ctrl.becomeProvider);
router.post('/me/push-token', validate(pushTokenSchema), notificationCtrl.registerPushToken);

module.exports = router;
