/**
 * Administrator yaratish. Admin rolini API orqali olib bo'lmaydi (xavfsizlik uchun),
 * shuning uchun birinchi adminni server tomonida shu skript bilan yaratasiz.
 *
 * Ishlatish:
 *   npm run create-admin -- +998901234567 "Kuchli_Parol_123" "Admin Ismi"
 *
 * Docker'da:
 *   docker compose exec backend node src/scripts/createAdmin.js +998901234567 "Kuchli_Parol_123" "Admin"
 *
 * Telefon allaqachon ro'yxatdan o'tgan bo'lsa, o'sha hisob admin qilinadi va paroli yangilanadi.
 */
const bcrypt = require('bcryptjs');
require('dotenv').config();
const { pool } = require('../config/db');

async function main() {
  const [phone, password, fullName = 'Administrator'] = process.argv.slice(2);

  if (!phone || !/^\+998\d{9}$/.test(phone)) {
    console.error('Xato: telefon +998XXXXXXXXX formatida bo\'lishi kerak');
    console.error('Misol: npm run create-admin -- +998901234567 "Parol_12345" "Admin"');
    process.exit(1);
  }
  if (!password || password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    console.error('Xato: parol kamida 8 belgi, harf va raqamdan iborat bo\'lishi kerak');
    process.exit(1);
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const result = await pool.query(
    `INSERT INTO users (phone, password_hash, full_name, role, is_phone_verified)
     VALUES ($1, $2, $3, 'admin', TRUE)
     ON CONFLICT (phone) DO UPDATE SET role = 'admin', password_hash = EXCLUDED.password_hash, is_active = TRUE
     RETURNING id, phone, full_name, role`,
    [phone, passwordHash, fullName]
  );

  console.log('✅ Administrator tayyor:', result.rows[0]);
  console.log('   Admin panel: http://localhost:4000/admin (login sifatida telefon raqamingizni kiriting)');
  await pool.end();
}

main().catch(async (err) => {
  console.error('Xato:', err.message);
  await pool.end();
  process.exit(1);
});
