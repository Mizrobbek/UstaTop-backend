/**
 * Oddiy migratsiya skripti (ORM ishlatilmagan, SQL sxema to'g'ridan-to'g'ri va nazoratda).
 *
 * Qo'llangan fayllar `schema_migrations` jadvalida saqlanadi, shuning uchun skriptni
 * istalgancha marta ishga tushirish xavfsiz: faqat yangi fayllar bajariladi.
 * Docker konteyner qayta ishga tushganda ham xato bermaydi.
 *
 * Ishlatish:
 *   node src/scripts/migrate.js          -> sxema fayllarini qo'llaydi (seed'siz)
 *   node src/scripts/migrate.js --seed   -> sxema + boshlang'ich ma'lumotlar (kategoriyalar)
 */
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { pool } = require('../config/db');

async function run() {
  const withSeed = process.argv.includes('--seed');
  const migrationsDir = path.join(__dirname, '..', '..', 'migrations');

  await pool.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      filename   TEXT PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )
  `);
  const appliedResult = await pool.query('SELECT filename FROM schema_migrations');
  const applied = new Set(appliedResult.rows.map((r) => r.filename));

  const files = fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith('.sql'))
    .filter((f) => (withSeed ? true : !f.includes('seed')))
    .sort();

  let appliedNow = 0;
  for (const file of files) {
    if (applied.has(file)) {
      console.log(`⏭  O'tkazib yuborildi (allaqachon qo'llangan): ${file}`);
      continue;
    }

    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    console.log(`▶ Bajarilmoqda: ${file}`);
    const client = await pool.connect();
    try {
      // Har bir fayl bitta tranzaksiyada: xato bo'lsa, yarim-yarti qo'llanib qolmaydi
      await client.query('BEGIN');
      await client.query(sql);
      await client.query('INSERT INTO schema_migrations (filename) VALUES ($1)', [file]);
      await client.query('COMMIT');
      console.log(`✔ Muvaffaqiyatli: ${file}`);
      appliedNow++;
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(`✘ Xato ${file} faylida:`, err.message);
      client.release();
      await pool.end();
      process.exit(1);
    }
    client.release();
  }

  console.log(appliedNow ? `\n✅ ${appliedNow} ta migratsiya qo'llandi` : '\n✅ Baza allaqachon yangilangan');
  await pool.end();
}

run();
