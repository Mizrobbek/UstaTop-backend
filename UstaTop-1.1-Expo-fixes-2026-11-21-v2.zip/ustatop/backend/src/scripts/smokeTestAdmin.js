/**
 * Admin controller'ini HAQIQIY kodi bilan ishga tushirib tekshiradi.
 *
 * smokeTestFakeDb.js SQL matnlarini qo'lda ko'chirib tekshirsa, bu skript esa
 * config/db modulini soxta baza bilan almashtirib (require.cache orqali), controller
 * funksiyalarining o'zini chaqiradi. Shu sababli controller'dagi SQL yoki mantiqiy xatolar
 * (noto'g'ri parametr tartibi, huquq tekshiruvi va h.k.) to'g'ridan-to'g'ri ushlanadi.
 * Express, Joi yoki PostgreSQL o'rnatilishi shart emas.
 *
 * Ishga tushirish: npm run verify   (yoki: node src/scripts/smokeTestAdmin.js)
 */
const assert = require('assert');
const { createFakeDb } = require('../../tests/testUtils/fakeDb');

const db = createFakeDb();
const dbModulePath = require.resolve('../config/db');
require.cache[dbModulePath] = {
  id: dbModulePath,
  filename: dbModulePath,
  loaded: true,
  exports: { query: db.query, getClient: db.getClient, pool: { query: db.query, end: async () => {} } },
};

const admin = require('../controllers/admin.controller');

let passed = 0;
function ok(desc) {
  passed++;
  console.log(`  ✔ ${desc}`);
}

/** Express'ning req/res obyektlarini taqlid qiluvchi minimal yordamchi */
async function call(handler, { params = {}, query = {}, body = {}, user = { id: 'admin-1', role: 'admin' } } = {}) {
  const out = { status: 200, body: undefined, error: undefined };
  const res = {
    status(code) {
      out.status = code;
      return this;
    },
    json(payload) {
      out.body = payload;
      return this;
    },
  };
  await handler({ params, query, body, user }, res, (err) => {
    out.error = err;
  });
  if (out.error) throw out.error;
  return out;
}

async function run() {
  const insertUser = `INSERT INTO users (phone, email, password_hash, full_name) VALUES ($1, $2, $3, $4) RETURNING *`;
  const adminUser = (await db.query(insertUser, ['+998900000001', null, 'h', 'Bosh Admin'])).rows[0];
  adminUser.role = 'admin';
  const otherAdmin = (await db.query(insertUser, ['+998900000002', null, 'h', 'Ikkinchi Admin'])).rows[0];
  otherAdmin.role = 'admin';
  const client = (await db.query(insertUser, ['+998900000003', 'ali@example.com', 'h', 'Ali Valiyev'])).rows[0];
  const provider = (await db.query(insertUser, ['+998900000004', null, 'h', 'Usta Karim'])).rows[0];
  provider.role = 'both';
  db.state.provider_profiles.push({
    user_id: provider.id, bio: null, experience_years: 3, rating_avg: 0, rating_count: 0,
    completed_orders_count: 0, is_verified: false,
  });
  const actor = { id: adminUser.id, role: 'admin' };

  db.state.categories.push({ id: 1, name_uz: 'Santexnik', is_active: true, sort_order: 1 });

  const insertListing = `INSERT INTO listings (client_id, category_id, title, description, price, price_type, address, city, latitude, longitude)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`;
  const l1 = (await db.query(insertListing, [client.id, 1, 'Kran tamiri', 'Suv oqyapti', 100000, 'fixed', null, 'Toshkent', null, null])).rows[0];
  const l2 = (await db.query(insertListing, [client.id, 1, 'Quvur almashtirish', 'Eski quvur', null, 'negotiable', null, 'Samarqand', null, null])).rows[0];
  await db.query(`UPDATE listings SET status = 'in_progress' WHERE id = $1`, [l2.id]);
  const o1 = (await db.query(
    `INSERT INTO orders (listing_id, offer_id, client_id, provider_id, agreed_price) VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [l2.id, 'offer-x', client.id, provider.id, 250000]
  )).rows[0];
  await db.query("UPDATE orders SET status = 'completed', completed_at = now() WHERE id = $1", [o1.id]);

  // ---- Statistika ----
  let r = await call(admin.getStats, { user: actor });
  assert.strictEqual(r.body.stats.users.total, 4);
  assert.strictEqual(r.body.stats.users.byRole.admin, 2);
  assert.strictEqual(r.body.stats.users.byRole.client, 1);
  assert.strictEqual(r.body.stats.listings.total, 2);
  assert.strictEqual(r.body.stats.listings.byStatus.open, 1);
  assert.strictEqual(r.body.stats.orders.completedVolume, 250000);
  ok('getStats: foydalanuvchi/e\'lon/buyurtma sonlari va yakunlangan buyurtmalar summasi to\'g\'ri');

  // ---- Foydalanuvchilar ro'yxati ----
  r = await call(admin.listUsers, { query: { page: 1, limit: 20 }, user: actor });
  assert.strictEqual(r.body.users.length, 4);
  assert.strictEqual(r.body.pagination.total, 4);
  ok('listUsers: filtrsiz barcha foydalanuvchilar qaytdi');

  r = await call(admin.listUsers, { query: { role: 'admin', page: 1, limit: 20 }, user: actor });
  assert.strictEqual(r.body.users.length, 2);
  ok('listUsers: rol bo\'yicha filtr ishladi');

  r = await call(admin.listUsers, { query: { search: 'ali@', page: 1, limit: 20 }, user: actor });
  assert.strictEqual(r.body.users.length, 1);
  assert.strictEqual(r.body.users[0].fullName, 'Ali Valiyev');
  ok('listUsers: email bo\'yicha qidiruv ishladi');

  r = await call(admin.listUsers, { query: { page: 1, limit: 2 }, user: actor });
  assert.strictEqual(r.body.users.length, 2);
  assert.strictEqual(r.body.pagination.totalPages, 2);
  ok('listUsers: sahifalash (limit=2 -> 2 sahifa) ishladi');

  r = await call(admin.listUsers, { query: { role: 'both', page: 1, limit: 20 }, user: actor });
  assert.strictEqual(r.body.users[0].providerVerified, false);
  ok('listUsers: usta uchun providerVerified holati qaytdi');

  // ---- Bloklash ----
  r = await call(admin.setUserActive, { params: { id: adminUser.id }, body: { isActive: false }, user: actor });
  assert.strictEqual(r.status, 400);
  ok('setUserActive: admin o\'zini bloklay olmaydi (400)');

  r = await call(admin.setUserActive, { params: { id: otherAdmin.id }, body: { isActive: false }, user: actor });
  assert.strictEqual(r.status, 403);
  ok('setUserActive: boshqa adminni bloklab bo\'lmaydi (403)');

  r = await call(admin.setUserActive, { params: { id: 'yoq-id' }, body: { isActive: false }, user: actor });
  assert.strictEqual(r.status, 404);
  ok('setUserActive: mavjud bo\'lmagan foydalanuvchi uchun 404');

  db.state.refresh_tokens.push({ id: 'rt1', user_id: client.id, token_hash: 'x', expires_at: new Date(Date.now() + 1e9), revoked: false });
  r = await call(admin.setUserActive, { params: { id: client.id }, body: { isActive: false }, user: actor });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(db.state.users.find((u) => u.id === client.id).is_active, false);
  assert.strictEqual(db.state.refresh_tokens.find((t) => t.id === 'rt1').revoked, true);
  ok('setUserActive: mijoz bloklandi va uning sessiyalari (refresh token) bekor qilindi');

  r = await call(admin.setUserActive, { params: { id: client.id }, body: { isActive: true }, user: actor });
  assert.strictEqual(db.state.users.find((u) => u.id === client.id).is_active, true);
  ok('setUserActive: blokdan chiqarish ishladi');

  // ---- Ustani tasdiqlash ----
  r = await call(admin.verifyProvider, { params: { id: provider.id }, body: { isVerified: true }, user: actor });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(db.state.provider_profiles[0].is_verified, true);
  ok('verifyProvider: usta tasdiqlandi');

  r = await call(admin.verifyProvider, { params: { id: client.id }, body: { isVerified: true }, user: actor });
  assert.strictEqual(r.status, 404);
  ok('verifyProvider: usta bo\'lmagan foydalanuvchi uchun 404');

  // ---- E'lonlar moderatsiyasi ----
  r = await call(admin.listListings, { query: { page: 1, limit: 20 }, user: actor });
  assert.strictEqual(r.body.listings.length, 2);
  assert.strictEqual(r.body.listings[0].clientName, 'Ali Valiyev');
  assert.strictEqual(r.body.listings[0].categoryName, 'Santexnik');
  ok('listListings: e\'lonlar kategoriya va egasi nomi bilan qaytdi');

  r = await call(admin.listListings, { query: { status: 'open', page: 1, limit: 20 }, user: actor });
  assert.strictEqual(r.body.listings.length, 1);
  ok('listListings: status filtri ishladi');

  r = await call(admin.listListings, { query: { search: 'quvur', page: 1, limit: 20 }, user: actor });
  assert.strictEqual(r.body.listings.length, 1);
  assert.strictEqual(r.body.listings[0].title, 'Quvur almashtirish');
  ok('listListings: sarlavha bo\'yicha qidiruv ishladi');

  r = await call(admin.cancelListing, { params: { id: l2.id }, user: actor });
  assert.strictEqual(r.status, 400);
  ok('cancelListing: jarayondagi e\'lonni bekor qilib bo\'lmaydi (400)');

  r = await call(admin.cancelListing, { params: { id: 'yoq' }, user: actor });
  assert.strictEqual(r.status, 404);
  ok('cancelListing: mavjud bo\'lmagan e\'lon uchun 404');

  r = await call(admin.cancelListing, { params: { id: l1.id }, user: actor });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(db.state.listings.find((l) => l.id === l1.id).status, 'cancelled');
  assert.strictEqual(db.state.notifications.length, 1);
  ok('cancelListing: ochiq e\'lon bekor qilindi va egasiga bildirishnoma yaratildi');

  // ---- Kategoriyalar ----
  r = await call(admin.createCategory, { body: { nameUz: 'Bog\'bon', nameRu: 'Садовник', icon: 'garden', sortOrder: 5 }, user: actor });
  assert.strictEqual(r.status, 201);
  assert.strictEqual(r.body.category.nameUz, 'Bog\'bon');
  assert.strictEqual(r.body.category.isActive, true);
  const newCatId = r.body.category.id;
  ok('createCategory: yangi kategoriya yaratildi');

  r = await call(admin.updateCategory, { params: { id: String(newCatId) }, body: { isActive: false, sortOrder: 9 }, user: actor });
  assert.strictEqual(r.body.category.isActive, false);
  assert.strictEqual(r.body.category.sortOrder, 9);
  assert.strictEqual(r.body.category.nameUz, 'Bog\'bon');
  ok('updateCategory: kategoriya nofaol qilindi (boshqa maydonlar o\'zgarmadi)');

  r = await call(admin.updateCategory, { params: { id: '999' }, body: { nameUz: 'Yo\'q' }, user: actor });
  assert.strictEqual(r.status, 404);
  ok('updateCategory: mavjud bo\'lmagan kategoriya uchun 404');

  r = await call(admin.updateCategory, { params: { id: 'abc' }, body: { nameUz: 'X' }, user: actor });
  assert.strictEqual(r.status, 400);
  ok('updateCategory: noto\'g\'ri ID formati uchun 400');

  r = await call(admin.listCategories, { user: actor });
  assert.strictEqual(r.body.categories.length, 2);
  assert.ok(r.body.categories.some((c) => c.isActive === false));
  ok('listCategories: nofaol kategoriyalar ham admin ro\'yxatida ko\'rinadi');

  console.log(`\n✅ Admin controller: ${passed} ta tekshiruv MUVAFFAQIYATLI o'tdi\n`);
}

run().catch((err) => {
  console.error('\n❌ ADMIN SMOKE TEST MUVAFFAQIYATSIZ:', err.message);
  console.error(err.stack);
  process.exit(1);
});
