// Bu fayl jest/express o'rnatilmagan muhitda ham fakeDb.js dagi SQL-moslashtirish
// mantig'ini HAQIQATDA ishga tushirib tekshirish uchun yozilgan qo'lda skript.
// Controller fayllaridagi SQL matnlarini so'zma-so'z ko'chirib, aynan fakeDb qanday
// javob berishini tekshiramiz - bu sintaksis tekshiruvidan farqli o'laroq, real xatolarni topadi.
const assert = require('assert');
const { createFakeDb } = require('../../tests/testUtils/fakeDb');

async function run() {
  const db = createFakeDb();
  let passed = 0;

  function ok(desc) {
    passed++;
    console.log(`  ✔ ${desc}`);
  }

  // ---- Foydalanuvchi yaratish (register controller bilan bir xil SQL) ----
  const insertUserSql = `INSERT INTO users (phone, email, password_hash, full_name)
       VALUES ($1, $2, $3, $4) RETURNING *`;
  const u1 = (await db.query(insertUserSql, ['+998900000001', null, 'hash1', 'Client One'])).rows[0];
  const u2 = (await db.query(insertUserSql, ['+998900000002', null, 'hash2', 'Provider One'])).rows[0];
  assert.strictEqual(u1.phone, '+998900000001');
  ok('Foydalanuvchi yaratish ishladi');

  // authenticate middleware SQL'i to'g'ri ishlashini tekshirish
  const authRow = (
    await db.query('SELECT id, phone, full_name, role, is_active FROM users WHERE id = $1', [u1.id])
  ).rows[0];
  assert.strictEqual(authRow.phone, u1.phone);
  ok('authenticate middleware so\'rovi ishladi');

  // ---- Kategoriya qo'shish (to'g'ridan-to'g'ri state orqali, seed kabi) ----
  db.state.categories.push({ id: 1, name_uz: 'Santexnik', is_active: true, sort_order: 1 });
  db.state.categories.push({ id: 2, name_uz: 'Elektrik', is_active: true, sort_order: 2 });

  const catCheck = (
    await db.query('SELECT id FROM categories WHERE id = $1 AND is_active = TRUE', [1])
  ).rows[0];
  assert.ok(catCheck);
  ok('Kategoriya tekshiruvi ishladi');

  // ---- E'lon yaratish (listing.controller.js bilan bir xil SQL) ----
  const insertListingSql = `INSERT INTO listings (client_id, category_id, title, description, price, price_type, address, city, latitude, longitude)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`;
  const listing1 = (
    await db.query(insertListingSql, [
      u1.id, 1, 'Kranni tamirlash kerak', 'Oshxonadagi kran suv oqizyapti', null, 'negotiable', null, 'Toshkent', 41.31, 69.28,
    ])
  ).rows[0];
  const listing2 = (
    await db.query(insertListingSql, [
      u1.id, 2, 'Elektr simini almashtirish', 'Rozetka ishlamayapti butunlay', 50000, 'fixed', null, 'Toshkent', 41.30, 69.25,
    ])
  ).rows[0];
  assert.strictEqual(listing1.status, 'open');
  ok('E\'lon yaratish ishladi');

  // ---- listListings: dinamik WHERE bilan filtrlash (eng murakkab qism) ----
  const mainSelectSql = `SELECT l.*, c.name_uz AS category_name, u.full_name AS client_name, u.avatar_url AS client_avatar,
              (SELECT COUNT(*) FROM offers o WHERE o.listing_id = l.id) AS offers_count,
              COALESCE(
                (SELECT json_agg(m.url ORDER BY m.sort_order) FROM listing_media m WHERE m.listing_id = l.id),
                '[]'
              ) AS media
       FROM listings l
       JOIN categories c ON c.id = l.category_id
       JOIN users u ON u.id = l.client_id
       WHERE l.status = $1
       ORDER BY l.created_at DESC
       LIMIT $2 OFFSET $3`;
  const allOpen = await db.query(mainSelectSql, ['open', 20, 0]);
  assert.strictEqual(allOpen.rows.length, 2, `Kutilgan 2 ta ochiq e'lon, olindi: ${allOpen.rows.length}`);
  ok('Status bo\'yicha filtrlash (status=open) ishladi');

  const categoryFilterSql = `SELECT l.*, c.name_uz AS category_name, u.full_name AS client_name, u.avatar_url AS client_avatar,
              (SELECT COUNT(*) FROM offers o WHERE o.listing_id = l.id) AS offers_count,
              COALESCE(
                (SELECT json_agg(m.url ORDER BY m.sort_order) FROM listing_media m WHERE m.listing_id = l.id),
                '[]'
              ) AS media
       FROM listings l
       JOIN categories c ON c.id = l.category_id
       JOIN users u ON u.id = l.client_id
       WHERE l.category_id = $1 AND l.status = $2
       ORDER BY l.created_at DESC
       LIMIT $3 OFFSET $4`;
  const cat1Only = await db.query(categoryFilterSql, [1, 'open', 20, 0]);
  assert.strictEqual(cat1Only.rows.length, 1);
  assert.strictEqual(cat1Only.rows[0].title, 'Kranni tamirlash kerak');
  ok('Kategoriya + status kombinatsiyasi bo\'yicha filtrlash ishladi (WHERE parser to\'g\'ri ishlayapti!)');

  const searchSql = `SELECT l.*, c.name_uz AS category_name, u.full_name AS client_name, u.avatar_url AS client_avatar,
              (SELECT COUNT(*) FROM offers o WHERE o.listing_id = l.id) AS offers_count,
              COALESCE(
                (SELECT json_agg(m.url ORDER BY m.sort_order) FROM listing_media m WHERE m.listing_id = l.id),
                '[]'
              ) AS media
       FROM listings l
       JOIN categories c ON c.id = l.category_id
       JOIN users u ON u.id = l.client_id
       WHERE l.status = $1 AND (l.title ILIKE $2 OR l.description ILIKE $2)
       ORDER BY l.created_at DESC
       LIMIT $3 OFFSET $4`;
  const searchResult = await db.query(searchSql, ['open', '%elektr%', 20, 0]);
  assert.strictEqual(searchResult.rows.length, 1);
  assert.strictEqual(searchResult.rows[0].title, 'Elektr simini almashtirish');
  ok('Qidiruv (search) filtri qavslar bilan to\'g\'ri parslandi');

  // ---- Offer yaratish va qabul qilish oqimi ----
  const insertOfferSql = `INSERT INTO offers (listing_id, provider_id, price, message) VALUES ($1, $2, $3, $4) RETURNING *`;
  const offer1 = (await db.query(insertOfferSql, [listing1.id, u2.id, 150000, 'Bugun kela olaman'])).rows[0];
  assert.strictEqual(offer1.status, 'pending');
  ok('Taklif (offer) yaratish ishladi');

  const offerJoinSql = `SELECT o.*, l.client_id, l.title, l.status AS listing_status
       FROM offers o JOIN listings l ON l.id = o.listing_id WHERE o.id = $1`;
  const offerJoined = (await db.query(offerJoinSql, [offer1.id])).rows[0];
  assert.strictEqual(offerJoined.client_id, u1.id);
  assert.strictEqual(offerJoined.title, 'Kranni tamirlash kerak');
  ok('Offer + Listing JOIN so\'rovi ishladi (updateOfferStatus uchun kritik)');

  await db.query('UPDATE offers SET status = $1 WHERE id = $2', ['accepted', offer1.id]);
  await db.query(`UPDATE listings SET status = 'in_progress' WHERE id = $1`, [listing1.id]);
  const updatedListing = (await db.query('SELECT * FROM listings WHERE id = $1', [listing1.id])).rows[0];
  assert.strictEqual(updatedListing.status, 'in_progress');
  ok('Taklif qabul qilingandan keyin e\'lon holati "in_progress"ga o\'zgardi');

  const insertOrderSql = `INSERT INTO orders (listing_id, offer_id, client_id, provider_id, agreed_price)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`;
  const order1 = (await db.query(insertOrderSql, [listing1.id, offer1.id, u1.id, u2.id, 150000])).rows[0];
  assert.strictEqual(order1.status, 'confirmed');
  ok('Buyurtma (order) yaratish ishladi');

  // ---- Chat va xabarlar oqimi ----
  const insertChatSql = `INSERT INTO chats (listing_id, client_id, provider_id) VALUES ($1, $2, $3)
       ON CONFLICT (listing_id, client_id, provider_id) DO UPDATE SET listing_id = EXCLUDED.listing_id
       RETURNING *`;
  const chat1 = (await db.query(insertChatSql, [listing1.id, u1.id, u2.id])).rows[0];
  assert.ok(chat1.id);
  ok('Chat yaratish ishladi');

  const insertMessageSql = `INSERT INTO messages (chat_id, sender_id, content, media_url) VALUES ($1, $2, $3, $4) RETURNING *`;
  await db.query(insertMessageSql, [chat1.id, u1.id, 'Salom, qachon kela olasiz?', null]);
  await new Promise((r) => setTimeout(r, 5));
  await db.query(insertMessageSql, [chat1.id, u2.id, 'Bugun soat 15:00 da', null]);

  const listChatsSql = `SELECT c.*, l.title AS listing_title,
              cu.full_name AS client_name, cu.avatar_url AS client_avatar,
              pu.full_name AS provider_name, pu.avatar_url AS provider_avatar,
              lm.content AS last_message_content, lm.created_at AS last_message_at,
              (SELECT COUNT(*) FROM messages m WHERE m.chat_id = c.id AND m.sender_id != $1 AND m.is_read = FALSE) AS unread_count
       FROM chats c
       LEFT JOIN listings l ON l.id = c.listing_id
       JOIN users cu ON cu.id = c.client_id
       JOIN users pu ON pu.id = c.provider_id
       LEFT JOIN LATERAL (
         SELECT content, created_at FROM messages WHERE chat_id = c.id ORDER BY created_at DESC LIMIT 1
       ) lm ON TRUE
       WHERE c.client_id = $1 OR c.provider_id = $1
       ORDER BY COALESCE(lm.created_at, c.created_at) DESC`;
  const clientChats = (await db.query(listChatsSql, [u1.id])).rows;
  assert.strictEqual(clientChats.length, 1);
  assert.strictEqual(clientChats[0].last_message_content, 'Bugun soat 15:00 da');
  assert.strictEqual(clientChats[0].unread_count, '1'); // usta yuborgan, hali o'qilmagan
  ok('Suhbatlar ro\'yxati + so\'nggi xabar + o\'qilmaganlar soni to\'g\'ri hisoblandi');

  const getMessagesSql = `SELECT * FROM messages WHERE chat_id = $1  ORDER BY created_at DESC LIMIT $2`;
  const msgs = (await db.query(getMessagesSql, [chat1.id, 30])).rows;
  assert.strictEqual(msgs.length, 2);
  ok('Xabarlar tarixini olish ishladi');

  await db.query('UPDATE messages SET is_read = TRUE WHERE chat_id = $1 AND sender_id != $2 AND is_read = FALSE', [
    chat1.id,
    u1.id,
  ]);
  const clientChatsAfterRead = (await db.query(listChatsSql, [u1.id])).rows;
  assert.strictEqual(clientChatsAfterRead[0].unread_count, '0');
  ok('Xabarni "o\'qilgan" deb belgilash ishladi');

  // ---- "Usta bo'lish" oqimi ----
  await db.query(
    `INSERT INTO provider_profiles (user_id, bio, experience_years) VALUES ($1, $2, $3)
       ON CONFLICT (user_id) DO UPDATE SET bio = EXCLUDED.bio, experience_years = EXCLUDED.experience_years`,
    [u2.id, 'Tajribali santexnik', 5]
  );
  await db.query(
    `INSERT INTO provider_categories (provider_id, category_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
    [u2.id, 1]
  );
  const providerProfileSql = `SELECT u.id, u.full_name, u.avatar_url, u.city, u.created_at,
              pp.bio, pp.experience_years, pp.rating_avg, pp.rating_count, pp.completed_orders_count, pp.is_verified
       FROM users u JOIN provider_profiles pp ON pp.user_id = u.id
       WHERE u.id = $1`;
  const providerProfile = (await db.query(providerProfileSql, [u2.id])).rows[0];
  assert.strictEqual(providerProfile.bio, 'Tajribali santexnik');
  assert.strictEqual(providerProfile.experience_years, 5);
  ok('"Usta bo\'lish" (provider_profiles yaratish) ishladi');

  // ---- Buyurtma holatini o'zgartirish (in_progress -> completed) ----
  await db.query("UPDATE orders SET status = 'in_progress', started_at = now() WHERE id = $1", [order1.id]);
  const inProgressOrder = (
    await db.query(`SELECT o.*, l.title AS listing_title, cu.full_name AS client_name, pu.full_name AS provider_name,
              EXISTS(SELECT 1 FROM reviews r WHERE r.order_id = o.id) AS has_review
       FROM orders o JOIN listings l ON l.id = o.listing_id
       JOIN users cu ON cu.id = o.client_id JOIN users pu ON pu.id = o.provider_id
       WHERE o.id = $1`, [order1.id])
  ).rows[0];
  assert.strictEqual(inProgressOrder.status, 'in_progress');
  ok('Buyurtma holatini "in_progress"ga o\'zgartirish ishladi');

  await db.query("UPDATE orders SET status = 'completed', completed_at = now() WHERE id = $1", [order1.id]);
  await db.query(`UPDATE listings SET status = 'completed' WHERE id = $1`, [listing1.id]);
  await db.query(
    'UPDATE provider_profiles SET completed_orders_count = completed_orders_count + 1 WHERE user_id = $1',
    [u2.id]
  );
  const completedListing = (await db.query('SELECT * FROM listings WHERE id = $1', [listing1.id])).rows[0];
  assert.strictEqual(completedListing.status, 'completed');
  const ppAfterComplete = (await db.query('SELECT * FROM provider_profiles WHERE user_id = $1', [u2.id])).rows[0];
  assert.strictEqual(ppAfterComplete.completed_orders_count, 1);
  ok('Buyurtmani yakunlash + e\'lon holati + completed_orders_count barchasi to\'g\'ri yangilandi');

  // ---- Sharh qoldirish va reyting hisoblash ----
  const insertReviewSql = `INSERT INTO reviews (order_id, reviewer_id, reviewee_id, rating, comment)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`;
  await db.query(insertReviewSql, [order1.id, u1.id, u2.id, 5, 'Zo\'r ishladi, tavsiya qilaman!']);
  const aggSql = `SELECT COUNT(*) AS count, COALESCE(AVG(rating), 0) AS avg FROM reviews WHERE reviewee_id = $1`;
  const agg = (await db.query(aggSql, [u2.id])).rows[0];
  assert.strictEqual(agg.count, '1');
  assert.strictEqual(Number(agg.avg), 5);
  await db.query('UPDATE provider_profiles SET rating_count = $1, rating_avg = $2 WHERE user_id = $3', [
    agg.count,
    Number(agg.avg).toFixed(1),
    u2.id,
  ]);
  const ppAfterReview = (await db.query('SELECT * FROM provider_profiles WHERE user_id = $1', [u2.id])).rows[0];
  assert.strictEqual(Number(ppAfterReview.rating_avg), 5);
  ok('Sharh qoldirish + ustaning o\'rtacha reytingini qayta hisoblash ishladi');

  console.log(`\n✅ Barcha ${passed} ta qo'lda tekshiruv MUVAFFAQIYATLI o'tdi (fakeDb mantiqi to'g'ri ishlaydi)\n`);
}

run().catch((err) => {
  console.error('\n❌ SMOKE TEST MUVAFFAQIYATSIZ:', err.message);
  console.error(err.stack);
  process.exit(1);
});
