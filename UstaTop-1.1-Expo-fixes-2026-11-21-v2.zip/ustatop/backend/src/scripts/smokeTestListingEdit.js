/**
 * Listing update controller'ining haqiqiy kodini fakeDb bilan tekshiradi.
 */
const assert = require('assert');
const { v4: uuidv4 } = require('uuid');
const { createFakeDb } = require('../../tests/testUtils/fakeDb');

const db = createFakeDb();
const dbModulePath = require.resolve('../config/db');
require.cache[dbModulePath] = {
  id: dbModulePath, filename: dbModulePath, loaded: true,
  exports: { query: db.query, getClient: db.getClient, pool: { query: db.query, end: async () => {} } },
};
const listingCtrl = require('../controllers/listing.controller');

function response() {
  return {
    statusCode: 200, body: null,
    status(code) { this.statusCode = code; return this; },
    json(body) { this.body = body; return this; },
  };
}
async function call(req) {
  const res = response();
  let error;
  await listingCtrl.updateListing(req, res, (err) => { error = err; });
  if (error) throw error;
  return res;
}

async function run() {
  const ownerId = uuidv4();
  const otherId = uuidv4();
  const listingId = uuidv4();
  db.state.users.push(
    { id: ownerId, full_name: 'E’lon egasi' },
    { id: otherId, full_name: 'Boshqa foydalanuvchi' },
  );
  db.state.categories.push({ id: 1, name_uz: 'Santexnik', is_active: true });
  db.state.listings.push({
    id: listingId, client_id: ownerId, category_id: 1,
    title: 'Eski sarlavha', description: 'Bu yetarlicha uzun tavsif matni',
    price: null, price_type: 'negotiable', address: null, city: 'Toshkent',
    latitude: null, longitude: null, status: 'open', created_at: new Date(),
  });

  const updated = await call({
    params: { id: listingId }, user: { id: ownerId },
    body: {
      title: 'Yangi sarlavha bilan',
      address: 'Chilonzor, 12-mavze',
      city: 'Toshkent',
      latitude: 41.285,
      longitude: 69.203,
    },
  });
  assert.strictEqual(updated.statusCode, 200);
  assert.strictEqual(updated.body.listing.latitude, 41.285);
  assert.strictEqual(updated.body.listing.longitude, 69.203);
  assert.strictEqual(updated.body.listing.address, 'Chilonzor, 12-mavze');

  const forbidden = await call({
    params: { id: listingId }, user: { id: otherId }, body: { title: 'Begona o‘zgartirish' },
  });
  assert.strictEqual(forbidden.statusCode, 403);

  db.state.listings[0].status = 'in_progress';
  const locked = await call({
    params: { id: listingId }, user: { id: ownerId }, body: { title: 'Jarayondagi ish' },
  });
  assert.strictEqual(locked.statusCode, 400);

  console.log('✅ Listing edit controller: 6 ta tekshiruv muvaffaqiyatli o‘tdi');
}

run().catch((err) => {
  console.error('❌ Listing edit tekshiruvi muvaffaqiyatsiz:', err);
  process.exit(1);
});
