/**
 * Xarita funksiyasini HAQIQIY kodi bilan tekshiradi (express/Joi/PostgreSQL kerak emas):
 *   - controllers/listing.controller.js -> getMapListings (soxta baza bilan)
 *   - utils/geo.js -> isInUzbekistanBounds, haversineKm (to'g'ridan-to'g'ri)
 *
 * Ishga tushirish: npm run verify   (yoki: node src/scripts/smokeTestMap.js)
 */
const assert = require('assert');
const { createFakeDb } = require('../../tests/testUtils/fakeDb');

const db = createFakeDb();
const dbModulePath = require.resolve('../config/db');
require.cache[dbModulePath] = {
  id: dbModulePath,
  filename: dbModulePath,
  loaded: true,
  exports: { query: db.query, getClient: db.getClient, pool: { query: db.query, end: async () => {} } },
};

const listingCtrl = require('../controllers/listing.controller');
const { isInUzbekistanBounds, haversineKm, UZ_BOUNDS } = require('../utils/geo');

let passed = 0;
const ok = (desc) => {
  passed++;
  console.log(`  ✔ ${desc}`);
};

async function callMap(query) {
  const out = { body: undefined, error: undefined };
  const res = { status() { return this; }, json(p) { out.body = p; return this; } };
  await listingCtrl.getMapListings({ query }, res, (err) => (out.error = err));
  if (out.error) throw out.error;
  return out.body;
}

// Joi'ning default qiymatlarini (limit) qo'lda taqlid qilamiz
const bbox = (minLat, maxLat, minLng, maxLng, extra = {}) => ({ minLat, maxLat, minLng, maxLng, limit: 150, ...extra });

async function run() {
  // ---------- geo yordamchilari ----------
  assert.strictEqual(isInUzbekistanBounds(41.3111, 69.2797), true);
  assert.strictEqual(isInUzbekistanBounds(42.46, 59.61), true, 'Nukus');
  assert.strictEqual(isInUzbekistanBounds(37.2242, 67.2783), true, 'Termiz (eng janubiy shaharlardan)');
  assert.strictEqual(isInUzbekistanBounds(41.0, 71.7), true, 'Farg\'ona vodiysi');
  ok('isInUzbekistanBounds: Toshkent, Nukus, Termiz, Farg\'ona vodiysi — ichida (noto\'g\'ri rad etish yo\'q)');

  assert.strictEqual(isInUzbekistanBounds(55.7558, 37.6173), false, 'Moskva');
  assert.strictEqual(isInUzbekistanBounds(43.2389, 76.8897), false, 'Almaty');
  assert.strictEqual(isInUzbekistanBounds(28.6139, 77.209), false, 'Dehli');
  assert.strictEqual(isInUzbekistanBounds(0, 0), false, '0,0 nuqtasi');
  assert.strictEqual(isInUzbekistanBounds(UZ_BOUNDS.minLat - 0.01, 66), false);
  assert.strictEqual(isInUzbekistanBounds('41.3', '69.2'), false, 'matn turidagi qiymat');
  assert.strictEqual(isInUzbekistanBounds(null, null), false);
  ok('isInUzbekistanBounds: Moskva, Almaty, Dehli, (0,0), chegaradan tashqari va noto\'g\'ri turlar — rad etildi');

  const tashSam = haversineKm(41.3111, 69.2797, 39.627, 66.975);
  assert.ok(tashSam > 255 && tashSam < 285, `Toshkent-Samarqand ~267 km bo'lishi kerak, chiqdi ${tashSam}`);
  assert.strictEqual(haversineKm(41.3, 69.2, 41.3, 69.2), 0);
  const symmetric = Math.abs(haversineKm(41.3, 69.2, 39.6, 66.9) - haversineKm(39.6, 66.9, 41.3, 69.2));
  assert.ok(symmetric < 1e-9);
  ok(`haversineKm: Toshkent–Samarqand = ${tashSam.toFixed(1)} km, bir xil nuqta = 0, simmetrik`);

  // ---------- ma'lumotlar ----------
  const u = (await db.query(
    `INSERT INTO users (phone, email, password_hash, full_name) VALUES ($1, $2, $3, $4) RETURNING *`,
    ['+998900000001', null, 'h', 'Mijoz']
  )).rows[0];
  db.state.categories.push({ id: 1, name_uz: 'Santexnik', icon: 'plumbing', is_active: true, sort_order: 1 });
  db.state.categories.push({ id: 2, name_uz: 'Elektrik', icon: 'electrical', is_active: true, sort_order: 2 });

  const ins = `INSERT INTO listings (client_id, category_id, title, description, price, price_type, address, city, latitude, longitude)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`;
  const mk = async (cat, title, city, lat, lng, price = 100000) =>
    (await db.query(ins, [u.id, cat, title, 'tavsif matni', price, price === null ? 'negotiable' : 'fixed', null, city, lat, lng])).rows[0];

  const tash = await mk(1, 'Toshkent kran', 'Toshkent', 41.3111, 69.2797);
  const sam = await mk(1, 'Samarqand kran', 'Samarqand', 39.627, 66.975, null);
  const bux = await mk(1, 'Buxoro kran', 'Buxoro', 39.7747, 64.4286);
  const nuk = await mk(1, 'Nukus kran', 'Nukus', 42.46, 59.61);
  await mk(1, 'Koordinatasiz e\'lon', 'Toshkent', null, null);
  const busy = await mk(1, 'Jarayondagi e\'lon', 'Toshkent', 41.32, 69.28);
  await db.query(`UPDATE listings SET status = 'in_progress' WHERE id = $1`, [busy.id]);
  const samElectric = await mk(2, 'Samarqand elektrik', 'Samarqand', 39.65, 66.96);

  // ---------- getMapListings ----------
  let r = await callMap(bbox(41.0, 41.6, 69.0, 69.6));
  assert.strictEqual(r.listings.length, 1);
  assert.strictEqual(r.listings[0].id, tash.id);
  assert.strictEqual(r.total, 1);
  assert.strictEqual(r.truncated, false);
  ok('Toshkent hududi: faqat 1 ta ochiq e\'lon (jarayondagi va koordinatasizlari chiqmadi)');

  r = await callMap(bbox(UZ_BOUNDS.minLat, UZ_BOUNDS.maxLat, UZ_BOUNDS.minLng, UZ_BOUNDS.maxLng));
  assert.strictEqual(r.listings.length, 5);
  const cLat = (UZ_BOUNDS.minLat + UZ_BOUNDS.maxLat) / 2;
  const cLng = (UZ_BOUNDS.minLng + UZ_BOUNDS.maxLng) / 2;
  const dists = r.listings.map((l) => (l.latitude - cLat) ** 2 + (l.longitude - cLng) ** 2);
  assert.deepStrictEqual(dists, [...dists].sort((a, b) => a - b), 'markazga yaqinlik bo\'yicha tartiblangan bo\'lishi kerak');
  assert.strictEqual(r.listings[r.listings.length - 1].id, nuk.id, 'markazdan eng uzoq — Nukus');
  ok('Butun O\'zbekiston hududi: 5 ta e\'lon, hudud markaziga yaqinlik bo\'yicha tartiblangan');

  r = await callMap(bbox(UZ_BOUNDS.minLat, UZ_BOUNDS.maxLat, UZ_BOUNDS.minLng, UZ_BOUNDS.maxLng, { limit: 2 }));
  assert.strictEqual(r.listings.length, 2);
  assert.strictEqual(r.total, 5);
  assert.strictEqual(r.truncated, true);
  ok('limit=2: 2 ta e\'lon qaytdi, total=5 va truncated=true (ilova "yaqinlashtiring" deydi)');

  r = await callMap(bbox(UZ_BOUNDS.minLat, UZ_BOUNDS.maxLat, UZ_BOUNDS.minLng, UZ_BOUNDS.maxLng, { categoryId: 2 }));
  assert.strictEqual(r.listings.length, 1);
  assert.strictEqual(r.listings[0].id, samElectric.id);
  assert.strictEqual(r.listings[0].categoryName, 'Elektrik');
  assert.strictEqual(r.listings[0].categoryIcon, 'electrical');
  ok('categoryId filtri ishladi, kategoriya nomi va ikonkasi qaytdi');

  r = await callMap(bbox(41.0, 41.6, 69.0, 69.6, { userLat: 41.3111, userLng: 69.2797 }));
  assert.ok(r.listings[0].distanceKm < 0.1, 'foydalanuvchi e\'lon yonida');
  r = await callMap(bbox(39.5, 39.7, 66.9, 67.1, { userLat: 41.3111, userLng: 69.2797 }));
  const samItem = r.listings.find((l) => l.id === sam.id);
  assert.ok(samItem.distanceKm > 255 && samItem.distanceKm < 285, `Samarqandgacha ~267 km, chiqdi ${samItem.distanceKm}`);
  assert.strictEqual(samItem.distanceKm, Math.round(samItem.distanceKm * 10) / 10, 'bir o\'nlik xonagacha yaxlitlangan');
  ok(`userLat/userLng bilan distanceKm hisoblandi (Toshkent → Samarqand: ${samItem.distanceKm} km)`);

  r = await callMap(bbox(41.0, 41.6, 69.0, 69.6));
  assert.strictEqual(r.listings[0].distanceKm, undefined);
  ok('userLat/userLng berilmasa distanceKm qaytmaydi');

  assert.strictEqual(samItem.price, null);
  assert.strictEqual(samItem.priceType, 'negotiable');
  r = await callMap(bbox(41.0, 41.6, 69.0, 69.6));
  assert.strictEqual(r.listings[0].price, 100000);
  assert.strictEqual(r.listings[0].priceType, 'fixed');
  ok('narx: "kelishiladi" e\'londa null, belgilangan narxli e\'londa raqam sifatida qaytdi');

  r = await callMap(bbox(-10, -5, 10, 15));
  assert.deepStrictEqual(r.listings, []);
  assert.strictEqual(r.total, 0);
  assert.strictEqual(r.truncated, false);
  ok('e\'lon yo\'q hudud: bo\'sh ro\'yxat, total=0');

  console.log(`\n✅ Xarita: ${passed} ta tekshiruv MUVAFFAQIYATLI o'tdi\n`);
}

run().catch((err) => {
  console.error('\n❌ XARITA SMOKE TEST MUVAFFAQIYATSIZ:', err.message);
  console.error(err.stack);
  process.exit(1);
});
