/**
 * Bildirishnoma/push tizimini HAQIQIY kodi bilan tekshiradi:
 *   - utils/notify.js -> notifyUser (bazaga yozish + push yuborish)
 *   - utils/pushNotifications.js -> sendPushNotifications (Expo API formatida)
 *   - controllers/notification.controller.js -> listNotifications, markRead, markAllRead, registerPushToken
 *   - controllers/offer.controller.js -> taklif rad etilganda ustaga avtomatik bildirishnoma
 *
 * Tashqi tarmoqqa chiqmasligi uchun global `fetch` soxtalashtirilgan (Expo serveriga
 * o'xshab javob qaytaradi) - shuning uchun bu test internetga ulanmasdan ham to'liq ishlaydi.
 *
 * Ishga tushirish: npm run verify   (yoki: node src/scripts/smokeTestNotifications.js)
 */
const assert = require('assert');
const { createFakeDb } = require('../../tests/testUtils/fakeDb');

const db = createFakeDb();
const dbModulePath = require.resolve('../config/db');
require.cache[dbModulePath] = {
  id: dbModulePath, filename: dbModulePath, loaded: true,
  exports: { query: db.query, getClient: db.getClient, pool: { query: db.query, end: async () => {} } },
};

const { notifyUser } = require('../utils/notify');
const notificationCtrl = require('../controllers/notification.controller');
const offerCtrl = require('../controllers/offer.controller');

let passed = 0;
const ok = (desc) => { passed++; console.log(`  ✔ ${desc}`); };

async function call(handler, { params = {}, query = {}, body = {}, user } = {}) {
  const out = { status: 200 };
  const res = { status(c) { out.status = c; return this; }, json(p) { out.body = p; return this; } };
  await handler({ params, query, body, user }, res, (err) => { if (err) throw err; });
  return out;
}

async function run() {
  const insertUser = `INSERT INTO users (phone, email, password_hash, full_name) VALUES ($1, $2, $3, $4) RETURNING *`;
  const user1 = (await db.query(insertUser, ['+998900000001', null, 'h', 'Foydalanuvchi'])).rows[0];
  const user2 = (await db.query(insertUser, ['+998900000002', null, 'h', 'Push\'siz'])).rows[0];

  // ---------- registerPushToken ----------
  let r = await call(notificationCtrl.registerPushToken, { body: { pushToken: 'notogri-format' }, user: { id: user1.id } });
  assert.strictEqual(r.status, 400);
  ok('registerPushToken: noto\'g\'ri formatdagi token rad etiladi (400)');

  r = await call(notificationCtrl.registerPushToken, { body: { pushToken: 'ExponentPushToken[abc123xyz]' }, user: { id: user1.id } });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(db.state.users.find((u) => u.id === user1.id).push_token, 'ExponentPushToken[abc123xyz]');
  ok('registerPushToken: to\'g\'ri Expo token formati saqlandi');

  // ---------- notifyUser: push MUVAFFAQIYATLI bo'lgan holat (fetch soxtalashtirilgan) ----------
  const sentRequests = [];
  const realFetch = global.fetch;
  global.fetch = async (url, options) => {
    sentRequests.push({ url, body: JSON.parse(options.body) });
    return {
      json: async () => ({
        data: JSON.parse(options.body).map(() => ({ status: 'ok', id: 'ticket-' + Math.random() })),
      }),
    };
  };

  await notifyUser(user1.id, { type: 'new_offer', title: 'Test sarlavha', body: 'Test matni', data: { foo: 'bar' } });

  assert.strictEqual(sentRequests.length, 1);
  assert.strictEqual(sentRequests[0].url, 'https://exp.host/--/api/v2/push/send');
  assert.strictEqual(sentRequests[0].body[0].to, 'ExponentPushToken[abc123xyz]');
  assert.strictEqual(sentRequests[0].body[0].title, 'Test sarlavha');
  assert.strictEqual(sentRequests[0].body[0].data.type, 'new_offer');
  ok('notifyUser: push_token mavjud bo\'lsa, Expo Push API\'ga TO\'G\'RI formatda so\'rov yuboradi (data.type bilan birga)');

  const dbNotif = db.state.notifications.find((n) => n.user_id === user1.id);
  assert.ok(dbNotif);
  assert.strictEqual(dbNotif.title, 'Test sarlavha');
  assert.deepStrictEqual(dbNotif.data, { foo: 'bar' });
  ok('notifyUser: xuddi shu bildirishnoma bazaga ham yozildi (ilova ichidagi ro\'yxat uchun)');

  // ---------- notifyUser: push_token yo'q foydalanuvchi uchun ----------
  sentRequests.length = 0;
  await notifyUser(user2.id, { type: 'system', title: 'Push\'siz xabar', body: '...' });
  assert.strictEqual(sentRequests.length, 0);
  assert.ok(db.state.notifications.find((n) => n.user_id === user2.id));
  ok('notifyUser: push_token yo\'q bo\'lsa, push yuborilmaydi, lekin bazaga baribir yoziladi');

  // ---------- notifyUser: Expo "DeviceNotRegistered" qaytarsa, token tozalanadi ----------
  global.fetch = async (url, options) => ({
    json: async () => ({
      data: JSON.parse(options.body).map(() => ({ status: 'error', details: { error: 'DeviceNotRegistered' } })),
    }),
  });
  await notifyUser(user1.id, { type: 'system', title: 'Eskirgan qurilma', body: '...' });
  assert.strictEqual(db.state.users.find((u) => u.id === user1.id).push_token, null);
  ok('notifyUser: Expo "DeviceNotRegistered" qaytarsa, eskirgan token bazadan avtomatik tozalanadi');

  // ---------- notifyUser: tarmoq xatosi bo'lsa ham funksiya yiqilmaydi ----------
  await db.query('UPDATE users SET push_token = $1 WHERE id = $2', ['ExponentPushToken[xyz]', user1.id]);
  global.fetch = async () => { throw new Error('tarmoq xatosi (simulyatsiya)'); };
  await notifyUser(user1.id, { type: 'system', title: 'Tarmoq xatosida ham ishlashi kerak', body: '...' });
  assert.ok(db.state.notifications.find((n) => n.title === 'Tarmoq xatosida ham ishlashi kerak'));
  ok('notifyUser: push yuborishda tarmoq xatosi bo\'lsa ham, funksiya xato otmaydi (asosiy amal davom etadi)');

  global.fetch = realFetch;

  // ---------- listNotifications / markRead / markAllRead ----------
  r = await call(notificationCtrl.listNotifications, { query: {}, user: { id: user1.id } });
  assert.strictEqual(r.status, 200);
  assert.ok(r.body.notifications.length >= 3);
  assert.ok(r.body.unreadCount >= 3);
  const firstNotifId = r.body.notifications[0].id;
  ok(`listNotifications: ${r.body.notifications.length} ta bildirishnoma va unreadCount=${r.body.unreadCount} qaytdi`);

  r = await call(notificationCtrl.markRead, { params: { id: firstNotifId }, user: { id: user1.id } });
  assert.strictEqual(r.status, 200);
  ok('markRead: bitta bildirishnoma o\'qilgan deb belgilandi');

  r = await call(notificationCtrl.markRead, { params: { id: 'yoq-id' }, user: { id: user1.id } });
  assert.strictEqual(r.status, 404);
  ok('markRead: mavjud bo\'lmagan bildirishnoma uchun 404');

  const otherUserNotif = db.state.notifications.find((n) => n.user_id === user2.id);
  r = await call(notificationCtrl.markRead, { params: { id: otherUserNotif.id }, user: { id: user1.id } });
  assert.strictEqual(r.status, 404);
  ok('markRead: boshqa foydalanuvchining bildirishnomasini o\'qilgan deb belgilab bo\'lmaydi (404)');

  r = await call(notificationCtrl.markAllRead, { user: { id: user1.id } });
  assert.strictEqual(r.status, 200);
  const afterAll = await call(notificationCtrl.listNotifications, { query: {}, user: { id: user1.id } });
  assert.strictEqual(afterAll.body.unreadCount, 0);
  ok('markAllRead: barcha bildirishnomalar o\'qilgan deb belgilandi (unreadCount=0)');

  // ---------- offer.controller.js -> taklif rad etilganda ustaga push/bildirishnoma ----------
  const client = (await db.query(insertUser, ['+998900000003', null, 'h', 'Mijoz'])).rows[0];
  const provider = (await db.query(insertUser, ['+998900000004', null, 'h', 'Usta'])).rows[0];
  db.state.categories.push({ id: 1, name_uz: 'Santexnik', is_active: true });
  const listing = (
    await db.query(
      `INSERT INTO listings (client_id, category_id, title, description, price, price_type, address, city, latitude, longitude)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [client.id, 1, 'Kran tamiri', 'tavsif matni yetarlicha uzun', null, 'negotiable', null, 'Toshkent', null, null]
    )
  ).rows[0];
  const offer = (
    await db.query(`INSERT INTO offers (listing_id, provider_id, price, message) VALUES ($1, $2, $3, $4) RETURNING *`, [
      listing.id, provider.id, 50000, null,
    ])
  ).rows[0];

  const rejectOut = {};
  const rejectRes = { status(c) { rejectOut.status = c; return this; }, json(p) { rejectOut.body = p; return this; } };
  global.fetch = realFetch; // push_token yo'q, shuning uchun fetch chaqirilmaydi - lekin xavfsizlik uchun asl holatga qaytaramiz
  await offerCtrl.updateOfferStatus({ params: { id: offer.id }, body: { status: 'rejected' }, user: { id: client.id } }, rejectRes, (e) => { throw e; });

  const providerNotif = db.state.notifications.find((n) => n.user_id === provider.id && n.type === 'offer_rejected');
  assert.ok(providerNotif, 'Usta "offer_rejected" bildirishnomasini olishi kerak');
  assert.strictEqual(providerNotif.title, 'Taklifingiz rad etildi');
  ok('offer.controller.js: taklif rad etilganda ustaga avtomatik bildirishnoma+push yuboriladi (real controller orqali)');

  console.log(`\n✅ Bildirishnomalar/Push: ${passed} ta tekshiruv MUVAFFAQIYATLI o'tdi\n`);
}

run().catch((err) => {
  console.error('\n❌ BILDIRISHNOMA SMOKE TEST MUVAFFAQIYATSIZ:', err.message);
  console.error(err.stack);
  process.exit(1);
});
