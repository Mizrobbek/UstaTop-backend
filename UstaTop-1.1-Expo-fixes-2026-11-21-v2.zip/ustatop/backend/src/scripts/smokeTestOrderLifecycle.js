/**
 * Buyurtma/taklif lifecycle controller'larini haqiqiy kod bilan fakeDb'da tekshiradi.
 * PostgreSQL'ning parallel lock xatti-harakatini almashtirmaydi; buning uchun integratsion test kerak.
 */
const assert = require('assert');
const { v4: uuidv4 } = require('uuid');
const { createFakeDb } = require('../../tests/testUtils/fakeDb');

const db = createFakeDb();
const dbModulePath = require.resolve('../config/db');
require.cache[dbModulePath] = {
  id: dbModulePath,
  filename: dbModulePath,
  loaded: true,
  exports: { query: db.query, getClient: db.getClient, pool: { query: db.query, end: async () => {} } },
};

const offerCtrl = require('../controllers/offer.controller');
const orderCtrl = require('../controllers/order.controller');

function response() {
  return {
    statusCode: 200,
    body: null,
    status(code) { this.statusCode = code; return this; },
    json(body) { this.body = body; return this; },
  };
}

async function call(handler, req) {
  const res = response();
  let error;
  await handler(req, res, (err) => { error = err; });
  if (error) throw error;
  return res;
}

async function run() {
  const clientId = uuidv4();
  const providerId = uuidv4();
  const secondProviderId = uuidv4();
  const listingId = uuidv4();
  const secondListingId = uuidv4();

  db.state.users.push(
    { id: clientId, full_name: 'Test mijoz', push_token: null },
    { id: providerId, full_name: 'Birinchi usta', push_token: null },
    { id: secondProviderId, full_name: 'Ikkinchi usta', push_token: null },
  );
  db.state.provider_profiles.push(
    { user_id: providerId, completed_orders_count: 0, myid_verified: true },
    { user_id: secondProviderId, completed_orders_count: 0, myid_verified: true },
  );
  db.state.listings.push(
    { id: listingId, client_id: clientId, title: 'Birinchi ish', status: 'open' },
    { id: secondListingId, client_id: clientId, title: 'Ikkinchi ish', status: 'open' },
  );

  // Taklif yuborilganda chat qabul qilishdan oldin yaratiladi.
  const firstOfferResponse = await call(offerCtrl.createOffer, {
    params: { id: listingId }, body: { price: 100000 }, user: { id: providerId },
  });
  assert.strictEqual(firstOfferResponse.statusCode, 201);
  assert.ok(firstOfferResponse.body.chatId);
  assert.strictEqual(db.state.chats.length, 1);

  // Taklifni qabul qilish order yaratadi va mavjud chatni qayta ishlatadi.
  const accepted = await call(offerCtrl.updateOfferStatus, {
    params: { id: firstOfferResponse.body.offer.id }, body: { status: 'accepted' }, user: { id: clientId },
  });
  assert.strictEqual(accepted.statusCode, 200);
  assert.strictEqual(accepted.body.chatId, firstOfferResponse.body.chatId);
  assert.strictEqual(db.state.orders.length, 1);

  // Yakunlash faqat bir marta hisoblagichni oshiradi.
  const completed = await call(orderCtrl.updateOrderStatus, {
    params: { id: accepted.body.order.id }, body: { status: 'completed' }, user: { id: providerId },
  });
  assert.strictEqual(completed.statusCode, 200);
  assert.strictEqual(db.state.provider_profiles[0].completed_orders_count, 1);

  const completedAgain = await call(orderCtrl.updateOrderStatus, {
    params: { id: accepted.body.order.id }, body: { status: 'completed' }, user: { id: providerId },
  });
  assert.strictEqual(completedAgain.statusCode, 400);
  assert.strictEqual(db.state.provider_profiles[0].completed_orders_count, 1);

  // Usta mijoz tasdig'isiz pulni olganini tasdiqlay olmaydi.
  const providerFirst = await call(orderCtrl.confirmServicePayment, {
    params: { id: accepted.body.order.id }, body: {}, user: { id: providerId },
  });
  assert.strictEqual(providerFirst.statusCode, 400);

  const clientConfirmed = await call(orderCtrl.confirmServicePayment, {
    params: { id: accepted.body.order.id }, body: {}, user: { id: clientId },
  });
  assert.strictEqual(clientConfirmed.statusCode, 200);
  assert.strictEqual(clientConfirmed.body.isPaid, false);
  assert.ok(clientConfirmed.body.clientPaymentConfirmedAt);

  const providerConfirmed = await call(orderCtrl.confirmServicePayment, {
    params: { id: accepted.body.order.id }, body: {}, user: { id: providerId },
  });
  assert.strictEqual(providerConfirmed.statusCode, 200);
  assert.strictEqual(providerConfirmed.body.isPaid, true);
  assert.ok(providerConfirmed.body.providerPaymentConfirmedAt);

  const providerConfirmedAgain = await call(orderCtrl.confirmServicePayment, {
    params: { id: accepted.body.order.id }, body: {}, user: { id: providerId },
  });
  assert.strictEqual(providerConfirmedAgain.statusCode, 200);
  assert.strictEqual(providerConfirmedAgain.body.isPaid, true);

  // Bekor qilingan buyurtma tarixda qoladi va e'lon qayta ishlatilishi mumkin.
  const cancelOffer = await call(offerCtrl.createOffer, {
    params: { id: secondListingId }, body: { price: 80000 }, user: { id: providerId },
  });
  const cancelAccepted = await call(offerCtrl.updateOfferStatus, {
    params: { id: cancelOffer.body.offer.id }, body: { status: 'accepted' }, user: { id: clientId },
  });
  const cancelled = await call(orderCtrl.updateOrderStatus, {
    params: { id: cancelAccepted.body.order.id },
    body: { status: 'cancelled', cancelReason: 'Vaqt mos kelmadi' },
    user: { id: clientId },
  });
  assert.strictEqual(cancelled.statusCode, 200);
  assert.strictEqual(db.state.listings.find((l) => l.id === secondListingId).status, 'open');

  const replacementOffer = await call(offerCtrl.createOffer, {
    params: { id: secondListingId }, body: { price: 90000 }, user: { id: secondProviderId },
  });
  const replacementAccepted = await call(offerCtrl.updateOfferStatus, {
    params: { id: replacementOffer.body.offer.id }, body: { status: 'accepted' }, user: { id: clientId },
  });
  assert.strictEqual(replacementAccepted.statusCode, 200);
  const history = db.state.orders.filter((o) => o.listing_id === secondListingId);
  assert.strictEqual(history.length, 2);
  assert.deepStrictEqual(history.map((o) => o.status).sort(), ['cancelled', 'confirmed']);

  console.log('✅ Order lifecycle controller: 24 ta tekshiruv muvaffaqiyatli o‘tdi');
}

run().catch((err) => {
  console.error('❌ Order lifecycle tekshiruvi muvaffaqiyatsiz:', err);
  process.exit(1);
});
