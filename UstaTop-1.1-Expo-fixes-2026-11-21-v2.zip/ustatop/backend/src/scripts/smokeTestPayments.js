/**
 * Xizmat haqi UstaTop orqali o'tmasligini tekshiradi.
 * Mijoz ustaga bevosita to'laydi; ikki tomon tasdig'i order.controller'da.
 */
const assert = require('assert');
const { createFakeDb } = require('../../tests/testUtils/fakeDb');

process.env.PAYME_MERCHANT_KEY = 'test_merchant_key';
const db = createFakeDb();
const dbModulePath = require.resolve('../config/db');
require.cache[dbModulePath] = {
  id: dbModulePath, filename: dbModulePath, loaded: true,
  exports: { query: db.query, getClient: db.getClient, pool: { query: db.query, end: async () => {} } },
};

const payment = require('../controllers/payment.controller');
let passed = 0;
const ok = (desc) => { passed++; console.log(`  ✔ ${desc}`); };

async function run() {
  const insertUser = `INSERT INTO users (phone, email, password_hash, full_name) VALUES ($1, $2, $3, $4) RETURNING *`;
  const client = (await db.query(insertUser, ['+998900000001', null, 'hash', 'Mijoz'])).rows[0];
  const provider = (await db.query(insertUser, ['+998900000002', null, 'hash', 'Usta'])).rows[0];
  const insertOrder = `INSERT INTO orders (listing_id, offer_id, client_id, provider_id, agreed_price) VALUES ($1, $2, $3, $4, $5) RETURNING *`;
  const order = (await db.query(insertOrder, ['listing-1', 'offer-1', client.id, provider.id, 150000])).rows[0];

  const payOut = {};
  const payRes = { status(code) { payOut.status = code; return this; }, json(body) { payOut.body = body; return this; } };
  await payment.initiatePayment({ params: { id: order.id }, body: { provider: 'payme' }, user: { id: client.id } }, payRes);
  assert.strictEqual(payOut.status, 410);
  assert.ok(payOut.body.error.includes('bevosita ustaga'));
  ok('Mobil checkout endpointi xizmat haqini UstaTop orqali olishni rad etadi (410)');

  const paymeOut = {};
  const paymeRes = { status(code) { paymeOut.status = code; return this; }, json(body) { paymeOut.body = body; return this; } };
  await payment.paymeWebhook(
    { body: { id: 10, method: 'CheckPerformTransaction', params: { account: { order_id: order.id } } } },
    paymeRes
  );
  assert.strictEqual(paymeOut.status, 200);
  assert.ok(paymeOut.body.error);
  ok('Payme webhook xizmat haqini qabul qilmaydi va JSON-RPC xatosi qaytaradi');

  const clickBody = { click_trans_id: '1', merchant_trans_id: order.id };
  const clickOut = {};
  const clickRes = { json(body) { clickOut.body = body; return this; } };
  await payment.clickPrepare({ body: clickBody }, clickRes);
  assert.notStrictEqual(clickOut.body.error, 0);
  ok('Click Prepare xizmat haqini platforma orqali qabul qilmaydi');

  const clickCompleteOut = {};
  const clickCompleteRes = { json(body) { clickCompleteOut.body = body; return this; } };
  await payment.clickComplete({ body: clickBody }, clickCompleteRes);
  assert.notStrictEqual(clickCompleteOut.body.error, 0);
  ok('Click Complete xizmat haqini platforma orqali qabul qilmaydi');

  console.log(`\n✅ Bevosita xizmat to'lovi: ${passed} ta tekshiruv MUVAFFAQIYATLI o'tdi\n`);
}

run().catch((err) => {
  console.error('\n❌ Xizmat to‘lovi tekshiruvi muvaffaqiyatsiz:', err.message);
  console.error(err.stack);
  process.exit(1);
});
