require('dotenv').config();
const http = require('http');
const app = require('./app');
const { pool } = require('./config/db');
const { initSocket } = require('./config/socket');
const { assertSafeEnv } = require('./config/env');

const PORT = process.env.PORT || 4000;

async function start() {
  try {
    assertSafeEnv();
  } catch (err) {
    console.error('[CONFIG]', err.message);
    process.exit(1);
  }

  try {
    // Server ko'tarilishidan oldin bazaga ulanishni tekshirib olamiz
    await pool.query('SELECT 1');
    console.log('[DB] PostgreSQL bazasiga muvaffaqiyatli ulandi');
  } catch (err) {
    console.error('[DB] Bazaga ulanib bo\'lmadi:', err.message);
    console.error('[DB] .env faylida DATABASE_URL to\'g\'ri sozlanganini va PostgreSQL ishga tushganini tekshiring');
    process.exit(1);
  }

  // Express app'ni oddiy HTTP serverga o'raymiz, chunki Socket.io xuddi shu
  // HTTP serverga "ulashib" ishlaydi (bitta portda ham REST, ham WebSocket)
  const httpServer = http.createServer(app);

  const corsOrigins = (process.env.CORS_ORIGINS || '*').split(',');
  const io = initSocket(httpServer, corsOrigins);
  app.set('io', io); // controller'lar req.app.get('io') orqali foydalanadi

  httpServer.listen(PORT, () => {
    console.log(`\n🚀 UstaTop backend http://localhost:${PORT} manzilida ishga tushdi`);
    console.log(`   Socket.io shu portda tayyor (real vaqtli chat uchun)`);
    console.log(`   Muhit: ${process.env.NODE_ENV || 'development'}\n`);
  });
}

start();

process.on('SIGTERM', async () => {
  console.log('SIGTERM qabul qilindi, server yopilmoqda...');
  await pool.end();
  process.exit(0);
});
