// Internal financial service. Never expose settlement as an admin/worker HTTP endpoint.
const { getClient } = require('../config/db');
async function assertWorkerClear(client, providerId) {
  await client.query('SELECT commission_assert_clear($1)', [providerId]);
}
function debtError(err, res, workerFacing) {
  if (err.code !== 'P0001' || err.message !== 'COMMISSION_DEBT') return false;
  // Clients must not learn the reason (or any rate/amount/status).
  res.status(409).json(workerFacing
    ? { error: 'Platforma komissiyasini to‘lash kerak', code: 'COMMISSION_DEBT' }
    : { error: 'Taklifni hozir qabul qilib bo‘lmaydi' });
  return true;
}
async function transaction(work) {
  const client = await getClient();
  try { await client.query('BEGIN'); const result = await work(client); await client.query('COMMIT'); return result; }
  catch (err) { await client.query('ROLLBACK'); throw err; }
  finally { client.release(); }
}
// verify must be supplied by a trusted server gateway adapter (stage 4), never HTTP body data.
async function settleVerifiedPayment(input, verify) {
  if (typeof verify !== 'function' || !(await verify(input))) throw new Error('Provider verification required');
  return transaction(async (client) => {
    const found = (await client.query(`SELECT p.*, c.provider_id FROM commission_payments p
      JOIN commission_charges c ON c.id=p.charge_id WHERE p.id=$1`, [input.paymentId])).rows[0];
    if (!found) throw new Error('Payment not found');
    await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE', [found.provider_id]);
    const previous = (await client.query('SELECT * FROM commission_settlements WHERE payment_id=$1', [input.paymentId])).rows[0];
    if (previous) {
      if (previous.provider !== input.provider || previous.provider_transaction_id !== input.transactionId
        || previous.amount !== String(input.amount) || previous.currency !== input.currency) throw new Error('Settlement replay mismatch');
      return previous;
    }
    return (await client.query(`INSERT INTO commission_settlements
      (payment_id,provider,provider_transaction_id,amount,currency,verification_reference)
      VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,
      [input.paymentId,input.provider,input.transactionId,input.amount,input.currency,input.verificationReference])).rows[0];
  });
}
module.exports = { assertWorkerClear, debtError, transaction, settleVerifiedPayment };
