const path = require('path');
const fs = require('fs');

// Storage adapter: hozir local disk; keyinchalik S3-compatible cloud adapter bilan almashtiriladi.
// Controller'lar faqat put/remove/publicUrl interfeysidan foydalanadi.
const root = path.resolve(process.env.MEDIA_STORAGE_DIR || path.join(__dirname, '../../uploads'));
fs.mkdirSync(root, { recursive: true });

const localStorage = {
  name: 'local',
  async put(file) {
    const safeName = `${Date.now()}-${require('crypto').randomUUID()}${path.extname(file.originalname).toLowerCase()}`;
    const destination = path.join(root, safeName);
    // Multer vaqtinchalik faylni os.tmpdir() ga yozadi. Docker'da /tmp va
    // /app/uploads turli filesystem/volume bo'lishi mumkin; rename() bu holatda
    // EXDEV (cross-device link not permitted) bilan yiqiladi.
    // Avval storage volume ichidagi vaqtinchalik faylga nusxalaymiz, so'ng
    // shu filesystem ichida atomik rename qilamiz.
    const staging = path.join(root, `.${safeName}.part`);
    try {
      await fs.promises.copyFile(file.path, staging, fs.constants.COPYFILE_EXCL);
      await fs.promises.rename(staging, destination);
      await fs.promises.rm(file.path, { force: true });
    } catch (err) {
      await fs.promises.rm(staging, { force: true }).catch(() => {});
      throw err;
    }
    return { key: safeName, url: `/uploads/${safeName}`, mimeType: file.mimetype, size: file.size };
  },
  async remove(key) {
    if (!key || path.basename(key) !== key) return;
    await fs.promises.rm(path.join(root, key), { force: true });
  },
};

const adapters = { local: localStorage };
const active = adapters[process.env.MEDIA_STORAGE_DRIVER || 'local'];
if (!active) throw new Error(`Noma'lum MEDIA_STORAGE_DRIVER: ${process.env.MEDIA_STORAGE_DRIVER}`);
module.exports = active;
