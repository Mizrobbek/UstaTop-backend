/**
 * Click.uz Shop API (Prepare/Complete) yordamchilari.
 *
 * DIQQAT — TASDIQLASH TALAB QILINADI: quyidagi MD5 imzo formulasi (`sign_string`ni
 * hisoblash tartibi) Click.uz'ning bir nechta mustaqil, ko'p yillik ochiq kodli
 * integratsiyalarida (PHP, Python, Flask, .NET SDK'lari) izchil ravishda ishlatilgan,
 * keng tarqalgan "sanoat standarti" formuladir. Biroq bu loyihani tayyorlash jarayonida
 * docs.click.uz saytining rasmiy sahifasidan formulaning o'zini (faqat maydonlar ro'yxatini
 * emas) so'zma-so'z tasdiqlab bo'lmadi, chunki sayt to'liq hujjatlarni faqat ro'yxatdan
 * o'tgan hamkorlarga ochadi. SHUNING UCHUN: production'ga chiqarishdan oldin, albatta
 * o'zingizning Click hamkorlik kabinetingizdagi (merchant.click.uz) rasmiy "Shop API"
 * hujjatidagi sign_string formulasi bilan solishtirib tasdiqlang.
 *
 * Prepare bosqichi:  sign_string = MD5(click_trans_id + service_id + SECRET_KEY + merchant_trans_id + amount + action + sign_time)
 * Complete bosqichi: sign_string = MD5(click_trans_id + service_id + SECRET_KEY + merchant_trans_id + merchant_prepare_id + amount + action + sign_time)
 *
 * Xato kodlari (Click javobida "error" maydoni sifatida qaytariladi):
 *   0  = muvaffaqiyatli
 *  -1  = SIGN CHECK FAILED (imzo mos kelmadi)
 *  -2  = noto'g'ri summa
 *  -3  = action topilmadi
 *  -4  = allaqachon to'langan
 *  -5  = buyurtma (foydalanuvchi/hisob) topilmadi
 *  -6  = tranzaksiya topilmadi
 *  -7  = foydalanuvchini yangilab bo'lmadi
 *  -8  = so'rovda xatolik
 *  -9  = tranzaksiya bekor qilingan
 */
const crypto = require('crypto');

const CLICK_ERRORS = Object.freeze({
  SUCCESS: 0,
  SIGN_FAILED: -1,
  INVALID_AMOUNT: -2,
  ACTION_NOT_FOUND: -3,
  ALREADY_PAID: -4,
  ORDER_NOT_FOUND: -5,
  TRANSACTION_NOT_FOUND: -6,
  UPDATE_FAILED: -7,
  BAD_REQUEST: -8,
  TRANSACTION_CANCELLED: -9,
});

const CLICK_ACTION = Object.freeze({ PREPARE: 0, COMPLETE: 1 });

function md5(str) {
  return crypto.createHash('md5').update(str).digest('hex');
}

function buildPrepareSignString({ clickTransId, serviceId, secretKey, merchantTransId, amount, action, signTime }) {
  return `${clickTransId}${serviceId}${secretKey}${merchantTransId}${amount}${action}${signTime}`;
}

function buildCompleteSignString({
  clickTransId,
  serviceId,
  secretKey,
  merchantTransId,
  merchantPrepareId,
  amount,
  action,
  signTime,
}) {
  return `${clickTransId}${serviceId}${secretKey}${merchantTransId}${merchantPrepareId}${amount}${action}${signTime}`;
}

function verifyPrepareSign(params, secretKey) {
  const expected = md5(
    buildPrepareSignString({
      clickTransId: params.click_trans_id,
      serviceId: params.service_id,
      secretKey,
      merchantTransId: params.merchant_trans_id,
      amount: params.amount,
      action: params.action,
      signTime: params.sign_time,
    })
  );
  return expected === params.sign_string;
}

function verifyCompleteSign(params, secretKey) {
  const expected = md5(
    buildCompleteSignString({
      clickTransId: params.click_trans_id,
      serviceId: params.service_id,
      secretKey,
      merchantTransId: params.merchant_trans_id,
      merchantPrepareId: params.merchant_prepare_id,
      amount: params.amount,
      action: params.action,
      signTime: params.sign_time,
    })
  );
  return expected === params.sign_string;
}

/** To'lov sahifasiga yo'naltiruvchi Click URL (rasmiy so'rov formati) */
function buildClickCheckoutUrl({ serviceId, merchantId, orderId, amountSom, returnUrl }) {
  const params = new URLSearchParams({
    service_id: serviceId,
    merchant_id: merchantId,
    amount: Number(amountSom).toFixed(2),
    transaction_param: orderId,
  });
  if (returnUrl) params.set('return_url', returnUrl);
  return `https://my.click.uz/services/pay?${params.toString()}`;
}

module.exports = { CLICK_ERRORS, CLICK_ACTION, md5, verifyPrepareSign, verifyCompleteSign, buildClickCheckoutUrl };
