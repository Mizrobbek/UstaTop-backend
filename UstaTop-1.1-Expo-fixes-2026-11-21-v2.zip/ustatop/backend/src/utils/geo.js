/**
 * Geografik yordamchilar.
 *
 * MUHIM (aniqlik haqida): UZ_BOUNDS — O'zbekistonni o'rab turuvchi TO'G'RI TO'RTBURCHAK
 * (bounding box), aniq davlat chegarasi EMAS. Shu sababli:
 *   - O'zbekiston ichidagi har qanday nuqta har doim qabul qilinadi (noto'g'ri rad etish yo'q);
 *   - ammo chegara bo'yidagi ba'zi qo'shni hududlar (masalan, Tojikiston/Turkmaniston/Qirg'iziston
 *     va Qozog'istonning bir qismi) ham "ichida" deb hisoblanishi mumkin.
 * Bu ataylab qilingan: aniq chegara ko'pburchagini kiritish, chegara qishloqlarida haqiqiy
 * foydalanuvchini noto'g'ri rad etish xavfini tug'diradi. Kerak bo'lsa, keyinchalik GeoJSON
 * ko'pburchagi bilan almashtirish mumkin (faqat shu fayldagi isInUzbekistanBounds o'zgaradi).
 *
 * Chegaralar: shimol ~45.59°, janub ~37.17°, g'arb ~55.99°, sharq ~73.15° (ozgina zaxira bilan).
 */
const UZ_BOUNDS = Object.freeze({ minLat: 37.1, maxLat: 45.7, minLng: 55.9, maxLng: 73.2 });

function isInUzbekistanBounds(lat, lng) {
  return (
    typeof lat === 'number' &&
    typeof lng === 'number' &&
    lat >= UZ_BOUNDS.minLat &&
    lat <= UZ_BOUNDS.maxLat &&
    lng >= UZ_BOUNDS.minLng &&
    lng <= UZ_BOUNDS.maxLng
  );
}

const EARTH_RADIUS_KM = 6371;
const toRad = (deg) => (deg * Math.PI) / 180;

/** Ikki nuqta orasidagi masofa (km), katta doira bo'ylab (haversine formulasi). */
function haversineKm(lat1, lng1, lat2, lng2) {
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(a)));
}

module.exports = { UZ_BOUNDS, isInUzbekistanBounds, haversineKm };
