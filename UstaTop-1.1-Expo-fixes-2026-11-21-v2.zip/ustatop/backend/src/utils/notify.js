const { query } = require('../config/db');
const { sendPushNotifications } = require('./pushNotifications');

/**
 * Foydalanuvchiga bildirishnoma yuboradi: (1) bazaga yozadi - ilova ichidagi
 * "Bildirishnomalar" ro'yxatida ko'rinishi uchun, (2) agar qurilmasi ro'yxatdan
 * o'tgan bo'lsa, push-xabar ham yuboradi. Ikkala amal ham xato bersa (masalan,
 * push tarmoq xatosi), asosiy biznes-amal (masalan, taklifni qabul qilish)
 * baribir davom etishi uchun xatolar bu yerning o'zida ushlanadi, yuqoriga
 * otilmaydi.
 *
 * @param {string} userId
 * @param {{type: string, title: string, body: string, data?: object}} notification
 */
async function notifyUser(userId, { type, title, body, data }) {
  try {
    await query(
      `INSERT INTO notifications (user_id, type, title, body, data) VALUES ($1, $2, $3, $4, $5)`,
      [userId, type, title, body || null, data ? JSON.stringify(data) : null]
    );
  } catch (err) {
    console.error('[notify] Bazaga yozishda xato:', err.message);
  }

  try {
    const userResult = await query('SELECT push_token FROM users WHERE id = $1', [userId]);
    const pushToken = userResult.rows[0]?.push_token;
    if (pushToken) {
      // 'type'ni ham data ichiga qo'shamiz - mobil ilova bildirishnomaga bosilganda
      // (push payload'ida alohida "type" maydoni yo'q) qaysi ekranga o'tishni shu orqali biladi
      const result = await sendPushNotifications([
        { to: pushToken, title, body: body || '', data: { ...(data || {}), type } },
      ]);
      if (result.invalidTokens.length > 0) {
        // Qurilma push'ni rad etgan yoki ilovani o'chirgan - eskirgan tokenni tozalaymiz
        await query('UPDATE users SET push_token = NULL WHERE id = $1 AND push_token = $2', [userId, pushToken]);
      }
    }
  } catch (err) {
    console.error('[notify] Push yuborishda xato:', err.message);
  }
}

module.exports = { notifyUser };
