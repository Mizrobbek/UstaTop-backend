const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { query } = require('../config/db');

const OTP_LENGTH = 5;
const OTP_TTL_MINUTES = 5;
const MAX_ATTEMPTS = 5;
const RESEND_COOLDOWN_SECONDS = 60;
// Kod yo'q va kod noto'g'ri holatlari bir xil javob beradi — raqam ro'yxatdan o'tganini oshkor qilmaslik uchun
const INVALID_CODE_MESSAGE = 'Kod noto\'g\'ri yoki muddati tugagan';

function generateCode() {
  // 5 xonali kod, masalan "48213"
  // Kriptografik xavfsiz generator (Math.random() taxmin qilinishi mumkin)
  return crypto.randomInt(10000, 100000).toString();
}

/**
 * Telefon raqami uchun yangi OTP kod yaratadi va bazaga (hash holida) saqlaydi.
 * Qaytaradi: { code } — code faqat SMS yuborish uchun ishlatiladi, bazada saqlanmaydi.
 * @param {string} phone
 * @param {'password_reset'|'phone_verify'|'signup_verify'} purpose
 */
async function createOtp(phone, purpose = 'password_reset') {
  // Spam/flood himoyasi: oxirgi so'rovdan RESEND_COOLDOWN_SECONDS o'tmagan bo'lsa, rad etamiz
  const recent = await query(
    `SELECT created_at FROM otp_codes WHERE phone = $1 AND purpose = $2 ORDER BY created_at DESC LIMIT 1`,
    [phone, purpose]
  );
  if (recent.rows[0]) {
    const secondsSince = (Date.now() - new Date(recent.rows[0].created_at).getTime()) / 1000;
    if (secondsSince < RESEND_COOLDOWN_SECONDS) {
      const wait = Math.ceil(RESEND_COOLDOWN_SECONDS - secondsSince);
      const err = new Error(`Iltimos, ${wait} soniyadan keyin qayta urinib ko'ring`);
      err.status = 429;
      throw err;
    }
  }

  const code = generateCode();
  const codeHash = await bcrypt.hash(code, 10);
  const expiresAt = new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000);

  await query(
    `INSERT INTO otp_codes (phone, purpose, code_hash, expires_at) VALUES ($1, $2, $3, $4)`,
    [phone, purpose, codeHash, expiresAt]
  );

  return { code, expiresInMinutes: OTP_TTL_MINUTES };
}

/**
 * Foydalanuvchi kiritgan kodni tekshiradi.
 * Qaytaradi: { valid: boolean, reason?: string, otpId?: string }
 * @param {string} phone
 * @param {string} code
 * @param {'password_reset'|'phone_verify'|'signup_verify'} purpose
 */
async function verifyOtp(phone, code, purpose = 'password_reset') {
  const res = await query(
    `SELECT id, code_hash, attempts, expires_at, verified
     FROM otp_codes WHERE phone = $1 AND purpose = $2 ORDER BY created_at DESC LIMIT 1`,
    [phone, purpose]
  );
  const record = res.rows[0];
  if (!record) return { valid: false, reason: INVALID_CODE_MESSAGE };
  if (record.verified) return { valid: false, reason: 'Bu kod allaqachon ishlatilgan' };
  if (new Date(record.expires_at) < new Date()) return { valid: false, reason: 'Kod muddati tugagan' };
  if (record.attempts >= MAX_ATTEMPTS) return { valid: false, reason: 'Urinishlar soni tugadi, yangi kod so\'rang' };

  const match = await bcrypt.compare(code, record.code_hash);
  if (!match) {
    await query(`UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1`, [record.id]);
    return { valid: false, reason: 'Kod noto\'g\'ri' };
  }

  return { valid: true, otpId: record.id };
}

/**
 * OTP'ni "ishlatilgan" deb belgilaydi (parol muvaffaqiyatli o'zgartirilgandan keyin chaqiriladi).
 * Bu bitta kodni ikki marta ishlatishning oldini oladi.
 */
async function markOtpUsed(otpId) {
  await query(`UPDATE otp_codes SET verified = TRUE WHERE id = $1`, [otpId]);
}

/**
 * Kodni tekshiradi va muvaffaqiyatda uni ATOMIK ravishda "ishlatilgan" deb belgilaydi.
 * Chaqiruvchi ochgan tranzaksiya (client) ichida ishlaydi: so'nggi kod qatori
 * FOR UPDATE bilan qulflanadi, shuning uchun bir xil kod bilan kelgan ikki parallel
 * so'rovdan faqat bittasi o'tadi. Noto'g'ri urinish hisoblagichi ham shu tranzaksiyada yoziladi,
 * shu sabab chaqiruvchi natija qanday bo'lmasin COMMIT qilishi kerak.
 * Qaytaradi: { valid: boolean, reason?: string, otpId?: string }
 */
async function consumeOtp(client, phone, code, purpose = 'password_reset') {
  const res = await client.query(
    `SELECT id, code_hash, attempts, expires_at, verified
     FROM otp_codes WHERE phone = $1 AND purpose = $2 ORDER BY created_at DESC LIMIT 1 FOR UPDATE`,
    [phone, purpose]
  );
  const record = res.rows[0];
  if (!record) return { valid: false, reason: INVALID_CODE_MESSAGE };
  if (record.verified) return { valid: false, reason: 'Bu kod allaqachon ishlatilgan' };
  if (new Date(record.expires_at) < new Date()) return { valid: false, reason: INVALID_CODE_MESSAGE };
  if (record.attempts >= MAX_ATTEMPTS) return { valid: false, reason: 'Urinishlar soni tugadi, yangi kod so\'rang' };

  const match = await bcrypt.compare(code, record.code_hash);
  if (!match) {
    await client.query(`UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1`, [record.id]);
    return { valid: false, reason: INVALID_CODE_MESSAGE };
  }

  const used = await client.query(
    `UPDATE otp_codes SET verified = TRUE WHERE id = $1 AND verified = FALSE RETURNING id`,
    [record.id]
  );
  if (!used.rows[0]) return { valid: false, reason: 'Bu kod allaqachon ishlatilgan' };
  return { valid: true, otpId: record.id };
}

module.exports = { createOtp, verifyOtp, markOtpUsed, consumeOtp, generateCode, INVALID_CODE_MESSAGE };
