/**
 * Payme Merchant API yordamchilari.
 *
 * MANBA: https://developer.help.paycom.uz/metody-merchant-api/ (rasmiy hujjat, shu loyiha
 * yozilayotganda tekshirilgan). Quyidagi barcha xato kodlari, holat (state) raqamlari va
 * so'rov/javob formatlari shu hujjatdan olingan:
 *   - Umumiy protokol xatolari: -32700 (JSON parse), -32600 (majburiy maydon yo'q),
 *     -32601 (metod topilmadi), -32504 (avtorizatsiya xato), -32400 (server xatosi)
 *   - -31001: noto'g'ri summa
 *   - -31003: tranzaksiya topilmadi
 *   - -31007: buyurtma allaqachon bajarilgan, bekor qilib bo'lmaydi
 *   - -31008: amalni bajarib bo'lmaydi (tranzaksiya holati mos kelmaydi)
 *   - -31050..-31099: "account" (bizda: order_id) bilan bog'liq xatolar
 *   - Holatlar (state): 1=yaratilgan, 2=o'tkazilgan(to'langan), -1=to'lovdan oldin bekor,
 *     -2=to'lovdan keyin bekor (pul qaytarilgan)
 *   - Summalar TIYINDA (1 so'm = 100 tiyin), vaqt millisekundlarda (Unix epoch)
 *   - Avtorizatsiya: "Authorization: Basic base64(Paycom:<MERCHANT_KEY>)"
 *   - 12 soatlik muddat tugashi (taймaut bo'yicha bekor qilish) Payme'ning O'ZIDA avtomatik
 *     amalga oshadi (CancelTransaction so'rovi orqali) — merchant tomonida alohida vaqt
 *     hisoblagich yozish shart EMAS.
 *
 * Ishlab chiqarishga chiqarishdan oldin, Payme texnik hujjatlarini o'z merchant kabinetingizda
 * qayta tekshirib chiqishni tavsiya qilamiz — protokol vaqt o'tishi bilan kichik yangilanishlar
 * olishi mumkin.
 */

const PAYME_ERRORS = Object.freeze({
  PARSE_ERROR: -32700,
  INVALID_REQUEST: -32600,
  METHOD_NOT_FOUND: -32601,
  INSUFFICIENT_PRIVILEGE: -32504, // avtorizatsiya xato
  INTERNAL_ERROR: -32400,
  INVALID_AMOUNT: -31001,
  TRANSACTION_NOT_FOUND: -31003,
  UNABLE_TO_CANCEL_COMPLETED: -31007,
  UNABLE_TO_PERFORM_OPERATION: -31008,
  ACCOUNT_ERROR_MIN: -31050,
  ACCOUNT_ERROR_MAX: -31099,
});

const PAYME_STATE = Object.freeze({
  CREATED: 1,
  COMPLETED: 2,
  CANCELLED_BEFORE_COMPLETE: -1,
  CANCELLED_AFTER_COMPLETE: -2,
});

function somToTiyin(som) {
  return Math.round(Number(som) * 100);
}

function tiyinToSom(tiyin) {
  return Number(tiyin) / 100;
}

/** JSON-RPC 2.0 xato javobi (Payme kutgan aniq formatda - "message" uch tilda) */
function paymeError(id, code, ruMessage, extraData) {
  return {
    jsonrpc: '2.0',
    id: id ?? null,
    error: {
      code,
      message: { ru: ruMessage, uz: ruMessage, en: ruMessage },
      ...(extraData ? { data: extraData } : {}),
    },
  };
}

function paymeResult(id, result) {
  return { jsonrpc: '2.0', id: id ?? null, result };
}

/**
 * To'lov sahifasiga yo'naltiruvchi checkout URL yasaydi.
 * Format (rasmiy): <checkout_url>/base64("m=MERCHANT_ID;ac.FIELD=VALUE;a=SUMMA_TIYINDA")
 */
function buildPaymeCheckoutUrl({ merchantId, orderId, amountSom, returnUrl, testMode }) {
  const amountTiyin = somToTiyin(amountSom);
  let raw = `m=${merchantId};ac.order_id=${orderId};a=${amountTiyin}`;
  if (returnUrl) raw += `;c=${returnUrl}`;
  const encoded = Buffer.from(raw, 'utf8').toString('base64');
  const base = testMode ? 'https://checkout.test.paycom.uz' : 'https://checkout.paycom.uz';
  return `${base}/${encoded}`;
}

module.exports = { PAYME_ERRORS, PAYME_STATE, somToTiyin, tiyinToSom, paymeError, paymeResult, buildPaymeCheckoutUrl };
