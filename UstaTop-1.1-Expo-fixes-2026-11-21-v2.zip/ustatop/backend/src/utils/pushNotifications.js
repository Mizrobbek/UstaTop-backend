/**
 * Expo Push Notification xizmati orqali qurilmalarga push-bildirishnoma yuborish.
 *
 * NIMA UCHUN XOM FIREBASE SDK EMAS: mobil ilova Expo (managed workflow) asosida qurilgan,
 * shuning uchun qurilma tokeni xom FCM/APNs tokeni emas, balki Expo'ning o'z formati
 * ("ExponentPushToken[...]"). Expo'ning push xizmati shu tokenni FCM (Android) yoki
 * APNs (iOS)'ga o'zi yo'naltiradi — backend'da Firebase hisob ma'lumotlarini (service
 * account JSON) saqlash yoki sozlash shart emas. Agar kelajakda ilova Expo'dan "eject"
 * qilinsa, shu faylni xom firebase-admin SDK bilan almashtirish kifoya (interfeys bir xil
 * qoladi: sendPushNotifications(messages)).
 *
 * MANBA: https://docs.expo.dev/push-notifications/sending-notifications/ (rasmiy hujjat).
 */
const EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send';
const MAX_BATCH_SIZE = 100; // Expo'ning bir so'rovdagi maksimal xabarlar soni

function isExpoPushToken(token) {
  return typeof token === 'string' && /^(ExponentPushToken|ExpoPushToken)\[.+\]$/.test(token);
}

function chunk(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) chunks.push(array.slice(i, i + size));
  return chunks;
}

/**
 * Bir nechta xabarni (har biri { to, title, body, data? }) Expo'ga yuboradi.
 * Qaytaradi: { sent, invalidTokens } — invalidTokens ro'yxatidagi tokenlarni chaqiruvchi
 * kod bazadan o'chirib tashlashi kerak (qurilma ilovani o'chirgan yoki push rad etilgan).
 */
async function sendPushNotifications(messages) {
  const valid = messages.filter((m) => isExpoPushToken(m.to));
  if (valid.length === 0) return { sent: 0, invalidTokens: [] };

  const invalidTokens = [];
  let sent = 0;

  for (const batch of chunk(valid, MAX_BATCH_SIZE)) {
    try {
      const headers = { 'Content-Type': 'application/json', Accept: 'application/json' };
      if (process.env.EXPO_ACCESS_TOKEN) {
        headers.Authorization = `Bearer ${process.env.EXPO_ACCESS_TOKEN}`;
      }
      const response = await fetch(EXPO_PUSH_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify(batch.map((m) => ({ ...m, sound: 'default' }))),
      });
      const json = await response.json();
      const tickets = json.data || [];

      tickets.forEach((ticket, idx) => {
        if (ticket.status === 'ok') {
          sent++;
        } else if (ticket.details?.error === 'DeviceNotRegistered') {
          invalidTokens.push(batch[idx].to);
        } else {
          console.warn('[Expo Push] Xabar yuborilmadi:', ticket.message);
        }
      });
    } catch (err) {
      // Tarmoq xatosi bo'lsa, butun oqimni to'xtatmaymiz - push ikkinchi darajali funksiya,
      // asosiy amal (masalan, taklif qabul qilish) hech qachon push tufayli muvaffaqiyatsiz bo'lmasligi kerak
      console.error('[Expo Push] So\'rov xatosi:', err.message);
    }
  }

  return { sent, invalidTokens };
}

module.exports = { sendPushNotifications, isExpoPushToken };
