/**
 * SMS yuborish xizmati.
 *
 * Ishlab chiqarishda (production) O'zbekiston SMS provayderlaridan birini ulang:
 *   - Eskiz.uz   (https://eskiz.uz)     - eng ko'p ishlatiladigan
 *   - Play Mobile (https://playmobile.uz)
 *   - UZ Mobile SMS gateway'lari
 *
 * Hozircha SMS_PROVIDER=console bo'lsa, kod real yuborilmaydi — faqat serverning
 * konsoliga chiqadi. Bu dasturchilar uchun (backend/mobil ilova testi paytida)
 * qulay, chunki haqiqiy SMS balansi sarflanmaydi.
 *
 * Eskiz.uz bilan ulashda qilinadigan ishlar:
 *  1) ESKIZ_EMAIL / ESKIZ_PASSWORD orqali /auth/login dan token olinadi (keshlanadi)
 *  2) POST https://notify.eskiz.uz/api/message/sms/send ga { mobile_phone, message, from } yuboriladi
 */

async function sendSms(phone, message) {
  const provider = process.env.SMS_PROVIDER || 'console';

  if (provider === 'console') {
    console.log(`\n[SMS -> ${phone}]: ${message}\n`);
    return { success: true, provider: 'console' };
  }

  if (provider === 'eskiz') {
    return sendViaEskiz(phone, message);
  }

  throw new Error(`Noma'lum SMS provayder: ${provider}`);
}

async function sendViaEskiz(phone, message) {
  // Eskiz.uz API bilan ishlash uchun to'liq implementatsiya.
  // Diqqat: bu funksiya tarmoq (network) so'rovi yuboradi, shuning uchun
  // ESKIZ_EMAIL va ESKIZ_PASSWORD .env faylida to'g'ri to'ldirilgan bo'lishi shart.
  const email = process.env.ESKIZ_EMAIL;
  const password = process.env.ESKIZ_PASSWORD;
  if (!email || !password) {
    throw new Error('ESKIZ_EMAIL yoki ESKIZ_PASSWORD .env faylida topilmadi');
  }

  const loginRes = await fetch('https://notify.eskiz.uz/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const loginData = await loginRes.json();
  const token = loginData?.data?.token;
  if (!token) throw new Error('Eskiz.uz autentifikatsiyasi muvaffaqiyatsiz');

  const sendRes = await fetch('https://notify.eskiz.uz/api/message/sms/send', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      mobile_phone: phone.replace('+', ''),
      message,
      from: '4546',
    }),
  });

  if (!sendRes.ok) {
    const errText = await sendRes.text();
    throw new Error(`Eskiz.uz SMS yuborishda xato: ${errText}`);
  }

  return { success: true, provider: 'eskiz' };
}

module.exports = { sendSms };
