const Joi = require('joi');

const pagination = {
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(20),
};

const listUsersQuerySchema = Joi.object({
  role: Joi.string().valid('client', 'provider', 'both', 'admin').optional(),
  search: Joi.string().trim().max(100).optional(),
  ...pagination,
});

const listListingsQuerySchema = Joi.object({
  status: Joi.string().valid('open', 'in_progress', 'completed', 'cancelled').optional(),
  search: Joi.string().trim().max(100).optional(),
  ...pagination,
});

const setUserActiveSchema = Joi.object({
  isActive: Joi.boolean().required(),
});

const verifyProviderSchema = Joi.object({
  isVerified: Joi.boolean().required(),
});

const createCategorySchema = Joi.object({
  nameUz: Joi.string().trim().min(2).max(100).required(),
  nameRu: Joi.string().trim().max(100).allow('', null).optional(),
  icon: Joi.string().trim().max(60).allow('', null).optional(),
  sortOrder: Joi.number().integer().min(0).max(9999).default(0),
});

const updateCategorySchema = Joi.object({
  nameUz: Joi.string().trim().min(2).max(100).optional(),
  nameRu: Joi.string().trim().max(100).allow('', null).optional(),
  icon: Joi.string().trim().max(60).allow('', null).optional(),
  sortOrder: Joi.number().integer().min(0).max(9999).optional(),
  isActive: Joi.boolean().optional(),
}).min(1);

module.exports = {
  listUsersQuerySchema,
  listListingsQuerySchema,
  setUserActiveSchema,
  verifyProviderSchema,
  createCategorySchema,
  updateCategorySchema,
};
