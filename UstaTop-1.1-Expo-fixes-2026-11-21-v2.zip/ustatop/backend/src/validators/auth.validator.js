const Joi = require('joi');

// O'zbekiston raqam formati: +998 va 9 ta raqam (masalan +998901234567)
const phoneSchema = Joi.string()
  .pattern(/^\+998\d{9}$/)
  .required()
  .messages({
    'string.pattern.base': 'Telefon raqam +998XXXXXXXXX formatida bo\'lishi kerak',
  });

// Kamida 8 belgi, kamida bitta harf va bitta raqam - real dunyoda foydalanuvchilar
// uchun juda qattiq bo'lmagan, lekin yetarlicha xavfsiz talab
const passwordSchema = Joi.string()
  .min(8)
  .max(72) // bcrypt cheklovi
  .pattern(/^(?=.*[A-Za-z])(?=.*\d).+$/)
  .required()
  .messages({
    'string.min': 'Parol kamida 8 ta belgidan iborat bo\'lishi kerak',
    'string.pattern.base': 'Parol kamida bitta harf va bitta raqamdan iborat bo\'lishi kerak',
  });

const registerSchema = Joi.object({
  fullName: Joi.string().min(2).max(120).required().messages({
    'string.min': 'Ism kamida 2 ta belgidan iborat bo\'lishi kerak',
  }),
  phone: phoneSchema,
  // Eski API klientlari uchun saqlanadi; yangi mobil oqim email yubormaydi.
  email: Joi.string().email().lowercase().optional().allow(null, ''),
  password: passwordSchema,
});

const loginSchema = Joi.object({
  identifier: Joi.string().min(3).max(120).required().messages({ 'string.empty': 'Telefon raqam kiritilishi shart' }),
  password: Joi.string().required().messages({
    'string.empty': 'Parol kiritilishi shart',
  }),
});

const verifyPhoneOtpSchema = Joi.object({
  phone: phoneSchema,
  code: Joi.string().length(5).pattern(/^\d+$/).required(),
});

const forgotPasswordSendCodeSchema = Joi.object({
  phone: phoneSchema,
});

const forgotPasswordResetSchema = Joi.object({
  phone: phoneSchema,
  code: Joi.string().length(5).pattern(/^\d+$/).required().messages({
    'string.length': 'Kod 5 xonali bo\'lishi kerak',
  }),
  newPassword: passwordSchema,
});

const refreshSchema = Joi.object({
  refreshToken: Joi.string().required(),
});

module.exports = {
  phoneSchema,
  passwordSchema,
  registerSchema,
  loginSchema,
  verifyPhoneOtpSchema,
  forgotPasswordSendCodeSchema,
  forgotPasswordResetSchema,
  refreshSchema,
};
