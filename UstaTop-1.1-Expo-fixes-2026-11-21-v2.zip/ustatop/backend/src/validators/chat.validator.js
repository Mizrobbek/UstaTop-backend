const Joi = require('joi');

const sendMessageSchema = Joi.object({
  content: Joi.string().trim().min(1).max(2000).optional(),
  mediaUrl: Joi.string().uri().optional(),
})
  .or('content', 'mediaUrl')
  .messages({
    'object.missing': 'Xabar matni yoki fayl biriktirilishi kerak',
  });

const paginationSchema = Joi.object({
  before: Joi.string().isoDate().optional(), // shu sanadan oldingi xabarlarni oladi (eski xabarlarni yuklash uchun)
  limit: Joi.number().integer().min(1).max(100).default(30),
});

module.exports = { sendMessageSchema, paginationSchema };
