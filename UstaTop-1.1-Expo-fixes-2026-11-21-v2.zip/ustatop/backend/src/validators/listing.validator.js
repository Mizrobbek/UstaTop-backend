const Joi = require('joi');
const { UZ_BOUNDS } = require('../utils/geo');

// Dastur faqat O'zbekiston hududida ishlaydi (chegara haqidagi eslatma uchun utils/geo.js'ga qarang)
const OUTSIDE_UZ = 'Joylashuv O\'zbekiston hududida bo\'lishi kerak';
const uzLatitude = Joi.number()
  .min(UZ_BOUNDS.minLat)
  .max(UZ_BOUNDS.maxLat)
  .messages({ 'number.min': OUTSIDE_UZ, 'number.max': OUTSIDE_UZ });
const uzLongitude = Joi.number()
  .min(UZ_BOUNDS.minLng)
  .max(UZ_BOUNDS.maxLng)
  .messages({ 'number.min': OUTSIDE_UZ, 'number.max': OUTSIDE_UZ });

const createListingSchema = Joi.object({
  categoryId: Joi.number().integer().positive().required(),
  title: Joi.string().min(5).max(160).required().messages({
    'string.min': 'Sarlavha kamida 5 ta belgidan iborat bo\'lishi kerak',
  }),
  description: Joi.string().min(10).max(3000).required().messages({
    'string.min': 'Tavsif kamida 10 ta belgidan iborat bo\'lishi kerak',
  }),
  price: Joi.number().positive().max(999999999).optional().allow(null),
  priceType: Joi.string().valid('fixed', 'negotiable').default('negotiable'),
  address: Joi.string().max(255).optional().allow(null, ''),
  city: Joi.string().max(80).default('Toshkent'),
  latitude: uzLatitude.optional().allow(null),
  longitude: uzLongitude.optional().allow(null),
  mediaUrls: Joi.array().items(Joi.string().uri()).max(10).optional(),
})
  // Koordinata faqat juftlik bilan: yo ikkalasi ham berilishi, yo hech biri
  .and('latitude', 'longitude')
  .messages({ 'object.and': 'Joylashuv uchun kenglik va uzunlik birga berilishi kerak' });

const updateListingSchema = Joi.object({
  categoryId: Joi.number().integer().positive().optional(),
  title: Joi.string().min(5).max(160).optional(),
  description: Joi.string().min(10).max(3000).optional(),
  price: Joi.number().positive().max(999999999).optional().allow(null),
  priceType: Joi.string().valid('fixed', 'negotiable').optional(),
  address: Joi.string().max(255).optional().allow(null, ''),
  city: Joi.string().max(80).optional(),
  latitude: uzLatitude.optional().allow(null),
  longitude: uzLongitude.optional().allow(null),
  status: Joi.string().valid('open', 'cancelled').optional(),
})
  .and('latitude', 'longitude')
  .messages({ 'object.and': 'Joylashuv uchun kenglik va uzunlik birga berilishi kerak' });

const listQuerySchema = Joi.object({
  categoryId: Joi.number().integer().positive().optional(),
  city: Joi.string().max(80).optional(),
  status: Joi.string().valid('open', 'in_progress', 'completed', 'cancelled').optional(),
  search: Joi.string().max(120).optional(),
  lat: Joi.number().min(-90).max(90).optional(),
  lng: Joi.number().min(-180).max(180).optional(),
  radiusKm: Joi.number().positive().max(200).default(20),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(50).default(20),
});

const createOfferSchema = Joi.object({
  price: Joi.number().positive().max(999999999).required(),
  message: Joi.string().max(1000).optional().allow(null, ''),
});

// Xarita ko'rinishi: ekrandagi hudud (bounding box) bo'yicha e'lonlar
const mapQuerySchema = Joi.object({
  minLat: Joi.number().min(-90).max(90).required(),
  maxLat: Joi.number().min(-90).max(90).greater(Joi.ref('minLat')).required(),
  minLng: Joi.number().min(-180).max(180).required(),
  maxLng: Joi.number().min(-180).max(180).greater(Joi.ref('minLng')).required(),
  categoryId: Joi.number().integer().positive().optional(),
  // Foydalanuvchining joylashuvi (ixtiyoriy) — e'longacha masofani (km) hisoblash uchun
  userLat: Joi.number().min(-90).max(90).optional(),
  userLng: Joi.number().min(-180).max(180).optional(),
  limit: Joi.number().integer().min(1).max(300).default(150),
}).and('userLat', 'userLng');

module.exports = { createListingSchema, updateListingSchema, listQuerySchema, createOfferSchema, mapQuerySchema };
