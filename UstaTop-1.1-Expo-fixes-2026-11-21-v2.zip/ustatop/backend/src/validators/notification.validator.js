const Joi = require('joi');

const pushTokenSchema = Joi.object({
  pushToken: Joi.string().allow(null, '').optional(),
});

const listNotificationsQuerySchema = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(50).default(20),
});

module.exports = { pushTokenSchema, listNotificationsQuerySchema };
