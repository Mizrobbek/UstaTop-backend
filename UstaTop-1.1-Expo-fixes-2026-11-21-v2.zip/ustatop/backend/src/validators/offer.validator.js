const Joi = require('joi');

const offerStatusSchema = Joi.object({
  status: Joi.string().valid('accepted', 'rejected').required(),
});

module.exports = { offerStatusSchema };
