const Joi = require('joi');

const updateOrderStatusSchema = Joi.object({
  status: Joi.string().valid('in_progress', 'completed', 'cancelled').required(),
  cancelReason: Joi.string().max(500).when('status', { is: 'cancelled', then: Joi.required() }),
});

module.exports = { updateOrderStatusSchema };
