const Joi = require('joi');

const initiatePaymentSchema = Joi.object({
  provider: Joi.string().valid('payme', 'click').required(),
});

module.exports = { initiatePaymentSchema };
