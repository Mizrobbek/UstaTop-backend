const Joi = require('joi');

const updateProfileSchema = Joi.object({
  fullName: Joi.string().min(2).max(120).optional(),
  city: Joi.string().max(80).optional(),
  avatarUrl: Joi.string().uri().optional().allow(null, ''),
});

const updateProviderProfileSchema = Joi.object({
  bio: Joi.string().max(1000).allow('').optional(),
  experienceYears: Joi.number().integer().min(0).max(60).optional(),
});

const becomeProviderSchema = Joi.object({
  bio: Joi.string().max(1000).optional().allow(''),
  experienceYears: Joi.number().integer().min(0).max(60).default(0),
  categoryIds: Joi.array().items(Joi.number().integer().positive()).min(1).max(10).required().messages({
    'array.min': 'Kamida bitta xizmat kategoriyasini tanlang',
  }),
});

module.exports = { updateProfileSchema, updateProviderProfileSchema, becomeProviderSchema };
