process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const request = require('supertest');
const app = require('../src/app');
const dbSingleton = require('./testUtils/dbSingleton');

dbSingleton.state.categories.push({ id: 1, name_uz: 'Santexnik', is_active: true, sort_order: 1 });

let adminToken, clientToken, clientId;

beforeAll(async () => {
  const admin = await request(app)
    .post('/api/auth/register')
    .send({ fullName: 'Admin Test', phone: '+998951112233', password: 'Parol1234' });
  adminToken = admin.body.accessToken;
  // Admin rolini API orqali olib bo'lmaydi - (createAdmin.js kabi) to'g'ridan-to'g'ri bazada belgilaymiz
  dbSingleton.state.users.find((u) => u.id === admin.body.user.id).role = 'admin';

  const client = await request(app)
    .post('/api/auth/register')
    .send({ fullName: 'Oddiy Mijoz', phone: '+998952223344', password: 'Parol1234' });
  clientToken = client.body.accessToken;
  clientId = client.body.user.id;
});

describe('Admin API — kirish huquqlari', () => {
  test('tokensiz so\'rov 401 qaytaradi', async () => {
    const res = await request(app).get('/api/admin/stats');
    expect(res.status).toBe(401);
  });

  test('oddiy foydalanuvchi admin API\'ga kira olmaydi (403)', async () => {
    const res = await request(app).get('/api/admin/stats').set('Authorization', `Bearer ${clientToken}`);
    expect(res.status).toBe(403);
  });

  test('admin statistikani ko\'ra oladi', async () => {
    const res = await request(app).get('/api/admin/stats').set('Authorization', `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
    expect(res.body.stats.users.total).toBe(2);
    expect(res.body.stats.users.byRole.admin).toBe(1);
  });
});

describe('Admin API — foydalanuvchilarni boshqarish', () => {
  test('foydalanuvchilar ro\'yxati qidiruv bilan ishlaydi', async () => {
    const res = await request(app)
      .get('/api/admin/users')
      .query({ search: 'Oddiy' })
      .set('Authorization', `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
    expect(res.body.users.length).toBe(1);
    expect(res.body.users[0].fullName).toBe('Oddiy Mijoz');
  });

  test('noto\'g\'ri rol filtri validatsiyadan o\'tmaydi (400)', async () => {
    const res = await request(app)
      .get('/api/admin/users')
      .query({ role: 'superman' })
      .set('Authorization', `Bearer ${adminToken}`);
    expect(res.status).toBe(400);
  });

  test('bloklangan foydalanuvchi mavjud tokeni bilan ham darhol kira olmaydi', async () => {
    const ban = await request(app)
      .patch(`/api/admin/users/${clientId}/active`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ isActive: false });
    expect(ban.status).toBe(200);

    const me = await request(app).get('/api/users/me').set('Authorization', `Bearer ${clientToken}`);
    expect(me.status).toBe(403);

    const login = await request(app)
      .post('/api/auth/login')
      .send({ identifier: '+998952223344', password: 'Parol1234' });
    expect(login.status).toBe(403);
  });

  test('blokdan chiqarilgach foydalanuvchi yana kira oladi', async () => {
    await request(app)
      .patch(`/api/admin/users/${clientId}/active`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ isActive: true });
    // 1-bosqich (P1): bloklash barcha sessiyalarni bekor qiladi, shuning uchun eski token
    // blokdan chiqarilgandan keyin ham qayta tiklanmaydi — foydalanuvchi qaytadan kiradi.
    const oldTokenMe = await request(app).get('/api/users/me').set('Authorization', `Bearer ${clientToken}`);
    expect(oldTokenMe.status).toBe(401);
    expect(oldTokenMe.body.code).toBe('TOKEN_REVOKED');

    const login = await request(app)
      .post('/api/auth/login')
      .send({ identifier: '+998952223344', password: 'Parol1234' });
    expect(login.status).toBe(200);
    const me = await request(app).get('/api/users/me').set('Authorization', `Bearer ${login.body.accessToken}`);
    expect(me.status).toBe(200);
  });
});

describe('Admin API — kategoriyalar', () => {
  test('bo\'sh nom bilan kategoriya yaratib bo\'lmaydi (400)', async () => {
    const res = await request(app)
      .post('/api/admin/categories')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ nameUz: '' });
    expect(res.status).toBe(400);
  });

  test('kategoriya yaratiladi va nofaol qilinsa ommaviy ro\'yxatdan yo\'qoladi', async () => {
    const created = await request(app)
      .post('/api/admin/categories')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ nameUz: 'Bog\'bon', icon: 'garden', sortOrder: 3 });
    expect(created.status).toBe(201);
    const id = created.body.category.id;

    const publicBefore = await request(app).get('/api/categories');
    expect(publicBefore.body.categories.some((c) => c.id === id)).toBe(true);

    const patched = await request(app)
      .patch(`/api/admin/categories/${id}`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ isActive: false });
    expect(patched.status).toBe(200);

    const publicAfter = await request(app).get('/api/categories');
    expect(publicAfter.body.categories.some((c) => c.id === id)).toBe(false);

    const adminList = await request(app).get('/api/admin/categories').set('Authorization', `Bearer ${adminToken}`);
    expect(adminList.body.categories.some((c) => c.id === id && c.isActive === false)).toBe(true);
  });

  test('bo\'sh o\'zgartirish so\'rovi rad etiladi (400)', async () => {
    const res = await request(app)
      .patch('/api/admin/categories/1')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({});
    expect(res.status).toBe(400);
  });
});
