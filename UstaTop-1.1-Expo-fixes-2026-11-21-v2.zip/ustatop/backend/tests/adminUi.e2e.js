/**
 * Admin panelning brauzer (E2E) testi. Haqiqiy Chromium'da, Helmet'dagi kabi qat'iy CSP bilan
 * ishlaydi, backend API'si esa soxtalashtirilgan (page.route) — shuning uchun PostgreSQL kerak emas.
 * Tekshiradi: kirish/parolni ko'rsatish, admin bo'lmagan hisobni rad etish, XSS'dan himoya,
 * bloklash/tasdiqlash/bekor qilish, kategoriya CRUD, mobil kenglik, konsol xatolari.
 *
 * Ishga tushirish (bir marta): npm install && npx playwright install chromium
 * Keyin:                       npm run test:admin-ui
 * Skrinshotlar tizimning vaqtinchalik papkasiga (os.tmpdir()) saqlanadi.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { chromium } = require('playwright');

const os = require('os');
const ADMIN_DIR = path.join(__dirname, '..', 'admin');
const SHOT = (name) => path.join(os.tmpdir(), name);
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css' };
// Helmet standart CSP'si (upgrade-insecure-requests'siz) bilan bir xil
const CSP = "default-src 'self';base-uri 'self';font-src 'self' https: data:;form-action 'self';frame-ancestors 'self';img-src 'self' data:;object-src 'none';script-src 'self';script-src-attr 'none';style-src 'self' https: 'unsafe-inline'";

const server = http.createServer((req, res) => {
  const file = req.url === '/' ? '/index.html' : req.url.split('?')[0];
  const full = path.join(ADMIN_DIR, file);
  if (!full.startsWith(ADMIN_DIR) || !fs.existsSync(full)) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'text/plain', 'Content-Security-Policy': CSP });
  res.end(fs.readFileSync(full));
});

const XSS_NAME = '<img src=x onerror="window.__xss=1">Hujumchi';
const adminUser = { id: 'a1', fullName: 'Bosh Admin', role: 'admin', phone: '+998900000001' };
const users = [
  { id: 'a1', phone: '+998900000001', email: null, fullName: 'Bosh Admin', role: 'admin', isActive: true, providerVerified: null, createdAt: new Date().toISOString() },
  { id: 'u2', phone: '+998900000002', email: 'x@y.uz', fullName: XSS_NAME, role: 'client', isActive: true, providerVerified: null, createdAt: new Date().toISOString() },
  { id: 'u3', phone: '+998900000003', email: null, fullName: 'Usta Karim', role: 'both', isActive: true, providerVerified: false, createdAt: new Date().toISOString() },
];
let categories = [
  { id: 1, nameUz: 'Santexnik', nameRu: 'Сантехник', icon: 'plumbing', sortOrder: 1, isActive: true },
  { id: 2, nameUz: 'Elektrik', nameRu: null, icon: null, sortOrder: 2, isActive: false },
];
const calls = [];

async function main() {
  await new Promise((r) => server.listen(0, r));
  const base = `http://localhost:${server.address().port}`;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });

  const problems = [];
  page.on('pageerror', (e) => problems.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/status of 401/.test(m.text())) problems.push('console: ' + m.text()); });
  page.on('dialog', async (d) => { calls.push('dialog:' + d.type()); await d.accept(); });

  await page.route('**/api/**', async (route) => {
    const req = route.request();
    const url = new URL(req.url());
    const p = url.pathname.replace(/^\/api/, '');
    const m = req.method();
    const body = req.postData() ? JSON.parse(req.postData()) : {};
    calls.push(`${m} ${p}${url.search}`);
    const json = (status, data) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(data) });

    if (p === '/auth/login') {
      if (body.password === 'wrong') return json(401, { error: 'Login yoki parol noto\'g\'ri' });
      if (body.identifier === '+998911111111') return json(200, { user: { id: 'c1', role: 'client', fullName: 'Oddiy' }, accessToken: 't', refreshToken: 'r' });
      return json(200, { user: adminUser, accessToken: 'acc', refreshToken: 'ref' });
    }
    if (p === '/auth/logout') return json(200, { message: 'ok' });
    if (p === '/admin/stats') return json(200, { stats: {
      users: { total: 3, byRole: { admin: 1, client: 1, both: 1 } },
      listings: { total: 5, byStatus: { open: 3, completed: 2 } },
      orders: { total: 2, byStatus: { completed: 2 }, completedVolume: 1250000 },
      reviews: { total: 4 } } });
    if (p === '/admin/users') {
      const search = url.searchParams.get('search');
      const list = search ? users.filter((u) => u.fullName.toLowerCase().includes(search.toLowerCase())) : users;
      return json(200, { users: list, pagination: { page: 1, limit: 15, total: list.length, totalPages: 1 } });
    }
    if (p.startsWith('/admin/users/') && p.endsWith('/active')) return json(200, { message: 'ok' });
    if (p.startsWith('/admin/providers/') && p.endsWith('/verify')) return json(200, { message: 'ok' });
    if (p === '/admin/listings') return json(200, { listings: [
      { id: 'l1', title: 'Kran tamiri', status: 'open', city: 'Toshkent', price: 100000, viewsCount: 12, categoryName: 'Santexnik', clientName: 'Ali', createdAt: new Date().toISOString() },
      { id: 'l2', title: 'Quvur', status: 'completed', city: 'Samarqand', price: null, viewsCount: 3, categoryName: 'Santexnik', clientName: 'Vali', createdAt: new Date().toISOString() },
    ], pagination: { page: 1, limit: 15, total: 2, totalPages: 1 } });
    if (p.startsWith('/admin/listings/') && p.endsWith('/cancel')) return json(200, { message: 'ok' });
    if (p === '/admin/categories' && m === 'GET') return json(200, { categories });
    if (p === '/admin/categories' && m === 'POST') {
      categories = categories.concat([{ id: 3, nameUz: body.nameUz, nameRu: body.nameRu || null, icon: body.icon || null, sortOrder: body.sortOrder, isActive: true }]);
      return json(201, { message: 'ok' });
    }
    if (p.startsWith('/admin/categories/') && m === 'PATCH') {
      const id = Number(p.split('/').pop());
      categories = categories.map((c) => (c.id === id ? Object.assign({}, c, body) : c));
      return json(200, { message: 'ok' });
    }
    return json(404, { error: 'mock yo\'q: ' + p });
  });

  // ---- Kirish ekrani ----
  await page.goto(base + '/');
  await page.waitForSelector('.login-card');
  await page.screenshot({ path: SHOT('admin_login.png') });

  const pass = page.locator('input[type=password]');
  await page.fill('input[type=text]', '+998 90 000 00 01');
  await pass.fill('secret123');
  await page.click('.toggle-pass');
  assert.strictEqual(await page.locator('.input-row input').getAttribute('type'), 'text', 'Parol ko\'rsatilishi kerak');
  await page.click('.toggle-pass');
  assert.strictEqual(await page.locator('.input-row input').getAttribute('type'), 'password', 'Parol yashirilishi kerak');
  console.log('  ✔ parolni ko\'rsatish/yashirish tugmasi ishlaydi');

  await pass.fill('wrong');
  await page.click('button[type=submit]');
  await page.waitForSelector('.error-box:not([hidden])');
  assert.match(await page.textContent('.error-box'), /noto'g'ri/);
  console.log('  ✔ noto\'g\'ri parolda xato xabari ko\'rsatildi');

  await page.fill('input[type=text]', '+998911111111');
  await pass.fill('secret123');
  await page.click('button[type=submit]');
  await page.waitForFunction(() => /faqat administratorlar/.test(document.querySelector('.error-box')?.textContent || ''));
  assert.ok(calls.includes('POST /auth/logout'), 'admin bo\'lmagan sessiya bekor qilinishi kerak');
  console.log('  ✔ admin bo\'lmagan hisob rad etildi va uning sessiyasi bekor qilindi');

  await page.fill('input[type=text]', '+998900000001');
  await pass.fill('secret123');
  await page.click('button[type=submit]');
  await page.waitForSelector('.topbar');
  await page.waitForSelector('.stat-value');
  const statsText = await page.textContent('.cards');
  assert.match(statsText, /1\s?250\s?000/);
  assert.match(statsText, /Foydalanuvchilar/);
  await page.screenshot({ path: SHOT('admin_dashboard.png') });
  console.log('  ✔ admin kirdi, bosh panel statistikasi ko\'rindi');

  // ---- Foydalanuvchilar ----
  await page.click('.tab:has-text("Foydalanuvchilar")');
  await page.waitForSelector('tbody tr');
  assert.strictEqual(await page.locator('tbody tr').count(), 3);
  assert.strictEqual(await page.evaluate(() => window.__xss), undefined, 'XSS bajarilmasligi kerak');
  assert.strictEqual(await page.locator('tbody img').count(), 0, 'Foydalanuvchi ismi HTML sifatida talqin qilinmasligi kerak');
  assert.ok((await page.textContent('tbody')).includes('<img src=x'), 'Zararli matn oddiy matn sifatida ko\'rinishi kerak');
  console.log('  ✔ XSS urinishi (ism ichidagi <img onerror>) bajarilmadi, oddiy matn sifatida ko\'rsatildi');

  const adminRow = page.locator('tbody tr', { hasText: 'Bosh Admin' });
  assert.strictEqual(await adminRow.locator('button').count(), 0, 'Adminni bloklash tugmasi bo\'lmasligi kerak');
  console.log('  ✔ admin qatorida bloklash tugmasi yo\'q');

  await page.screenshot({ path: SHOT('admin_users.png') });
  await page.locator('tbody tr', { hasText: 'Usta Karim' }).locator('button:has-text("Bloklash")').click();
  await page.waitForFunction(() => document.querySelector('#toast') && !document.querySelector('#toast').hidden);
  assert.ok(calls.includes('dialog:confirm'), 'bloklashdan oldin tasdiq so\'ralishi kerak');
  assert.ok(calls.includes('PATCH /admin/users/u3/active'));
  console.log('  ✔ bloklash: tasdiq oynasi chiqdi va PATCH so\'rovi yuborildi');

  await page.locator('tbody tr', { hasText: 'Usta Karim' }).locator('button:has-text("Tasdiqlash")').click();
  await page.waitForFunction(() => /tasdiqlandi/i.test(document.querySelector('#toast').textContent));
  console.log('  ✔ ustani tasdiqlash ishladi');

  await page.fill('.toolbar input', 'karim');
  await page.press('.toolbar input', 'Enter');
  await page.waitForFunction(() => document.querySelectorAll('tbody tr').length === 1);
  assert.ok(calls.some((c) => c.includes('/admin/users?search=karim')));
  console.log('  ✔ qidiruv (Enter) serverga so\'rov yubordi va natijani filtrladi');

  // ---- E'lonlar ----
  await page.click('.tab:has-text("E\'lonlar")');
  await page.waitForSelector('tbody tr');
  assert.strictEqual(await page.locator('button:has-text("Bekor qilish")').count(), 1, 'Faqat ochiq e\'lon uchun tugma bo\'lishi kerak');
  await page.screenshot({ path: SHOT('admin_listings.png') });
  await page.click('button:has-text("Bekor qilish")');
  await page.waitForFunction(() => /bekor qilindi/i.test(document.querySelector('#toast').textContent));
  assert.ok(calls.includes('PATCH /admin/listings/l1/cancel'));
  console.log('  ✔ e\'lonlar: faqat ochiq e\'londa "Bekor qilish" bor, ishladi');

  // ---- Kategoriyalar ----
  await page.click('.tab:has-text("Kategoriyalar")');
  await page.waitForSelector('tbody tr');
  assert.strictEqual(await page.locator('tbody tr').count(), 2);
  await page.fill('.form-grid .field:nth-child(1) input', 'Bog\'bon');
  await page.click('button:has-text("Qo\'shish")');
  await page.waitForFunction(() => document.querySelectorAll('tbody tr').length === 3);
  console.log('  ✔ yangi kategoriya qo\'shildi va ro\'yxat yangilandi');

  await page.locator('tbody tr', { hasText: 'Santexnik' }).locator('button:has-text("Tahrirlash")').click();
  const editInput = page.locator('tbody tr input').first();
  await editInput.fill('Santexnik-usta');
  await page.click('button:has-text("Saqlash")');
  await page.waitForFunction(() => document.body.textContent.includes('Santexnik-usta'));
  console.log('  ✔ kategoriyani inline tahrirlash ishladi');

  await page.locator('tbody tr', { hasText: 'Elektrik' }).locator('button:has-text("Faollashtirish")').click();
  await page.waitForFunction(() => /faollashtirildi/i.test(document.querySelector('#toast').textContent));
  console.log('  ✔ nofaol kategoriyani faollashtirish ishladi');
  await page.screenshot({ path: SHOT('admin_categories.png') });

  // ---- Mobil ko'rinish ----
  await page.setViewportSize({ width: 390, height: 800 });
  await page.click('.tab:has-text("Bosh panel")');
  await page.waitForSelector('.stat-value');
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
  assert.strictEqual(overflow, false, 'Mobil ekranda sahifa yon tomonga sirpanib ketmasligi kerak');
  await page.screenshot({ path: SHOT('admin_mobile.png') });
  console.log('  ✔ mobil kenglikda (390px) gorizontal siljish yo\'q');

  // ---- Chiqish ----
  await page.click('button:has-text("Chiqish")');
  await page.waitForSelector('.login-card');
  console.log('  ✔ chiqish login ekraniga qaytardi');

  assert.deepStrictEqual(problems, [], 'Konsol/sahifa xatolari: ' + problems.join(' | '));
  console.log('  ✔ brauzer konsolida xato va CSP buzilishi yo\'q');

  await browser.close();
  server.close();
  console.log('\n✅ Admin panel brauzer testi MUVAFFAQIYATLI\n');
}

main().catch(async (e) => { console.error('\n❌ XATO:', e.message); server.close(); process.exit(1); });
