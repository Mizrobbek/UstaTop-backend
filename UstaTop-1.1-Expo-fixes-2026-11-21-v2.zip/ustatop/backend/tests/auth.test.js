process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console'; // testlarda haqiqiy SMS yubormaslik uchun
process.env.NODE_ENV = 'test';

// config/db modulini soxta baza bilan almashtiramiz - shu bilan haqiqiy PostgreSQL kerak bo'lmaydi
jest.mock('../src/config/db', () => {
  const { createFakeDb } = require('./testUtils/fakeDb');
  const db = createFakeDb();
  return { query: db.query, getClient: db.getClient, pool: { query: db.query, end: async () => {} } };
});

const request = require('supertest');
const app = require('../src/app');

const VALID_PHONE = '+998901234567';
const VALID_PASSWORD = 'Parol1234';

describe('POST /api/auth/register', () => {
  test('to\'g\'ri ma\'lumotlar bilan muvaffaqiyatli ro\'yxatdan o\'tkazadi', async () => {
    const res = await request(app).post('/api/auth/register').send({
      fullName: 'Aziz Karimov',
      phone: VALID_PHONE,
      email: 'aziz@example.com',
      password: VALID_PASSWORD,
    });

    expect(res.status).toBe(201);
    expect(res.body.user.phone).toBe(VALID_PHONE);
    expect(res.body.user.fullName).toBe('Aziz Karimov');
    expect(res.body.accessToken).toBeDefined();
    expect(res.body.refreshToken).toBeDefined();
    // Parol hech qachon javobda qaytmasligi kerak
    expect(res.body.user.password_hash).toBeUndefined();
    expect(res.body.user.password).toBeUndefined();
  });

  test('email ixtiyoriy - emailsiz ham ro\'yxatdan o\'tish mumkin', async () => {
    const res = await request(app).post('/api/auth/register').send({
      fullName: 'Malika Yusupova',
      phone: '+998907654321',
      password: VALID_PASSWORD,
    });
    expect(res.status).toBe(201);
    expect(res.body.user.email).toBeNull();
  });

  test('noto\'g\'ri telefon formatini rad etadi', async () => {
    const res = await request(app).post('/api/auth/register').send({
      fullName: 'Test User',
      phone: '901234567', // +998 yo'q
      password: VALID_PASSWORD,
    });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/noto'g'ri/i);
  });

  test('kuchsiz parolni rad etadi (faqat harflar, raqamsiz)', async () => {
    const res = await request(app).post('/api/auth/register').send({
      fullName: 'Test User',
      phone: '+998911111111',
      password: 'onlyletters',
    });
    expect(res.status).toBe(400);
  });

  test('takroriy telefon raqamini rad etadi (409)', async () => {
    const res = await request(app).post('/api/auth/register').send({
      fullName: 'Ikkinchi Foydalanuvchi',
      phone: VALID_PHONE, // birinchi testda allaqachon ro'yxatdan o'tgan
      password: VALID_PASSWORD,
    });
    expect(res.status).toBe(409);
  });
});

describe('POST /api/auth/login', () => {
  test('telefon raqami va to\'g\'ri parol bilan kirish mumkin', async () => {
    const res = await request(app).post('/api/auth/login').send({
      identifier: VALID_PHONE,
      password: VALID_PASSWORD,
    });
    expect(res.status).toBe(200);
    expect(res.body.accessToken).toBeDefined();
    expect(res.body.user.phone).toBe(VALID_PHONE);
  });

  test('email va to\'g\'ri parol bilan kirish mumkin', async () => {
    const res = await request(app).post('/api/auth/login').send({
      identifier: 'aziz@example.com',
      password: VALID_PASSWORD,
    });
    expect(res.status).toBe(200);
    expect(res.body.user.email).toBe('aziz@example.com');
  });

  test('noto\'g\'ri parol bilan kirish rad etiladi (401)', async () => {
    const res = await request(app).post('/api/auth/login').send({
      identifier: VALID_PHONE,
      password: 'NotoGriParol1',
    });
    expect(res.status).toBe(401);
    expect(res.body.error).toMatch(/noto'g'ri/i);
  });

  test('mavjud bo\'lmagan foydalanuvchi bilan kirish rad etiladi (401, xatolik xabari bir xil)', async () => {
    const res = await request(app).post('/api/auth/login').send({
      identifier: '+998999999999',
      password: VALID_PASSWORD,
    });
    expect(res.status).toBe(401);
    // Xavfsizlik uchun: xato xabari "foydalanuvchi topilmadi" bilan "parol xato"da bir xil bo'lishi kerak
    expect(res.body.error).toMatch(/noto'g'ri/i);
  });
});

describe('Parolni telefon orqali tiklash (forgot password)', () => {
  const PHONE = VALID_PHONE;
  let sentCode;
  let consoleSpy;

  beforeAll(() => {
    // sendSms 'console' provayderda kodni console.log orqali chiqaradi - shuni ushlab olamiz
    consoleSpy = jest.spyOn(console, 'log').mockImplementation((msg) => {
      const match = /kodi[:\s—-]*\s*(\d{5})/i.exec(msg) || /(\d{5})/.exec(msg);
      if (match && msg.includes('SMS')) sentCode = match[1];
    });
  });
  afterAll(() => consoleSpy.mockRestore());

  test('mavjud telefon uchun kod yuboriladi', async () => {
    const res = await request(app).post('/api/auth/forgot-password/send-code').send({ phone: PHONE });
    expect(res.status).toBe(200);
    expect(sentCode).toBeDefined();
    expect(sentCode).toHaveLength(5);
  });

  test('mavjud bo\'lmagan telefon uchun ham bir xil (xavfsiz) javob qaytadi', async () => {
    const res = await request(app)
      .post('/api/auth/forgot-password/send-code')
      .send({ phone: '+998955555555' });
    expect(res.status).toBe(200);
  });

  test('noto\'g\'ri kod bilan parolni tiklab bo\'lmaydi', async () => {
    const res = await request(app).post('/api/auth/forgot-password/reset').send({
      phone: PHONE,
      code: '00000',
      newPassword: 'YangiParol1',
    });
    expect(res.status).toBe(400);
  });

  test('to\'g\'ri kod bilan parol muvaffaqiyatli yangilanadi va yangi parol bilan kirish mumkin', async () => {
    const resetRes = await request(app).post('/api/auth/forgot-password/reset').send({
      phone: PHONE,
      code: sentCode,
      newPassword: 'YangiParol1',
    });
    expect(resetRes.status).toBe(200);

    // Eski parol endi ishlamasligi kerak
    const oldLoginRes = await request(app)
      .post('/api/auth/login')
      .send({ identifier: PHONE, password: VALID_PASSWORD });
    expect(oldLoginRes.status).toBe(401);

    // Yangi parol bilan kirish muvaffaqiyatli bo'lishi kerak
    const newLoginRes = await request(app)
      .post('/api/auth/login')
      .send({ identifier: PHONE, password: 'YangiParol1' });
    expect(newLoginRes.status).toBe(200);
  });
});

describe('POST /api/auth/refresh va /api/auth/logout', () => {
  test('yaroqli refreshToken bilan yangi tokenlar olinadi', async () => {
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({ identifier: VALID_PHONE, password: 'YangiParol1' });

    const refreshRes = await request(app)
      .post('/api/auth/refresh')
      .send({ refreshToken: loginRes.body.refreshToken });

    expect(refreshRes.status).toBe(200);
    expect(refreshRes.body.accessToken).toBeDefined();
    expect(refreshRes.body.refreshToken).toBeDefined();
    // Token rotation - eski refresh token endi ishlamasligi kerak
    const secondUse = await request(app)
      .post('/api/auth/refresh')
      .send({ refreshToken: loginRes.body.refreshToken });
    expect(secondUse.status).toBe(401);
  });

  test('logout qilingandan keyin refreshToken bekor bo\'ladi', async () => {
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({ identifier: VALID_PHONE, password: 'YangiParol1' });

    await request(app).post('/api/auth/logout').send({ refreshToken: loginRes.body.refreshToken });

    const refreshRes = await request(app)
      .post('/api/auth/refresh')
      .send({ refreshToken: loginRes.body.refreshToken });
    expect(refreshRes.status).toBe(401);
  });
});
