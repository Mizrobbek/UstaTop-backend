process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const request = require('supertest');
const app = require('../src/app');
const dbSingleton = require('./testUtils/dbSingleton');

const CATEGORY_ID = 1;
dbSingleton.state.categories.push({ id: CATEGORY_ID, name_uz: 'Santexnik', is_active: true, sort_order: 1 });

let clientToken, providerToken, outsiderToken;
let listingId, chatId;

beforeAll(async () => {
  const client = await request(app)
    .post('/api/auth/register')
    .send({ fullName: 'Mijoz Test', phone: '+998931112233', password: 'Parol1234' });
  clientToken = client.body.accessToken;

  const provider = await request(app)
    .post('/api/auth/register')
    .send({ fullName: 'Usta Test', phone: '+998932223344', password: 'Parol1234' });
  providerToken = provider.body.accessToken;
  const providerId = provider.body.user.id;
  dbSingleton.state.users.find((u) => u.id === providerId).role = 'both';

  const outsider = await request(app)
    .post('/api/auth/register')
    .send({ fullName: 'Begona Odam', phone: '+998933334455', password: 'Parol1234' });
  outsiderToken = outsider.body.accessToken;

  // E'lon yaratib, taklif berib, qabul qilib - shu orqali chat avtomatik yaratiladi
  const listingRes = await request(app)
    .post('/api/listings')
    .set('Authorization', `Bearer ${clientToken}`)
    .send({ categoryId: CATEGORY_ID, title: 'Elektr simini almashtirish', description: 'Rozetka ishlamayapti butunlay' });
  listingId = listingRes.body.listing.id;

  const offerRes = await request(app)
    .post(`/api/listings/${listingId}/offers`)
    .set('Authorization', `Bearer ${providerToken}`)
    .send({ price: 80000 });
  const offerId = offerRes.body.offer.id;

  const acceptRes = await request(app)
    .patch(`/api/offers/${offerId}`)
    .set('Authorization', `Bearer ${clientToken}`)
    .send({ status: 'accepted' });
  chatId = acceptRes.body.chatId;
});

describe('GET /api/chats', () => {
  test('mijoz o\'z suhbatlarini ko\'ra oladi', async () => {
    const res = await request(app).get('/api/chats').set('Authorization', `Bearer ${clientToken}`);
    expect(res.status).toBe(200);
    expect(res.body.chats.length).toBe(1);
    expect(res.body.chats[0].otherUser.fullName).toBe('Usta Test');
    expect(res.body.chats[0].listingTitle).toBe('Elektr simini almashtirish');
  });

  test('usta ham xuddi shu suhbatni o\'z ro\'yxatida ko\'radi', async () => {
    const res = await request(app).get('/api/chats').set('Authorization', `Bearer ${providerToken}`);
    expect(res.status).toBe(200);
    expect(res.body.chats.length).toBe(1);
    expect(res.body.chats[0].otherUser.fullName).toBe('Mijoz Test');
  });

  test('aloqasi bo\'lmagan foydalanuvchi hech qanday suhbat ko\'rmaydi', async () => {
    const res = await request(app).get('/api/chats').set('Authorization', `Bearer ${outsiderToken}`);
    expect(res.status).toBe(200);
    expect(res.body.chats.length).toBe(0);
  });
});

describe('Xabar yuborish va o\'qish', () => {
  test('begona odam suhbatga xabar yubora olmaydi (403)', async () => {
    const res = await request(app)
      .post(`/api/chats/${chatId}/messages`)
      .set('Authorization', `Bearer ${outsiderToken}`)
      .send({ content: 'Salom' });
    expect(res.status).toBe(403);
  });

  test('mijoz xabar yubora oladi', async () => {
    const res = await request(app)
      .post(`/api/chats/${chatId}/messages`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ content: 'Assalomu alaykum, qachon kela olasiz?' });
    expect(res.status).toBe(201);
    expect(res.body.message.content).toBe('Assalomu alaykum, qachon kela olasiz?');
    expect(res.body.message.isRead).toBe(false);
  });

  test('bo\'sh xabar (matnsiz va faylsiz) rad etiladi', async () => {
    const res = await request(app)
      .post(`/api/chats/${chatId}/messages`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({});
    expect(res.status).toBe(400);
  });

  test('usta javob yozadi', async () => {
    const res = await request(app)
      .post(`/api/chats/${chatId}/messages`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ content: 'Bugun soat 15:00 da kela olaman' });
    expect(res.status).toBe(201);
  });

  test('xabarlar tarixi eskisidan yangisiga tartiblangan holda qaytadi', async () => {
    const res = await request(app)
      .get(`/api/chats/${chatId}/messages`)
      .set('Authorization', `Bearer ${clientToken}`);
    expect(res.status).toBe(200);
    expect(res.body.messages.length).toBe(2);
    expect(res.body.messages[0].content).toBe('Assalomu alaykum, qachon kela olasiz?');
    expect(res.body.messages[1].content).toBe('Bugun soat 15:00 da kela olaman');
  });

  test('xabarlarni o\'qish ularni "o\'qilgan" deb belgilaydi', async () => {
    // Mijoz suhbatni ochganda, usta yuborgan xabar "o'qilgan" bo'lib qolishi kerak
    await request(app).get(`/api/chats/${chatId}/messages`).set('Authorization', `Bearer ${clientToken}`);

    const chatsRes = await request(app).get('/api/chats').set('Authorization', `Bearer ${clientToken}`);
    expect(chatsRes.body.chats[0].unreadCount).toBe(0);
  });

  test('begona odam xabarlar tarixini ko\'ra olmaydi (403)', async () => {
    const res = await request(app)
      .get(`/api/chats/${chatId}/messages`)
      .set('Authorization', `Bearer ${outsiderToken}`);
    expect(res.status).toBe(403);
  });

  test('mavjud bo\'lmagan suhbat uchun 404', async () => {
    const res = await request(app)
      .get('/api/chats/00000000-0000-0000-0000-000000000000/messages')
      .set('Authorization', `Bearer ${clientToken}`);
    expect(res.status).toBe(404);
  });
});
