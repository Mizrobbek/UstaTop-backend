/**
 * 1-bosqich (P1): HAQIQIY PostgreSQL bilan parallel (race) testlar.
 * Ishga tushirish: migratsiyalangan bo'sh test bazasi kerak:
 *   TEST_DATABASE_URL=postgresql://... npm run test:pg
 * TEST_DATABASE_URL berilmasa testlar o'tkazib yuboriladi (skip) — bu "o'tdi" degani emas.
 * DIQQAT: test bazadagi ma'lumotlarni tozalaydi. Hech qachon production bazaga ulamang.
 */
const TEST_DB = process.env.TEST_DATABASE_URL;
const describeIfPg = TEST_DB ? describe : describe.skip;

if (TEST_DB) process.env.DATABASE_URL = TEST_DB;
process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

describeIfPg('P1 — haqiqiy PostgreSQL bilan parallel so\'rovlar', () => {
  let request, app, pool, categoryId;
  let client, provider, provider2;
  let lastSms = null;

  const register = async (fullName, phone) => {
    const res = await request(app).post('/api/auth/register').send({ fullName, phone, password: 'Parol1234' });
    expect(res.status).toBe(201);
    return res.body;
  };
  const auth = (t) => ({ Authorization: `Bearer ${t}` });
  const createListing = async () => {
    const res = await request(app).post('/api/listings').set(auth(client.accessToken))
      .send({ categoryId, title: 'Kran almashtirish kerak', description: 'Eski kran ishlamayapti butunlay' });
    expect(res.status).toBe(201);
    return res.body.listing.id;
  };
  const createOffer = async (listingId, who, price = 100000) => {
    const res = await request(app).post(`/api/listings/${listingId}/offers`).set(auth(who.accessToken)).send({ price });
    expect(res.status).toBe(201);
    return res.body.offer.id;
  };

  beforeAll(async () => {
    jest.spyOn(console, 'log').mockImplementation((msg) => {
      const m = /\[SMS -> [^\]]+\]: .*?(\d{5})/.exec(String(msg));
      if (m) lastSms = m[1];
    });
    jest.spyOn(console, 'error').mockImplementation(() => {});
    request = require('supertest');
    app = require('../../src/app');
    ({ pool } = require('../../src/config/db'));

    await pool.query(`TRUNCATE users, otp_codes, refresh_tokens, listings, offers, orders, chats, messages,
      notifications, payments, reviews, provider_profiles, provider_categories RESTART IDENTITY CASCADE`);
    categoryId = (await pool.query('SELECT id FROM categories WHERE is_active = TRUE ORDER BY id LIMIT 1')).rows[0].id;

    client = await register('Mijoz PG', '+998973330001');
    provider = await register('Usta PG', '+998973330002');
    provider2 = await register('Usta2 PG', '+998973330003');
    for (const p of [provider, provider2]) {
      const r = await request(app).post('/api/users/me/become-provider').set(auth(p.accessToken)).send({ categoryIds: [categoryId] });
      expect(r.status).toBe(200);
    }
  });

  afterAll(async () => {
    jest.restoreAllMocks();
    await pool.end();
  });

  test('bir e\'londagi ikki taklif parallel qabul qilinsa faqat bittasi o\'tadi', async () => {
    const listingId = await createListing();
    const o1 = await createOffer(listingId, provider);
    const o2 = await createOffer(listingId, provider2);
    const results = await Promise.all([o1, o2].map((id) =>
      request(app).patch(`/api/offers/${id}`).set(auth(client.accessToken)).send({ status: 'accepted' })));
    expect(results.map((r) => r.status).sort()).toEqual([200, 400]);
    const orders = await pool.query('SELECT COUNT(*)::int AS c FROM orders WHERE listing_id = $1', [listingId]);
    expect(orders.rows[0].c).toBe(1);
  });

  test('e\'lon tahriri va taklif qabul qilish parallel kelsa holat buzilmaydi (10 marta)', async () => {
    for (let i = 0; i < 10; i++) {
      const listingId = await createListing();
      const offerId = await createOffer(listingId, provider);
      await Promise.all([
        request(app).patch(`/api/offers/${offerId}`).set(auth(client.accessToken)).send({ status: 'accepted' }),
        request(app).patch(`/api/listings/${listingId}`).set(auth(client.accessToken)).send({ status: 'open', title: `Yangilangan sarlavha ${i}` }),
      ]);
      const row = (await pool.query(
        `SELECT l.status, (SELECT COUNT(*)::int FROM orders o WHERE o.listing_id = l.id AND o.status IN ('confirmed','in_progress')) AS active
         FROM listings l WHERE l.id = $1`, [listingId])).rows[0];
      if (row.active > 0) expect(row.status).toBe('in_progress');
      else expect(['open', 'cancelled']).toContain(row.status);
    }
  });

  test('buyurtmasi bor e\'lon API orqali ham, to\'g\'ridan-to\'g\'ri SQL orqali ham o\'chirilmaydi', async () => {
    const listingId = await createListing();
    const offerId = await createOffer(listingId, provider);
    const acc = await request(app).patch(`/api/offers/${offerId}`).set(auth(client.accessToken)).send({ status: 'accepted' });
    expect(acc.status).toBe(200);

    const del = await request(app).delete(`/api/listings/${listingId}`).set(auth(client.accessToken));
    expect(del.status).toBe(409);
    await expect(pool.query('DELETE FROM listings WHERE id = $1', [listingId])).rejects.toMatchObject({ code: '23503' });
    const orders = await pool.query('SELECT COUNT(*)::int AS c FROM orders WHERE listing_id = $1', [listingId]);
    expect(orders.rows[0].c).toBe(1);
  });

  test('bir xil OTP kod bilan ikki parallel parol tiklashdan faqat bittasi o\'tadi', async () => {
    const send = await request(app).post('/api/auth/forgot-password/send-code').send({ phone: '+998973330003' });
    expect(send.status).toBe(200);
    const code = lastSms;
    const results = await Promise.all(['YangiParol1', 'BoshqaParol2'].map((newPassword) =>
      request(app).post('/api/auth/forgot-password/reset').send({ phone: '+998973330003', code, newPassword })));
    expect(results.map((r) => r.status).sort()).toEqual([200, 400]);
    const otp = await pool.query(`SELECT verified FROM otp_codes WHERE phone = '+998973330003'`);
    expect(otp.rows.map((r) => r.verified)).toEqual([true]);
  });

  test('bir refresh token parallel ishlatilsa faqat bitta yangi juftlik chiqadi', async () => {
    const results = await Promise.all([1, 2].map(() =>
      request(app).post('/api/auth/refresh').send({ refreshToken: provider.refreshToken })));
    const ok = results.filter((r) => r.status === 200);
    expect(ok.length).toBe(1);
    expect(results.filter((r) => r.status === 401).length).toBe(1);
    const active = await pool.query(
      'SELECT COUNT(*)::int AS c FROM refresh_tokens WHERE user_id = $1 AND revoked = FALSE', [provider.user.id]);
    // replay aniqlangan bo'lsa hammasi yopiladi (0), aks holda faqat yangi bitta qoladi (1)
    expect(active.rows[0].c).toBeLessThanOrEqual(1);
  });
});
