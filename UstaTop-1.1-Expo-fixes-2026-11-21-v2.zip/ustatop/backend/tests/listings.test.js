process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const request = require('supertest');
const app = require('../src/app');
const dbSingleton = require('./testUtils/dbSingleton');

// Test uchun kategoriya to'g'ridan-to'g'ri "bazaga" qo'yiladi
// (real hayotda bu migrations/002_seed.sql orqali amalga oshadi)
const CATEGORY_ID = 1;
dbSingleton.state.categories.push({ id: CATEGORY_ID, name_uz: 'Santexnik', is_active: true, sort_order: 1 });
dbSingleton.state.categories.push({ id: 2, name_uz: 'Elektrik', is_active: true, sort_order: 2 });

let clientToken;
let providerToken;
let providerId;

beforeAll(async () => {
  const clientRes = await request(app).post('/api/auth/register').send({
    fullName: 'Mijoz Aliyev',
    phone: '+998911112233',
    password: 'Parol1234',
  });
  clientToken = clientRes.body.accessToken;

  const providerRes = await request(app).post('/api/auth/register').send({
    fullName: 'Usta Rustamov',
    phone: '+998922223344',
    password: 'Parol1234',
  });
  providerToken = providerRes.body.accessToken;
  providerId = providerRes.body.user.id;

  // Diqqat: ro'yxatdan o'tgan foydalanuvchi default 'client' rolida bo'ladi.
  // Usta sifatida ishlashi uchun rolini to'g'ridan-to'g'ri "bazada" yangilaymiz
  // (haqiqiy oqimda buning uchun alohida "usta bo'lish" endpoint'i bo'ladi - keyingi bosqichda).
  const providerUser = dbSingleton.state.users.find((u) => u.id === providerId);
  providerUser.role = 'both';
});

describe('GET /api/categories', () => {
  test('faol kategoriyalar ro\'yxatini qaytaradi', async () => {
    const res = await request(app).get('/api/categories');
    expect(res.status).toBe(200);
    expect(res.body.categories.length).toBe(2);
    expect(res.body.categories[0].name_uz).toBe('Santexnik');
  });
});

describe('POST /api/listings — e\'lon yaratish', () => {
  test('login qilmasdan e\'lon yaratib bo\'lmaydi (401)', async () => {
    const res = await request(app).post('/api/listings').send({
      categoryId: CATEGORY_ID,
      title: 'Kranni tamirlash kerak',
      description: 'Oshxonadagi kran suv oqizyapti',
    });
    expect(res.status).toBe(401);
  });

  test('mijoz to\'g\'ri ma\'lumotlar bilan e\'lon yaratadi', async () => {
    const res = await request(app)
      .post('/api/listings')
      .set('Authorization', `Bearer ${clientToken}`)
      .send({
        categoryId: CATEGORY_ID,
        title: 'Kranni tamirlash kerak',
        description: 'Oshxonadagi kran suv oqizyapti, tezroq kerak',
        priceType: 'negotiable',
        city: 'Toshkent',
      });
    expect(res.status).toBe(201);
    expect(res.body.listing.title).toBe('Kranni tamirlash kerak');
    expect(res.body.listing.status).toBe('open');
    global.__listingId = res.body.listing.id;
  });

  test('mavjud bo\'lmagan kategoriya bilan xato qaytaradi', async () => {
    const res = await request(app)
      .post('/api/listings')
      .set('Authorization', `Bearer ${clientToken}`)
      .send({
        categoryId: 999,
        title: 'Test elon sarlavhasi',
        description: 'Test tavsif kamida on belgidan',
      });
    expect(res.status).toBe(400);
  });

  test('juda qisqa sarlavha rad etiladi (validatsiya)', async () => {
    const res = await request(app)
      .post('/api/listings')
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ categoryId: CATEGORY_ID, title: 'Qisq', description: 'Yetarlicha uzun tavsif matni' });
    expect(res.status).toBe(400);
  });
});

describe('PATCH /api/listings/:id — e’lonni tahrirlash', () => {
  test('egasi sarlavha, manzil va xarita koordinatalarini saqlay oladi', async () => {
    const res = await request(app)
      .patch(`/api/listings/${global.__listingId}`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({
        title: 'Kran va quvurni ta’mirlash kerak',
        address: 'Toshkent, Chilonzor',
        city: 'Toshkent',
        latitude: 41.285,
        longitude: 69.203,
      });
    expect(res.status).toBe(200);
    expect(res.body.listing.latitude).toBe(41.285);
    expect(res.body.listing.longitude).toBe(69.203);
    expect(res.body.listing.address).toBe('Toshkent, Chilonzor');
  });

  test('boshqa foydalanuvchi e’lonni tahrirlay olmaydi', async () => {
    const res = await request(app)
      .patch(`/api/listings/${global.__listingId}`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ title: 'Boshqa sarlavha' });
    expect(res.status).toBe(403);
  });
});

describe('GET /api/listings — qidiruv va filtrlash', () => {
  test('ochiq e\'lonlar ro\'yxatini qaytaradi', async () => {
    const res = await request(app).get('/api/listings');
    expect(res.status).toBe(200);
    expect(res.body.listings.length).toBeGreaterThanOrEqual(1);
    expect(res.body.pagination.total).toBeGreaterThanOrEqual(1);
  });

  test('kategoriya bo\'yicha filtrlaydi', async () => {
    const res = await request(app).get('/api/listings').query({ categoryId: 2 });
    expect(res.status).toBe(200);
    expect(res.body.listings.length).toBe(0); // Elektrik kategoriyasida hali e'lon yo'q
  });

  test('kalit so\'z bo\'yicha qidiradi', async () => {
    const res = await request(app).get('/api/listings').query({ search: 'kran' });
    expect(res.status).toBe(200);
    expect(res.body.listings.length).toBeGreaterThanOrEqual(1);
  });
});

describe('GET /api/listings/:id', () => {
  test('e\'lonni ko\'rish soni oshadi', async () => {
    const res1 = await request(app).get(`/api/listings/${global.__listingId}`);
    expect(res1.status).toBe(200);
    const viewsBefore = res1.body.listing.viewsCount;

    const res2 = await request(app).get(`/api/listings/${global.__listingId}`);
    expect(res2.body.listing.viewsCount).toBe(viewsBefore + 1);
  });

  test('mavjud bo\'lmagan e\'lon uchun 404', async () => {
    const res = await request(app).get('/api/listings/00000000-0000-0000-0000-000000000000');
    expect(res.status).toBe(404);
  });
});

describe('Takliflar (offers) oqimi', () => {
  test('usta e\'longa taklif yubora oladi', async () => {
    const res = await request(app)
      .post(`/api/listings/${global.__listingId}/offers`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ price: 150000, message: 'Bugun kelib bera olaman' });
    expect(res.status).toBe(201);
    expect(res.body.offer.status).toBe('pending');
    expect(res.body.chatId).toBeDefined();
    global.__offerId = res.body.offer.id;
    global.__chatId = res.body.chatId;

    const clientChats = await request(app)
      .get('/api/chats')
      .set('Authorization', `Bearer ${clientToken}`);
    expect(clientChats.status).toBe(200);
    expect(clientChats.body.chats.some((chat) => chat.id === global.__chatId)).toBe(true);
  });

  test('mijoz o\'z e\'loniga taklif bera olmaydi', async () => {
    const res = await request(app)
      .post(`/api/listings/${global.__listingId}/offers`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ price: 100000 });
    expect(res.status).toBe(400);
  });

  test('faqat e\'lon egasi takliflar ro\'yxatini ko\'ra oladi', async () => {
    const forbidden = await request(app)
      .get(`/api/listings/${global.__listingId}/offers`)
      .set('Authorization', `Bearer ${providerToken}`);
    expect(forbidden.status).toBe(403);

    const allowed = await request(app)
      .get(`/api/listings/${global.__listingId}/offers`)
      .set('Authorization', `Bearer ${clientToken}`);
    expect(allowed.status).toBe(200);
    expect(allowed.body.offers.length).toBe(1);
    expect(allowed.body.offers[0].chatId).toBe(global.__chatId);
  });

  test('mijoz taklifni qabul qilganda buyurtma yaratiladi va e\'lon holati o\'zgaradi', async () => {
    const res = await request(app)
      .patch(`/api/offers/${global.__offerId}`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ status: 'accepted' });
    expect(res.status).toBe(200);
    expect(res.body.order.status).toBe('confirmed');
    expect(res.body.chatId).toBeDefined();

    const listingRes = await request(app).get(`/api/listings/${global.__listingId}`);
    expect(listingRes.body.listing.status).toBe('in_progress');
  });

  test('qabul qilingan taklifga qayta javob berib bo\'lmaydi', async () => {
    const res = await request(app)
      .patch(`/api/offers/${global.__offerId}`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ status: 'rejected' });
    expect(res.status).toBe(400);
  });

  test('usta o\'z takliflari ro\'yxatini ko\'ra oladi', async () => {
    const res = await request(app).get('/api/offers/mine').set('Authorization', `Bearer ${providerToken}`);
    expect(res.status).toBe(200);
    expect(res.body.offers.length).toBe(1);
    expect(res.body.offers[0].status).toBe('accepted');
  });
});
