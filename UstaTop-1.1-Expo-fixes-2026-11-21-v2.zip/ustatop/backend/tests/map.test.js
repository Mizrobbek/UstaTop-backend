process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const request = require('supertest');
const app = require('../src/app');
const dbSingleton = require('./testUtils/dbSingleton');

dbSingleton.state.categories.push({ id: 1, name_uz: 'Santexnik', icon: 'plumbing', is_active: true, sort_order: 1 });

let token;

const baseListing = {
  categoryId: 1,
  title: 'Kran tamirlash kerak',
  description: 'Oshxonadagi kran suv oqizyapti',
};

beforeAll(async () => {
  const res = await request(app)
    .post('/api/auth/register')
    .send({ fullName: 'Xarita Mijoz', phone: '+998961112233', password: 'Parol1234' });
  token = res.body.accessToken;
});

const create = (body) => request(app).post('/api/listings').set('Authorization', `Bearer ${token}`).send(body);

describe('E\'lon koordinatalari — O\'zbekiston chegarasi', () => {
  test('Toshkent koordinatalari bilan e\'lon yaratiladi', async () => {
    const res = await create({ ...baseListing, latitude: 41.3111, longitude: 69.2797 });
    expect(res.status).toBe(201);
    expect(res.body.listing.latitude).toBe(41.3111);
  });

  test('Moskva koordinatalari rad etiladi (400)', async () => {
    const res = await create({ ...baseListing, latitude: 55.7558, longitude: 37.6173 });
    expect(res.status).toBe(400);
    expect(JSON.stringify(res.body.details)).toMatch(/O'zbekiston hududida/);
  });

  test('Almaty koordinatalari rad etiladi (400)', async () => {
    const res = await create({ ...baseListing, latitude: 43.2389, longitude: 76.8897 });
    expect(res.status).toBe(400);
  });

  test('faqat kenglik berilsa (uzunliksiz) rad etiladi (400)', async () => {
    const res = await create({ ...baseListing, latitude: 41.3 });
    expect(res.status).toBe(400);
    expect(JSON.stringify(res.body.details)).toMatch(/birga berilishi/);
  });

  test('koordinatasiz e\'lon ham yaratiladi', async () => {
    const res = await create(baseListing);
    expect(res.status).toBe(201);
  });

  test('ikkala koordinata null bo\'lsa ham qabul qilinadi', async () => {
    const res = await create({ ...baseListing, latitude: null, longitude: null });
    expect(res.status).toBe(201);
  });
});

describe('GET /api/listings/map', () => {
  const tashkentBox = { minLat: 41.0, maxLat: 41.6, minLng: 69.0, maxLng: 69.6 };

  test('hudud parametrlarisiz so\'rov rad etiladi (400)', async () => {
    const res = await request(app).get('/api/listings/map');
    expect(res.status).toBe(400);
  });

  test('maxLat <= minLat bo\'lsa rad etiladi (400)', async () => {
    const res = await request(app).get('/api/listings/map').query({ ...tashkentBox, maxLat: 40.0 });
    expect(res.status).toBe(400);
  });

  test('userLat bilan userLng birga berilishi shart (400)', async () => {
    const res = await request(app).get('/api/listings/map').query({ ...tashkentBox, userLat: 41.3 });
    expect(res.status).toBe(400);
  });

  test('"/map" e\'lon ID sifatida talqin qilinmaydi (404 emas, 200)', async () => {
    const res = await request(app).get('/api/listings/map').query(tashkentBox);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.listings)).toBe(true);
  });

  test('faqat koordinatali e\'lonlar qaytadi, koordinatasizlari yo\'q', async () => {
    const res = await request(app).get('/api/listings/map').query(tashkentBox);
    expect(res.body.listings.length).toBe(1);
    expect(res.body.total).toBe(1);
    expect(res.body.truncated).toBe(false);
    expect(res.body.listings[0].categoryName).toBe('Santexnik');
  });

  test('userLat/userLng bilan masofa (km) qaytadi', async () => {
    const res = await request(app)
      .get('/api/listings/map')
      .query({ ...tashkentBox, userLat: 41.3111, userLng: 69.2797 });
    expect(res.body.listings[0].distanceKm).toBeLessThan(0.1);
  });

  test('boshqa hududda e\'lon yo\'q — bo\'sh ro\'yxat', async () => {
    const res = await request(app)
      .get('/api/listings/map')
      .query({ minLat: 39.0, maxLat: 39.5, minLng: 66.0, maxLng: 67.0 });
    expect(res.status).toBe(200);
    expect(res.body.listings).toEqual([]);
  });

  test('limit qiymati 300 dan oshsa rad etiladi (400)', async () => {
    const res = await request(app).get('/api/listings/map').query({ ...tashkentBox, limit: 1000 });
    expect(res.status).toBe(400);
  });
});
