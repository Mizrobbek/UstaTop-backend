const test = require('node:test');
const assert = require('node:assert/strict');
const { allowedMimeTypes, classifyMimeType } = require('../src/middleware/mediaTypes');

test('chat media allowlist accepts images, video, audio and common documents', () => {
  for (const mime of [
    'image/jpeg', 'image/png', 'video/mp4', 'audio/mpeg', 'audio/mp4',
    'application/pdf', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'text/plain', 'text/csv',
  ]) assert.equal(allowedMimeTypes.has(mime), true, `${mime} should be allowed`);
});

test('chat media allowlist rejects executables, archives and HTML', () => {
  for (const mime of ['application/x-msdownload', 'application/x-executable', 'application/zip', 'text/html']) {
    assert.equal(allowedMimeTypes.has(mime), false, `${mime} should be rejected`);
  }
});

test('media type classification keeps audio and documents distinct', () => {
  assert.equal(classifyMimeType('image/jpeg'), 'image');
  assert.equal(classifyMimeType('video/quicktime'), 'video');
  assert.equal(classifyMimeType('audio/mpeg'), 'audio');
  assert.equal(classifyMimeType('application/pdf'), 'file');
});
