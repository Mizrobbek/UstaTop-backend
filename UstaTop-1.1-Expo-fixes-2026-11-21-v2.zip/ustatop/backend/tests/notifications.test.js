process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const request = require('supertest');
const app = require('../src/app');
const dbSingleton = require('./testUtils/dbSingleton');

dbSingleton.state.categories.push({ id: 1, name_uz: 'Santexnik', is_active: true, sort_order: 1 });

let token;
const originalFetch = global.fetch;

beforeAll(async () => {
  const res = await request(app).post('/api/auth/register').send({ fullName: 'Bildirishnoma Test', phone: '+998981112233', password: 'Parol1234' });
  token = res.body.accessToken;
  // Tashqi Expo Push API'ga haqiqiy so'rov ketmasligi uchun
  global.fetch = async () => ({ json: async () => ({ data: [{ status: 'ok' }] }) });
});

afterAll(() => {
  global.fetch = originalFetch;
});

describe('POST /api/users/me/push-token', () => {
  test('login qilmasdan token saqlab bo\'lmaydi (401)', async () => {
    const res = await request(app).post('/api/users/me/push-token').send({ pushToken: 'ExponentPushToken[abc]' });
    expect(res.status).toBe(401);
  });

  test('noto\'g\'ri formatdagi token rad etiladi (400)', async () => {
    const res = await request(app).post('/api/users/me/push-token').set('Authorization', `Bearer ${token}`).send({ pushToken: 'random-string' });
    expect(res.status).toBe(400);
  });

  test('to\'g\'ri Expo token formati saqlanadi', async () => {
    const res = await request(app)
      .post('/api/users/me/push-token')
      .set('Authorization', `Bearer ${token}`)
      .send({ pushToken: 'ExponentPushToken[xxxxxxxxxxxxxxxxxxxxxx]' });
    expect(res.status).toBe(200);
  });

  test('null yuborib tokenni o\'chirish mumkin', async () => {
    const res = await request(app).post('/api/users/me/push-token').set('Authorization', `Bearer ${token}`).send({ pushToken: null });
    expect(res.status).toBe(200);
  });
});

describe('GET /api/notifications', () => {
  test('boshida bo\'sh ro\'yxat qaytaradi', async () => {
    const res = await request(app).get('/api/notifications').set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.notifications).toEqual([]);
    expect(res.body.unreadCount).toBe(0);
  });

  test('yangi e\'longa taklif kelganda bildirishnoma paydo bo\'ladi', async () => {
    const provider = await request(app).post('/api/auth/register').send({ fullName: 'Bildirishnoma Usta', phone: '+998982223344', password: 'Parol1234' });
    const listing = await request(app)
      .post('/api/listings')
      .set('Authorization', `Bearer ${token}`)
      .send({ categoryId: 1, title: 'Test e\'lon sarlavhasi', description: 'Test tavsif matni yetarlicha uzun' });
    await request(app)
      .post(`/api/listings/${listing.body.listing.id}/offers`)
      .set('Authorization', `Bearer ${provider.body.accessToken}`)
      .send({ price: 50000 });

    const res = await request(app).get('/api/notifications').set('Authorization', `Bearer ${token}`);
    expect(res.body.notifications.length).toBeGreaterThanOrEqual(1);
    expect(res.body.notifications[0].type).toBe('new_offer');
    expect(res.body.unreadCount).toBeGreaterThanOrEqual(1);
  });
});

describe('PATCH /api/notifications/:id/read va /read-all', () => {
  test('mavjud bo\'lmagan bildirishnoma uchun 404', async () => {
    const res = await request(app).patch('/api/notifications/00000000-0000-0000-0000-000000000000/read').set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(404);
  });

  test('read-all barcha bildirishnomalarni o\'qilgan deb belgilaydi', async () => {
    const before = await request(app).get('/api/notifications').set('Authorization', `Bearer ${token}`);
    if (before.body.notifications.length === 0) return;

    const res = await request(app).patch('/api/notifications/read-all').set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);

    const after = await request(app).get('/api/notifications').set('Authorization', `Bearer ${token}`);
    expect(after.body.unreadCount).toBe(0);
  });
});
