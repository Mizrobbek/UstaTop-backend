process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const request = require('supertest');
const app = require('../src/app');
const dbSingleton = require('./testUtils/dbSingleton');

const CATEGORY_ID = 1;
dbSingleton.state.categories.push({ id: CATEGORY_ID, name_uz: 'Santexnik', is_active: true, sort_order: 1 });

let clientToken, providerToken, providerId;
let listingId, offerId, orderId;

beforeAll(async () => {
  const client = await request(app)
    .post('/api/auth/register')
    .send({ fullName: 'Mijoz Orders', phone: '+998941112233', password: 'Parol1234' });
  clientToken = client.body.accessToken;

  const provider = await request(app)
    .post('/api/auth/register')
    .send({ fullName: 'Usta Orders', phone: '+998942223344', password: 'Parol1234' });
  providerToken = provider.body.accessToken;
  providerId = provider.body.user.id;
});

describe('POST /api/users/me/become-provider', () => {
  test('mavjud bo\'lmagan kategoriya bilan xato beradi', async () => {
    const res = await request(app)
      .post('/api/users/me/become-provider')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ categoryIds: [999] });
    expect(res.status).toBe(400);
  });

  test('to\'g\'ri ma\'lumotlar bilan foydalanuvchi usta bo\'ladi', async () => {
    const res = await request(app)
      .post('/api/users/me/become-provider')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ bio: 'Tajribali santexnik', experienceYears: 5, categoryIds: [CATEGORY_ID] });
    expect(res.status).toBe(200);

    const me = await request(app).get('/api/users/me').set('Authorization', `Bearer ${providerToken}`);
    expect(me.body.user.role).toBe('both');
    expect(me.body.user.providerProfile.experienceYears).toBe(5);
  });

  test('ikkinchi marta usta bo\'lishga urinish rad etiladi', async () => {
    const res = await request(app)
      .post('/api/users/me/become-provider')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ categoryIds: [CATEGORY_ID] });
    expect(res.status).toBe(400);
  });
});

describe('GET /api/providers/:id', () => {
  test('ustaning ommaviy profilini qaytaradi', async () => {
    const res = await request(app).get(`/api/providers/${providerId}`);
    expect(res.status).toBe(200);
    expect(res.body.provider.fullName).toBe('Usta Orders');
    expect(res.body.provider.experienceYears).toBe(5);
    expect(res.body.provider.categories.length).toBe(1);
  });
});

describe('Buyurtma yaratish (offer accept orqali)', () => {
  test('to\'liq zanjir: e\'lon -> taklif -> qabul -> buyurtma', async () => {
    const listingRes = await request(app)
      .post('/api/listings')
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ categoryId: CATEGORY_ID, title: 'Kran almashtirish kerak', description: 'Eski kran ishlamayapti butunlay' });
    listingId = listingRes.body.listing.id;

    const offerRes = await request(app)
      .post(`/api/listings/${listingId}/offers`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ price: 100000 });
    offerId = offerRes.body.offer.id;

    const acceptRes = await request(app)
      .patch(`/api/offers/${offerId}`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ status: 'accepted' });
    orderId = acceptRes.body.order.id;
    expect(acceptRes.status).toBe(200);
  });
});

describe('GET /api/orders', () => {
  test('mijoz o\'z buyurtmalarini ko\'radi', async () => {
    const res = await request(app).get('/api/orders').set('Authorization', `Bearer ${clientToken}`);
    expect(res.status).toBe(200);
    expect(res.body.orders.length).toBe(1);
    expect(res.body.orders[0].status).toBe('confirmed');
  });

  test('?role=provider bilan filtrlash ishlaydi', async () => {
    const res = await request(app).get('/api/orders?role=provider').set('Authorization', `Bearer ${providerToken}`);
    expect(res.status).toBe(200);
    expect(res.body.orders.length).toBe(1);
  });
});

describe('PATCH /api/orders/:id/status', () => {
  test('mijoz ishni "in_progress" deb belgilay olmaydi (faqat usta)', async () => {
    const res = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ status: 'in_progress' });
    expect(res.status).toBe(403);
  });

  test('usta ishni boshlangan deb belgilaydi', async () => {
    const res = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ status: 'in_progress' });
    expect(res.status).toBe(200);
  });

  test('usta ishni yakunlangan deb belgilaydi', async () => {
    const res = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ status: 'completed' });
    expect(res.status).toBe(200);

    const listingRes = await request(app).get(`/api/listings/${listingId}`);
    expect(listingRes.body.listing.status).toBe('completed');
  });

  test('yakunlangan buyurtmani qayta bekor qilib bo\'lmaydi', async () => {
    const res = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ status: 'cancelled', cancelReason: 'Fikrim o\'zgardi' });
    expect(res.status).toBe(400);
  });

  test('yakunlangan buyurtmani ikkinchi marta yakunlash profil hisoblagichini oshirmaydi', async () => {
    const before = dbSingleton.state.provider_profiles.find((p) => p.user_id === providerId).completed_orders_count;
    const res = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ status: 'completed' });
    const after = dbSingleton.state.provider_profiles.find((p) => p.user_id === providerId).completed_orders_count;
    expect(res.status).toBe(400);
    expect(after).toBe(before);
  });
});

describe('Bekor qilingan e’lonni qayta ishlatish', () => {
  test('bekor qilingan buyurtma tarixda qoladi va shu e’lon uchun yangi buyurtma ochiladi', async () => {
    const provider2 = await request(app)
      .post('/api/auth/register')
      .send({ fullName: 'Ikkinchi Usta', phone: '+998943334455', password: 'Parol1234' });
    const provider2Token = provider2.body.accessToken;
    const provider2Id = provider2.body.user.id;

    const becomeProvider = await request(app)
      .post('/api/users/me/become-provider')
      .set('Authorization', `Bearer ${provider2Token}`)
      .send({ bio: 'Elektrik', experienceYears: 3, categoryIds: [CATEGORY_ID] });
    expect(becomeProvider.status).toBe(200);

    const listing = await request(app)
      .post('/api/listings')
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ categoryId: CATEGORY_ID, title: 'Yangi rozetka kerak', description: 'Rozetka almashtirish kerak' });
    const reusableListingId = listing.body.listing.id;

    const firstOffer = await request(app)
      .post(`/api/listings/${reusableListingId}/offers`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ price: 80000 });
    const firstAccepted = await request(app)
      .patch(`/api/offers/${firstOffer.body.offer.id}`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ status: 'accepted' });
    expect(firstAccepted.status).toBe(200);

    const cancelled = await request(app)
      .patch(`/api/orders/${firstAccepted.body.order.id}/status`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ status: 'cancelled', cancelReason: 'Vaqt mos kelmadi' });
    expect(cancelled.status).toBe(200);

    const secondOffer = await request(app)
      .post(`/api/listings/${reusableListingId}/offers`)
      .set('Authorization', `Bearer ${provider2Token}`)
      .send({ price: 90000 });
    expect(secondOffer.status).toBe(201);

    const secondAccepted = await request(app)
      .patch(`/api/offers/${secondOffer.body.offer.id}`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ status: 'accepted' });
    expect(secondAccepted.status).toBe(200);
    expect(secondAccepted.body.order.id).not.toBe(firstAccepted.body.order.id);

    const history = dbSingleton.state.orders.filter((o) => o.listing_id === reusableListingId);
    expect(history).toHaveLength(2);
    expect(history.map((o) => o.status).sort()).toEqual(['cancelled', 'confirmed']);
    expect(dbSingleton.state.users.some((u) => u.id === provider2Id)).toBe(true);
  });
});

describe('PATCH /api/orders/:id/payment-confirmation', () => {
  test('usta mijoz tasdig‘isiz to‘lovni olganini tasdiqlay olmaydi', async () => {
    const res = await request(app)
      .patch(`/api/orders/${orderId}/payment-confirmation`)
      .set('Authorization', `Bearer ${providerToken}`);
    expect(res.status).toBe(400);
  });

  test('mijoz va usta tasdiqlagandan keyingina isPaid=true bo‘ladi', async () => {
    const clientConfirm = await request(app)
      .patch(`/api/orders/${orderId}/payment-confirmation`)
      .set('Authorization', `Bearer ${clientToken}`);
    expect(clientConfirm.status).toBe(200);
    expect(clientConfirm.body.isPaid).toBe(false);
    expect(clientConfirm.body.clientPaymentConfirmedAt).toBeTruthy();

    const providerConfirm = await request(app)
      .patch(`/api/orders/${orderId}/payment-confirmation`)
      .set('Authorization', `Bearer ${providerToken}`);
    expect(providerConfirm.status).toBe(200);
    expect(providerConfirm.body.isPaid).toBe(true);
    expect(providerConfirm.body.providerPaymentConfirmedAt).toBeTruthy();
  });

  test('to‘lovni qayta tasdiqlash holatni buzmaydi', async () => {
    const res = await request(app)
      .patch(`/api/orders/${orderId}/payment-confirmation`)
      .set('Authorization', `Bearer ${providerToken}`);
    expect(res.status).toBe(200);
    expect(res.body.isPaid).toBe(true);
  });
});

describe('POST /api/orders/:id/review', () => {
  test('usta o\'ziga sharh yoza olmaydi (faqat mijoz)', async () => {
    const res = await request(app)
      .post(`/api/orders/${orderId}/review`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ rating: 5 });
    expect(res.status).toBe(403);
  });

  test('mijoz sharh qoldiradi va usta reytingi yangilanadi', async () => {
    const res = await request(app)
      .post(`/api/orders/${orderId}/review`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ rating: 5, comment: 'Zo\'r ishladi!' });
    expect(res.status).toBe(201);

    const providerRes = await request(app).get(`/api/providers/${providerId}`);
    expect(providerRes.body.provider.ratingAvg).toBe(5);
    expect(providerRes.body.provider.ratingCount).toBe(1);
    expect(providerRes.body.provider.completedOrdersCount).toBe(1);
  });

  test('bir buyurtmaga ikkinchi marta sharh qoldirib bo\'lmaydi', async () => {
    const res = await request(app)
      .post(`/api/orders/${orderId}/review`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ rating: 3 });
    expect(res.status).toBe(409);
  });

  test('ustaning barcha sharhlari ro\'yxatda ko\'rinadi', async () => {
    const res = await request(app).get(`/api/providers/${providerId}/reviews`);
    expect(res.status).toBe(200);
    expect(res.body.reviews.length).toBe(1);
    expect(res.body.reviews[0].reviewerName).toBe('Mijoz Orders');
  });
});
