const { validateProductionEnv, assertSafeEnv } = require('../src/config/env');

const SAFE = {
  NODE_ENV: 'production',
  JWT_ACCESS_SECRET: 'a'.repeat(40),
  JWT_REFRESH_SECRET: 'b'.repeat(40),
  DATABASE_URL: 'postgresql://app:Str0ng-Unique-Pass@db.internal:5432/ustatop',
  SMS_PROVIDER: 'eskiz',
  CORS_ORIGINS: 'https://admin.ustatop.uz',
};

describe('Production konfiguratsiya tekshiruvi', () => {
  test('xavfsiz sozlamalar o\'tadi', () => {
    expect(validateProductionEnv(SAFE)).toEqual([]);
    expect(() => assertSafeEnv(SAFE)).not.toThrow();
  });
  test('docker-compose namunasidagi JWT kalitlari rad etiladi', () => {
    const p = validateProductionEnv({ ...SAFE, JWT_ACCESS_SECRET: 'change_this_access_secret', JWT_REFRESH_SECRET: 'change_this_refresh_secret' });
    expect(p.length).toBe(2);
  });
  test('qisqa yoki bir xil kalitlar rad etiladi', () => {
    expect(validateProductionEnv({ ...SAFE, JWT_ACCESS_SECRET: 'short' }).length).toBe(1);
    expect(validateProductionEnv({ ...SAFE, JWT_REFRESH_SECRET: SAFE.JWT_ACCESS_SECRET }).length).toBe(1);
  });
  test('standart baza paroli (usta_pass) rad etiladi', () => {
    expect(validateProductionEnv({ ...SAFE, DATABASE_URL: 'postgresql://usta_user:usta_pass@db:5432/usta_topamiz' }).length).toBe(1);
  });
  test('SMS_PROVIDER=console yoki o\'rnatilmagan holat rad etiladi', () => {
    expect(validateProductionEnv({ ...SAFE, SMS_PROVIDER: 'console' }).length).toBe(1);
    const { SMS_PROVIDER, ...noSms } = SAFE; // eslint-disable-line no-unused-vars
    expect(validateProductionEnv(noSms).length).toBe(1);
  });
  test('CORS "*" rad etiladi', () => {
    expect(validateProductionEnv({ ...SAFE, CORS_ORIGINS: '*' }).length).toBe(1);
  });
  test('development muhitida tekshiruv to\'smaydi', () => {
    expect(validateProductionEnv({ NODE_ENV: 'development' })).toEqual([]);
  });
  test('xato xabarida maxfiy qiymat chiqmaydi', () => {
    const secret = 'change_this_access_secret';
    try { assertSafeEnv({ ...SAFE, JWT_ACCESS_SECRET: secret }); } catch (e) { expect(e.message).not.toContain(secret); }
    expect.assertions(1);
  });
});
