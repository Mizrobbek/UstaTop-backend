/**
 * 1-bosqich (P1) regressiya testlari — soxta baza bilan.
 * Parallel (race) holatlar haqiqiy PostgreSQL'da: tests/integration/p1.pg.test.js
 */
process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const jwt = require('jsonwebtoken');
const request = require('supertest');
const app = require('../src/app');
const db = require('./testUtils/dbSingleton');
const { generateCode } = require('../src/utils/otp');

const CATEGORY_ID = 1;
db.state.categories.push({ id: CATEGORY_ID, name_uz: 'Santexnik', is_active: true, sort_order: 1 });

const PASSWORD = 'Parol1234';
const RESET_PHONE = '+998971110001';
let client, provider, resetUser;
let lastSms = null;
let missingBody = null;
let consoleSpy;

async function register(fullName, phone) {
  const res = await request(app).post('/api/auth/register').send({ fullName, phone, password: PASSWORD });
  expect(res.status).toBe(201);
  return res.body;
}
const me = (token) => request(app).get('/api/users/me').set('Authorization', `Bearer ${token}`);

beforeAll(async () => {
  consoleSpy = jest.spyOn(console, 'log').mockImplementation((msg) => {
    const m = /\[SMS -> [^\]]+\]: .*?(\d{5})/.exec(String(msg));
    if (m) lastSms = m[1];
  });
  jest.spyOn(console, 'error').mockImplementation(() => {});
  client = await register('Mijoz P1', '+998971110002');
  provider = await register('Usta P1', '+998971110003');
  resetUser = await register('Tiklash P1', RESET_PHONE);
  await request(app)
    .post('/api/users/me/become-provider')
    .set('Authorization', `Bearer ${provider.accessToken}`)
    .send({ categoryIds: [CATEGORY_ID] });
});
afterAll(() => jest.restoreAllMocks());

describe('Parol tiklash — hisob mavjudligini oshkor qilmaslik', () => {
  test('mavjud va mavjud bo\'lmagan raqamga javob bir xil', async () => {
    const existing = await request(app).post('/api/auth/forgot-password/send-code').send({ phone: RESET_PHONE });
    const missing = await request(app).post('/api/auth/forgot-password/send-code').send({ phone: '+998979999999' });
    expect(existing.status).toBe(200);
    expect(missing.status).toBe(existing.status);
    expect(missing.body).toEqual(existing.body);
    missingBody = missing.body;
    expect(lastSms).toHaveLength(5);
  });

  test('qayta yuborish cheklovi (cooldown) ham mavjud raqamni oshkor qilmaydi', async () => {
    const again = await request(app).post('/api/auth/forgot-password/send-code').send({ phone: RESET_PHONE });
    expect(again.status).toBe(200);
    expect(again.body).toEqual(missingBody);
  });
});

describe('OTP — kriptografik generatsiya va bir martalik ishlatish', () => {
  test('kod Math.random ishlatmaydi va har doim 5 xonali', () => {
    const spy = jest.spyOn(Math, 'random');
    for (let i = 0; i < 2000; i++) expect(generateCode()).toMatch(/^\d{5}$/);
    expect(spy).not.toHaveBeenCalled();
    spy.mockRestore();
  });

  test('bitta kod ikkinchi marta ishlamaydi va parol tiklash eski access tokenni bekor qiladi', async () => {
    expect((await me(resetUser.accessToken)).status).toBe(200);
    const code = lastSms;
    const first = await request(app).post('/api/auth/forgot-password/reset').send({ phone: RESET_PHONE, code, newPassword: 'YangiParol1' });
    expect(first.status).toBe(200);
    const second = await request(app).post('/api/auth/forgot-password/reset').send({ phone: RESET_PHONE, code, newPassword: 'BoshqaParol2' });
    expect(second.status).toBe(400);

    const old = await me(resetUser.accessToken);
    expect(old.status).toBe(401);
    expect(old.body.code).toBe('TOKEN_REVOKED');
    const oldRefresh = await request(app).post('/api/auth/refresh').send({ refreshToken: resetUser.refreshToken });
    expect(oldRefresh.status).toBe(401);
  });
});

describe('Refresh token rotatsiyasi va replay himoyasi', () => {
  test('ishlatilgan refresh token qayta kelsa barcha sessiyalar yopiladi', async () => {
    const login = await request(app).post('/api/auth/login').send({ identifier: '+998971110002', password: PASSWORD });
    expect(login.status).toBe(200);
    const rt1 = login.body.refreshToken;

    const r1 = await request(app).post('/api/auth/refresh').send({ refreshToken: rt1 });
    expect(r1.status).toBe(200);
    expect(r1.body.refreshToken).not.toBe(rt1);

    const replay = await request(app).post('/api/auth/refresh').send({ refreshToken: rt1 });
    expect(replay.status).toBe(401);
    expect(replay.body.code).toBe('REFRESH_REUSED');

    expect((await request(app).post('/api/auth/refresh').send({ refreshToken: r1.body.refreshToken })).status).toBe(401);
    expect((await me(r1.body.accessToken)).status).toBe(401);
    expect((await me(client.accessToken)).status).toBe(401); // boshqa qurilma sessiyasi ham yopildi
  });

  test('bir soniyada chiqarilgan ikki token bir xil emas (jti)', async () => {
    const { signRefreshToken } = require('../src/utils/jwt');
    expect(signRefreshToken({ sub: 'a' })).not.toBe(signRefreshToken({ sub: 'a' }));
  });
});

describe('Logout — access token darhol bekor bo\'ladi', () => {
  test('logoutdan keyin shu sessiyaning access tokeni 401', async () => {
    const login = await request(app).post('/api/auth/login').send({ identifier: '+998971110002', password: PASSWORD });
    expect(login.status).toBe(200);
    client = login.body;
    expect((await me(client.accessToken)).status).toBe(200);
    await request(app).post('/api/auth/logout').send({ refreshToken: client.refreshToken });
    const after = await me(client.accessToken);
    expect(after.status).toBe(401);
    expect(after.body.code).toBe('TOKEN_REVOKED');
  });

  test('sid/ver maydonisiz eski tokenlar (migratsiyadan oldingi) muddati tugaguncha ishlaydi', async () => {
    const legacy = jwt.sign({ sub: provider.user.id, role: 'client' }, process.env.JWT_ACCESS_SECRET, { expiresIn: '15m' });
    expect((await me(legacy)).status).toBe(200);
  });
});

describe('E\'lon o\'chirish — buyurtma tarixini himoya qilish', () => {
  test('buyurtmasi bor e\'lon o\'chirilmaydi, buyurtmasiz e\'lon o\'chiriladi', async () => {
    const login = await request(app).post('/api/auth/login').send({ identifier: '+998971110002', password: PASSWORD });
    const token = login.body.accessToken;
    const mk = () => request(app).post('/api/listings').set('Authorization', `Bearer ${token}`)
      .send({ categoryId: CATEGORY_ID, title: 'Kran almashtirish kerak', description: 'Eski kran ishlamayapti butunlay' });

    const withOrder = (await mk()).body.listing.id;
    const offer = await request(app).post(`/api/listings/${withOrder}/offers`)
      .set('Authorization', `Bearer ${provider.accessToken}`).send({ price: 100000 });
    expect(offer.status).toBe(201);
    const accept = await request(app).patch(`/api/offers/${offer.body.offer.id}`)
      .set('Authorization', `Bearer ${token}`).send({ status: 'accepted' });
    expect(accept.status).toBe(200);

    const del = await request(app).delete(`/api/listings/${withOrder}`).set('Authorization', `Bearer ${token}`);
    expect(del.status).toBe(409);
    expect(del.body.code).toBe('LISTING_HAS_ORDERS');
    expect(db.state.listings.find((l) => l.id === withOrder)).toBeDefined();
    expect(db.state.orders.filter((o) => o.listing_id === withOrder)).toHaveLength(1);

    const plain = (await mk()).body.listing.id;
    const del2 = await request(app).delete(`/api/listings/${plain}`).set('Authorization', `Bearer ${token}`);
    expect(del2.status).toBe(200);
  });
});
