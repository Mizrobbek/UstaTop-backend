/**
 * 1-bosqich (P1): chat socket xavfsizligi — haqiqiy socket.io server va mijoz bilan.
 */
process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const http = require('http');
const request = require('supertest');
const { io: ioClient } = require('socket.io-client');
const app = require('../src/app');
const db = require('./testUtils/dbSingleton');
const { initSocket } = require('../src/config/socket');

let server, url, io;
let alice, bob, mallory;
const CHAT_ID = '11111111-1111-4111-8111-111111111111';
const sockets = [];

async function register(fullName, phone) {
  const res = await request(app).post('/api/auth/register').send({ fullName, phone, password: 'Parol1234' });
  return res.body;
}
function connect(token) {
  return new Promise((resolve, reject) => {
    const s = ioClient(url, { auth: { token }, transports: ['websocket'], reconnection: false, forceNew: true });
    sockets.push(s);
    s.on('connect', () => resolve(s));
    s.on('connect_error', (e) => reject(e));
  });
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

beforeAll(async () => {
  alice = await register('Alice', '+998972220001');
  bob = await register('Bob', '+998972220002');
  mallory = await register('Mallory', '+998972220003');
  db.state.chats.push({ id: CHAT_ID, listing_id: null, client_id: alice.user.id, provider_id: bob.user.id, created_at: new Date() });

  server = http.createServer(app);
  io = initSocket(server, ['*']);
  app.set('io', io);
  await new Promise((r) => server.listen(0, r));
  url = `http://localhost:${server.address().port}`;
});

afterAll(async () => {
  sockets.forEach((s) => s.close());
  io.close();
  await new Promise((r) => server.close(r));
});

test('ishtirokchi bo\'lmagan foydalanuvchi "yozmoqda" yubora olmaydi va xonaga qo\'shilmaydi', async () => {
  const a = await connect(alice.accessToken);
  const m = await connect(mallory.accessToken);
  a.emit('chat:join', { chatId: CHAT_ID });
  const typingSeen = jest.fn();
  a.on('chat:typing', typingSeen);

  const errors = [];
  m.on('error', (e) => errors.push(e.message));
  m.emit('chat:join', { chatId: CHAT_ID });
  m.emit('chat:typing', { chatId: CHAT_ID });
  await wait(300);

  expect(typingSeen).not.toHaveBeenCalled();
  expect(errors.length).toBe(2);
  const roomMembers = await io.in(`chat:${CHAT_ID}`).fetchSockets();
  expect(roomMembers.map((s) => s.user.id)).toEqual([alice.user.id]);
});

test('ishtirokchi "yozmoqda" yuborsa ikkinchi ishtirokchi oladi', async () => {
  const a = await connect(alice.accessToken);
  const b = await connect(bob.accessToken);
  a.emit('chat:join', { chatId: CHAT_ID });
  b.emit('chat:join', { chatId: CHAT_ID });
  await wait(200);
  const got = new Promise((r) => a.on('chat:typing', r));
  b.emit('chat:typing', { chatId: CHAT_ID });
  await expect(got).resolves.toEqual({ chatId: CHAT_ID, userId: bob.user.id });
});

test('logout qilinganda shu sessiyaning socket ulanishi server tomonidan uziladi', async () => {
  const b = await connect(bob.accessToken);
  const disconnected = new Promise((r) => b.on('disconnect', r));
  await request(app).post('/api/auth/logout').send({ refreshToken: bob.refreshToken });
  await expect(disconnected).resolves.toBeDefined();
  // eski token bilan qayta ulanib bo'lmaydi
  await expect(connect(bob.accessToken)).rejects.toThrow();
});

test('bloklangan foydalanuvchi socketga ulana olmaydi', async () => {
  db.state.users.find((u) => u.id === mallory.user.id).is_active = false;
  await expect(connect(mallory.accessToken)).rejects.toThrow(/bloklangan/);
});
