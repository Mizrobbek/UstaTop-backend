process.env.JWT_ACCESS_SECRET = 'test_access_secret';
process.env.JWT_REFRESH_SECRET = 'test_refresh_secret';
process.env.SMS_PROVIDER = 'console';
process.env.NODE_ENV = 'test';
process.env.PAYME_MERCHANT_KEY = 'test_merchant_key';

jest.mock('../src/config/db', () => require('./testUtils/dbSingleton'));

const request = require('supertest');
const app = require('../src/app');
const dbSingleton = require('./testUtils/dbSingleton');

dbSingleton.state.categories.push({ id: 1, name_uz: 'Santexnik', is_active: true, sort_order: 1 });

let clientToken, providerToken, orderId;
const AUTH_HEADER = `Basic ${Buffer.from('Paycom:test_merchant_key').toString('base64')}`;

beforeAll(async () => {
  const client = await request(app).post('/api/auth/register').send({
    fullName: 'To‘lov Mijoz', phone: '+998971112233', password: 'Parol1234',
  });
  clientToken = client.body.accessToken;

  const provider = await request(app).post('/api/auth/register').send({
    fullName: 'To‘lov Usta', phone: '+998972223344', password: 'Parol1234',
  });
  providerToken = provider.body.accessToken;
  await request(app)
    .post('/api/users/me/become-provider')
    .set('Authorization', `Bearer ${providerToken}`)
    .send({ bio: 'Usta', experienceYears: 2, categoryIds: [1] });

  const listing = await request(app)
    .post('/api/listings')
    .set('Authorization', `Bearer ${clientToken}`)
    .send({ categoryId: 1, title: 'Kran tamiri kerak', description: 'Oshxonadagi kran suv oqizyapti' });

  const offer = await request(app)
    .post(`/api/listings/${listing.body.listing.id}/offers`)
    .set('Authorization', `Bearer ${providerToken}`)
    .send({ price: 150000 });

  const accepted = await request(app)
    .patch(`/api/offers/${offer.body.offer.id}`)
    .set('Authorization', `Bearer ${clientToken}`)
    .send({ status: 'accepted' });

  orderId = accepted.body.order.id;
});

describe('POST /api/orders/:id/pay — platforma xizmat haqini qabul qilmaydi', () => {
  test('login qilmasdan to‘lov endpointiga kira olmaydi (401)', async () => {
    const res = await request(app).post(`/api/orders/${orderId}/pay`).send({ provider: 'payme' });
    expect(res.status).toBe(401);
  });

  test('mijoz uchun Payme/Click checkout yaratish o‘chirilgan (410)', async () => {
    const res = await request(app)
      .post(`/api/orders/${orderId}/pay`)
      .set('Authorization', `Bearer ${clientToken}`)
      .send({ provider: 'payme' });
    expect(res.status).toBe(410);
    expect(res.body.error).toContain('bevosita ustaga');
  });

  test('usta ham platforma checkoutini boshlay olmaydi (410)', async () => {
    const res = await request(app)
      .post(`/api/orders/${orderId}/pay`)
      .set('Authorization', `Bearer ${providerToken}`)
      .send({ provider: 'click' });
    expect(res.status).toBe(410);
  });

  test('GET payment-status boshida isPaid=false qaytaradi', async () => {
    const res = await request(app)
      .get(`/api/orders/${orderId}/payment-status`)
      .set('Authorization', `Bearer ${clientToken}`);
    expect(res.status).toBe(200);
    expect(res.body.isPaid).toBe(false);
  });
});

describe('Payme/Click webhooklari — xizmat haqi platformadan o‘tmaydi', () => {
  test('Payme webhooki xizmat to‘lovini rad etadi', async () => {
    const res = await request(app)
      .post('/api/payments/payme')
      .set('Authorization', AUTH_HEADER)
      .send({
        method: 'CheckPerformTransaction',
        params: { amount: 15000000, account: { order_id: orderId } },
        id: 1,
      });
    expect(res.status).toBe(200);
    expect(res.body.error).toBeDefined();
  });

  test('Click Prepare va Complete xizmat to‘lovini rad etadi', async () => {
    const prepare = await request(app).post('/api/payments/click/prepare').send({
      click_trans_id: '1', service_id: 's1', merchant_trans_id: orderId,
      amount: '150000.00', action: 0, sign_time: 't', sign_string: 'unused',
    });
    expect(prepare.body.error).not.toBe(0);

    const complete = await request(app).post('/api/payments/click/complete').send({
      click_trans_id: '1', service_id: 's1', merchant_trans_id: orderId,
      amount: '150000.00', action: 1, sign_time: 't', sign_string: 'unused',
    });
    expect(complete.body.error).not.toBe(0);
  });
});
