const fs = require('fs');
const os = require('os');
const path = require('path');

describe('local media storage', () => {
  let storageRoot;
  let sourceDir;
  let storage;

  beforeEach(() => {
    storageRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'ustatop-storage-'));
    sourceDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ustatop-upload-source-'));
    process.env.MEDIA_STORAGE_DIR = storageRoot;
    jest.resetModules();
    storage = require('../src/storage');
  });

  afterEach(() => {
    fs.rmSync(storageRoot, { recursive: true, force: true });
    fs.rmSync(sourceDir, { recursive: true, force: true });
    delete process.env.MEDIA_STORAGE_DIR;
  });

  test('copies uploads into the persistent storage volume without cross-device rename', async () => {
    const source = path.join(sourceDir, 'profile.jpeg');
    fs.writeFileSync(source, Buffer.from('ustatop-media-test'));

    const saved = await storage.put({
      path: source,
      originalname: 'profile.jpeg',
      mimetype: 'image/jpeg',
      size: 19,
    });

    expect(fs.readFileSync(path.join(storageRoot, saved.key), 'utf8')).toBe('ustatop-media-test');
    expect(fs.existsSync(source)).toBe(false);
    expect(saved.url).toBe(`/uploads/${saved.key}`);
  });

  test('removes stored media by key', async () => {
    const source = path.join(sourceDir, 'work.png');
    fs.writeFileSync(source, Buffer.from('portfolio-media'));
    const saved = await storage.put({
      path: source,
      originalname: 'work.png',
      mimetype: 'image/png',
      size: 15,
    });

    await storage.remove(saved.key);
    expect(fs.existsSync(path.join(storageRoot, saved.key))).toBe(false);
  });
});
