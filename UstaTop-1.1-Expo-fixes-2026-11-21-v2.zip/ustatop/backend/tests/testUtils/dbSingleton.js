/**
 * Bitta test fayli ichida bir nechta modul (masalan config/db.js) bir xil
 * "soxta baza" holatiga (state) murojaat qilishi kerak bo'lganda ishlatiladi.
 * jest.mock() factory funksiyasi shu faylni chaqirsa, test o'zi ham xuddi shu
 * instansiyani import qilib, kategoriyalarni oldindan "urug'lantirishi" (seed)
 * mumkin bo'ladi.
 */
const { createFakeDb } = require('./fakeDb');

const db = createFakeDb();

module.exports = {
  query: db.query,
  getClient: db.getClient,
  pool: { query: db.query, end: async () => {} },
  state: db.state,
};
