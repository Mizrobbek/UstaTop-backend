/**
 * Testlar uchun engil "soxta baza" (in-memory fake DB).
 *
 * Nima uchun kerak: bu loyihaning testlari haqiqiy PostgreSQL'ga ulanmasdan ham
 * ishlashi kerak (CI/CD tez ishlashi, va bazasiz muhitlarda ham tekshirish uchun).
 * Shu bilan birga, controller'lardagi HAQIQIY SQL matnlari bilan ishlaydi —
 * ya'ni bu controller mantiqini chinakam sinaydi, faqat tarmoq/diskni chetlab o'tadi.
 *
 * Real integratsion test uchun README.md'da ko'rsatilganidek, docker-compose orqali
 * chinakam PostgreSQL'ga ulab ham shu testlarni ishga tushirish mumkin
 * (buning uchun jest.mock qatorini olib tashlab, config/db.js ni real bazaga ulash kifoya).
 */
const { v4: uuidv4 } = require('uuid');

function normalize(sql) {
  return sql.replace(/\s+/g, ' ').trim();
}

function createFakeDb() {
  const state = {
    users: [],
    otp_codes: [],
    refresh_tokens: [],
    categories: [],
    listings: [],
    listing_media: [],
    offers: [],
    orders: [],
    chats: [],
    messages: [],
    notifications: [],
    provider_profiles: [],
    provider_categories: [],
    reviews: [],
    payments: [],
  };

  function findUser(id) {
    return state.users.find((u) => u.id === id);
  }

  /**
   * listings-bog'liq SELECT so'rovlaridagi WHERE shartini SQL matnining o'zidan
   * (dinamik ravishda) o'qib, mos parametr bilan filtrlaydi. Bu controller'dagi
   * haqiqiy dinamik SQL qurilishini (listing.controller.js) qayta yozmasdan,
   * uni to'g'ridan-to'g'ri sinash imkonini beradi.
   */
  function splitTopLevelAnd(clause) {
    const parts = [];
    let depth = 0;
    let current = '';
    for (let i = 0; i < clause.length; i++) {
      const ch = clause[i];
      if (ch === '(') depth++;
      if (ch === ')') depth--;
      if (depth === 0 && clause.slice(i, i + 5) === ' AND ') {
        parts.push(current.trim());
        current = '';
        i += 4;
        continue;
      }
      current += ch;
    }
    if (current.trim()) parts.push(current.trim());
    return parts;
  }

  function extractWhereClause(sql) {
    const fromIdx = sql.indexOf('FROM listings l');
    if (fromIdx === -1) return null;
    const tail = sql.slice(fromIdx);
    const match = /WHERE (.+?)(?: ORDER BY| LIMIT|$)/.exec(tail);
    return match ? match[1] : null;
  }

  function listingMatchesConditions(listing, whereClause, params) {
    if (!whereClause) return true;
    const clauses = splitTopLevelAnd(whereClause);
    for (const clause of clauses) {
      let m;
      if ((m = /l\.category_id = \$(\d+)/.exec(clause))) {
        if (listing.category_id !== params[Number(m[1]) - 1]) return false;
      } else if ((m = /l\.city ILIKE \$(\d+)/.exec(clause))) {
        if (listing.city.toLowerCase() !== String(params[Number(m[1]) - 1]).toLowerCase()) return false;
      } else if ((m = /l\.status = \$(\d+)/.exec(clause))) {
        if (listing.status !== params[Number(m[1]) - 1]) return false;
      } else if ((m = /l\.title ILIKE \$(\d+) OR l\.description ILIKE \$\d+/.exec(clause))) {
        const needle = String(params[Number(m[1]) - 1]).replace(/%/g, '').toLowerCase();
        const haystack = `${listing.title} ${listing.description}`.toLowerCase();
        if (!haystack.includes(needle)) return false;
      } else if ((m = /l\.latitude BETWEEN \$(\d+) AND \$(\d+)/.exec(clause))) {
        const [min, max] = [params[Number(m[1]) - 1], params[Number(m[2]) - 1]];
        if (listing.latitude == null || listing.latitude < min || listing.latitude > max) return false;
      } else if ((m = /l\.longitude BETWEEN \$(\d+) AND \$(\d+)/.exec(clause))) {
        const [min, max] = [params[Number(m[1]) - 1], params[Number(m[2]) - 1]];
        if (listing.longitude == null || listing.longitude < min || listing.longitude > max) return false;
      }
    }
    return true;
  }

  function buildListingRow(listing) {
    const category = state.categories.find((c) => c.id === listing.category_id);
    const owner = findUser(listing.client_id);
    const media = state.listing_media.filter((m) => m.listing_id === listing.id).sort((a, b) => a.sort_order - b.sort_order).map((m) => m.url);
    const offersCount = state.offers.filter((o) => o.listing_id === listing.id).length;
    return {
      ...listing,
      category_name: category?.name_uz,
      client_name: owner?.full_name,
      client_avatar: owner?.avatar_url,
      offers_count: String(offersCount),
      media,
    };
  }


  async function query(text, params = []) {
    const sql = normalize(text);

    // ---- USERS ----
    if (sql === 'SELECT id FROM users WHERE phone = $1') {
      const row = state.users.find((u) => u.phone === params[0]);
      return { rows: row ? [{ id: row.id }] : [] };
    }
    if (sql === 'SELECT id FROM users WHERE email = $1') {
      const row = state.users.find((u) => u.email === params[0]);
      return { rows: row ? [{ id: row.id }] : [] };
    }
    if (sql.startsWith('INSERT INTO users (phone, email, password_hash, full_name)')) {
      const [phone, email, password_hash, full_name] = params;
      const row = {
        id: uuidv4(),
        phone,
        email: email || null,
        password_hash,
        full_name,
        role: 'client',
        avatar_url: null,
        city: 'Toshkent',
        is_active: true,
        is_phone_verified: true,
        is_email_verified: false,
        created_at: new Date(),
      };
      state.users.push(row);
      return { rows: [row] };
    }
    if (sql.startsWith('INSERT INTO users (phone, email, password_hash, full_name, is_phone_verified)')) {
      const [phone, email, password_hash, full_name] = params;
      const row = { id: uuidv4(), phone, email: email || null, password_hash, full_name, role: 'client', avatar_url: null, city: 'Toshkent', is_active: true, is_phone_verified: true, is_email_verified: false, created_at: new Date() };
      state.users.push(row);
      return { rows: [row] };
    }
    if (sql === 'SELECT * FROM users WHERE email = $1') {
      const row = state.users.find((u) => u.email === params[0]);
      return { rows: row ? [row] : [] };
    }
    if (sql === 'SELECT * FROM users WHERE phone = $1') {
      const row = state.users.find((u) => u.phone === params[0]);
      return { rows: row ? [row] : [] };
    }
    if (sql === 'SELECT id, phone, full_name, role, is_active FROM users WHERE id = $1') {
      const row = state.users.find((u) => u.id === params[0]);
      return {
        rows: row ? [{ id: row.id, phone: row.phone, full_name: row.full_name, role: row.role, is_active: row.is_active }] : [],
      };
    }
    if (sql === 'SELECT id, phone, full_name, role FROM users WHERE id = $1') {
      const row = state.users.find((u) => u.id === params[0]);
      return { rows: row ? [{ id: row.id, phone: row.phone, full_name: row.full_name, role: row.role }] : [] };
    }
    if (sql === 'SELECT * FROM users WHERE id = $1') {
      const row = state.users.find((u) => u.id === params[0]);
      return { rows: row ? [row] : [] };
    }
    if (sql === 'UPDATE users SET password_hash = $1 WHERE id = $2') {
      const row = state.users.find((u) => u.id === params[1]);
      if (row) row.password_hash = params[0];
      return { rows: [] };
    }

    // ---- P1: sessiya / token versiyasi ----
    if (sql.startsWith('SELECT u.id, u.phone, u.full_name, u.role, u.is_active, u.is_phone_verified, u.token_version, s.revoked AS session_revoked FROM users u LEFT JOIN refresh_tokens s')) {
      const u = state.users.find((x) => x.id === params[0]);
      if (!u) return { rows: [] };
      const sess = params[1] ? state.refresh_tokens.find((t) => t.id === params[1] && t.user_id === u.id) : null;
      return {
        rows: [{
          id: u.id, phone: u.phone, full_name: u.full_name, role: u.role, is_active: u.is_active,
          is_phone_verified: u.is_phone_verified !== false, token_version: u.token_version ?? 0, session_revoked: sess ? sess.revoked : null,
        }],
      };
    }
    if (sql === 'UPDATE users SET token_version = token_version + 1 WHERE id = $1') {
      const u = state.users.find((x) => x.id === params[0]);
      if (u) u.token_version = (u.token_version ?? 0) + 1;
      return { rows: [] };
    }
    if (sql.startsWith('INSERT INTO refresh_tokens (id, user_id, token_hash, device_info, expires_at)')) {
      const [id, user_id, token_hash, device_info, expires_at] = params;
      state.refresh_tokens.push({ id, user_id, token_hash, device_info, expires_at, revoked: false, rotated_at: null, created_at: new Date() });
      return { rows: [] };
    }
    if (sql === 'UPDATE refresh_tokens SET revoked = TRUE, rotated_at = now() WHERE user_id = $1 AND token_hash = $2 AND revoked = FALSE AND expires_at > now() RETURNING id') {
      const t = state.refresh_tokens.find((x) => x.user_id === params[0] && x.token_hash === params[1] && !x.revoked && x.expires_at > new Date());
      if (!t) return { rows: [] };
      t.revoked = true; t.rotated_at = new Date();
      return { rows: [{ id: t.id }] };
    }
    if (sql === 'SELECT id FROM refresh_tokens WHERE user_id = $1 AND token_hash = $2 AND rotated_at IS NOT NULL') {
      const t = state.refresh_tokens.find((x) => x.user_id === params[0] && x.token_hash === params[1] && x.rotated_at);
      return { rows: t ? [{ id: t.id }] : [] };
    }
    if (sql === 'UPDATE refresh_tokens SET revoked = TRUE WHERE token_hash = $1 RETURNING id, user_id') {
      const rows = state.refresh_tokens.filter((t) => t.token_hash === params[0]);
      rows.forEach((t) => (t.revoked = true));
      return { rows: rows.map((t) => ({ id: t.id, user_id: t.user_id })) };
    }
    if (sql === 'SELECT id, code_hash, attempts, expires_at, verified FROM otp_codes WHERE phone = $1 AND purpose = $2 ORDER BY created_at DESC LIMIT 1 FOR UPDATE') {
      const rows = state.otp_codes
        .filter((o) => o.phone === params[0] && o.purpose === params[1])
        .sort((a, b) => b.created_at - a.created_at);
      return { rows: rows[0] ? [rows[0]] : [] };
    }
    if (sql === 'UPDATE otp_codes SET verified = TRUE WHERE id = $1 AND verified = FALSE RETURNING id') {
      const row = state.otp_codes.find((o) => o.id === params[0] && !o.verified);
      if (!row) return { rows: [] };
      row.verified = true;
      return { rows: [{ id: row.id }] };
    }
    if (sql === 'SELECT client_id FROM listings WHERE id = $1 FOR UPDATE') {
      const row = state.listings.find((l) => l.id === params[0]);
      return { rows: row ? [{ client_id: row.client_id }] : [] };
    }
    if (sql === 'SELECT COUNT(*)::int AS count FROM orders WHERE listing_id = $1') {
      return { rows: [{ count: state.orders.filter((o) => o.listing_id === params[0]).length }] };
    }

    // ---- OTP CODES ----
    if (sql === 'SELECT created_at FROM otp_codes WHERE phone = $1 AND purpose = $2 ORDER BY created_at DESC LIMIT 1') {
      const rows = state.otp_codes
        .filter((o) => o.phone === params[0] && o.purpose === params[1])
        .sort((a, b) => b.created_at - a.created_at);
      return { rows: rows[0] ? [rows[0]] : [] };
    }
    if (sql.startsWith('INSERT INTO otp_codes (phone, purpose, code_hash, expires_at)')) {
      const [phone, purpose, code_hash, expires_at] = params;
      const row = {
        id: uuidv4(),
        phone,
        purpose,
        code_hash,
        attempts: 0,
        expires_at,
        verified: false,
        created_at: new Date(),
      };
      state.otp_codes.push(row);
      return { rows: [row] };
    }
    if (
      sql ===
      'SELECT id, code_hash, attempts, expires_at, verified FROM otp_codes WHERE phone = $1 AND purpose = $2 ORDER BY created_at DESC LIMIT 1'
    ) {
      const rows = state.otp_codes
        .filter((o) => o.phone === params[0] && o.purpose === params[1])
        .sort((a, b) => b.created_at - a.created_at);
      return { rows: rows[0] ? [rows[0]] : [] };
    }
    if (sql === 'UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1') {
      const row = state.otp_codes.find((o) => o.id === params[0]);
      if (row) row.attempts += 1;
      return { rows: [] };
    }
    if (sql === 'UPDATE otp_codes SET verified = TRUE WHERE id = $1') {
      const row = state.otp_codes.find((o) => o.id === params[0]);
      if (row) row.verified = true;
      return { rows: [] };
    }

    // ---- REFRESH TOKENS ----
    if (sql.startsWith('INSERT INTO refresh_tokens (user_id, token_hash, device_info, expires_at)')) {
      const [user_id, token_hash, device_info, expires_at] = params;
      state.refresh_tokens.push({
        id: uuidv4(),
        user_id,
        token_hash,
        device_info,
        expires_at,
        revoked: false,
        created_at: new Date(),
      });
      return { rows: [] };
    }
    if (
      sql ===
      'SELECT * FROM refresh_tokens WHERE user_id = $1 AND token_hash = $2 AND revoked = FALSE AND expires_at > now()'
    ) {
      const row = state.refresh_tokens.find(
        (t) => t.user_id === params[0] && t.token_hash === params[1] && !t.revoked && t.expires_at > new Date()
      );
      return { rows: row ? [row] : [] };
    }
    if (sql === 'UPDATE refresh_tokens SET revoked = TRUE WHERE id = $1') {
      const row = state.refresh_tokens.find((t) => t.id === params[0]);
      if (row) row.revoked = true;
      return { rows: [] };
    }
    if (sql === 'UPDATE refresh_tokens SET revoked = TRUE WHERE user_id = $1') {
      state.refresh_tokens.filter((t) => t.user_id === params[0]).forEach((t) => (t.revoked = true));
      return { rows: [] };
    }
    if (sql === 'UPDATE refresh_tokens SET revoked = TRUE WHERE token_hash = $1') {
      state.refresh_tokens.filter((t) => t.token_hash === params[0]).forEach((t) => (t.revoked = true));
      return { rows: [] };
    }

    // ---- ORDERS: to'lov bilan bog'liq ----
    if (/^UPDATE orders SET status = '(\w+)' WHERE id = \$1$/.test(sql)) {
      const newStatus = /status = '(\w+)'/.exec(sql)[1];
      const row = state.orders.find((o) => o.id === params[0]);
      if (row) row.status = newStatus;
      return { rows: [] };
    }
    if (sql.startsWith('SELECT * FROM orders WHERE id = $1')) {
      const row = state.orders.find((o) => o.id === params[0]);
      return { rows: row ? [row] : [] };
    }
    if (sql === 'UPDATE orders SET client_payment_confirmed_at = now() WHERE id = $1') {
      const row = state.orders.find((o) => o.id === params[0]);
      if (row && !row.client_payment_confirmed_at) row.client_payment_confirmed_at = new Date();
      return { rows: [] };
    }
    if (sql === `UPDATE orders SET provider_payment_confirmed_at = now(), is_paid = TRUE, paid_at = now() WHERE id = $1`) {
      const row = state.orders.find((o) => o.id === params[0]);
      if (row && row.client_payment_confirmed_at && !row.provider_payment_confirmed_at) {
        row.provider_payment_confirmed_at = new Date();
        row.is_paid = true;
        row.paid_at = new Date();
      }
      return { rows: [] };
    }
    if (sql === "UPDATE orders SET is_paid = TRUE, paid_at = $1 WHERE id = $2") {
      const row = state.orders.find((o) => o.id === params[1]);
      if (row) { row.is_paid = true; row.paid_at = params[0]; }
      return { rows: [] };
    }
    if (sql === "UPDATE orders SET is_paid = TRUE, paid_at = now() WHERE id = $1") {
      const row = state.orders.find((o) => o.id === params[0]);
      if (row) { row.is_paid = true; row.paid_at = new Date(); }
      return { rows: [] };
    }
    if (sql === "UPDATE orders SET is_paid = FALSE, paid_at = NULL WHERE id = $1") {
      const row = state.orders.find((o) => o.id === params[0]);
      if (row) { row.is_paid = false; row.paid_at = null; }
      return { rows: [] };
    }
    if (sql === 'SELECT client_id, provider_id, is_paid, paid_at FROM orders WHERE id = $1') {
      const row = state.orders.find((o) => o.id === params[0]);
      return { rows: row ? [{ client_id: row.client_id, provider_id: row.provider_id, is_paid: !!row.is_paid, paid_at: row.paid_at || null }] : [] };
    }
    if (sql === 'SELECT status FROM orders WHERE id = $1') {
      const row = state.orders.find((o) => o.id === params[0]);
      return { rows: row ? [{ status: row.status }] : [] };
    }

    // ---- PAYMENTS ----
    if (sql === 'SELECT * FROM payments WHERE provider = $1 AND external_id = $2') {
      const row = state.payments.find((p) => p.provider === params[0] && p.external_id === params[1]);
      return { rows: row ? [row] : [] };
    }
    if (sql === "SELECT id FROM payments WHERE order_id = $1 AND status = 'pending'") {
      const row = state.payments.find((p) => p.order_id === params[0] && p.status === 'pending');
      return { rows: row ? [{ id: row.id }] : [] };
    }
    if (sql.startsWith('INSERT INTO payments (order_id, provider, external_id, amount, status, payme_state, create_time)')) {
      // Haqiqiy SQL: VALUES ($1, 'payme', $2, $3, 'pending', $4, $5) - provider/status SQL matnida literal
      const [order_id, external_id, amount, payme_state, create_time] = params;
      const row = {
        id: uuidv4(), order_id, provider: 'payme', external_id, amount: Number(amount), status: 'pending',
        payme_state, payme_reason: null, click_prepare_id: null, create_time, perform_time: null, cancel_time: null,
      };
      state.payments.push(row);
      return { rows: [row] };
    }
    if (sql.startsWith('INSERT INTO payments (order_id, provider, external_id, amount, status, click_prepare_id, create_time)')) {
      // Haqiqiy SQL: VALUES ($1, 'click', $2, $3, 'pending', $4, now()) - provider/status SQL matnida literal
      const [order_id, external_id, amount, click_prepare_id] = params;
      const row = {
        id: uuidv4(), order_id, provider: 'click', external_id, amount: Number(amount), status: 'pending',
        payme_state: null, payme_reason: null, click_prepare_id, create_time: new Date(), perform_time: null, cancel_time: null,
      };
      state.payments.push(row);
      return { rows: [{ id: row.id }] };
    }
    if (sql === "UPDATE payments SET status = 'paid', payme_state = $1, perform_time = $2 WHERE id = $3") {
      const row = state.payments.find((p) => p.id === params[2]);
      if (row) { row.status = 'paid'; row.payme_state = params[0]; row.perform_time = params[1]; }
      return { rows: [] };
    }
    if (sql === "UPDATE payments SET status = 'cancelled', payme_state = $1, payme_reason = $2, cancel_time = $3 WHERE id = $4") {
      const row = state.payments.find((p) => p.id === params[3]);
      if (row) { row.status = 'cancelled'; row.payme_state = params[0]; row.payme_reason = params[1]; row.cancel_time = params[2]; }
      return { rows: [] };
    }
    if (sql === "UPDATE payments SET status = 'paid', perform_time = now() WHERE id = $1") {
      const row = state.payments.find((p) => p.id === params[0]);
      if (row) { row.status = 'paid'; row.perform_time = new Date(); }
      return { rows: [] };
    }
    if (sql === "UPDATE payments SET status = 'cancelled', cancel_time = now() WHERE id = $1") {
      const row = state.payments.find((p) => p.id === params[0]);
      if (row) { row.status = 'cancelled'; row.cancel_time = new Date(); }
      return { rows: [] };
    }
    if (sql.startsWith('SELECT p.*, o.id AS order_id FROM payments p JOIN orders o')) {
      const [from, to] = params;
      const rows = state.payments
        .filter((p) => p.provider === 'payme' && p.create_time >= from && p.create_time <= to)
        .sort((a, b) => a.create_time - b.create_time)
        .map((p) => ({ ...p, order_id: p.order_id }));
      return { rows };
    }

    // ---- XARITA: hudud (bounding box) bo'yicha e'lonlar ----
    // Parametrlar: [minLat, maxLat, minLng, maxLng, categoryId|null, limit, centerLat, centerLng]
    if (
      sql.startsWith('SELECT l.id, l.title, l.price, l.price_type, l.latitude') ||
      sql.startsWith('SELECT COUNT(*) AS in_view FROM listings l')
    ) {
      const [minLat, maxLat, minLng, maxLng, categoryId] = params;
      const inView = state.listings.filter(
        (l) =>
          l.status === 'open' &&
          l.latitude != null &&
          l.longitude != null &&
          l.latitude >= minLat && l.latitude <= maxLat &&
          l.longitude >= minLng && l.longitude <= maxLng &&
          (categoryId == null || l.category_id === categoryId)
      );
      if (sql.startsWith('SELECT COUNT(*)')) return { rows: [{ in_view: String(inView.length) }] };
      const [limit, centerLat, centerLng] = [params[5], params[6], params[7]];
      const sqDist = (l) => (l.latitude - centerLat) ** 2 + (l.longitude - centerLng) ** 2;
      const rows = inView
        .sort((a, b) => sqDist(a) - sqDist(b))
        .slice(0, limit)
        .map((l) => {
          const cat = state.categories.find((c) => c.id === l.category_id);
          return { ...l, category_name: cat?.name_uz, category_icon: cat?.icon };
        });
      return { rows };
    }

    // ---- ADMIN: statistika (GROUP BY) ----
    if (sql === 'SELECT role, COUNT(*) AS count FROM users GROUP BY role') {
      const counts = {};
      state.users.forEach((u) => (counts[u.role] = (counts[u.role] || 0) + 1));
      return { rows: Object.entries(counts).map(([role, count]) => ({ role, count: String(count) })) };
    }
    if (sql === 'SELECT status, COUNT(*) AS count FROM listings GROUP BY status') {
      const counts = {};
      state.listings.forEach((l) => (counts[l.status] = (counts[l.status] || 0) + 1));
      return { rows: Object.entries(counts).map(([status, count]) => ({ status, count: String(count) })) };
    }
    if (sql === 'SELECT status, COUNT(*) AS count FROM orders GROUP BY status') {
      const counts = {};
      state.orders.forEach((o) => (counts[o.status] = (counts[o.status] || 0) + 1));
      return { rows: Object.entries(counts).map(([status, count]) => ({ status, count: String(count) })) };
    }
    if (sql === 'SELECT COUNT(*) AS count FROM reviews') {
      return { rows: [{ count: String(state.reviews.length) }] };
    }
    if (sql === "SELECT COALESCE(SUM(agreed_price), 0) AS total FROM orders WHERE status = 'completed'") {
      const total = state.orders.filter((o) => o.status === 'completed').reduce((sum, o) => sum + Number(o.agreed_price), 0);
      return { rows: [{ total: String(total) }] };
    }

    // ---- ADMIN: foydalanuvchilar ----
    // Parametrlar: [role|null, '%qidiruv%'|null, (limit, offset)]
    if (sql.startsWith('SELECT u.id, u.phone, u.email, u.full_name, u.role') || sql.startsWith('SELECT COUNT(*) AS total FROM users u')) {
      const [roleFilter, searchFilter] = params;
      const needle = searchFilter ? searchFilter.replace(/%/g, '').toLowerCase() : null;
      const matched = state.users
        .filter((u) => !roleFilter || u.role === roleFilter)
        .filter(
          (u) =>
            !needle ||
            [u.full_name, u.phone, u.email].some((v) => v && String(v).toLowerCase().includes(needle))
        )
        .sort((a, b) => b.created_at - a.created_at);
      if (sql.startsWith('SELECT COUNT(*)')) return { rows: [{ total: String(matched.length) }] };
      const [limit, offset] = [params[2], params[3]];
      const rows = matched.slice(offset, offset + limit).map((u) => {
        const pp = state.provider_profiles.find((p) => p.user_id === u.id);
        return { ...u, provider_verified: pp ? pp.is_verified : null };
      });
      return { rows };
    }
    if (sql === 'SELECT id, role FROM users WHERE id = $1') {
      const row = state.users.find((u) => u.id === params[0]);
      return { rows: row ? [{ id: row.id, role: row.role }] : [] };
    }
    if (sql === 'UPDATE users SET is_active = $1 WHERE id = $2') {
      const row = state.users.find((u) => u.id === params[1]);
      if (row) row.is_active = params[0];
      return { rows: [] };
    }
    if (sql === 'UPDATE provider_profiles SET is_verified = $1 WHERE user_id = $2 RETURNING user_id') {
      const row = state.provider_profiles.find((p) => p.user_id === params[1]);
      if (row) row.is_verified = params[0];
      return { rows: row ? [{ user_id: row.user_id }] : [] };
    }

    // ---- ADMIN: e'lonlar moderatsiyasi ----
    // Parametrlar: [status|null, '%qidiruv%'|null, (limit, offset)]
    if (sql.startsWith('SELECT l.id, l.title, l.status, l.city') || sql.startsWith('SELECT COUNT(*) AS total FROM listings l')) {
      const [statusFilter, searchFilter] = params;
      const needle = searchFilter ? searchFilter.replace(/%/g, '').toLowerCase() : null;
      const matched = state.listings
        .filter((l) => !statusFilter || l.status === statusFilter)
        .filter((l) => !needle || l.title.toLowerCase().includes(needle))
        .sort((a, b) => b.created_at - a.created_at);
      if (sql.startsWith('SELECT COUNT(*)')) return { rows: [{ total: String(matched.length) }] };
      const [limit, offset] = [params[2], params[3]];
      const rows = matched.slice(offset, offset + limit).map((l) => ({
        ...l,
        category_name: state.categories.find((c) => c.id === l.category_id)?.name_uz,
        client_name: findUser(l.client_id)?.full_name,
      }));
      return { rows };
    }

    // ---- ADMIN: kategoriyalar ----
    if (sql.startsWith('SELECT id, name_uz, name_ru, icon, sort_order, is_active, parent_id FROM categories')) {
      const rows = [...state.categories]
        .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0) || a.id - b.id)
        .map((c) => ({ is_active: true, name_ru: null, icon: null, sort_order: 0, ...c }));
      return { rows };
    }
    if (sql.startsWith('INSERT INTO categories (name_uz, name_ru, icon, sort_order)')) {
      const [name_uz, name_ru, icon, sort_order] = params;
      const row = {
        id: state.categories.reduce((max, c) => Math.max(max, c.id), 0) + 1,
        name_uz,
        name_ru,
        icon,
        sort_order,
        is_active: true,
        parent_id: null,
      };
      state.categories.push(row);
      return { rows: [row] };
    }
    if (sql.startsWith('UPDATE categories SET') && sql.includes('RETURNING *')) {
      const idMatch = /WHERE id = \$(\d+) RETURNING/.exec(sql);
      const row = state.categories.find((c) => c.id === params[Number(idMatch[1]) - 1]);
      if (row) {
        const setClause = /UPDATE categories SET (.+) WHERE/.exec(sql)[1];
        for (const assign of setClause.split(', ')) {
          const m = /(\w+) = \$(\d+)/.exec(assign);
          if (m) row[m[1]] = params[Number(m[2]) - 1];
        }
      }
      return { rows: row ? [{ is_active: true, name_ru: null, icon: null, sort_order: 0, ...row }] : [] };
    }

    if (sql === 'SELECT 1') return { rows: [{ '?column?': 1 }] };

    // ---- CATEGORIES ----
    if (sql === 'SELECT id FROM categories WHERE id = $1 AND is_active = TRUE') {
      const row = state.categories.find((c) => c.id === params[0] && c.is_active !== false);
      return { rows: row ? [{ id: row.id }] : [] };
    }
    if (sql === 'SELECT name_uz FROM categories WHERE id = $1') {
      const row = state.categories.find((c) => c.id === params[0]);
      return { rows: row ? [{ name_uz: row.name_uz }] : [] };
    }
    if (sql.startsWith('SELECT id, parent_id, name_uz, name_ru, icon, sort_order')) {
      const rows = state.categories
        .filter((c) => c.is_active !== false)
        .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0) || a.id - b.id);
      return { rows };
    }

    // ---- LISTINGS: yaratish/o'chirish/oddiy CRUD ----
    if (sql.startsWith('INSERT INTO listings (client_id, category_id, title, description, price, price_type, address, city, latitude, longitude)')) {
      const [client_id, category_id, title, description, price, price_type, address, city, latitude, longitude] = params;
      const row = {
        id: uuidv4(),
        client_id,
        category_id,
        title,
        description,
        price,
        price_type,
        address,
        city,
        latitude,
        longitude,
        status: 'open',
        views_count: 0,
        created_at: new Date(),
        updated_at: new Date(),
      };
      state.listings.push(row);
      return { rows: [row] };
    }
    if (sql.startsWith("INSERT INTO listing_media (listing_id, url, type, sort_order) VALUES ($1, $2, 'image', $3)")) {
      const [listing_id, url, sort_order] = params;
      state.listing_media.push({ id: uuidv4(), listing_id, url, type: 'image', sort_order });
      return { rows: [] };
    }
    if (sql === 'UPDATE listings SET views_count = views_count + 1 WHERE id = $1') {
      const row = state.listings.find((l) => l.id === params[0]);
      if (row) row.views_count += 1;
      return { rows: [] };
    }
    if (sql.startsWith('SELECT * FROM listings WHERE id = $1')) {
      const row = state.listings.find((l) => l.id === params[0]);
      return { rows: row ? [row] : [] };
    }
    if (sql === 'SELECT client_id FROM listings WHERE id = $1') {
      const row = state.listings.find((l) => l.id === params[0]);
      return { rows: row ? [{ client_id: row.client_id }] : [] };
    }
    if (sql === 'DELETE FROM listings WHERE id = $1') {
      state.listings = state.listings.filter((l) => l.id !== params[0]);
      return { rows: [] };
    }
    if (sql.startsWith('UPDATE listings SET') && sql.includes('RETURNING *')) {
      const idMatch = /WHERE id = \$(\d+)(?: AND client_id = \$(\d+) AND status IN \('open', 'cancelled'\))? RETURNING/.exec(sql);
      let row = state.listings.find((l) => l.id === params[Number(idMatch[1]) - 1]);
      if (row && idMatch[2] && (row.client_id !== params[Number(idMatch[2]) - 1] || !['open', 'cancelled'].includes(row.status))) row = null;
      if (row) {
        const setClause = /UPDATE listings SET (.+) WHERE/.exec(sql)[1];
        for (const assign of setClause.split(', ')) {
          const m = /(\w+) = \$(\d+)/.exec(assign);
          if (m) row[m[1]] = params[Number(m[2]) - 1];
        }
        row.updated_at = new Date();
      }
      return { rows: row ? [row] : [] };
    }
    if (/^UPDATE listings SET status = '(\w+)' WHERE id = \$1$/.test(sql)) {
      const newStatus = /status = '(\w+)'/.exec(sql)[1];
      const row = state.listings.find((l) => l.id === params[0]);
      if (row) row.status = newStatus;
      return { rows: [] };
    }

    // ---- LISTINGS: qidiruv/filtr (dinamik WHERE) ----
    if (sql.startsWith('SELECT l.*, c.name_uz AS category_name, u.full_name AS client_name') && sql.includes('LIMIT')) {
      const whereClause = extractWhereClause(sql);
      const limitMatch = /LIMIT \$(\d+) OFFSET \$(\d+)/.exec(sql);
      const limit = params[Number(limitMatch[1]) - 1];
      const offset = params[Number(limitMatch[2]) - 1];
      const filtered = state.listings
        .filter((l) => listingMatchesConditions(l, whereClause, params))
        .sort((a, b) => b.created_at - a.created_at);
      const page = filtered.slice(offset, offset + limit).map(buildListingRow);
      return { rows: page };
    }
    if (sql.startsWith('SELECT l.*, c.name_uz AS category_name, u.full_name AS client_name') && sql.includes('WHERE l.id = $1')) {
      const row = state.listings.find((l) => l.id === params[0]);
      return { rows: row ? [buildListingRow(row)] : [] };
    }
    if (sql.startsWith('SELECT l.*, c.name_uz AS category_name') && sql.includes('WHERE l.client_id = $1')) {
      const rows = state.listings
        .filter((l) => l.client_id === params[0])
        .sort((a, b) => b.created_at - a.created_at)
        .map(buildListingRow);
      return { rows };
    }
    if (sql.startsWith('SELECT COUNT(*) FROM listings l')) {
      const whereClause = extractWhereClause(sql);
      const count = state.listings.filter((l) => listingMatchesConditions(l, whereClause, params)).length;
      return { rows: [{ count: String(count) }] };
    }

    // ---- OFFERS ----
    if (sql.startsWith('INSERT INTO offers (listing_id, provider_id, price, message)')) {
      const [listing_id, provider_id, price, message] = params;
      const row = { id: uuidv4(), listing_id, provider_id, price, message, status: 'pending', created_at: new Date() };
      state.offers.push(row);
      return { rows: [row] };
    }
    if (sql.startsWith('SELECT o.*, u.full_name AS provider_name')) {
      const rows = state.offers
        .filter((o) => o.listing_id === params[0])
        .sort((a, b) => a.created_at - b.created_at)
        .map((o) => {
          const provider = findUser(o.provider_id);
          const listing = state.listings.find((l) => l.id === o.listing_id);
          const chat = state.chats.find((c) => c.listing_id === o.listing_id && c.client_id === listing?.client_id && c.provider_id === o.provider_id);
          return {
            ...o,
            provider_name: provider?.full_name,
            provider_avatar: provider?.avatar_url,
            provider_rating: 0,
            chat_id: chat?.id,
          };
        });
      return { rows };
    }
    if (sql.startsWith('SELECT o.*, l.title AS listing_title, l.status AS listing_status')) {
      const rows = state.offers
        .filter((o) => o.provider_id === params[0])
        .sort((a, b) => b.created_at - a.created_at)
        .map((o) => {
          const listing = state.listings.find((l) => l.id === o.listing_id);
          return { ...o, listing_title: listing?.title, listing_status: listing?.status };
        });
      return { rows };
    }
    if (sql.startsWith('SELECT o.*, l.client_id, l.title, l.status AS listing_status')) {
      const offer = state.offers.find((o) => o.id === params[0]);
      if (!offer) return { rows: [] };
      const listing = state.listings.find((l) => l.id === offer.listing_id);
      return { rows: [{ ...offer, client_id: listing.client_id, title: listing.title, listing_status: listing.status }] };
    }
    if (sql === 'UPDATE offers SET status = $1 WHERE id = $2') {
      const row = state.offers.find((o) => o.id === params[1]);
      if (row) row.status = params[0];
      return { rows: [] };
    }
    if (sql.startsWith("UPDATE offers SET status = 'rejected' WHERE listing_id = $1 AND id != $2 AND status = 'pending'")) {
      state.offers
        .filter((o) => o.listing_id === params[0] && o.id !== params[1] && o.status === 'pending')
        .forEach((o) => (o.status = 'rejected'));
      return { rows: [] };
    }

    // ---- ORDERS / CHATS / NOTIFICATIONS ----
    if (sql.startsWith('INSERT INTO orders (listing_id, offer_id, client_id, provider_id, agreed_price)')) {
      const [listing_id, offer_id, client_id, provider_id, agreed_price] = params;
      const row = { id: uuidv4(), listing_id, offer_id, client_id, provider_id, agreed_price, status: 'confirmed', is_paid: false, paid_at: null, client_payment_confirmed_at: null, provider_payment_confirmed_at: null, created_at: new Date() };
      state.orders.push(row);
      return { rows: [row] };
    }
    if (sql.startsWith('INSERT INTO chats (listing_id, client_id, provider_id)')) {
      const [listing_id, client_id, provider_id] = params;
      let row = state.chats.find((c) => c.listing_id === listing_id && c.client_id === client_id && c.provider_id === provider_id);
      if (!row) {
        row = { id: uuidv4(), listing_id, client_id, provider_id, created_at: new Date() };
        state.chats.push(row);
      }
      return { rows: [row] };
    }
    if (sql.startsWith('INSERT INTO notifications (user_id, type, title, body, data)')) {
      const [user_id, type, title, body, data] = params;
      const row = {
        id: uuidv4(), user_id, type, title, body,
        data: data ? JSON.parse(data) : null, is_read: false, created_at: new Date(),
      };
      state.notifications.push(row);
      return { rows: [row] };
    }
    if (sql === 'SELECT * FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3') {
      const rows = state.notifications
        .filter((n) => n.user_id === params[0])
        .sort((a, b) => b.created_at - a.created_at)
        .slice(params[2], params[2] + params[1]);
      return { rows };
    }
    if (sql === 'SELECT COUNT(*) AS count FROM notifications WHERE user_id = $1 AND is_read = FALSE') {
      const count = state.notifications.filter((n) => n.user_id === params[0] && !n.is_read).length;
      return { rows: [{ count: String(count) }] };
    }
    if (sql === 'UPDATE notifications SET is_read = TRUE WHERE id = $1 AND user_id = $2 RETURNING id') {
      const row = state.notifications.find((n) => n.id === params[0] && n.user_id === params[1]);
      if (row) row.is_read = true;
      return { rows: row ? [{ id: row.id }] : [] };
    }
    if (sql === 'UPDATE notifications SET is_read = TRUE WHERE user_id = $1 AND is_read = FALSE') {
      state.notifications.filter((n) => n.user_id === params[0] && !n.is_read).forEach((n) => (n.is_read = true));
      return { rows: [] };
    }

    // ---- CHATS ----
    if (sql === 'SELECT * FROM chats WHERE id = $1') {
      const row = state.chats.find((c) => c.id === params[0]);
      return { rows: row ? [row] : [] };
    }
    if (sql === 'SELECT client_id, provider_id FROM chats WHERE id = $1') {
      const row = state.chats.find((c) => c.id === params[0]);
      return { rows: row ? [{ client_id: row.client_id, provider_id: row.provider_id }] : [] };
    }
    if (sql.startsWith('SELECT c.*, l.title AS listing_title')) {
      const userId = params[0];
      const rows = state.chats
        .filter((c) => c.client_id === userId || c.provider_id === userId)
        .map((c) => {
          const listing = state.listings.find((l) => l.id === c.listing_id);
          const clientUser = findUser(c.client_id);
          const providerUser = findUser(c.provider_id);
          const chatMessages = state.messages
            .filter((m) => m.chat_id === c.id)
            .sort((a, b) => b.created_at - a.created_at);
          const lastMsg = chatMessages[0];
          const unreadCount = chatMessages.filter((m) => m.sender_id !== userId && !m.is_read).length;
          return {
            ...c,
            listing_title: listing?.title,
            client_name: clientUser?.full_name,
            client_avatar: clientUser?.avatar_url,
            provider_name: providerUser?.full_name,
            provider_avatar: providerUser?.avatar_url,
            last_message_content: lastMsg?.content,
            last_message_at: lastMsg?.created_at,
            unread_count: String(unreadCount),
          };
        })
        .sort((a, b) => (b.last_message_at || b.created_at) - (a.last_message_at || a.created_at));
      return { rows };
    }

    // ---- MESSAGES ----
    if (sql.startsWith('INSERT INTO messages (chat_id, sender_id, content, media_url)')) {
      const [chat_id, sender_id, content, media_url] = params;
      const row = { id: uuidv4(), chat_id, sender_id, content, media_url, is_read: false, created_at: new Date() };
      state.messages.push(row);
      return { rows: [row] };
    }
    if (sql.startsWith('SELECT * FROM messages WHERE chat_id = $1')) {
      let rows = state.messages.filter((m) => m.chat_id === params[0]);
      if (sql.includes('created_at < $2')) {
        const beforeDate = new Date(params[1]);
        rows = rows.filter((m) => m.created_at < beforeDate);
      }
      rows = rows.sort((a, b) => b.created_at - a.created_at);
      const limit = params[params.length - 1];
      return { rows: rows.slice(0, limit) };
    }
    if (sql === 'UPDATE messages SET is_read = TRUE WHERE chat_id = $1 AND sender_id != $2 AND is_read = FALSE') {
      state.messages
        .filter((m) => m.chat_id === params[0] && m.sender_id !== params[1] && !m.is_read)
        .forEach((m) => (m.is_read = true));
      return { rows: [] };
    }

    if (sql === 'SELECT push_token FROM users WHERE id = $1') {
      const row = state.users.find((u) => u.id === params[0]);
      return { rows: row ? [{ push_token: row.push_token || null }] : [] };
    }
    if (sql === 'UPDATE users SET push_token = $1 WHERE id = $2') {
      const row = state.users.find((u) => u.id === params[1]);
      if (row) row.push_token = params[0];
      return { rows: [] };
    }
    if (sql === 'UPDATE users SET push_token = NULL WHERE id = $1 AND push_token = $2') {
      const row = state.users.find((u) => u.id === params[0] && u.push_token === params[1]);
      if (row) row.push_token = null;
      return { rows: [] };
    }

    // ---- USERS: dinamik UPDATE (updateMe) ----
    if (sql.startsWith('UPDATE users SET') && sql.includes('RETURNING *')) {
      const idMatch = /WHERE id = \$(\d+) RETURNING/.exec(sql);
      const row = state.users.find((u) => u.id === params[Number(idMatch[1]) - 1]);
      if (row) {
        const setClause = /UPDATE users SET (.+) WHERE/.exec(sql)[1];
        for (const assign of setClause.split(', ')) {
          const m = /(\w+) = \$(\d+)/.exec(assign);
          if (m) row[m[1]] = params[Number(m[2]) - 1];
        }
      }
      return { rows: row ? [row] : [] };
    }
    if (sql === "UPDATE users SET role = 'both' WHERE id = $1") {
      const row = state.users.find((u) => u.id === params[0]);
      if (row) row.role = 'both';
      return { rows: [] };
    }

    // ---- PROVIDER PROFILES / CATEGORIES ----
    if (sql === 'SELECT * FROM provider_profiles WHERE user_id = $1') {
      const row = state.provider_profiles.find((p) => p.user_id === params[0]);
      return { rows: row ? [row] : [] };
    }
    if (sql === 'SELECT myid_verified FROM provider_profiles WHERE user_id = $1') {
      const row = state.provider_profiles.find((p) => p.user_id === params[0]);
      return { rows: row ? [{ myid_verified: row.myid_verified === true }] : [] };
    }
    if (sql.startsWith('SELECT id FROM categories WHERE id = ANY($1)')) {
      const ids = params[0];
      const rows = state.categories.filter((c) => ids.includes(c.id) && c.is_active !== false);
      return { rows: rows.map((r) => ({ id: r.id })) };
    }
    if (sql.startsWith('INSERT INTO provider_profiles (user_id, bio, experience_years)')) {
      const [user_id, bio, experience_years] = params;
      let row = state.provider_profiles.find((p) => p.user_id === user_id);
      if (row) {
        row.bio = bio;
        row.experience_years = experience_years;
      } else {
        row = {
          user_id,
          bio,
          experience_years,
          rating_avg: 0,
          rating_count: 0,
          completed_orders_count: 0,
          is_verified: false,
          myid_verified: true,
        };
        state.provider_profiles.push(row);
      }
      return { rows: [row] };
    }
    if (sql.startsWith('INSERT INTO provider_categories (provider_id, category_id)')) {
      const [provider_id, category_id] = params;
      if (!state.provider_categories.find((pc) => pc.provider_id === provider_id && pc.category_id === category_id)) {
        state.provider_categories.push({ provider_id, category_id });
      }
      return { rows: [] };
    }
    if (sql === 'UPDATE provider_profiles SET myid_verified = TRUE WHERE user_id = $1') {
      const row = state.provider_profiles.find((p) => p.user_id === params[0]);
      if (row) row.myid_verified = true;
      return { rows: [] };
    }
    if (sql === 'UPDATE provider_profiles SET completed_orders_count = completed_orders_count + 1 WHERE user_id = $1') {
      const row = state.provider_profiles.find((p) => p.user_id === params[0]);
      if (row) row.completed_orders_count += 1;
      return { rows: [] };
    }
    if (sql === 'UPDATE provider_profiles SET rating_count = $1, rating_avg = $2 WHERE user_id = $3') {
      const row = state.provider_profiles.find((p) => p.user_id === params[2]);
      if (row) {
        row.rating_count = Number(params[0]);
        row.rating_avg = Number(params[1]);
      }
      return { rows: [] };
    }
    if (sql.startsWith('SELECT u.id, u.full_name, u.avatar_url, u.city, u.created_at')) {
      const user = findUser(params[0]);
      const pp = state.provider_profiles.find((p) => p.user_id === params[0]);
      if (!user || !pp) return { rows: [] };
      return {
        rows: [
          {
            id: user.id,
            full_name: user.full_name,
            avatar_url: user.avatar_url,
            city: user.city,
            created_at: user.created_at,
            bio: pp.bio,
            experience_years: pp.experience_years,
            rating_avg: pp.rating_avg,
            rating_count: pp.rating_count,
            completed_orders_count: pp.completed_orders_count,
            is_verified: pp.is_verified,
            myid_verified: pp.myid_verified === true,
          },
        ],
      };
    }
    if (sql.startsWith('SELECT c.id, c.name_uz, c.icon FROM provider_categories')) {
      const rows = state.provider_categories
        .filter((pc) => pc.provider_id === params[0])
        .map((pc) => state.categories.find((c) => c.id === pc.category_id))
        .filter(Boolean)
        .map((c) => ({ id: c.id, name_uz: c.name_uz, icon: c.icon }));
      return { rows };
    }

    // ---- ORDERS ----
    if (sql.startsWith('SELECT o.*, l.title AS listing_title') && sql.includes('FROM orders o')) {
      let filtered;
      if (sql.includes('WHERE (o.client_id = $1 OR o.provider_id = $1)')) {
        filtered = state.orders.filter((o) => o.client_id === params[0] || o.provider_id === params[0]);
      } else if (sql.includes('WHERE o.client_id = $1')) {
        filtered = state.orders.filter((o) => o.client_id === params[0]);
      } else if (sql.includes('WHERE o.provider_id = $1')) {
        filtered = state.orders.filter((o) => o.provider_id === params[0]);
      } else if (sql.includes('WHERE o.id = $1')) {
        filtered = state.orders.filter((o) => o.id === params[0]);
      } else {
        filtered = [];
      }
      const rows = filtered
        .sort((a, b) => b.created_at - a.created_at)
        .map((o) => {
          const listing = state.listings.find((l) => l.id === o.listing_id);
          const clientUser = findUser(o.client_id);
          const providerUser = findUser(o.provider_id);
          const hasReview = state.reviews.some((r) => r.order_id === o.id);
          return {
            ...o,
            listing_title: listing?.title,
            client_name: clientUser?.full_name,
            provider_name: providerUser?.full_name,
            has_review: hasReview,
          };
        });
      return { rows };
    }
    if (sql === "UPDATE orders SET status = 'in_progress', started_at = now() WHERE id = $1") {
      const row = state.orders.find((o) => o.id === params[0]);
      if (row) {
        row.status = 'in_progress';
        row.started_at = new Date();
      }
      return { rows: [] };
    }
    if (sql === "UPDATE orders SET status = 'completed', completed_at = now() WHERE id = $1") {
      const row = state.orders.find((o) => o.id === params[0]);
      if (row) {
        row.status = 'completed';
        row.completed_at = new Date();
      }
      return { rows: [] };
    }
    if (sql === "UPDATE orders SET status = 'cancelled', cancelled_at = now(), cancel_reason = $1 WHERE id = $2") {
      const row = state.orders.find((o) => o.id === params[1]);
      if (row) {
        row.status = 'cancelled';
        row.cancelled_at = new Date();
        row.cancel_reason = params[0];
      }
      return { rows: [] };
    }

    // ---- REVIEWS ----
    if (sql === 'SELECT id FROM reviews WHERE order_id = $1') {
      const row = state.reviews.find((r) => r.order_id === params[0]);
      return { rows: row ? [{ id: row.id }] : [] };
    }
    if (sql.startsWith('INSERT INTO reviews (order_id, reviewer_id, reviewee_id, rating, comment)')) {
      const [order_id, reviewer_id, reviewee_id, rating, comment] = params;
      const row = { id: uuidv4(), order_id, reviewer_id, reviewee_id, rating, comment, created_at: new Date() };
      state.reviews.push(row);
      return { rows: [row] };
    }
    if (sql.startsWith('SELECT COUNT(*) AS count, COALESCE(AVG(rating), 0) AS avg FROM reviews')) {
      const matching = state.reviews.filter((r) => r.reviewee_id === params[0]);
      const avg = matching.length ? matching.reduce((sum, r) => sum + r.rating, 0) / matching.length : 0;
      return { rows: [{ count: String(matching.length), avg: String(avg) }] };
    }
    if (sql.startsWith('SELECT r.*, u.full_name AS reviewer_name')) {
      const rows = state.reviews
        .filter((r) => r.reviewee_id === params[0])
        .sort((a, b) => b.created_at - a.created_at)
        .map((r) => {
          const reviewer = findUser(r.reviewer_id);
          return { ...r, reviewer_name: reviewer?.full_name, reviewer_avatar: reviewer?.avatar_url };
        });
      return { rows };
    }


    throw new Error(`[fakeDb] Kutilmagan SQL so'rovi (test uchun implement qilinmagan): ${sql}`);
  }

  async function getClient() {
    return {
      query: async (text, params) => {
        const sql = normalize(text);
        if (sql === 'BEGIN' || sql === 'COMMIT' || sql === 'ROLLBACK') return { rows: [] };
        return query(text, params);
      },
      release: () => {},
    };
  }

  return { query, getClient, state };
}

module.exports = { createFakeDb };
