const { allowedMimeTypes, classifyMimeType } = require('../src/middleware/mediaTypes');

describe('chat media upload policy', () => {
  test.each([
    ['image/jpeg', 'image'],
    ['video/mp4', 'video'],
    ['audio/mpeg', 'audio'],
    ['application/pdf', 'file'],
    ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'file'],
  ])('classifies %s as %s', (mime, expected) => {
    expect(allowedMimeTypes.has(mime)).toBe(true);
    expect(classifyMimeType(mime)).toBe(expected);
  });

  test.each(['application/pdf', 'audio/mpeg', 'text/plain'])('accepts supported attachment MIME %s', (mime) => {
    expect(allowedMimeTypes.has(mime)).toBe(true);
  });

  test.each(['application/x-msdownload', 'application/x-executable', 'text/html', 'application/zip'])('rejects unsafe or unsupported MIME %s', (mime) => {
    expect(allowedMimeTypes.has(mime)).toBe(false);
  });
});
