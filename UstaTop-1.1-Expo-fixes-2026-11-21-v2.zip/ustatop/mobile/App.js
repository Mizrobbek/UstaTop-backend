import React, { useEffect, useState, useCallback } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { NavigationContainer, createNavigationContainerRef } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import colors from './src/theme/colors';
import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import ForgotPasswordScreen from './src/screens/ForgotPasswordScreen';
import HomeScreen from './src/screens/HomeScreen';
import CreateListingScreen from './src/screens/CreateListingScreen';
import CategoryListingsScreen from './src/screens/CategoryListingsScreen';
import ListingDetailScreen from './src/screens/ListingDetailScreen';
import ListingOffersScreen from './src/screens/ListingOffersScreen';
import ProviderProfileScreen from './src/screens/ProviderProfileScreen';
import ProviderReviewsScreen from './src/screens/ProviderReviewsScreen';
import ChatsListScreen from './src/screens/ChatsListScreen';
import ChatScreen from './src/screens/ChatScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import EditProfileScreen from './src/screens/EditProfileScreen';
import PortfolioScreen from './src/screens/PortfolioScreen';
import BecomeProviderScreen from './src/screens/BecomeProviderScreen';
import MyOrdersScreen from './src/screens/MyOrdersScreen';
import MapListingsScreen from './src/screens/MapListingsScreen';
import LocationPickerScreen from './src/screens/LocationPickerScreen';
import PaymentWebViewScreen from './src/screens/PaymentWebViewScreen';
import NotificationsScreen, { navigateForNotification } from './src/screens/NotificationsScreen';
import { getStoredUser, clearSession } from './src/api/client';
import { registerForPushNotifications, unregisterPushToken, addNotificationTapListener } from './src/api/pushNotifications';

const Stack = createNativeStackNavigator();
const navigationRef = createNavigationContainerRef();

export default function App() {
  const [checkingSession, setCheckingSession] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const storedUser = await getStoredUser();
        if (mounted) {
          setUser(storedUser);
          // Sessiya saqlangan bo‘lsa, push tokenini yangilaymiz.
          if (storedUser) registerForPushNotifications();
        }
      } catch (error) {
        if (mounted) setUser(null);
      } finally {
        if (mounted) setCheckingSession(false);
      }
    })();

    return () => { mounted = false; };
  }, []);

  // Bildirishnomaga bosilganda (ilova fonda/yopiq bo'lsa ham) tegishli ekranga o'tkazamiz.
  // Bir xil marshrutlash mantig'i NotificationsScreen'dagi ro'yxatda bosilganda ham ishlatiladi.
  useEffect(() => {
    const removeListener = addNotificationTapListener((data) => {
      if (navigationRef.isReady()) {
        navigateForNotification(navigationRef, { type: data.type, data });
      }
    });
    return removeListener;
  }, []);

  const handleLoginSuccess = useCallback((loggedInUser) => {
    setUser(loggedInUser);
    registerForPushNotifications();
  }, []);

  const handleLogout = useCallback(async () => {
    await unregisterPushToken();
    await clearSession();
    setUser(null);
  }, []);

  if (checkingSession) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {user ? (
          <>
            <Stack.Screen name="Home">
              {(props) => <HomeScreen {...props} user={user} onLogout={handleLogout} />}
            </Stack.Screen>
            <Stack.Screen name="CreateListing" component={CreateListingScreen} />
            <Stack.Screen name="CategoryListings" component={CategoryListingsScreen} />
            <Stack.Screen name="ListingDetail">
              {(props) => <ListingDetailScreen {...props} currentUser={user} />}
            </Stack.Screen>
            <Stack.Screen name="ListingOffers" component={ListingOffersScreen} />
            <Stack.Screen name="ProviderProfile" component={ProviderProfileScreen} />
            <Stack.Screen name="ProviderReviews" component={ProviderReviewsScreen} />
            <Stack.Screen name="ChatsList" component={ChatsListScreen} />
            <Stack.Screen name="Chat" component={ChatScreen} />
            <Stack.Screen name="Profile">
              {(props) => <ProfileScreen {...props} onLogout={handleLogout} />}
            </Stack.Screen>
            <Stack.Screen name="EditProfile" component={EditProfileScreen} />
            <Stack.Screen name="Portfolio" component={PortfolioScreen} />
            <Stack.Screen name="BecomeProvider" component={BecomeProviderScreen} />
            <Stack.Screen name="MyOrders" component={MyOrdersScreen} />
            <Stack.Screen name="Map" component={MapListingsScreen} />
            <Stack.Screen name="LocationPicker" component={LocationPickerScreen} />
            <Stack.Screen name="PaymentWebView" component={PaymentWebViewScreen} />
            <Stack.Screen name="Notifications" component={NotificationsScreen} />
          </>
        ) : (
          <>
            <Stack.Screen name="Login">
              {(props) => <LoginScreen {...props} onLoginSuccess={handleLoginSuccess} />}
            </Stack.Screen>
            <Stack.Screen name="Register">
              {(props) => <RegisterScreen {...props} onLoginSuccess={handleLoginSuccess} />}
            </Stack.Screen>
            <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
});
