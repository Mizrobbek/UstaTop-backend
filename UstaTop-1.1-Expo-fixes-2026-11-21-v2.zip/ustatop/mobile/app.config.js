const appJson = require('./app.json');

// Production (do'kon) build'larda API faqat HTTPS bo'lishi shart: aks holda parol va
// tokenlar shifrlanmagan tarmoq orqali yuboriladi. Mahalliy LAN/HTTP faqat development uchun.
function resolveApiUrl() {
  const apiUrl = process.env.EXPO_PUBLIC_API_URL || appJson.expo.extra.apiUrl;
  const isProductionBuild = process.env.EAS_BUILD_PROFILE === 'production' || process.env.APP_ENV === 'production';
  if (isProductionBuild && !/^https:\/\//i.test(apiUrl)) {
    throw new Error('Production build uchun EXPO_PUBLIC_API_URL https:// bilan boshlanishi kerak');
  }
  return apiUrl;
}

module.exports = ({ config }) => ({
  ...config,
  ...appJson.expo,
  extra: {
    ...appJson.expo.extra,
    apiUrl: resolveApiUrl(),
  },
});
