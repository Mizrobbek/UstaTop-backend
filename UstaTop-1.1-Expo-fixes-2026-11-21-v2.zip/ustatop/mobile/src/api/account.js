import { api } from './client';

export async function fetchMe() {
  const { data } = await api.get('/users/me');
  return data.user;
}

export async function fetchMyCommissions() {
  const [summary, history] = await Promise.all([
    api.get('/commissions/summary'), api.get('/commissions/history'),
  ]);
  return { ...summary.data, ...history.data };
}

export async function updateProfile(payload) {
  const { data } = await api.patch('/users/me', payload);
  return data.user;
}

export async function becomeProvider(payload) {
  const { data } = await api.post('/users/me/become-provider', payload);
  return data;
}

export async function fetchMyOrders(role) {
  const { data } = await api.get('/orders', { params: role ? { role } : {} });
  return data.orders;
}

export async function fetchOrder(id) {
  const { data } = await api.get(`/orders/${id}`);
  return data.order;
}

export async function updateOrderStatus(id, status, cancelReason) {
  const { data } = await api.patch(`/orders/${id}/status`, { status, cancelReason });
  return data;
}

export async function confirmServicePayment(orderId) {
  const { data } = await api.patch(`/orders/${orderId}/payment-confirmation`);
  return data;
}

export async function initiatePayment(orderId, provider) {
  const { data } = await api.post(`/orders/${orderId}/pay`, { provider });
  return data; // { paymentUrl, provider, amount }
}

export async function fetchPaymentStatus(orderId) {
  const { data } = await api.get(`/orders/${orderId}/payment-status`);
  return data; // { isPaid, paidAt }
}

export async function submitReview(orderId, { rating, comment }) {
  const { data } = await api.post(`/orders/${orderId}/review`, { rating, comment });
  return data.review;
}

export async function fetchProviderProfile(providerId) {
  const { data } = await api.get(`/providers/${providerId}`);
  return data.provider;
}

export async function fetchProviderReviews(providerId) {
  const { data } = await api.get(`/providers/${providerId}/reviews`);
  return data.reviews;
}

export async function fetchNotifications(page = 1) {
  const { data } = await api.get('/notifications', { params: { page } });
  return data; // { notifications, unreadCount }
}

export async function markNotificationRead(id) {
  const { data } = await api.patch(`/notifications/${id}/read`);
  return data;
}

export async function markAllNotificationsRead() {
  const { data } = await api.patch('/notifications/read-all');
  return data;
}

export async function uploadMedia(files) {
  const form = new FormData();
  files.forEach((file, index) => form.append('files', { uri: file.uri, name: file.name || `upload-${index}.jpg`, type: file.type || 'image/jpeg' }));
  const { data } = await api.post('/media/upload', form, { headers: { 'Content-Type': 'multipart/form-data' }, timeout: 120000, transformRequest: [(data) => data] });
  return data.files;
}
export async function fetchMyPortfolio() { const { data } = await api.get('/portfolio/me'); return data.items; }
export async function addPortfolioItem(payload) { const { data } = await api.post('/portfolio/me', payload); return data.item; }
export async function deletePortfolioItem(id) { return api.delete(`/portfolio/me/${id}`); }

export async function requestPhoneChange(phone) { const { data } = await api.post('/users/me/phone/change/request', { phone }); return data; }
export async function confirmPhoneChange(phone, code) { const { data } = await api.post('/users/me/phone/change/confirm', { phone, code }); return data; }
