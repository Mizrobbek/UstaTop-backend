import { api } from './client';

export async function fetchChats() {
  const { data } = await api.get('/chats');
  return data.chats;
}

export async function fetchMessages(chatId, before) {
  const { data } = await api.get(`/chats/${chatId}/messages`, { params: before ? { before } : {} });
  return data; // { messages, chat }
}

export async function sendMessageRequest(chatId, { content, mediaUrl }) {
  const { data } = await api.post(`/chats/${chatId}/messages`, { content, mediaUrl });
  return data.message;
}
