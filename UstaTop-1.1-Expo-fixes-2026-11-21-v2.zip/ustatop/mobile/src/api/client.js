import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';
import { disconnectSocket } from './socket';

// app.json > expo.extra.apiUrl orqali sozlanadi.
// Real Android telefon (Expo Go) uchun kompyuterning LAN IP manzili ishlatiladi.
// IP o'zgarsa mobile/app.json > expo.extra.apiUrl va ushbu fallback yangilanadi.
const API_URL = Constants.expoConfig?.extra?.apiUrl || 'http://172.20.125.60:4001/api';

const STORAGE_KEYS = {
  accessToken: 'ustatop_access_token',
  refreshToken: 'ustatop_refresh_token',
  user: 'ustatop_user',
};

export const api = axios.create({
  baseURL: API_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Har bir so'rovga avtomatik token qo'shish
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem(STORAGE_KEYS.accessToken);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Token muddati tugasa (401 + TOKEN_EXPIRED), avtomatik refresh qilib, so'rovni qayta yuboradi
let isRefreshing = false;
let pendingQueue = [];

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const originalRequest = error.config;
    const status = error.response?.status;
    const code = error.response?.data?.code;

    if (status === 401 && code === 'TOKEN_EXPIRED' && !originalRequest._retry) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          pendingQueue.push({ resolve, reject });
        }).then((token) => {
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return api(originalRequest);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;
      try {
        const refreshToken = await AsyncStorage.getItem(STORAGE_KEYS.refreshToken);
        const { data } = await axios.post(`${API_URL}/auth/refresh`, { refreshToken });
        await AsyncStorage.setItem(STORAGE_KEYS.accessToken, data.accessToken);
        await AsyncStorage.setItem(STORAGE_KEYS.refreshToken, data.refreshToken);
        pendingQueue.forEach((p) => p.resolve(data.accessToken));
        pendingQueue = [];
        originalRequest.headers.Authorization = `Bearer ${data.accessToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        pendingQueue.forEach((p) => p.reject(refreshError));
        pendingQueue = [];
        await clearSession();
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    // Server sessiyani bekor qilgan (logout boshqa joydan, parol tiklash, replay) — mahalliy sessiyani tozalaymiz
    if (status === 401 && (code === 'TOKEN_REVOKED' || code === 'REFRESH_REUSED')) {
      await clearSession();
    }

    return Promise.reject(error);
  }
);

/** Xato javobidan foydalanuvchiga ko'rsatiladigan tushunarli xabarni chiqarib oladi */
export function getErrorMessage(err) {
  return (
    err?.response?.data?.error ||
    err?.response?.data?.details?.[0] ||
    'Xatolik yuz berdi. Internet aloqasini tekshirib, qayta urinib ko\'ring.'
  );
}

export async function saveSession({ accessToken, refreshToken, user } = {}) {
  if (
    typeof accessToken !== 'string' || !accessToken ||
    typeof refreshToken !== 'string' || !refreshToken ||
    !user || typeof user !== 'object' || Array.isArray(user)
  ) {
    throw new Error('Server sessiya ma’lumotlarini to‘liq qaytarmadi. Qaytadan kiring.');
  }

  await AsyncStorage.multiSet([
    [STORAGE_KEYS.accessToken, accessToken],
    [STORAGE_KEYS.refreshToken, refreshToken],
    [STORAGE_KEYS.user, JSON.stringify(user)],
  ]);
}

export async function getStoredUser() {
  try {
    const values = await AsyncStorage.multiGet([
      STORAGE_KEYS.accessToken,
      STORAGE_KEYS.refreshToken,
      STORAGE_KEYS.user,
    ]);
    const accessToken = values[0]?.[1];
    const refreshToken = values[1]?.[1];
    const rawUser = values[2]?.[1];

    if (!rawUser) {
      await clearSession();
      return null;
    }

    const user = JSON.parse(rawUser);
    if (!user || typeof user !== 'object' || Array.isArray(user) || !refreshToken) {
      await clearSession();
      return null;
    }

    if (accessToken) return user;

    // Access token yo‘q bo‘lsa, refresh token orqali yangi juftlik olinadi.
    const { data } = await axios.post(
      `${API_URL}/auth/refresh`,
      { refreshToken },
      { timeout: 15000, headers: { 'Content-Type': 'application/json' } }
    );

    if (
      typeof data?.accessToken !== 'string' || !data.accessToken ||
      typeof data?.refreshToken !== 'string' || !data.refreshToken
    ) {
      throw new Error('Server yangi tokenlarni qaytarmadi');
    }

    await AsyncStorage.multiSet([
      [STORAGE_KEYS.accessToken, data.accessToken],
      [STORAGE_KEYS.refreshToken, data.refreshToken],
    ]);
    return user;
  } catch (error) {
    // Noto'g'ri/yaroqsiz refresh token bo'lsa sessiyani tozalaymiz.
    // Tarmoq yoki server vaqtincha ishlamasa tokenlarni saqlab qolamiz:
    // aks holda oddiy internet uzilishi foydalanuvchini hisobidan chiqarib yuboradi.
    if (
      error instanceof SyntaxError ||
      error?.response?.status === 401 ||
      error?.response?.status === 403
    ) {
      await clearSession();
      return null;
    }
    throw error;
  }
}

export async function clearSession() {
  disconnectSocket();
  await AsyncStorage.multiRemove([STORAGE_KEYS.accessToken, STORAGE_KEYS.refreshToken, STORAGE_KEYS.user]);
}

// ---------- Auth endpoint'lari ----------

export async function registerRequest({ fullName, phone, password }) {
  const { data } = await api.post('/auth/register/request-code', { fullName, phone, password });
  return data;
}

export async function verifyRegistrationCodeRequest({ phone, code }) {
  const { data } = await api.post('/auth/register/verify-code', { phone, code });
  return data;
}


export async function loginRequest({ identifier, password }) {
  const { data } = await api.post('/auth/login', { identifier, password });
  return data;
}

export async function verifyLoginPhoneRequest({ phone, code }) {
  const { data } = await api.post('/auth/login/verify-phone', { phone, code });
  return data;
}

export async function forgotPasswordSendCodeRequest({ phone }) {
  const { data } = await api.post('/auth/forgot-password/send-code', { phone });
  return data;
}

export async function forgotPasswordResetRequest({ phone, code, newPassword }) {
  const { data } = await api.post('/auth/forgot-password/reset', { phone, code, newPassword });
  return data;
}

export async function logoutRequest() {
  const refreshToken = await AsyncStorage.getItem(STORAGE_KEYS.refreshToken);
  try {
    disconnectSocket();
    await api.post('/auth/logout', { refreshToken });
  } finally {
    await clearSession();
  }
}
