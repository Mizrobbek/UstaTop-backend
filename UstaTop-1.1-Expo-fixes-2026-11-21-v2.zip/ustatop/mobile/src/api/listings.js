import { api } from './client';

export async function fetchCategories() {
  const { data } = await api.get('/categories');
  return data.categories;
}

export async function fetchListings(params = {}) {
  const { data } = await api.get('/listings', { params });
  return data; // { listings, pagination }
}

export async function fetchMapListings(params) {
  const { data } = await api.get('/listings/map', { params });
  return data; // { listings, total, truncated }
}

export async function fetchListing(id) {
  const { data } = await api.get(`/listings/${id}`);
  return data.listing;
}

export async function createListing(payload) {
  const { data } = await api.post('/listings', payload);
  return data.listing;
}

export async function updateListing(id, payload) {
  const { data } = await api.patch(`/listings/${id}`, payload);
  return data.listing;
}

export async function fetchMyListings() {
  const { data } = await api.get('/listings/mine');
  return data.listings;
}

export async function createOffer(listingId, payload) {
  const { data } = await api.post(`/listings/${listingId}/offers`, payload);
  return data; // { offer, chatId }
}

export async function fetchOffersForListing(listingId) {
  const { data } = await api.get(`/listings/${listingId}/offers`);
  return data.offers;
}

export async function respondToOffer(offerId, status) {
  const { data } = await api.patch(`/offers/${offerId}`, { status });
  return data;
}

export async function fetchMyOffers() {
  const { data } = await api.get('/offers/mine');
  return data.offers;
}
