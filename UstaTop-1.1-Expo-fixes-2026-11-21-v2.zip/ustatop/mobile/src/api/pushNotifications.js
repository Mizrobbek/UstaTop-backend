import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { api } from './client';

// Ilova old planda (foreground) ochiq turganda ham bildirishnoma ko'rsatilsin
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

/**
 * Qurilmadan ruxsat so'raydi, Expo push tokenini oladi va backend'ga yuboradi.
 * Faqat haqiqiy qurilmada ishlaydi (simulyator/emulyatorda push token bo'lmaydi).
 * Ruxsat berilmasa yoki xato bo'lsa, jim qaytadi — bu ilovaning asosiy ishlashiga
 * hech qanday ta'sir qilmasligi kerak.
 */
export async function registerForPushNotifications() {
  try {
    // Android Expo Go'da (SDK 53+) remote push token qo'llab-quvvatlanmaydi.
    // Native channel manager chaqirig'i Expo Go ichida NPE berishi mumkin.
    const isExpoGo = Constants.executionEnvironment === 'storeClient' || Constants.appOwnership === 'expo';
    if (Platform.OS === 'android' && isExpoGo) {
      console.log("[Push] Android Expo Go: remote push uchun development build kerak; roʻyxatdan oʻtkazish oʻtkazib yuborildi");
      return null;
    }

    if (!Device.isDevice) {
      console.log('[Push] Simulyator/emulyatorda push token mavjud emas - o\'tkazib yuborildi');
      return null;
    }

    if (Platform.OS === 'android' && typeof Notifications.setNotificationChannelAsync === 'function') {
      try {
        await Notifications.setNotificationChannelAsync('default', {
          name: 'Asosiy',
          importance: Notifications.AndroidImportance?.DEFAULT ?? 3,
          vibrationPattern: [0, 250, 250, 250],
        });
      } catch (channelError) {
        // Kanal xatosi asosiy ilova va push token olish jarayonini to'xtatmasin.
        console.warn('[Push] Android notification channel yaratilmadi:', channelError?.message || channelError);
      }
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== 'granted') {
      console.log('[Push] Foydalanuvchi ruxsat bermadi');
      return null;
    }

    const configuredProjectId = Constants.expoConfig?.extra?.eas?.projectId;
    const projectId = typeof configuredProjectId === 'string' &&
      configuredProjectId.trim() && !configuredProjectId.startsWith('YOUR-')
      ? configuredProjectId.trim()
      : null;
    if (!projectId) {
      console.log('[Push] EAS projectId sozlanmagan; push token olinmadi');
      return null;
    }
    const tokenResponse = await Notifications.getExpoPushTokenAsync({ projectId });
    const token = tokenResponse.data;

    await api.post('/users/me/push-token', { pushToken: token });
    return token;
  } catch (err) {
    console.log('[Push] Ro\'yxatdan o\'tkazishda xato:', err.message);
    return null;
  }
}

/** Chiqishda (logout) tokenni backend'dan o'chiradi - endi push kelmasligi uchun */
export async function unregisterPushToken() {
  try {
    await api.post('/users/me/push-token', { pushToken: null });
  } catch (err) {
    // Jim o'tkazamiz - logout jarayoni buning uchun to'xtab qolmasligi kerak
  }
}

/**
 * Bildirishnomaga bosilganda (ilova fon/yopiq holatida bo'lsa ham) chaqiriladigan
 * listener'ni o'rnatadi. `onTap` ga bildirishnoma ichidagi `data` obyekti beriladi -
 * backend'dagi notifyUser() qaysi `data` bilan yuborgan bo'lsa, shu (type maydoni bilan birga).
 */
export function addNotificationTapListener(onTap) {
  const subscription = Notifications.addNotificationResponseReceivedListener((response) => {
    onTap(response.notification.request.content.data || {});
  });
  return () => subscription.remove();
}

export { Notifications };
