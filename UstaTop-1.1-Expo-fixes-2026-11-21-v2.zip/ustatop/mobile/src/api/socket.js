import { io } from 'socket.io-client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';

// API bazasi "/api" bilan tugaydi, socket esa server ildiziga ulanadi
const API_URL = Constants.expoConfig?.extra?.apiUrl || 'http://172.20.125.60:4000/api';
const SOCKET_URL = API_URL.replace(/\/api\/?$/, '');

let socket = null;
let socketToken = null; // ulanish qaysi access token bilan ochilganini eslab qolamiz

/**
 * Socket ulanishini (agar hali ulanmagan bo'lsa) yaratadi va qaytaradi.
 * Har bir ekran shu bitta umumiy ulanishdan foydalanadi (qayta-qayta ulanmaslik uchun).
 */
export async function getSocket() {
  const token = await AsyncStorage.getItem('ustatop_access_token');
  if (!token) {
    // Hisobdan chiqilgan: eski ulanish boshqa foydalanuvchi nomidan qolmasligi kerak
    disconnectSocket();
    return null;
  }

  // Faqat aynan shu token bilan ochilgan ulanishni qayta ishlatamiz (hisob almashsa — yangi ulanish)
  if (socket && socket.connected && socketToken === token) return socket;

  if (socket) {
    socket.disconnect();
  }
  socketToken = token;

  socket = io(SOCKET_URL, {
    auth: { token },
    transports: ['websocket'],
    reconnection: true,
    reconnectionAttempts: 5,
  });

  return socket;
}

export function disconnectSocket() {
  if (socket) {
    socket.removeAllListeners();
    socket.disconnect();
    socket = null;
  }
  socketToken = null;
}

export function joinChatRoom(chatId) {
  socket?.emit('chat:join', { chatId });
}

export function leaveChatRoom(chatId) {
  socket?.emit('chat:leave', { chatId });
}

export function emitTyping(chatId) {
  socket?.emit('chat:typing', { chatId });
}
