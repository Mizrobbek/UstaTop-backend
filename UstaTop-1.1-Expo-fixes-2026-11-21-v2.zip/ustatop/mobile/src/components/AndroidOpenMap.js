import React, { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View, Pressable } from 'react-native';
import { WebView } from 'react-native-webview';
import colors from '../theme/colors';

const STYLE_URL = 'https://tiles.openfreemap.org/styles/liberty';
const MAPLIBRE_VERSION = '5.24.1';

function regionZoom(region) {
  const delta = Math.max(Number(region?.longitudeDelta) || 0.15, 0.002);
  return Math.max(4, Math.min(18, Math.log2(360 / delta)));
}

export function buildOpenMapHtml(region) {
  const latitude = Number(region?.latitude) || 41.3111;
  const longitude = Number(region?.longitude) || 69.2797;
  const zoom = regionZoom(region);
  return `<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"><link id="map-css" href="https://cdn.jsdelivr.net/npm/maplibre-gl@${MAPLIBRE_VERSION}/dist/maplibre-gl.css" rel="stylesheet" onerror="this.href='https://unpkg.com/maplibre-gl@${MAPLIBRE_VERSION}/dist/maplibre-gl.css'"><style>html,body,#map{margin:0;width:100%;height:100%;overflow:hidden;background:#eef2f3}.maplibregl-ctrl-logo{display:none!important}.maplibregl-ctrl-attrib{font:10px sans-serif}.price-marker{background:#0f766e;color:white;border:2px solid white;border-radius:14px;padding:5px 8px;font:600 11px sans-serif;white-space:nowrap;box-shadow:0 1px 5px #0005}.status{position:absolute;left:12px;right:12px;top:45%;padding:12px;background:#fff;color:#334155;border-radius:8px;text-align:center;font:14px sans-serif;box-shadow:0 2px 12px #0002}</style></head><body><div id="map"></div><div id="status" class="status">Xarita yuklanmoqda…</div><script src="https://cdn.jsdelivr.net/npm/maplibre-gl@${MAPLIBRE_VERSION}/dist/maplibre-gl.js" onerror="var s=document.createElement('script');s.src='https://unpkg.com/maplibre-gl@${MAPLIBRE_VERSION}/dist/maplibre-gl.js';document.head.appendChild(s)"></script><script>
(function(){
 const status=document.getElementById('status');
 let mapLoaded=false;
 function waitForLibrary(){if(!window.maplibregl){if(!window.__mapFallbackTimer){window.__mapFallbackTimer=setTimeout(()=>{if(!window.maplibregl){status.textContent='Xarita kutubxonasi yuklanmadi. Internet aloqasini tekshiring.';if(window.ReactNativeWebView)window.ReactNativeWebView.postMessage(JSON.stringify({type:'mapError',message:'MapLibre CDN yuklanmadi'}));}},8000);}setTimeout(waitForLibrary,150);return;}initMap();}
 function initMap(){
 const map=new maplibregl.Map({container:'map',style:${JSON.stringify(STYLE_URL)},center:[${longitude},${latitude}],zoom:${zoom},attributionControl:false});
 map.addControl(new maplibregl.NavigationControl({showCompass:false}),'top-right');
 map.addControl(new maplibregl.AttributionControl({compact:true}),'bottom-right');
 const markers=[];
 function send(data){if(window.ReactNativeWebView)window.ReactNativeWebView.postMessage(JSON.stringify(data));}
 function sendRegion(){const b=map.getBounds();send({type:'region',region:{latitude:map.getCenter().lat,longitude:map.getCenter().lng,latitudeDelta:Math.abs(b.getNorth()-b.getSouth()),longitudeDelta:Math.abs(b.getEast()-b.getWest())}});}
 map.on('load',()=>{mapLoaded=true;status.style.display='none';send({type:'ready'});sendRegion();});
 // Tile/glyph so'rovlaridagi ayrim xatolar butun xaritani yopib qo'ymasligi kerak.
 map.on('error',(e)=>{if(!mapLoaded){status.textContent='Xarita serveriga ulanib bo‘lmadi. Internetni tekshirib, qayta oching.';send({type:'mapError',message:String(e&&e.error&&e.error.message||'map error')});}});
 map.on('click',(e)=>send({type:'mapPress',latitude:e.lngLat.lat,longitude:e.lngLat.lng}));
 map.on('moveend',sendRegion);
 window.setMarkers=function(items){while(markers.length)markers.pop().remove();(items||[]).forEach(item=>{if(!Number.isFinite(Number(item.latitude))||!Number.isFinite(Number(item.longitude)))return;const el=document.createElement('div');el.className='price-marker';el.textContent=String(item.label||'UstaTop');el.addEventListener('click',ev=>{ev.stopPropagation();send({type:'markerPress',id:item.id})});const marker=new maplibregl.Marker({element:el,anchor:'bottom'}).setLngLat([Number(item.longitude),Number(item.latitude)]).addTo(map);markers.push(marker);});};
 window.moveToRegion=function(r,duration){if(!r)return;const d=Math.max(Number(r.longitudeDelta)||0.05,0.002);map.flyTo({center:[Number(r.longitude),Number(r.latitude)],zoom:Math.max(4,Math.min(18,Math.log2(360/d))),duration:Math.max(0,Number(duration)||400)});};
 }
 waitForLibrary();
})();
</script></body></html>`;
}

const AndroidOpenMap = forwardRef(function AndroidOpenMap({ initialRegion, markers = [], onMapPress, onMarkerPress, onRegionChangeComplete, onMapError, style }, ref) {
  const webRef = useRef(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const html = useMemo(() => buildOpenMapHtml(initialRegion), []);

  useImperativeHandle(ref, () => ({
    animateToRegion(region, duration = 400) {
      const payload = JSON.stringify(region || {});
      webRef.current?.injectJavaScript(`window.moveToRegion && window.moveToRegion(${payload},${Number(duration) || 400}); true;`);
    },
  }), []);

  useEffect(() => {
    if (!ready) return;
    const payload = JSON.stringify(markers.map((item) => ({ id: item.id, latitude: item.latitude, longitude: item.longitude, label: item.label })));
    webRef.current?.injectJavaScript(`window.setMarkers && window.setMarkers(${payload}); true;`);
  }, [markers, ready]);

  function handleMessage(event) {
    try {
      const message = JSON.parse(event.nativeEvent.data);
      if (message.type === 'ready') { setReady(true); setFailed(false); }
      if (message.type === 'mapPress') onMapPress?.({ latitude: message.latitude, longitude: message.longitude });
      if (message.type === 'markerPress') onMarkerPress?.(message.id);
      if (message.type === 'region') onRegionChangeComplete?.(message.region);
      if (message.type === 'mapError') { setFailed(true); onMapError?.(message.message); }
    } catch (_) {
      // Ignore malformed messages from the embedded map.
    }
  }

  return <View style={[styles.container, style]}>
    <WebView key={reloadKey} ref={webRef} source={{ html, baseUrl: 'https://ustatop.local/' }} originWhitelist={['*']} javaScriptEnabled domStorageEnabled allowFileAccess={false} mixedContentMode="never" onMessage={handleMessage} onError={() => { setFailed(true); onMapError?.('WebView network error'); }} onHttpError={(e) => { if (e.nativeEvent.isForMainFrame) { setFailed(true); onMapError?.(`HTTP ${e.nativeEvent.statusCode}`); } }} style={styles.webview} />
    {!ready && !failed && <View pointerEvents="none" style={styles.loading}><ActivityIndicator color={colors.primary}/><Text style={styles.loadingText}>Xarita yuklanmoqda…</Text></View>}
    {failed && <View style={styles.errorOverlay}><Text style={styles.errorTitle}>Xarita yuklanmadi</Text><Text style={styles.loadingText}>Internet aloqasini tekshirib, qayta urinib ko‘ring.</Text><Pressable style={styles.retry} onPress={() => { setFailed(false); setReady(false); setReloadKey(k => k + 1); }}><Text style={styles.retryText}>Qayta yuklash</Text></Pressable></View>}
  </View>;
});

const styles = StyleSheet.create({ container: { flex: 1, overflow: 'hidden', backgroundColor: '#eef2f3' }, webview: { flex: 1, backgroundColor: 'transparent' }, loading: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#eef2f3' }, loadingText: { color: colors.textMuted, fontSize: 12 }, errorOverlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: '#eef2f3' }, errorTitle: { color: '#334155', fontSize: 16, fontWeight: '800', marginBottom: 8 }, retry: { marginTop: 16, backgroundColor: colors.primary, borderRadius: 12, paddingHorizontal: 20, paddingVertical: 11 }, retryText: { color: '#fff', fontSize: 13, fontWeight: '700' } });

export default AndroidOpenMap;
