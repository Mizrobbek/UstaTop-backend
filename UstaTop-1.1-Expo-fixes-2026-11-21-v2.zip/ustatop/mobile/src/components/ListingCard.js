import React from 'react';
import { Pressable, View, Text, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';

function formatPrice(listing) {
  if (listing.priceType === 'negotiable' || listing.price === null) return 'Kelishiladi';
  return `${Number(listing.price).toLocaleString('ru-RU')} so'm`;
}

function timeAgo(dateStr) {
  const diffMs = Date.now() - new Date(dateStr).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 1) return 'hozirgina';
  if (minutes < 60) return `${minutes} daqiqa oldin`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} soat oldin`;
  return `${Math.floor(hours / 24)} kun oldin`;
}

export default function ListingCard({ listing, onPress }) {
  return (
    <Pressable style={({ pressed }) => [styles.card, pressed && { opacity: 0.85 }]} onPress={onPress}>
      {!!listing.media?.[0] && <Image source={{uri:listing.media[0]}} style={styles.coverImage} />}
      <View style={styles.headerRow}>
        <Text style={styles.category}>{listing.categoryName}</Text>
        <Text style={styles.time}>{timeAgo(listing.createdAt)}</Text>
      </View>
      <Text style={styles.title} numberOfLines={2}>
        {listing.title}
      </Text>
      <Text style={styles.description} numberOfLines={2}>
        {listing.description}
      </Text>
      <View style={styles.footerRow}>
        <Text style={styles.price}>{formatPrice(listing)}</Text>
        <View style={styles.metaRow}>
          {listing.offersCount !== undefined && (
            <View style={styles.metaItem}>
              <Ionicons name="people-outline" size={13} color={colors.textMuted} />
              <Text style={styles.metaText}>{listing.offersCount}</Text>
            </View>
          )}
          <View style={styles.metaItem}>
            <Ionicons name="location-outline" size={13} color={colors.textMuted} />
            <Text style={styles.metaText}>{listing.city}</Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  coverImage:{width:'100%',height:150,borderRadius:10,marginBottom:12,backgroundColor:colors.border},
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  category: { fontSize: 12, fontWeight: '700', color: colors.primary },
  time: { fontSize: 11.5, color: colors.textMuted },
  title: { fontSize: 15.5, fontWeight: '700', color: colors.textPrimary, marginBottom: 4 },
  description: { fontSize: 13, color: colors.textSecondary, lineHeight: 18, marginBottom: 10 },
  footerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  price: { fontSize: 15, fontWeight: '800', color: colors.accentDark },
  metaRow: { flexDirection: 'row', gap: 10 },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  metaText: { fontSize: 12, color: colors.textMuted },
});
