import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Path, Circle, Defs, LinearGradient, Stop, Rect } from 'react-native-svg';
import colors from '../theme/colors';

/**
 * Faqat ikonka qismi (LogoMark).
 * G'oya: joylashuv nishoni (pin) shakli ichida gaechkalt (ochiq kalit) siluetini
 * uyg'unlashtiradi — "yaqiningizdagi ustani toping" degan ma'noni bir zumda anglatadi.
 * Rounded-square fon gradienti ilovaning zamonaviy, "app-icon" uslubidagi ko'rinishini beradi.
 */
export function LogoMark({ size = 88 }) {
  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size} viewBox="0 0 100 100">
        <Defs>
          <LinearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor="#14B8A6" />
            <Stop offset="1" stopColor="#0B4F49" />
          </LinearGradient>
          <LinearGradient id="pinGrad" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#FFFFFF" />
            <Stop offset="1" stopColor="#FFE8D6" />
          </LinearGradient>
        </Defs>

        {/* Fon - yumaloq burchakli kvadrat, ilova ikonkasi uslubida */}
        <Rect x="0" y="0" width="100" height="100" rx="24" fill="url(#bgGrad)" />

        {/* Joylashuv nishoni (pin) shakli */}
        <Path
          d="M50 18 C36 18 25 29 25 43 C25 62 50 82 50 82 C50 82 75 62 75 43 C75 29 64 18 50 18 Z"
          fill="url(#pinGrad)"
        />

        {/* Pin ichida: kesishgan ikkita asbob (kalit turi) - "usta/ta'mirlash" ramzi.
            Oddiy geometrik shakllardan yasalgan, shuning uchun har qanday o'lchamda tiniq ko'rinadi. */}
        <Rect x="34" y="41.5" width="32" height="6" rx="3" fill={colors.accent} transform="rotate(45 50 44.5)" />
        <Rect x="34" y="41.5" width="32" height="6" rx="3" fill={colors.primaryDark} transform="rotate(-45 50 44.5)" />
        <Circle cx="38" cy="33" r="5.5" fill={colors.accent} />
        <Circle cx="38" cy="33" r="2.2" fill="#FFFFFF" />
        <Circle cx="62" cy="33" r="5.5" fill={colors.primaryDark} />
        <Circle cx="62" cy="33" r="2.2" fill="#FFFFFF" />
      </Svg>
    </View>
  );
}

/**
 * To'liq logotip: ikonka + "UstaTop" so'zi.
 * `light` — och fon ustida (default: qorong'i/gradient fon uchun oq matn)
 */
export default function Logo({ size = 88, showText = true, light = true, textSize = 30 }) {
  return (
    <View style={styles.row}>
      <LogoMark size={size} />
      {showText && (
        <View style={styles.textWrap}>
          <Text style={[styles.wordmark, { fontSize: textSize, color: light ? colors.white : colors.primaryDark }]}>
            Usta<Text style={{ color: colors.accent }}>Top</Text>
          </Text>
          <Text style={[styles.tagline, { color: light ? 'rgba(255,255,255,0.85)' : colors.textSecondary }]}>
            Kerakli ustani toping
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  textWrap: {
    marginTop: 10,
    alignItems: 'center',
  },
  wordmark: {
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  tagline: {
    fontSize: 13,
    marginTop: 2,
    fontWeight: '500',
  },
});
