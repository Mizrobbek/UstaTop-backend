import React, { useState } from 'react';
import { View, TextInput, Text, StyleSheet, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';

/**
 * Parol maydoni. O'ng tomonida ko'z ikonkasi bor - bosilganda parol matni
 * ochiq/yashirin holatga almashadi (foydalanuvchi so'ragan asosiy talab).
 */
export default function PasswordInput({
  label = 'Parol',
  value,
  onChangeText,
  placeholder = 'Parolingizni kiriting',
  error,
  returnKeyType,
  onSubmitEditing,
  editable = true,
}) {
  const [visible, setVisible] = useState(false);

  return (
    <View style={styles.wrap}>
      {label && <Text style={styles.label}>{label}</Text>}
      <View style={[styles.inputRow, error && styles.inputRowError]}>
        <Ionicons name="lock-closed-outline" size={19} color={colors.textMuted} style={styles.icon} />
        <TextInput
          style={styles.input}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.placeholder}
          secureTextEntry={!visible}
          autoCapitalize="none"
          autoCorrect={false}
          returnKeyType={returnKeyType}
          onSubmitEditing={onSubmitEditing}
          editable={editable}
        />
        <Pressable
          onPress={() => setVisible((v) => !v)}
          hitSlop={10}
          style={styles.eyeButton}
          accessibilityLabel={visible ? 'Parolni yashirish' : 'Parolni ko\'rsatish'}
        >
          <Ionicons name={visible ? 'eye-off-outline' : 'eye-outline'} size={21} color={colors.textSecondary} />
        </Pressable>
      </View>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { marginBottom: 16, width: '100%' },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: 6,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: 14,
    paddingHorizontal: 14,
    height: 52,
  },
  inputRowError: {
    borderColor: colors.error,
  },
  icon: { marginRight: 8 },
  input: {
    flex: 1,
    fontSize: 15.5,
    color: colors.textPrimary,
    height: '100%',
  },
  eyeButton: {
    paddingLeft: 8,
    paddingVertical: 6,
  },
  errorText: {
    color: colors.error,
    fontSize: 12.5,
    marginTop: 5,
    marginLeft: 2,
  },
});
