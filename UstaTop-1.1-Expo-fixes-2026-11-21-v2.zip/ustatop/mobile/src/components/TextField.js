import React from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';

export default function TextField({
  label,
  icon,
  prefix,
  error,
  value,
  onChangeText,
  placeholder,
  keyboardType = 'default',
  autoCapitalize = 'none',
  style,
  ...rest
}) {
  return (
    <View style={styles.wrap}>
      {label && <Text style={styles.label}>{label}</Text>}
      <View style={[styles.inputRow, error && styles.inputRowError, style && { height: undefined, alignItems: 'flex-start' }]}>
        {icon && <Ionicons name={icon} size={19} color={colors.textMuted} style={styles.icon} />}
        {prefix ? <Text style={styles.prefix}>{prefix}</Text> : null}
        <TextInput
          style={[styles.input, style]}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.placeholder}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
          {...rest}
        />
      </View>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { marginBottom: 16, width: '100%' },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: 6,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: 14,
    paddingHorizontal: 14,
    height: 52,
  },
  inputRowError: {
    borderColor: colors.error,
  },
  icon: { marginRight: 8 },
  prefix: { color: colors.textPrimary, fontSize: 15.5, fontWeight: '700', marginRight: 8 },
  input: {
    flex: 1,
    fontSize: 15.5,
    color: colors.textPrimary,
    height: '100%',
  },
  errorText: {
    color: colors.error,
    fontSize: 12.5,
    marginTop: 5,
    marginLeft: 2,
  },
});
