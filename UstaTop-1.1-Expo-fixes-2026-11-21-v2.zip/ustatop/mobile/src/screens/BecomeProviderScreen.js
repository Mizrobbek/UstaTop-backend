import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import TextField from '../components/TextField';
import PrimaryButton from '../components/PrimaryButton';
import { fetchCategories } from '../api/listings';
import { becomeProvider } from '../api/account';
import { getErrorMessage } from '../api/client';
import { getCategoryIcon } from '../utils/categoryIcons';

export default function BecomeProviderScreen({ navigation }) {
  const [categories, setCategories] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [bio, setBio] = useState('');
  const [experienceYears, setExperienceYears] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchCategories()
      .then(setCategories)
      .catch((err) => Alert.alert('Xatolik', getErrorMessage(err)));
  }, []);

  function toggleCategory(id) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
    if (error) setError(null);
  }

  async function handleSubmit() {
    if (selectedIds.length === 0) {
      setError('Kamida bitta xizmat turini tanlang');
      return;
    }
    setLoading(true);
    try {
      await becomeProvider({
        bio: bio.trim() || undefined,
        experienceYears: experienceYears ? Number(experienceYears) : 0,
        categoryIds: selectedIds,
      });
      Alert.alert('Ariza qabul qilindi', 'Usta profilingiz yaratildi. Taklif yuborish uchun MyID orqali shaxsingizni tasdiqlashingiz kerak. Tasdiqlashgacha mijoz sifatida foydalanishingiz mumkin.', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Usta bo'lish</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 48 }}>
        <Text style={styles.intro}>
          Xizmat ko'rsatadigan sohalaringizni tanlang. Mijozlar sizni shu kategoriyalar bo'yicha topadi.
        </Text>

        <Text style={styles.label}>Xizmat turlari</Text>
        {error && <Text style={styles.errorText}>{error}</Text>}
        <View style={styles.categoryGrid}>
          {categories.map((cat) => {
            const active = selectedIds.includes(cat.id);
            return (
              <Pressable
                key={cat.id}
                style={[styles.categoryChip, active && styles.categoryChipActive]}
                onPress={() => toggleCategory(cat.id)}
              >
                <Ionicons name={getCategoryIcon(cat.icon)} size={16} color={active ? colors.white : colors.primary} />
                <Text style={[styles.categoryChipText, active && { color: colors.white }]}>{cat.name_uz}</Text>
              </Pressable>
            );
          })}
        </View>

        <TextField
          label="Tajribangiz (yil)"
          placeholder="5"
          value={experienceYears}
          onChangeText={(t) => setExperienceYears(t.replace(/\D/g, ''))}
          keyboardType="number-pad"
        />

        <TextField
          label="O'zingiz haqingizda (ixtiyoriy)"
          placeholder="Tajribangiz, ixtisosligingiz haqida qisqacha yozing..."
          value={bio}
          onChangeText={setBio}
          multiline
          numberOfLines={4}
          style={{ height: 100, textAlignVertical: 'top', paddingTop: 12 }}
        />

        <PrimaryButton title="Tasdiqlash" onPress={handleSubmit} loading={loading} style={{ marginTop: 12 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 54,
    paddingBottom: 14,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.textPrimary },
  intro: { fontSize: 13.5, color: colors.textSecondary, lineHeight: 20, marginBottom: 20 },
  label: { fontSize: 13, fontWeight: '600', color: colors.textSecondary, marginBottom: 8 },
  errorText: { color: colors.error, fontSize: 12.5, marginBottom: 6 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 20,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  categoryChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  categoryChipText: { fontSize: 12.5, fontWeight: '600', color: colors.textPrimary },
});
