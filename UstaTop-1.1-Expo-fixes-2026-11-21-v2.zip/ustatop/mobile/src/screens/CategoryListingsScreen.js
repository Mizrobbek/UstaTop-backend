import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import TextField from '../components/TextField';
import ListingCard from '../components/ListingCard';
import { fetchListings } from '../api/listings';
import { getErrorMessage } from '../api/client';

export default function CategoryListingsScreen({ navigation, route }) {
  const category = route.params?.category || null;
  const [search, setSearch] = useState('');
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const load = useCallback(
    async (pageToLoad = 1, searchTerm = search) => {
      try {
        const data = await fetchListings({
          categoryId: category?.id,
          search: searchTerm || undefined,
          page: pageToLoad,
          limit: 15,
        });
        setListings((prev) => (pageToLoad === 1 ? data.listings : [...prev, ...data.listings]));
        setHasMore(pageToLoad < data.pagination.totalPages);
        setPage(pageToLoad);
      } catch (err) {
        Alert.alert('Xatolik', getErrorMessage(err));
      }
    },
    [category?.id, search]
  );

  useEffect(() => {
    setLoading(true);
    load(1).finally(() => setLoading(false));
  }, [category?.id]);

  function handleSearchSubmit() {
    setLoading(true);
    load(1, search).finally(() => setLoading(false));
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle} numberOfLines={1}>
          {category ? category.name_uz : 'Barcha e\'lonlar'}
        </Text>
        <View style={{ width: 26 }} />
      </View>

      <View style={styles.searchWrap}>
        <TextField
          icon="search-outline"
          placeholder="E'lonlarni qidirish..."
          value={search}
          onChangeText={setSearch}
          returnKeyType="search"
          onSubmitEditing={handleSearchSubmit}
        />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={listings}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 20, paddingTop: 0 }}
          renderItem={({ item }) => (
            <ListingCard listing={item} onPress={() => navigation.navigate('ListingDetail', { listingId: item.id })} />
          )}
          onEndReachedThreshold={0.4}
          onEndReached={() => hasMore && load(page + 1)}
          ListEmptyComponent={<Text style={styles.emptyText}>Bu bo'yicha hozircha e'lonlar topilmadi</Text>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 54,
    paddingBottom: 14,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.textPrimary, flex: 1, textAlign: 'center' },
  searchWrap: { paddingHorizontal: 20, paddingTop: 16 },
  emptyText: { textAlign: 'center', color: colors.textMuted, marginTop: 40 },
});
