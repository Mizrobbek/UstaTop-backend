import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
  Image,
  Linking,
  Modal,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import colors from '../theme/colors';
import { fetchMessages, sendMessageRequest } from '../api/chat';
import { getSocket, joinChatRoom, leaveChatRoom } from '../api/socket';
import { getErrorMessage, getStoredUser } from '../api/client';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { uploadMedia } from '../api/account';

function formatTime(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' });
}

export default function ChatScreen({ navigation, route }) {
  const { chatId, otherUserName, listingTitle } = route.params;
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [attachmentOpen, setAttachmentOpen] = useState(false);
  const [currentUserId, setCurrentUserId] = useState(null);
  const listRef = useRef(null);
  const socketRef = useRef(null);

  const handleIncomingMessage = useCallback(
    (message) => {
      if (message.chatId !== chatId) return;
      setMessages((prev) => {
        if (prev.some((m) => m.id === message.id)) return prev;
        return [...prev, message];
      });
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    },
    [chatId]
  );

  // Xabarlar tarixi va Socket.IO ulanishini xavfsiz boshqarish.
  useEffect(() => {
    let isMounted = true;
    let activeSocket = null;

    async function initializeChat() {
      try {
        const [user, data] = await Promise.all([
          getStoredUser(),
          fetchMessages(chatId),
        ]);
        if (!isMounted) return;
        setCurrentUserId(user?.id || null);
        setMessages(Array.isArray(data?.messages) ? data.messages : []);
      } catch (err) {
        if (isMounted) Alert.alert('Xatolik', getErrorMessage(err));
      } finally {
        if (isMounted) setLoading(false);
      }

      try {
        const socket = await getSocket();
        if (!socket || !isMounted) return;
        activeSocket = socket;
        socketRef.current = socket;
        joinChatRoom(chatId);
        socket.on('message:new', handleIncomingMessage);
      } catch (err) {
        // REST chat ishlashda davom etadi; Socket.IO uzilishi xabar yuborishni to'xtatmasin.
      }
    }

    initializeChat();

    return () => {
      isMounted = false;
      if (activeSocket) {
        activeSocket.off('message:new', handleIncomingMessage);
        leaveChatRoom(chatId);
      }
      if (socketRef.current === activeSocket) socketRef.current = null;
    };
  }, [chatId, handleIncomingMessage]);

  async function handleSend() {
    const content = text.trim();
    if (!content || sending) return;
    setSending(true);
    setText('');
    try {
      const message = await sendMessageRequest(chatId, { content });
      // Socket orqali ham qaytib kelishi mumkin (o'ziga yubormaydi odatda),
      // shuning uchun REST javobidan darhol UI'ga qo'shamiz - tezkor his qildiradi
      setMessages((prev) => (prev.some((m) => m.id === message.id) ? prev : [...prev, message]));
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
      setText(content); // xato bo'lsa, matnni qaytarib beramiz
    } finally {
      setSending(false);
    }
  }

  async function uploadAndSendAttachment(asset, fallbackType = 'application/octet-stream') {
    setSending(true);
    try {
      const name = asset.fileName || asset.name || `chat-${Date.now()}`;
      const extension = name.includes('.') ? name.split('.').pop().toLowerCase() : '';
      const mimeByExtension = { mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', wav: 'audio/wav', ogg: 'audio/ogg', amr: 'audio/amr', mp4: 'video/mp4', mov: 'video/quicktime', pdf: 'application/pdf', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', txt: 'text/plain', csv: 'text/csv' };
      const mimeType = asset.mimeType || asset.type || mimeByExtension[extension] || fallbackType;
      const uploaded = await uploadMedia([{
        uri: asset.uri,
        name,
        type: mimeType,
      }]);
      const message = await sendMessageRequest(chatId, { mediaUrl: uploaded[0].url });
      setMessages((prev) => (prev.some((m) => m.id === message.id) ? prev : [...prev, message]));
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (err) {
      Alert.alert('Fayl yuborilmadi', getErrorMessage(err));
    } finally {
      setSending(false);
    }
  }

  async function handleChoosePhotoOrVideo() {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images', 'videos'],
        allowsMultipleSelection: false,
        quality: 0.85,
      });
      if (result.canceled || !result.assets?.length) return;
      const asset = result.assets[0];
      const isVideo = asset.type === 'video' || asset.mimeType?.startsWith('video/');
      await uploadAndSendAttachment({
        ...asset,
        name: asset.fileName || `chat-${Date.now()}.${isVideo ? 'mp4' : 'jpg'}`,
        mimeType: asset.mimeType || (isVideo ? 'video/mp4' : 'image/jpeg'),
      });
    } catch (err) {
      Alert.alert('Fayl tanlanmadi', getErrorMessage(err));
    }
  }

  async function handleChooseAudioOrDocument() {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['audio/*', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'text/plain', 'text/csv'],
        multiple: false,
        copyToCacheDirectory: true,
      });
      if (result.canceled || !result.assets?.length) return;
      await uploadAndSendAttachment(result.assets[0]);
    } catch (err) {
      Alert.alert('Fayl tanlanmadi', getErrorMessage(err));
    }
  }

  function handleAttachMedia() { if (!sending) setAttachmentOpen(true); }
  function chooseAttachment(kind) {
    setAttachmentOpen(false);
    setTimeout(() => kind === 'media' ? handleChoosePhotoOrVideo() : handleChooseAudioOrDocument(), 180);
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <StatusBar barStyle="light-content" backgroundColor="#0F766E" />
      <LinearGradient colors={['#0F766E', '#115E59']} style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10} style={styles.backButton}>
          <Ionicons name="chevron-back" size={23} color="#FFFFFF" />
        </Pressable>
        <View style={styles.headerAvatar}><Text style={styles.headerAvatarText}>{(otherUserName || 'U')[0].toUpperCase()}</Text></View>
        <View style={{ flex: 1, marginLeft: 10 }}>
          <Text style={styles.headerName} numberOfLines={1}>{otherUserName || 'Suhbat'}</Text>
          <Text style={styles.headerSubtitle} numberOfLines={1}>{listingTitle || 'UstaTop orqali muloqot'}</Text>
        </View>
        <View style={styles.headerSecure}><Ionicons name="shield-checkmark-outline" size={17} color="#D1FAE5" /></View>
      </LinearGradient>

      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={(item) => item.id}
        style={styles.messageList}
        contentContainerStyle={{ paddingHorizontal: 15, paddingTop: 18, paddingBottom: 20, flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
        renderItem={({ item }) => {
          const isMine = item.senderId === currentUserId;
          return (
            <View style={[styles.bubbleRow, isMine && styles.bubbleRowMine]}>
              <View style={[styles.bubble, isMine ? styles.bubbleMine : styles.bubbleTheirs]}>
                {item.content ? (
                  <Text style={[styles.bubbleText, isMine && styles.bubbleTextMine]}>{item.content}</Text>
                ) : null}
                {item.mediaUrl ? (
                  /\.(jpe?g|png|webp|heic)(\?|$)/i.test(item.mediaUrl) ? (
                    <Image source={{ uri: item.mediaUrl }} style={styles.messageImage} resizeMode="cover" />
                  ) : (
                    <Pressable onPress={() => Linking.openURL(item.mediaUrl)} style={styles.attachmentLink}>
                      <Ionicons name={/\.(mp3|m4a|aac|wav|ogg|amr)(\?|$)/i.test(item.mediaUrl) ? 'musical-notes-outline' : /\.(mp4|mov|3gp|webm)(\?|$)/i.test(item.mediaUrl) ? 'play-circle-outline' : 'document-text-outline'} size={19} color={isMine ? colors.white : colors.primary} />
                      <Text style={[styles.attachmentText, isMine && styles.bubbleTextMine]}>{/\.(mp3|m4a|aac|wav|ogg|amr)(\?|$)/i.test(item.mediaUrl) ? 'Audio faylni ochish' : /\.(mp4|mov|3gp|webm)(\?|$)/i.test(item.mediaUrl) ? 'Videoni ochish' : 'Hujjatni ochish'}</Text>
                    </Pressable>
                  )
                ) : null}
                <Text style={[styles.bubbleTime, isMine && styles.bubbleTimeMine]}>{formatTime(item.createdAt)}</Text>
              </View>
            </View>
          );
        }}
        ListEmptyComponent={<Text style={styles.emptyText}>Suhbatni boshlash uchun xabar yozing 👋</Text>}
      />

      <View style={styles.inputRow}>
        <Pressable style={styles.attachButton} onPress={handleAttachMedia} disabled={sending}>
          <Ionicons name="add" size={24} color={colors.white} />
        </Pressable>
        <TextInput
          style={styles.input}
          value={text}
          onChangeText={setText}
          placeholder="Xabar yozing..."
          placeholderTextColor={colors.placeholder}
          multiline
        />
        <Pressable
          style={[styles.sendButton, (!text.trim() || sending) && { opacity: 0.5 }]}
          onPress={handleSend}
          disabled={!text.trim() || sending}
        >
          <Ionicons name="send" size={19} color={colors.white} />
        </Pressable>
      </View>
      <Modal visible={attachmentOpen} transparent animationType="slide" onRequestClose={() => setAttachmentOpen(false)}>
        <Pressable style={styles.sheetBackdrop} onPress={() => setAttachmentOpen(false)}>
          <Pressable style={styles.attachmentSheet} onPress={() => {}}>
            <View style={styles.sheetHandle} /><Text style={styles.sheetTitle}>Fayl biriktirish</Text>
            <View style={styles.attachmentOptions}>
              <Pressable style={styles.attachmentOption} onPress={() => chooseAttachment('media')}>
                <View style={[styles.attachmentIcon, { backgroundColor: '#E0F2FE' }]}><Ionicons name="images-outline" size={25} color="#0284C7" /></View>
                <Text style={styles.attachmentLabel}>Foto yoki video</Text>
              </Pressable>
              <Pressable style={styles.attachmentOption} onPress={() => chooseAttachment('document')}>
                <View style={[styles.attachmentIcon, { backgroundColor: '#EDE9FE' }]}><Ionicons name="document-text-outline" size={25} color="#7C3AED" /></View>
                <Text style={styles.attachmentLabel}>Audio / hujjat</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  messageList: { flex: 1, backgroundColor: '#F2F7F7' },
  header: {
    flexDirection: 'row', alignItems: 'center', paddingTop: 52, paddingBottom: 15,
    paddingHorizontal: 15, borderBottomLeftRadius: 20, borderBottomRightRadius: 20,
  },
  backButton: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.16)', alignItems: 'center', justifyContent: 'center' },
  headerAvatar: { width: 40, height: 40, borderRadius: 20, marginLeft: 9, backgroundColor: '#D1FAE5', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: 'rgba(255,255,255,0.55)' },
  headerAvatarText: { color: '#0F766E', fontSize: 16, fontWeight: '900' },
  headerName: { fontSize: 15.5, fontWeight: '800', color: '#FFFFFF' },
  headerSubtitle: { fontSize: 11, color: 'rgba(255,255,255,0.78)', marginTop: 3 },
  headerSecure: { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.13)', alignItems: 'center', justifyContent: 'center' },
  bubbleRow: { flexDirection: 'row', marginBottom: 10 },
  bubbleRowMine: { justifyContent: 'flex-end' },
  bubble: { maxWidth: '82%', borderRadius: 20, paddingHorizontal: 15, paddingVertical: 11, shadowColor: '#0F172A', shadowOpacity: 0.05, shadowRadius: 5, elevation: 1 },
  bubbleTheirs: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', borderTopLeftRadius: 5 },
  bubbleMine: { backgroundColor: '#0F766E', borderTopRightRadius: 5 },
  bubbleText: { fontSize: 14.5, color: colors.textPrimary, lineHeight: 20 },
  bubbleTextMine: { color: colors.white },
  bubbleTime: { fontSize: 10.5, color: colors.textMuted, marginTop: 4, alignSelf: 'flex-end' },
  bubbleTimeMine: { color: 'rgba(255,255,255,0.75)' },
  emptyText: { textAlign: 'center', color: colors.textMuted, marginTop: 60 },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 13, paddingTop: 11, paddingBottom: Platform.OS === 'android' ? 10 : 18,
    gap: 9, backgroundColor: '#FFFFFF', borderTopWidth: 1, borderTopColor: '#E5EEEE',
  },
  attachButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#0F766E', alignItems: 'center', justifyContent: 'center' },
  messageImage: { width: 210, height: 170, borderRadius: 10, marginTop: 4 },
  attachmentLink: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 5 },
  attachmentText: { color: colors.primary, fontSize: 13, fontWeight: '600' },
  input: {
    flex: 1,
    backgroundColor: '#F2F7F7',
    borderRadius: 22,
    paddingHorizontal: 17,
    paddingVertical: 11,
    maxHeight: 100,
    fontSize: 14.5,
    color: colors.textPrimary,
    borderWidth: 1,
    borderColor: '#E0EBE9',
  },
  sheetBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(15,23,42,0.38)' },
  attachmentSheet: { backgroundColor: '#FFFFFF', paddingHorizontal: 22, paddingTop: 12, paddingBottom: 34, borderTopLeftRadius: 26, borderTopRightRadius: 26 },
  sheetHandle: { width: 42, height: 4, borderRadius: 3, backgroundColor: '#CBD5E1', alignSelf: 'center', marginBottom: 18 },
  sheetTitle: { color: '#0F172A', fontSize: 17, fontWeight: '800', marginBottom: 18 },
  attachmentOptions: { flexDirection: 'row', gap: 16 },
  attachmentOption: { alignItems: 'center', width: 112, gap: 9 },
  attachmentIcon: { width: 62, height: 62, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  attachmentLabel: { color: '#334155', fontSize: 12, fontWeight: '600', textAlign: 'center' },
  sendButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
