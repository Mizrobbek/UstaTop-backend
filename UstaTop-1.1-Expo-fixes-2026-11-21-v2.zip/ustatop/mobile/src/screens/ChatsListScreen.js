import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator, Alert, RefreshControl } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import { fetchChats } from '../api/chat';
import { getErrorMessage } from '../api/client';

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const diffMs = Date.now() - new Date(dateStr).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 1) return 'hozir';
  if (minutes < 60) return `${minutes}d`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}s`;
  return `${Math.floor(hours / 24)}kun`;
}


function groupChatsByPerson(chats) {
  const groups = new Map();
  for (const chat of chats) {
    const personId = chat.otherUser?.id || chat.id;
    if (!groups.has(personId)) {
      groups.set(personId, { personId, otherUser: chat.otherUser, chats: [], unreadCount: 0 });
    }
    const group = groups.get(personId);
    group.chats.push(chat);
    group.unreadCount += Number(chat.unreadCount || 0);
  }

  return [...groups.values()]
    .map((group) => ({
      ...group,
      chats: group.chats.sort(
        (a, b) => new Date(b.lastMessageAt || b.createdAt) - new Date(a.lastMessageAt || a.createdAt)
      ),
    }))
    .sort((a, b) => {
      const aLatest = a.chats[0];
      const bLatest = b.chats[0];
      return new Date(bLatest.lastMessageAt || bLatest.createdAt) - new Date(aLatest.lastMessageAt || aLatest.createdAt);
    });
}

export default function ChatsListScreen({ navigation }) {
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [expandedUserId, setExpandedUserId] = useState(null);

  const load = useCallback(async ({ showError = true } = {}) => {
    try {
      const data = await fetchChats();
      setChats(groupChatsByPerson(Array.isArray(data) ? data : []));
    } catch (err) {
      if (showError) Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  // Ekran ochilganda va suhbatdan qaytilganda faqat bitta so'rov yuboriladi.
  useFocusEffect(
    useCallback(() => {
      load({ showError: true });
      return undefined;
    }, [load])
  );

  async function handleRefresh() {
    setRefreshing(true);
    try {
      await load();
    } finally {
      setRefreshing(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Suhbatlar</Text>
      </View>

      <FlatList
        data={chats}
        keyExtractor={(item) => item.personId}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[colors.primary]} />}
        contentContainerStyle={{ padding: 16, flexGrow: 1 }}
        renderItem={({ item }) => {
          const latest = item.chats[0];
          const isExpanded = expandedUserId === item.personId;
          const openChat = (chat) =>
            navigation.navigate('Chat', {
              chatId: chat.id,
              otherUserName: item.otherUser.fullName,
              listingTitle: chat.listingTitle,
            });

          return (
            <View style={styles.groupCard}>
              <Pressable
                style={({ pressed }) => [styles.chatRow, pressed && { opacity: 0.7 }]}
                onPress={() => {
                  if (item.chats.length > 1) {
                    setExpandedUserId(isExpanded ? null : item.personId);
                  } else {
                    openChat(latest);
                  }
                }}
              >
                <View style={styles.avatar}>
                  <Text style={styles.avatarInitial}>{item.otherUser.fullName?.[0] || '?'}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <View style={styles.rowTop}>
                    <Text style={styles.name} numberOfLines={1}>{item.otherUser.fullName}</Text>
                    <Text style={styles.time}>{timeAgo(latest.lastMessageAt || latest.createdAt)}</Text>
                  </View>
                  {item.chats.length > 1 ? (
                    <Text style={styles.listingTitle}>{item.chats.length} ta e'lon bo'yicha suhbat</Text>
                  ) : latest.listingTitle ? (
                    <Text style={styles.listingTitle} numberOfLines={1}>{latest.listingTitle}</Text>
                  ) : null}
                  <Text style={[styles.lastMessage, item.unreadCount > 0 && styles.lastMessageUnread]} numberOfLines={1}>
                    {latest.lastMessage || 'Suhbatni boshlang...'}
                  </Text>
                </View>
                {item.unreadCount > 0 && (
                  <View style={styles.unreadBadge}>
                    <Text style={styles.unreadBadgeText}>{item.unreadCount}</Text>
                  </View>
                )}
                {item.chats.length > 1 && (
                  <Ionicons name={isExpanded ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textMuted} />
                )}
              </Pressable>

              {isExpanded && item.chats.map((chat) => (
                <Pressable key={chat.id} style={styles.nestedChat} onPress={() => openChat(chat)}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.nestedTitle} numberOfLines={1}>{chat.listingTitle || 'E’lon bo‘yicha suhbat'}</Text>
                    <Text style={[styles.lastMessage, chat.unreadCount > 0 && styles.lastMessageUnread]} numberOfLines={1}>
                      {chat.lastMessage || 'Suhbatni boshlang...'}
                    </Text>
                  </View>
                  <Text style={styles.time}>{timeAgo(chat.lastMessageAt || chat.createdAt)}</Text>
                  {chat.unreadCount > 0 && (
                    <View style={styles.unreadBadge}>
                      <Text style={styles.unreadBadgeText}>{chat.unreadCount}</Text>
                    </View>
                  )}
                </Pressable>
              ))}
            </View>
          );
        }}
        ListEmptyComponent={
          <View style={styles.emptyWrap}>
            <Ionicons name="chatbubbles-outline" size={48} color={colors.textMuted} />
            <Text style={styles.emptyText}>Hozircha suhbatlaringiz yo'q</Text>
            <Text style={styles.emptySubtext}>Usta taklif yuborgach, qabul qilishdan oldin ham chatda kelishishingiz mumkin.</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  header: {
    paddingTop: 54,
    paddingBottom: 16,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 20, fontWeight: '800', color: colors.textPrimary },
  groupCard: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  chatRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
  },
  nestedChat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 11,
    paddingHorizontal: 16,
    marginLeft: 58,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  nestedTitle: { fontSize: 12.5, fontWeight: '700', color: colors.primary, flex: 1 },
  avatar: {
    width: 48, height: 48, borderRadius: 24, backgroundColor: colors.primaryLight,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarInitial: { color: colors.white, fontWeight: '800', fontSize: 18 },
  rowTop: { flexDirection: 'row', justifyContent: 'space-between' },
  name: { fontSize: 15, fontWeight: '700', color: colors.textPrimary, flex: 1 },
  time: { fontSize: 11.5, color: colors.textMuted, marginLeft: 8 },
  listingTitle: { fontSize: 12, color: colors.primary, fontWeight: '600', marginTop: 1 },
  lastMessage: { fontSize: 13, color: colors.textMuted, marginTop: 3 },
  lastMessageUnread: { color: colors.textPrimary, fontWeight: '600' },
  unreadBadge: {
    minWidth: 22, height: 22, borderRadius: 11, backgroundColor: colors.accent,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6,
  },
  unreadBadgeText: { color: colors.white, fontSize: 11.5, fontWeight: '700' },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80 },
  emptyText: { fontSize: 15, fontWeight: '700', color: colors.textSecondary, marginTop: 14 },
  emptySubtext: { fontSize: 13, color: colors.textMuted, marginTop: 4, textAlign: 'center', paddingHorizontal: 40 },
});
