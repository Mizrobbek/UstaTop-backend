import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Switch, Image,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import TextField from '../components/TextField';
import PrimaryButton from '../components/PrimaryButton';
import { fetchCategories, createListing, updateListing } from '../api/listings';
import { getErrorMessage } from '../api/client';
import { uploadMedia } from '../api/account';
import { getCategoryIcon } from '../utils/categoryIcons';

export default function CreateListingScreen({ navigation, route }) {
  const editingListing = route.params?.listing || null;
  const [categories, setCategories] = useState([]);
  const [categoryId, setCategoryId] = useState(editingListing?.categoryId || route.params?.category?.id || null);
  const [title, setTitle] = useState(editingListing?.title || '');
  const [description, setDescription] = useState(editingListing?.description || '');
  const [price, setPrice] = useState(editingListing?.price != null ? String(editingListing.price) : '');
  const [negotiable, setNegotiable] = useState(editingListing?.priceType !== 'fixed');
  const [address, setAddress] = useState(editingListing?.address || '');
  const [location, setLocation] = useState(
    editingListing?.latitude != null && editingListing?.longitude != null
      ? { latitude: Number(editingListing.latitude), longitude: Number(editingListing.longitude) }
      : null
  ); // { latitude, longitude } | null
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [media, setMedia] = useState(editingListing?.media || []);
  const [uploadingMedia, setUploadingMedia] = useState(false);

  useEffect(() => {
    fetchCategories()
      .then(setCategories)
      .catch((err) => Alert.alert('Xatolik', getErrorMessage(err)));
  }, []);

  function validate() {
    const next = {};
    if (!categoryId) next.category = 'Kategoriyani tanlang';
    if (!title.trim() || title.trim().length < 5) next.title = 'Sarlavha kamida 5 ta belgidan iborat bo\'lishi kerak';
    if (!description.trim() || description.trim().length < 10)
      next.description = 'Tavsif kamida 10 ta belgidan iborat bo\'lishi kerak';
    if (!negotiable && (!price || Number(price) <= 0)) next.price = 'Narxni kiriting yoki "Kelishamiz"ni tanlang';
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function chooseListingImages() {
    try {
      const permission=await ImagePicker.requestMediaLibraryPermissionsAsync(); if(!permission.granted) return Alert.alert('Ruxsat kerak','Galereyaga ruxsat bering.');
      const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],allowsMultipleSelection:true,selectionLimit:10,quality:0.85}); if(result.canceled||!result.assets?.length)return;
      setUploadingMedia(true); const files=await uploadMedia(result.assets.map((a,i)=>({uri:a.uri,name:a.fileName||`listing-${Date.now()}-${i}.jpg`,type:a.mimeType||'image/jpeg'}))); setMedia(v=>[...v,...files.map(f=>f.url)].slice(0,10));
    } catch(e){Alert.alert('Rasm yuklash xatosi',getErrorMessage(e));} finally{setUploadingMedia(false);}
  }
  async function handleSubmit() {
    if (!validate()) return;
    setLoading(true);
    try {
      const payload = {
        categoryId,
        title: title.trim(),
        description: description.trim(),
        priceType: negotiable ? 'negotiable' : 'fixed',
        price: negotiable ? null : Number(price),
        address: address.trim() || location?.address || null,
        latitude: location?.latitude ?? null,
        longitude: location?.longitude ?? null,
        mediaUrls: media,
      };

      if (editingListing) {
        await updateListing(editingListing.id, payload);
        Alert.alert('Muvaffaqiyat!', 'E\'loningiz yangilandi', [
          {
            text: 'OK',
            onPress: () => navigation.navigate('ListingDetail', {
              listingId: editingListing.id,
              refreshKey: Date.now(),
            }),
          },
        ]);
      } else {
        await createListing(payload);
        Alert.alert('Muvaffaqiyat!', 'E\'loningiz muvaffaqiyatli joylandi', [
          { text: 'OK', onPress: () => navigation.goBack() },
        ]);
      }
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>{editingListing ? "E'lonni tahrirlash" : "Yangi e'lon"}</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Text style={styles.label}>Kategoriya</Text>
        {errors.category && <Text style={styles.errorText}>{errors.category}</Text>}
        <View style={styles.categoryRow}>
          {categories.map((cat) => (
            <Pressable
              key={cat.id}
              style={[styles.categoryChip, categoryId === cat.id && styles.categoryChipActive]}
              onPress={() => {
                setCategoryId(cat.id);
                setErrors((e) => ({ ...e, category: null }));
              }}
            >
              <Ionicons
                name={getCategoryIcon(cat.icon)}
                size={16}
                color={categoryId === cat.id ? colors.white : colors.primary}
              />
              <Text style={[styles.categoryChipText, categoryId === cat.id && { color: colors.white }]}>
                {cat.name_uz}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text style={styles.label}>E'lon rasmlari (10 tagacha)</Text>
        <Pressable style={styles.mediaButton} onPress={chooseListingImages} disabled={uploadingMedia}><Ionicons name="images-outline" size={20} color={colors.primary}/><Text style={styles.mapPickerText}>{uploadingMedia?'Rasmlar yuklanmoqda...':'Galereyadan rasm tanlash'}</Text></Pressable>
        <View style={styles.mediaPreview}>{media.map((uri,index)=><View key={`${uri}-${index}`}><Image source={{uri}} style={styles.previewImage}/><Pressable onPress={()=>setMedia(v=>v.filter((_,i)=>i!==index))} style={styles.removeMedia}><Ionicons name="close-circle" size={22} color="#dc2626"/></Pressable></View>)}</View>
        <TextField
          label="Sarlavha"
          placeholder="Masalan: Kranni tamirlash kerak"
          value={title}
          onChangeText={(t) => {
            setTitle(t);
            if (errors.title) setErrors((e) => ({ ...e, title: null }));
          }}
          error={errors.title}
        />

        <TextField
          label="Tavsif"
          placeholder="Muammoni batafsil yozing: qayerda, qachon, nima bo'ldi..."
          value={description}
          onChangeText={(t) => {
            setDescription(t);
            if (errors.description) setErrors((e) => ({ ...e, description: null }));
          }}
          error={errors.description}
          multiline
          numberOfLines={4}
          style={{ height: 100, textAlignVertical: 'top', paddingTop: 12 }}
        />

        <View style={styles.switchRow}>
          <Text style={styles.switchLabel}>Narxni kelishamiz</Text>
          <Switch
            value={negotiable}
            onValueChange={setNegotiable}
            trackColor={{ false: colors.border, true: colors.primaryLight }}
            thumbColor={colors.white}
          />
        </View>

        {!negotiable && (
          <TextField
            label="Narx (so'm)"
            placeholder="150000"
            value={price}
            onChangeText={(t) => {
              setPrice(t.replace(/\D/g, ''));
              if (errors.price) setErrors((e) => ({ ...e, price: null }));
            }}
            error={errors.price}
            keyboardType="number-pad"
          />
        )}

        <TextField
          label="Manzil (ixtiyoriy)"
          icon="location-outline"
          placeholder="Toshkent, Chilonzor tumani"
          value={address}
          onChangeText={setAddress}
        />

        <Text style={styles.label}>Joylashuv xaritada (ixtiyoriy)</Text>
        <Pressable
          style={styles.mapPickerButton}
          onPress={() =>
            navigation.navigate('LocationPicker', {
              initialLocation: location,
              onSelect: (loc) => { setLocation(loc); if (loc.address && !address.trim()) setAddress(loc.address); },
            })
          }
        >
          <Ionicons
            name={location ? 'location' : 'map-outline'}
            size={20}
            color={location ? colors.accent : colors.primary}
          />
          <Text style={styles.mapPickerText}>
            {location
              ? `Belgilandi: ${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}`
              : 'Xaritadan joyni belgilash'}
          </Text>
          {location && (
            <Pressable onPress={() => setLocation(null)} hitSlop={8}>
              <Ionicons name="close-circle" size={20} color={colors.textMuted} />
            </Pressable>
          )}
        </Pressable>
        <Text style={styles.mapPickerHint}>
          Aniq joylashuv belgilansa, e'lon xarita bo'limida va yaqin ustolarga ko'rinadi
        </Text>

        <PrimaryButton title={editingListing ? 'Saqlash' : "E'lon berish"} onPress={handleSubmit} loading={loading} style={{ marginTop: 12 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 54,
    paddingBottom: 14,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.textPrimary },
  content: { padding: 20, paddingBottom: 48 },
  label: { fontSize: 13, fontWeight: '600', color: colors.textSecondary, marginBottom: 8 },
  errorText: { color: colors.error, fontSize: 12.5, marginBottom: 6 },
  categoryRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 20,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  categoryChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  categoryChipText: { fontSize: 12.5, fontWeight: '600', color: colors.textPrimary },
  mediaButton:{flexDirection:'row',alignItems:'center',gap:10,backgroundColor:colors.surface,borderWidth:1,borderColor:colors.border,borderRadius:12,padding:14,marginBottom:10}, mediaPreview:{flexDirection:'row',flexWrap:'wrap',gap:8,marginBottom:16}, previewImage:{width:76,height:76,borderRadius:8}, removeMedia:{position:'absolute',right:-5,top:-7,backgroundColor:'#fff',borderRadius:12},
  mapPickerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: colors.surface,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: 14,
    paddingHorizontal: 14,
    height: 52,
    marginBottom: 6,
  },
  mapPickerText: { flex: 1, fontSize: 14, color: colors.textPrimary, fontWeight: '600' },
  mapPickerHint: { fontSize: 12, color: colors.textMuted, marginBottom: 16 },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    paddingVertical: 4,
  },
  switchLabel: { fontSize: 14.5, fontWeight: '600', color: colors.textPrimary },
});
