import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert, KeyboardAvoidingView, Platform, Image, Pressable, ActivityIndicator } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import colors from '../theme/colors';
import TextField from '../components/TextField';
import PrimaryButton from '../components/PrimaryButton';
import { fetchMe, updateProfile } from '../api/account';
import { api, getErrorMessage } from '../api/client';
import { uploadMedia, requestPhoneChange, confirmPhoneChange } from '../api/account';
import { toE164Uzbek } from '../utils/phone';

export default function EditProfileScreen({ navigation }) {
  const [fullName, setFullName] = useState(''); const [city, setCity] = useState('');
  const [avatarUrl, setAvatarUrl] = useState(''); const [bio, setBio] = useState('');
  const [experienceYears, setExperienceYears] = useState('0'); const [phone,setPhone]=useState(''); const [otp,setOtp]=useState(''); const [otpSent,setOtpSent]=useState(false); const [isProvider, setIsProvider] = useState(false);
  const [loading, setLoading] = useState(false); const [uploading, setUploading] = useState(false);
  useEffect(() => { fetchMe().then((u) => { setFullName(u.fullName || ''); setPhone(u.phone || ''); setCity(u.city || ''); setAvatarUrl(u.avatarUrl || ''); setIsProvider(['provider','both'].includes(u.role)); setBio(u.providerProfile?.bio || ''); setExperienceYears(String(u.providerProfile?.experienceYears || 0)); }).catch((e) => Alert.alert('Xatolik', getErrorMessage(e))); }, []);
  async function chooseAvatar() {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) return Alert.alert('Ruxsat kerak', 'Profil rasmi uchun galereyaga ruxsat bering.');
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, aspect: [1,1], quality: 0.85 });
      if (result.canceled || !result.assets?.[0]) return;
      setUploading(true);
      const asset = result.assets[0];
      const files = await uploadMedia([{ uri: asset.uri, name: asset.fileName || 'avatar.jpg', type: asset.mimeType || 'image/jpeg' }]);
      setAvatarUrl(files[0].url);
    } catch (e) { Alert.alert('Yuklash xatosi', getErrorMessage(e)); } finally { setUploading(false); }
  }
  async function sendPhoneCode() { try { const normalized=toE164Uzbek(phone); await requestPhoneChange(normalized); setPhone(normalized); setOtpSent(true); Alert.alert('Kod yuborildi','SMS tasdiqlash kodini kiriting. Test muhitida SMS kodi backend konsolida ko‘rinadi.'); } catch(e){Alert.alert('Xatolik',getErrorMessage(e));} }
  async function verifyPhone() { try { const normalized=toE164Uzbek(phone); await confirmPhoneChange(normalized,otp); Alert.alert('Telefon yangilandi','Xavfsizlik uchun tizimdan chiqib, yangi raqam bilan qayta kiring.'); } catch(e){Alert.alert('Xatolik',getErrorMessage(e));} }
  async function save() {
    setLoading(true);
    try {
      await updateProfile({ fullName: fullName.trim(), city: city.trim(), ...(avatarUrl.trim() ? { avatarUrl: avatarUrl.trim() } : {}) });
      if (isProvider) await api.patch('/users/me/provider-profile', { bio, experienceYears: Number(experienceYears || 0) });
      Alert.alert('Saqlandi', 'Profil ma’lumotlari yangilandi', [{ text: 'OK', onPress: () => navigation.goBack() }]);
    } catch (e) { Alert.alert('Xatolik', getErrorMessage(e)); } finally { setLoading(false); }
  }
  return <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}><ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <Text style={styles.heading}>Profilni tahrirlash</Text>
    <Pressable onPress={chooseAvatar} style={styles.avatarPicker}>
      {avatarUrl ? <Image source={{ uri: avatarUrl }} style={styles.avatarImage} /> : <Text style={styles.avatarPlaceholder}>Rasm tanlash</Text>}
      {uploading ? <ActivityIndicator color={colors.primary} /> : <Text style={styles.avatarAction}>Profil rasmini yuklash</Text>}
    </Pressable>
    <TextField label="Ism va familiya" value={fullName} onChangeText={setFullName} autoCapitalize="words" />
    <TextField label="Telefon raqami (+998)" value={phone.replace(/^\+998/, '')} onChangeText={(v)=>setPhone(v)} keyboardType="phone-pad" placeholder="90 123 45 67" />
    <PrimaryButton title="Telefonni tasdiqlash kodini yuborish" onPress={sendPhoneCode} loading={loading || uploading} />
    {otpSent && <><TextField label="SMS kodi" value={otp} onChangeText={setOtp} keyboardType="number-pad"/><PrimaryButton title="Telefon raqamini tasdiqlash" onPress={verifyPhone}/></>}
    <TextField label="Shahar / tuman" value={city} onChangeText={setCity} placeholder="Toshkent" />
    <Text style={styles.hint}>Telefon raqami faqat SMS kodi tasdiqlangandan keyin almashtiriladi.</Text>
    {isProvider && <><TextField label="Men haqimda" value={bio} onChangeText={setBio} multiline numberOfLines={4} /><TextField label="Tajriba (yil)" value={experienceYears} onChangeText={(v) => setExperienceYears(v.replace(/\D/g, '').slice(0,2))} keyboardType="number-pad" /></>}
    <PrimaryButton title="Saqlash" onPress={save} loading={loading} />
  </ScrollView></KeyboardAvoidingView>;
}
const styles = StyleSheet.create({ container:{flex:1,backgroundColor:colors.background}, content:{padding:20,gap:12,paddingBottom:40}, avatarPicker:{alignItems:'center',gap:8,marginBottom:10}, avatarImage:{width:104,height:104,borderRadius:52,backgroundColor:colors.border}, avatarPlaceholder:{width:104,height:104,borderRadius:52,textAlign:'center',textAlignVertical:'center',backgroundColor:colors.border,color:colors.textPrimary}, avatarAction:{color:colors.primary,fontWeight:'700'}, heading:{fontSize:21,fontWeight:'800',color:colors.textPrimary,marginBottom:8}, hint:{fontSize:12,color:colors.textMuted,lineHeight:18,marginBottom:8} });
