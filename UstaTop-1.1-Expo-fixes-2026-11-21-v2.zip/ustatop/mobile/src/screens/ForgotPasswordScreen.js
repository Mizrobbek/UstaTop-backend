import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Pressable,
  Alert,
  TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';

import colors, { gradients } from '../theme/colors';
import { LogoMark } from '../components/Logo';
import TextField from '../components/TextField';
import PasswordInput from '../components/PasswordInput';
import PrimaryButton from '../components/PrimaryButton';
import { forgotPasswordSendCodeRequest, forgotPasswordResetRequest, getErrorMessage } from '../api/client';
import { toE164Uzbek, isValidUzbekPhone } from '../utils/phone';

const STEPS = { PHONE: 1, CODE_AND_PASSWORD: 2, DONE: 3 };
const CODE_LENGTH = 5;
const RESEND_SECONDS = 60;

export default function ForgotPasswordScreen({ navigation }) {
  const [step, setStep] = useState(STEPS.PHONE);
  const [phone, setPhone] = useState('');
  const [phoneError, setPhoneError] = useState(null);
  const [loading, setLoading] = useState(false);

  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  async function handleSendCode() {
    const normalized = toE164Uzbek(phone);
    if (!isValidUzbekPhone(normalized)) {
      setPhoneError('Telefon raqamni to\'liq kiriting (9 ta raqam)');
      return;
    }
    setPhoneError(null);
    setLoading(true);
    try {
      await forgotPasswordSendCodeRequest({ phone: normalized });
      setStep(STEPS.CODE_AND_PASSWORD);
      setCooldown(RESEND_SECONDS);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  async function handleResend() {
    if (cooldown > 0) return;
    setLoading(true);
    try {
      await forgotPasswordSendCodeRequest({ phone: toE164Uzbek(phone) });
      setCooldown(RESEND_SECONDS);
      Alert.alert('Yuborildi', 'Yangi tasdiqlash kodi yuborildi');
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  function validateResetForm() {
    const next = {};
    if (code.length !== CODE_LENGTH) next.code = `Kod ${CODE_LENGTH} xonali bo'lishi kerak`;
    if (newPassword.length < 8) next.newPassword = 'Parol kamida 8 ta belgidan iborat bo\'lishi kerak';
    else if (!/^(?=.*[A-Za-z])(?=.*\d).+$/.test(newPassword))
      next.newPassword = 'Parol kamida bitta harf va bitta raqamdan iborat bo\'lishi kerak';
    if (confirmPassword !== newPassword) next.confirmPassword = 'Parollar bir xil emas';
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleResetPassword() {
    if (!validateResetForm()) return;
    setLoading(true);
    try {
      await forgotPasswordResetRequest({
        phone: toE164Uzbek(phone),
        code,
        newPassword,
      });
      setStep(STEPS.DONE);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient colors={gradients.hero} style={styles.hero}>
        <Pressable style={styles.backButton} onPress={() => navigation.goBack()} hitSlop={10}>
          <Text style={styles.backButtonText}>‹</Text>
        </Pressable>
        <LogoMark size={64} />
        <Text style={styles.heroTitle}>Parolni tiklash</Text>
      </LinearGradient>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.sheet}
        keyboardVerticalOffset={40}
      >
        <ScrollView
          contentContainerStyle={styles.sheetContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {step === STEPS.PHONE && (
            <>
              <Text style={styles.title}>Telefon raqamingizni kiriting</Text>
              <Text style={styles.subtitle}>
                Ro'yxatdan o'tgan telefon raqamingizga tasdiqlash kodi yuboramiz
              </Text>
              <TextField
                label="Telefon raqam"
                icon="call-outline"
                placeholder="+998 90 123 45 67"
                value={phone}
                onChangeText={(t) => {
                  setPhone(t);
                  if (phoneError) setPhoneError(null);
                }}
                error={phoneError}
                keyboardType="phone-pad"
                returnKeyType="done"
                onSubmitEditing={handleSendCode}
              />
              <PrimaryButton title="Kod yuborish" onPress={handleSendCode} loading={loading} />
            </>
          )}

          {step === STEPS.CODE_AND_PASSWORD && (
            <>
              <Text style={styles.title}>Kodni kiriting</Text>
              <Text style={styles.subtitle}>{toE164Uzbek(phone)} raqamiga yuborilgan 5 xonali kod</Text>

              <CodeInput value={code} onChange={setCode} length={CODE_LENGTH} error={errors.code} />

              <Pressable onPress={handleResend} disabled={cooldown > 0} style={styles.resendRow} hitSlop={8}>
                <Text style={[styles.resendText, cooldown > 0 && { color: colors.textMuted }]}>
                  {cooldown > 0 ? `Qayta yuborish (${cooldown}s)` : 'Kodni qayta yuborish'}
                </Text>
              </Pressable>

              <View style={{ height: 8 }} />

              <PasswordInput
                label="Yangi parol"
                value={newPassword}
                onChangeText={(t) => {
                  setNewPassword(t);
                  if (errors.newPassword) setErrors((e) => ({ ...e, newPassword: null }));
                }}
                error={errors.newPassword}
                placeholder="Kamida 8 ta belgi, harf + raqam"
              />
              <PasswordInput
                label="Yangi parolni tasdiqlang"
                value={confirmPassword}
                onChangeText={(t) => {
                  setConfirmPassword(t);
                  if (errors.confirmPassword) setErrors((e) => ({ ...e, confirmPassword: null }));
                }}
                error={errors.confirmPassword}
                placeholder="Parolni qayta kiriting"
                returnKeyType="done"
                onSubmitEditing={handleResetPassword}
              />

              <PrimaryButton title="Parolni yangilash" onPress={handleResetPassword} loading={loading} />
            </>
          )}

          {step === STEPS.DONE && (
            <View style={styles.doneWrap}>
              <View style={styles.doneCircle}>
                <Text style={styles.doneCheck}>✓</Text>
              </View>
              <Text style={styles.title}>Parol yangilandi!</Text>
              <Text style={styles.subtitle}>Endi yangi parolingiz bilan tizimga kirishingiz mumkin</Text>
              <PrimaryButton
                title="Kirish sahifasiga o'tish"
                onPress={() => navigation.navigate('Login')}
                style={{ marginTop: 16 }}
              />
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

/** 5 ta alohida katakchadan iborat kod kiritish komponenti */
function CodeInput({ value, onChange, length, error }) {
  const inputRef = useRef(null);
  const digits = value.split('');

  return (
    <Pressable onPress={() => inputRef.current?.focus()} style={{ marginBottom: 8 }}>
      <View style={styles.codeRow}>
        {Array.from({ length }).map((_, i) => (
          <View key={i} style={[styles.codeBox, digits[i] && styles.codeBoxFilled, error && styles.codeBoxError]}>
            <Text style={styles.codeDigit}>{digits[i] || ''}</Text>
          </View>
        ))}
      </View>
      <TextInput
        ref={inputRef}
        value={value}
        onChangeText={(t) => onChange(t.replace(/\D/g, '').slice(0, length))}
        keyboardType="number-pad"
        maxLength={length}
        style={styles.hiddenInput}
        autoFocus
      />
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: {
    height: 220,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  backButton: {
    position: 'absolute',
    top: 52,
    left: 20,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backButtonText: { color: colors.white, fontSize: 24, marginTop: -2 },
  heroTitle: { color: colors.white, fontSize: 17, fontWeight: '700', marginTop: 10 },
  sheet: { flex: 1, marginTop: -24 },
  sheetContent: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 24,
    paddingTop: 26,
    paddingBottom: 40,
    flexGrow: 1,
  },
  title: { fontSize: 22, fontWeight: '800', color: colors.textPrimary, marginBottom: 6 },
  subtitle: { fontSize: 14, color: colors.textSecondary, marginBottom: 24, lineHeight: 20 },
  codeRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  codeBox: {
    width: 52,
    height: 58,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  codeBoxFilled: { borderColor: colors.primary },
  codeBoxError: { borderColor: colors.error },
  codeDigit: { fontSize: 22, fontWeight: '700', color: colors.textPrimary },
  hiddenInput: { position: 'absolute', opacity: 0, height: 0, width: 0 },
  errorText: { color: colors.error, fontSize: 12.5, marginTop: 8 },
  resendRow: { alignSelf: 'center', marginBottom: 20 },
  resendText: { color: colors.primary, fontWeight: '700', fontSize: 13.5 },
  doneWrap: { alignItems: 'center', paddingTop: 20 },
  doneCircle: {
    width: 84,
    height: 84,
    borderRadius: 42,
    backgroundColor: colors.success,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 22,
  },
  doneCheck: { color: colors.white, fontSize: 40, fontWeight: '800' },
});
