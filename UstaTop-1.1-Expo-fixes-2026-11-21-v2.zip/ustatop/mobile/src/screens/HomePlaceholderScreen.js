import React from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import colors, { gradients } from '../theme/colors';
import { LogoMark } from '../components/Logo';
import PrimaryButton from '../components/PrimaryButton';
import { logoutRequest } from '../api/client';

/**
 * Bu ekran vaqtinchalik — loyihaning keyingi bosqichida (kategoriyalar, e'lonlar,
 * xarita va h.k.) to'liq Bosh sahifa bilan almashtiriladi. Hozircha faqat
 * kirish/ro'yxatdan o'tish oqimi to'liq ishlashini ko'rsatish uchun kerak.
 */
export default function HomePlaceholderScreen({ user, onLogout }) {
  async function handleLogout() {
    Alert.alert('Chiqish', 'Hisobingizdan chiqmoqchimisiz?', [
      { text: 'Bekor qilish', style: 'cancel' },
      {
        text: 'Chiqish',
        style: 'destructive',
        onPress: async () => {
          await logoutRequest();
          onLogout?.();
        },
      },
    ]);
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient colors={gradients.hero} style={styles.hero}>
        <LogoMark size={72} />
      </LinearGradient>
      <View style={styles.content}>
        <Text style={styles.welcome}>Xush kelibsiz,</Text>
        <Text style={styles.name}>{user?.fullName || 'Foydalanuvchi'} 👋</Text>
        <Text style={styles.info}>Telefon: {user?.phone}</Text>
        {user?.email ? <Text style={styles.info}>Email: {user.email}</Text> : null}
        <View style={{ height: 24 }} />
        <Text style={styles.note}>
          Tizimga muvaffaqiyatli kirdingiz. Bosh sahifa, xizmatlar va boshqa bo'limlar keyingi bosqichda qo'shiladi.
        </Text>
        <PrimaryButton title="Chiqish" variant="outline" onPress={handleLogout} style={{ marginTop: 32 }} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: { height: 180, alignItems: 'center', justifyContent: 'center' },
  content: { flex: 1, padding: 24, alignItems: 'center' },
  welcome: { fontSize: 16, color: colors.textSecondary, marginTop: 24 },
  name: { fontSize: 26, fontWeight: '800', color: colors.textPrimary, marginBottom: 12 },
  info: { fontSize: 14.5, color: colors.textSecondary },
  note: { textAlign: 'center', color: colors.textMuted, fontSize: 13.5, lineHeight: 20 },
});
