import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, Pressable, ActivityIndicator, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';

import colors, { gradients } from '../theme/colors';
import { LogoMark } from '../components/Logo';
import ListingCard from '../components/ListingCard';
import { fetchListings, fetchCategories } from '../api/listings';
import { getCategoryIcon } from '../utils/categoryIcons';
import { fetchNotifications } from '../api/account';
import { getErrorMessage } from '../api/client';

export default function HomeScreen({ navigation, user, onLogout }) {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [categories, setCategories] = useState([]);
  const isProvider = user?.role === 'provider' || user?.role === 'both';

  // Ekranga har safar qaytilganda (masalan, bildirishnomalarni o'qib qaytganda)
  // o'qilmaganlar sonini yangilab turamiz
  useFocusEffect(
    useCallback(() => {
      fetchNotifications()
        .then((data) => setUnreadCount(data.unreadCount))
        .catch(() => {});
    }, [])
  );

  const loadData = useCallback(async () => {
    try {
      const listingsData = await fetchListings({ limit: 10 });
      setListings(listingsData.listings);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    }
  }, []);

  useEffect(() => {
    if (isProvider) fetchCategories().then((items) => setCategories(Array.isArray(items) ? items : [])).catch(() => setCategories([]));
    else setCategories([]);
  }, [isProvider]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await loadData();
      setLoading(false);
    })();
  }, [loadData]);

  async function handleRefresh() {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }

  if (loading) {
    return (
      <View style={styles.loadingWrap}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <FlatList
        data={listings}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[colors.primary]} />}
        contentContainerStyle={{ paddingBottom: 32 }}
        ListHeaderComponent={
          <>
            <LinearGradient colors={gradients.hero} style={styles.hero}>
              <View style={styles.heroTopRow}>
                <LogoMark size={44} />
                <View style={styles.heroActions}>
                  <Pressable onPress={() => navigation.navigate('Map')} hitSlop={10} style={{ marginRight: 18 }}>
                    <Ionicons name="map-outline" size={23} color={colors.white} />
                  </Pressable>
                  <Pressable onPress={() => navigation.navigate('ChatsList')} hitSlop={10} style={{ marginRight: 18 }}>
                    <Ionicons name="chatbubbles-outline" size={23} color={colors.white} />
                  </Pressable>
                  <Pressable onPress={() => navigation.navigate('Notifications')} hitSlop={10} style={{ marginRight: 18 }}>
                    <View>
                      <Ionicons name="notifications-outline" size={23} color={colors.white} />
                      {unreadCount > 0 && (
                        <View style={styles.unreadDot}>
                          <Text style={styles.unreadDotText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
                        </View>
                      )}
                    </View>
                  </Pressable>
                  <Pressable onPress={() => navigation.navigate('Profile')} hitSlop={10}>
                    <Ionicons name="person-circle-outline" size={25} color={colors.white} />
                  </Pressable>
                </View>
              </View>
              <Text style={styles.heroGreeting}>Salom, {user?.fullName?.split(' ')[0] || 'do\'stim'} 👋</Text>
              <Text style={styles.heroSubtitle}>Bugun qanday xizmat kerak?</Text>
            </LinearGradient>

            <View style={styles.quickActionsRow}>
              <Pressable style={[styles.createButton, { flex: 1 }]} onPress={() => navigation.navigate('CreateListing')}>
                <Ionicons name="add-circle" size={20} color={colors.white} />
                <Text style={styles.createButtonText}>{isProvider ? 'Xizmat e’loni berish' : 'E’lon berish'}</Text>
              </Pressable>
              <Pressable style={styles.mapButton} onPress={() => navigation.navigate('Map')}>
                <Ionicons name="map" size={20} color={colors.primary} />
                <Text style={styles.mapButtonText}>Xaritada ko‘rish</Text>
              </Pressable>
            </View>

            {isProvider && (
              <View style={styles.providerCategorySection}>
                <View style={styles.sectionHeaderRow}>
                  <Text style={styles.sectionTitle}>Kategoriyalar</Text>
                  <Pressable onPress={() => navigation.navigate('CategoryListings', { category: null })}><Text style={styles.seeAll}>Barchasi</Text></Pressable>
                </View>
                {categories.length ? (
                  <View style={styles.categoryGrid}>
                    {categories.map((cat) => (
                      <Pressable key={cat.id} style={styles.categoryChip} onPress={() => navigation.navigate('CategoryListings', { category: { id: cat.id, name: cat.name_uz } })}>
                        <Ionicons name={getCategoryIcon(cat.icon)} size={15} color={colors.primary} />
                        <Text style={styles.categoryChipText}>{cat.name_uz}</Text>
                      </Pressable>
                    ))}
                  </View>
                ) : (
                  <View style={styles.categoryEmpty}>
                    <Ionicons name="layers-outline" size={20} color={colors.textMuted} />
                    <Text style={styles.categoryEmptyText}>Kategoriyalar yuklanmadi. Internet aloqasini tekshiring.</Text>
                  </View>
                )}
              </View>
            )}

            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>So'nggi e'lonlar</Text>
              <Pressable onPress={() => navigation.navigate('CategoryListings', { category: null })}>
                <Text style={styles.seeAll}>Barchasi</Text>
              </Pressable>
            </View>
          </>
        }
        renderItem={({ item }) => (
          <View style={{ paddingHorizontal: 20 }}>
            <ListingCard listing={item} onPress={() => navigation.navigate('ListingDetail', { listingId: item.id })} />
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>Hozircha e'lonlar yo'q. Birinchi bo'lib e'lon bering!</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  hero: {
    paddingTop: 56,
    paddingBottom: 28,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
  },
  heroTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  heroActions: { flexDirection: 'row', alignItems: 'center' },
  unreadDot: {
    position: 'absolute',
    top: -4,
    right: -6,
    minWidth: 15,
    height: 15,
    borderRadius: 8,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
    borderWidth: 1.5,
    borderColor: colors.primaryDark,
  },
  unreadDotText: { color: colors.white, fontSize: 9, fontWeight: '800' },
  heroGreeting: { color: colors.white, fontSize: 21, fontWeight: '800', marginTop: 18 },
  heroSubtitle: { color: 'rgba(255,255,255,0.85)', fontSize: 14, marginTop: 4 },
  quickActionsRow: {
    flexDirection: 'row',
    gap: 10,
    marginHorizontal: 20,
    marginTop: -20,
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    borderRadius: 16,
    height: 52,
    gap: 8,
    shadowColor: colors.accentDark,
    shadowOpacity: 0.3,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  createButtonText: { color: colors.white, fontWeight: '700', fontSize: 14.5 },
  mapButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
    borderRadius: 16,
    height: 52,
    gap: 8,
    paddingHorizontal: 14,
    borderWidth: 1.5,
    borderColor: colors.border,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  mapButtonText: { color: colors.primary, fontWeight: '700', fontSize: 13.5 },
  sectionTitle: { fontSize: 17, fontWeight: '800', color: colors.textPrimary, marginTop: 24, marginBottom: 12, marginHorizontal: 20 },
  sectionHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginHorizontal: 20 },
  seeAll: { color: colors.primary, fontWeight: '700', fontSize: 13 },
  providerCategorySection: { marginTop: 22 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: 20, marginTop: 10 },
  categoryChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 18, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  categoryChipText: { color: colors.textPrimary, fontSize: 12, fontWeight: '700' },
  categoryEmpty: { marginHorizontal: 20, marginTop: 10, padding: 14, borderRadius: 14, borderWidth: 1, borderStyle: 'dashed', borderColor: colors.primary, flexDirection: 'row', alignItems: 'center', gap: 8 },
  categoryEmptyText: { color: colors.textMuted, fontWeight: '600', fontSize: 12 },
  emptyText: { textAlign: 'center', color: colors.textMuted, marginTop: 20, paddingHorizontal: 40 },
});
