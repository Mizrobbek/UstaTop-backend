import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, ActivityIndicator, Alert, Linking, Platform, Image } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import AndroidOpenMap from '../components/AndroidOpenMap';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import TextField from '../components/TextField';
import PrimaryButton from '../components/PrimaryButton';
import { fetchListing, createOffer } from '../api/listings';
import { getErrorMessage } from '../api/client';

function formatPrice(listing) {
  if (!listing || listing.priceType === 'negotiable' || listing.price === null) return 'Kelishiladi';
  return `${Number(listing.price).toLocaleString('ru-RU')} so'm`;
}

/** Qurilmadagi xarita ilovasini (Apple Maps yoki Google Maps) yo'nalish bilan ochadi */
function openDirections(listing) {
  const { latitude, longitude, title } = listing;
  const label = encodeURIComponent(title || 'Manzil');
  const url =
    Platform.OS === 'ios'
      ? `maps://?daddr=${latitude},${longitude}&q=${label}`
      : `geo:${latitude},${longitude}?q=${latitude},${longitude}(${label})`;

  Linking.openURL(url).catch(() => {
    // Zaxira variant: qurilmada mahalliy xarita ilovasi topilmasa, brauzerda Google Maps ochamiz
    Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`);
  });
}

export default function ListingDetailScreen({ navigation, route, currentUser }) {
  const { listingId } = route.params;
  const [listing, setListing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showOfferForm, setShowOfferForm] = useState(false);
  const [offerPrice, setOfferPrice] = useState('');
  const [offerMessage, setOfferMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchListing(listingId)
      .then(setListing)
      .catch((err) => Alert.alert('Xatolik', getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [listingId, route.params?.refreshKey]);

  const isOwner = currentUser && listing && currentUser.id === listing.clientId;

  async function handleSendOffer() {
    if (!offerPrice || Number(offerPrice) <= 0) {
      Alert.alert('Xatolik', 'Iltimos, narxni to\'g\'ri kiriting');
      return;
    }
    setSubmitting(true);
    try {
      const result = await createOffer(listingId, { price: Number(offerPrice), message: offerMessage.trim() || undefined });
      Alert.alert('Yuborildi!', 'Taklifingiz mijozga yuborildi. Endi mijoz bilan narx va ish tafsilotlarini chatda kelishishingiz mumkin.', [
        {
          text: 'Chatni ochish',
          onPress: () => navigation.navigate('Chat', {
            chatId: result.chatId,
            otherUserName: listing.clientName || 'Mijoz',
            listingTitle: listing.title,
          }),
        },
        { text: 'Keyinroq', style: 'cancel', onPress: () => navigation.goBack() },
      ]);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!listing) {
    return (
      <View style={styles.center}>
        <Text>E'lon topilmadi</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>E'lon</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.badgeRow}>
          <Text style={styles.categoryBadge}>{listing.categoryName}</Text>
          <View style={[styles.statusBadge, statusStyle(listing.status)]}>
            <Text style={styles.statusBadgeText}>{statusLabel(listing.status)}</Text>
          </View>
        </View>

        <Text style={styles.title}>{listing.title}</Text>
        {!!listing.media?.length && <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.mediaStrip}>{listing.media.map((uri,index)=><Image key={`${uri}-${index}`} source={{uri}} style={styles.listingImage}/>)}</ScrollView>}
        <Text style={styles.price}>{formatPrice(listing)}</Text>

        <View style={styles.metaRow}>
          <Ionicons name="location-outline" size={16} color={colors.textMuted} />
          <Text style={styles.metaText}>{listing.address || listing.city}</Text>
        </View>
        <View style={styles.metaRow}>
          <Ionicons name="eye-outline" size={16} color={colors.textMuted} />
          <Text style={styles.metaText}>{listing.viewsCount} marta ko'rilgan</Text>
          {listing.offersCount !== undefined && (
            <>
              <Ionicons name="people-outline" size={16} color={colors.textMuted} style={{ marginLeft: 14 }} />
              <Text style={styles.metaText}>{listing.offersCount} ta taklif</Text>
            </>
          )}
        </View>

        {listing.latitude != null && listing.longitude != null && (
          <View style={styles.mapWrap}>
            {Platform.OS === 'android' ? (
              <AndroidOpenMap
                style={styles.miniMap}
                initialRegion={{ latitude: listing.latitude, longitude: listing.longitude, latitudeDelta: 0.02, longitudeDelta: 0.02 }}
                markers={[{ id: 'listing-location', latitude: listing.latitude, longitude: listing.longitude, label: 'Buyurtma joyi' }]}
              />
            ) : (
              <MapView style={styles.miniMap} initialRegion={{ latitude: listing.latitude, longitude: listing.longitude, latitudeDelta: 0.02, longitudeDelta: 0.02 }} scrollEnabled={false} zoomEnabled={false} pointerEvents="none">
                <Marker coordinate={{ latitude: listing.latitude, longitude: listing.longitude }} pinColor={colors.accent} />
              </MapView>
            )}
                  <Pressable style={styles.directionsButton} onPress={() => openDirections(listing)}>
              <Ionicons name="navigate" size={16} color={colors.white} />
              <Text style={styles.directionsButtonText}>Yo'nalishni ko'rish</Text>
            </Pressable>
          </View>
        )}

        <View style={styles.divider} />

        <Text style={styles.sectionTitle}>Tavsif</Text>
        <Text style={styles.description}>{listing.description}</Text>

        <View style={styles.divider} />

        <Text style={styles.sectionTitle}>E'lon egasi</Text>
        <View style={styles.ownerRow}>
          <View style={styles.avatarPlaceholder}>
            <Text style={styles.avatarInitial}>{listing.clientName?.[0] || '?'}</Text>
          </View>
          <Text style={styles.ownerName}>{listing.clientName}</Text>
        </View>

        {isOwner && ['open', 'cancelled'].includes(listing.status) && (
          <Pressable
            style={styles.viewOffersButton}
            onPress={() => navigation.navigate('CreateListing', { listing })}
          >
            <Ionicons name="create-outline" size={18} color={colors.primary} />
            <Text style={styles.viewOffersText}>E'lonni tahrirlash</Text>
          </Pressable>
        )}

        {isOwner && (
          <Pressable style={styles.viewOffersButton} onPress={() => navigation.navigate('ListingOffers', { listingId })}>
            <Ionicons name="chatbubbles-outline" size={18} color={colors.primary} />
            <Text style={styles.viewOffersText}>Takliflarni ko'rish ({listing.offersCount || 0})</Text>
          </Pressable>
        )}

        {!isOwner && listing.status === 'open' && (
          <>
            {!showOfferForm ? (
              <PrimaryButton title="Taklif berish" onPress={() => setShowOfferForm(true)} style={{ marginTop: 20 }} />
            ) : (
              <View style={styles.offerForm}>
                <Text style={styles.sectionTitle}>Sizning taklifingiz</Text>
                <TextField
                  label="Narxingiz (so'm)"
                  placeholder="150000"
                  value={offerPrice}
                  onChangeText={(t) => setOfferPrice(t.replace(/\D/g, ''))}
                  keyboardType="number-pad"
                />
                <TextField
                  label="Xabar (ixtiyoriy)"
                  placeholder="Bugun kela olaman, tajribam bor..."
                  value={offerMessage}
                  onChangeText={setOfferMessage}
                  multiline
                  numberOfLines={3}
                  style={{ height: 80, textAlignVertical: 'top', paddingTop: 12 }}
                />
                <PrimaryButton title="Taklifni yuborish" onPress={handleSendOffer} loading={submitting} />
              </View>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

function statusLabel(status) {
  return { open: 'Ochiq', in_progress: 'Jarayonda', completed: 'Tugallangan', cancelled: 'Bekor qilingan' }[status] || status;
}
function statusStyle(status) {
  const map = {
    open: { backgroundColor: '#DCFCE7' },
    in_progress: { backgroundColor: '#FEF3C7' },
    completed: { backgroundColor: '#DBEAFE' },
    cancelled: { backgroundColor: '#FEE2E2' },
  };
  return map[status] || {};
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 54,
    paddingBottom: 14,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.textPrimary },
  mediaStrip:{marginVertical:12}, listingImage:{width:230,height:170,borderRadius:12,marginRight:10,backgroundColor:colors.border},
  content: { padding: 20, paddingBottom: 48 },
  badgeRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  categoryBadge: { fontSize: 13, fontWeight: '700', color: colors.primary },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusBadgeText: { fontSize: 11.5, fontWeight: '700', color: colors.textPrimary },
  title: { fontSize: 21, fontWeight: '800', color: colors.textPrimary, marginBottom: 8 },
  price: { fontSize: 20, fontWeight: '800', color: colors.accentDark, marginBottom: 14 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  mapWrap: { marginTop: 12, borderRadius: 16, overflow: 'hidden', borderWidth: 1, borderColor: colors.border },
  miniMap: { width: '100%', height: 140 },
  mapAttribution: {
    position: 'absolute',
    top: 6,
    right: 6,
    backgroundColor: 'rgba(255,255,255,0.88)',
    color: '#334155',
    fontSize: 9,
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 4,
  },
  directionsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: colors.primary,
    paddingVertical: 10,
  },
  directionsButtonText: { color: colors.white, fontWeight: '700', fontSize: 13 },
  metaText: { fontSize: 13, color: colors.textMuted },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 18 },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: colors.textPrimary, marginBottom: 10 },
  description: { fontSize: 14.5, color: colors.textSecondary, lineHeight: 22 },
  ownerRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatarPlaceholder: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primaryLight,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarInitial: { color: colors.white, fontWeight: '800', fontSize: 18 },
  ownerName: { fontSize: 15, fontWeight: '700', color: colors.textPrimary },
  viewOffersButton: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    marginTop: 20, paddingVertical: 14, borderRadius: 14, borderWidth: 1.5, borderColor: colors.primary,
  },
  viewOffersText: { color: colors.primary, fontWeight: '700', fontSize: 14.5 },
  offerForm: { marginTop: 20 },
});
