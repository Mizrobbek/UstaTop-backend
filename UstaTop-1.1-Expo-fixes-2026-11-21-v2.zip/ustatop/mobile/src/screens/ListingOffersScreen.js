import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import PrimaryButton from '../components/PrimaryButton';
import { fetchOffersForListing, respondToOffer } from '../api/listings';
import { getErrorMessage } from '../api/client';

export default function ListingOffersScreen({ navigation, route }) {
  const { listingId } = route.params;
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [respondingId, setRespondingId] = useState(null);

  const load = useCallback(async () => {
    try {
      const data = await fetchOffersForListing(listingId);
      setOffers(data);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    }
  }, [listingId]);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  async function handleRespond(offerId, status) {
    if (status === 'accepted') {
      Alert.alert('Tasdiqlang', 'Taklifni qabul qilishdan oldin usta bilan chatda narx va ish shartlarini kelishib oling. Qabul qilsangiz buyurtma ochiladi, qolgan takliflar rad etiladi.', [
        { text: 'Bekor qilish', style: 'cancel' },
        { text: 'Ha, qabul qilaman', onPress: () => respond(offerId, status) },
      ]);
    } else {
      respond(offerId, status);
    }
  }

  async function respond(offerId, status) {
    setRespondingId(offerId);
    try {
      const result = await respondToOffer(offerId, status);
      await load();
      if (status === 'accepted') {
        const acceptedOffer = offers.find((o) => o.id === offerId);
        Alert.alert('Ajoyib!', 'Buyurtma tasdiqlandi. Endi usta bilan suhbatlashishingiz mumkin.', [
          {
            text: 'Suhbatga o\'tish',
            onPress: () =>
              navigation.replace('Chat', { chatId: result.chatId, otherUserName: acceptedOffer?.providerName }),
          },
          { text: 'Keyinroq', style: 'cancel' },
        ]);
      }
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setRespondingId(null);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Kelgan takliflar</Text>
        <View style={{ width: 26 }} />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={offers}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 20 }}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.avatarPlaceholder}>
                  <Text style={styles.avatarInitial}>{item.providerName?.[0] || '?'}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Pressable onPress={() => navigation.navigate('ProviderProfile', { providerId: item.providerId })} disabled={!item.providerId}>
                    <Text style={styles.providerName}>{item.providerName}</Text>
                  </Pressable>
                  {item.providerRating > 0 && (
                    <View style={styles.ratingRow}>
                      <Ionicons name="star" size={13} color="#F59E0B" />
                      <Text style={styles.ratingText}>{item.providerRating.toFixed(1)}</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.offerPrice}>{Number(item.price).toLocaleString('ru-RU')} so'm</Text>
              </View>

              {item.message ? <Text style={styles.message}>{item.message}</Text> : null}

              {item.chatId && ['pending', 'accepted'].includes(item.status) && (
                <Pressable
                  style={styles.chatButton}
                  onPress={() => navigation.navigate('Chat', {
                    chatId: item.chatId,
                    otherUserName: item.providerName,
                  })}
                >
                  <Ionicons name="chatbubble-ellipses-outline" size={17} color={colors.primary} />
                  <Text style={styles.chatButtonText}>Avval chatda kelishib oling</Text>
                </Pressable>
              )}

              {item.status === 'pending' ? (
                <>
                  <Text style={styles.negotiationHint}>
                    Buyurtmani faqat kelishuvga erishganingizdan keyin qabul qiling.
                  </Text>
                  <View style={styles.actionsRow}>
                  <PrimaryButton
                    title="Rad etish"
                    variant="outline"
                    onPress={() => handleRespond(item.id, 'rejected')}
                    loading={respondingId === item.id}
                    style={{ flex: 1 }}
                  />
                  <PrimaryButton
                    title="Kelishuvdan so'ng qabul qilish"
                    onPress={() => handleRespond(item.id, 'accepted')}
                    loading={respondingId === item.id}
                    style={{ flex: 1 }}
                  />
                  </View>
                </>
              ) : (
                <View style={[styles.statusPill, item.status === 'accepted' ? styles.statusAccepted : styles.statusRejected]}>
                  <Text style={styles.statusPillText}>
                    {item.status === 'accepted' ? '✓ Qabul qilingan' : '✕ Rad etilgan'}
                  </Text>
                </View>
              )}
            </View>
          )}
          ListEmptyComponent={<Text style={styles.emptyText}>Hozircha takliflar yo'q</Text>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 54,
    paddingBottom: 14,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.textPrimary },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  avatarPlaceholder: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: colors.primaryLight,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarInitial: { color: colors.white, fontWeight: '800', fontSize: 16 },
  providerName: { fontSize: 15, fontWeight: '700', color: colors.textPrimary },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 2 },
  ratingText: { fontSize: 12, color: colors.textMuted },
  offerPrice: { fontSize: 15, fontWeight: '800', color: colors.accentDark },
  message: { fontSize: 13.5, color: colors.textSecondary, marginBottom: 14, lineHeight: 19 },
  chatButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  chatButtonText: { color: colors.primary, fontSize: 13, fontWeight: '700' },
  negotiationHint: { fontSize: 12, color: colors.textMuted, lineHeight: 17, marginBottom: 10 },
  actionsRow: { flexDirection: 'row', gap: 10 },
  statusPill: { alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10 },
  statusAccepted: { backgroundColor: '#DCFCE7' },
  statusRejected: { backgroundColor: '#FEE2E2' },
  statusPillText: { fontSize: 12.5, fontWeight: '700', color: colors.textPrimary },
  emptyText: { textAlign: 'center', color: colors.textMuted, marginTop: 40 },
});
