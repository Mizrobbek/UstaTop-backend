import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, Pressable, Alert, ActivityIndicator, Platform } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import AndroidOpenMap from '../components/AndroidOpenMap';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import PrimaryButton from '../components/PrimaryButton';
import { DEFAULT_REGION, isInUzbekistan } from '../utils/geo';

/**
 * Joylashuvni tanlash ekrani. Ishlatilishi:
 *   navigation.navigate('LocationPicker', {
 *     initialLocation: { latitude, longitude } | null,
 *     onSelect: (location) => { ... },
 *   })
 * `onSelect` — React Navigation'da params ichida funksiya uzatish odatiy amaliyot
 * (JS runtime ichida ishlaydi, ekranlar orasida serializatsiya qilinmaydi).
 */
export default function LocationPickerScreen({ navigation, route }) {
  const { initialLocation, onSelect } = route.params || {};
  const [marker, setMarker] = useState(initialLocation || null);
  const [locating, setLocating] = useState(false);
  const mapRef = useRef(null);

  function handleMapPress(e) {
    const coordinate = e?.nativeEvent?.coordinate || e;
    const { latitude, longitude } = coordinate || {};
    if (!isInUzbekistan(latitude, longitude)) {
      Alert.alert('Diqqat', 'Ilova hozircha faqat O\'zbekiston hududida ishlaydi. Iltimos, xarita ichidan joy tanlang.');
      return;
    }
    setMarker({ latitude, longitude });
  }

  async function handleUseMyLocation() {
    setLocating(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Ruxsat berilmadi', 'Joylashuvni aniqlash uchun ruxsat berish kerak. Xaritadan qo\'lda ham belgilashingiz mumkin.');
        return;
      }
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const { latitude, longitude } = position.coords;

      if (!isInUzbekistan(latitude, longitude)) {
        Alert.alert(
          'Joylashuv topilmadi',
          'Qurilmangiz joylashuvi O\'zbekiston hududidan tashqarida ko\'rinyapti. Iltimos, xaritadan qo\'lda belgilang.'
        );
        return;
      }

      setMarker({ latitude, longitude });
      mapRef.current?.animateToRegion({ latitude, longitude, latitudeDelta: 0.02, longitudeDelta: 0.02 }, 500);
    } catch (err) {
      Alert.alert('Xatolik', 'Joylashuvni aniqlab bo\'lmadi. GPS yoqilganini tekshiring.');
    } finally {
      setLocating(false);
    }
  }

  async function handleConfirm() {
    if (!marker) {
      Alert.alert('Joy tanlanmagan', 'Xaritada bosib yoki "Joylashuvimni aniqlash" tugmasi orqali joy belgilang');
      return;
    }
    let resolvedAddress = null;
    try {
      const places = await Location.reverseGeocodeAsync(marker);
      const place = places?.[0];
      if (place) {
        resolvedAddress = [place.district, place.subregion, place.street, place.name]
          .filter((part, index, all) => part && all.indexOf(part) === index)
          .join(', ');
      }
    } catch (_) {
      // Reverse-geocoding ixtiyoriy: koordinatalar baribir saqlanadi.
    }
    onSelect?.({ ...marker, address: resolvedAddress });
    navigation.goBack();
  }

  return (
    <View style={styles.container}>
      {Platform.OS === 'android' ? (
        <AndroidOpenMap
          ref={mapRef}
          initialRegion={marker ? { ...marker, latitudeDelta: 0.05, longitudeDelta: 0.05 } : DEFAULT_REGION}
          markers={marker ? [{ id: 'selected-location', ...marker, label: 'Tanlangan joy' }] : []}
          onMapPress={handleMapPress}
        />
      ) : (
        <MapView ref={mapRef} style={StyleSheet.absoluteFill} initialRegion={marker ? { ...marker, latitudeDelta: 0.05, longitudeDelta: 0.05 } : DEFAULT_REGION} onPress={handleMapPress} minZoomLevel={5}>
          {marker && <Marker coordinate={marker} pinColor={colors.accent} />}
        </MapView>
      )}

      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.backButton} hitSlop={10}>
          <Ionicons name="chevron-back" size={24} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Joylashuvni belgilang</Text>
        <View style={{ width: 40 }} />
      </View>

      <Pressable style={styles.myLocationButton} onPress={handleUseMyLocation} disabled={locating}>
        {locating ? (
          <ActivityIndicator size="small" color={colors.primary} />
        ) : (
          <Ionicons name="locate" size={22} color={colors.primary} />
        )}
      </Pressable>


      <View style={styles.bottomPanel}>
        <Text style={styles.hint}>
          {marker ? '📍 Joy belgilandi. Kerak bo\'lsa xaritada boshqa joyni bosing.' : 'Xaritada joyni bosing yoki GPS orqali aniqlang'}
        </Text>
        <PrimaryButton title="Tasdiqlash" onPress={handleConfirm} disabled={!marker} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    position: 'absolute',
    top: 50,
    left: 16,
    right: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  headerTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textPrimary,
    backgroundColor: colors.surface,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  myLocationButton: {
    position: 'absolute',
    right: 16,
    bottom: 150,
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  mapAttribution: {
    position: 'absolute',
    left: 12,
    bottom: 154,
    backgroundColor: 'rgba(255,255,255,0.88)',
    color: '#334155',
    fontSize: 10,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 4,
  },
  bottomPanel: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    paddingBottom: 32,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 6,
  },
  hint: {
    fontSize: 13,
    color: colors.textSecondary,
    marginBottom: 14,
    textAlign: 'center',
  },
});
