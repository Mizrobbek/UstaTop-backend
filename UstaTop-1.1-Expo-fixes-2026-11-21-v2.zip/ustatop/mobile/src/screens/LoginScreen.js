import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Pressable,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';

import colors, { gradients } from '../theme/colors';
import Logo from '../components/Logo';
import TextField from '../components/TextField';
import PasswordInput from '../components/PasswordInput';
import PrimaryButton from '../components/PrimaryButton';
import { loginRequest, verifyLoginPhoneRequest, saveSession, getErrorMessage } from '../api/client';

export default function LoginScreen({ navigation, onLoginSuccess }) {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [otpRequired, setOtpRequired] = useState(false);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  function validate() {
    const next = {};
    if (!identifier.trim()) next.identifier = 'Telefon raqamingizni kiriting';
    if (!password) next.password = 'Parolingizni kiriting';
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleLogin() {
    if (!otpRequired && !validate()) return;
    if (otpRequired && !/^\d{5}$/.test(otp)) { Alert.alert('Xatolik', '5 xonali SMS kodni kiriting'); return; }
    setLoading(true);
    try {
      const normalizedPhone = `+998${identifier.replace(/\D/g, '').replace(/^998/, '').slice(-9)}`;
      const data = otpRequired
        ? await verifyLoginPhoneRequest({ phone: normalizedPhone, code: otp })
        : await loginRequest({ identifier: normalizedPhone, password });
      if (data.requiresPhoneVerification) {
        setOtpRequired(true);
        Alert.alert('Telefonni tasdiqlash', data.debugCode ? `Test SMS kodi: ${data.debugCode}` : 'Telefoningizga SMS kodi yuborildi.');
        return;
      }
      await saveSession(data);
      onLoginSuccess?.(data.user);
    } catch (err) {
      Alert.alert(otpRequired ? 'Kod tasdiqlanmadi' : 'Kirish muvaffaqiyatsiz', getErrorMessage(err));
    } finally { setLoading(false); }
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient colors={gradients.hero} style={styles.hero}>
        <Logo size={92} textSize={32} />
      </LinearGradient>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.sheet}
        keyboardVerticalOffset={40}
      >
        <ScrollView
          contentContainerStyle={styles.sheetContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.title}>Xush kelibsiz!</Text>
          <Text style={styles.subtitle}>Davom etish uchun hisobingizga kiring</Text>

          <TextField
            label="Telefon raqam"
            icon="person-outline"
            prefix="+998"
            placeholder="90 123 45 67"
            value={identifier}
            onChangeText={(t) => {
              setIdentifier(t.replace(/\D/g, "").replace(/^998/, "").slice(0, 9));
              if (errors.identifier) setErrors((e) => ({ ...e, identifier: null }));
            }}
            error={errors.identifier}
            keyboardType="phone-pad"
            returnKeyType="next"
            editable={!otpRequired}
          />

          <PasswordInput
            value={password}
            onChangeText={(t) => {
              setPassword(t);
              if (errors.password) setErrors((e) => ({ ...e, password: null }));
            }}
            error={errors.password}
            returnKeyType="done"
            onSubmitEditing={handleLogin}
            editable={!otpRequired}
          />

          {otpRequired ? (
            <TextField
              label="SMS tasdiqlash kodi"
              icon="keypad-outline"
              placeholder="5 xonali kod"
              value={otp}
              onChangeText={(t) => setOtp(t.replace(/\D/g, '').slice(0, 5))}
              keyboardType="number-pad"
              returnKeyType="done"
            />
          ) : null}

          <Pressable
            style={styles.forgotLink}
            onPress={() => navigation.navigate('ForgotPassword')}
            hitSlop={8}
          >
            <Text style={styles.forgotLinkText}>Parolni unutdingizmi?</Text>
          </Pressable>

          <PrimaryButton title={otpRequired ? 'Telefonni tasdiqlash' : 'Kirish'} onPress={handleLogin} loading={loading} style={{ marginTop: 8 }} />

          <View style={styles.dividerRow}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>yoki</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.bottomRow}>
            <Text style={styles.bottomText}>Hisobingiz yo'qmi? </Text>
            <Pressable onPress={() => navigation.navigate('Register')} hitSlop={8}>
              <Text style={styles.bottomLink}>Ro'yxatdan o'tish</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: {
    height: 260,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  sheet: { flex: 1, marginTop: -28 },
  sheetContent: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 24,
    paddingTop: 28,
    paddingBottom: 40,
    flexGrow: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14.5,
    color: colors.textSecondary,
    marginBottom: 24,
  },
  forgotLink: { alignSelf: 'flex-end', marginTop: -6, marginBottom: 20 },
  forgotLinkText: { color: colors.primary, fontWeight: '600', fontSize: 13.5 },
  dividerRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 22 },
  dividerLine: { flex: 1, height: 1, backgroundColor: colors.border },
  dividerText: { marginHorizontal: 12, color: colors.textMuted, fontSize: 12.5 },
  bottomRow: { flexDirection: 'row', justifyContent: 'center' },
  bottomText: { color: colors.textSecondary, fontSize: 14.5 },
  bottomLink: { color: colors.accent, fontWeight: '700', fontSize: 14.5 },
});
