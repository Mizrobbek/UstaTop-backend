import React, { useState, useRef, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, Pressable, ActivityIndicator, ScrollView, Platform } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import AndroidOpenMap from '../components/AndroidOpenMap';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import { fetchMapListings, fetchCategories } from '../api/listings';
import { getErrorMessage } from '../api/client';
import { getCategoryIcon } from '../utils/categoryIcons';
import { DEFAULT_REGION, regionToBoundingBox } from '../utils/geo';

function formatMarkerPrice(item) {
  if (item.price === null) return 'Kelishiladi';
  const rounded = item.price >= 1000000 ? `${Math.round(item.price / 100000) / 10}mln` : `${Math.round(item.price / 1000)}ming`;
  return rounded;
}

export default function MapListingsScreen({ navigation }) {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [truncated, setTruncated] = useState(false);
  const [categories, setCategories] = useState([]);
  const [activeCategoryId, setActiveCategoryId] = useState(null);
  const [locating, setLocating] = useState(false);
  const mapRef = useRef(null);
  const lastRegion = useRef(null);
  const debounceTimer = useRef(null);
  const latestRequestId = useRef(0);

  useEffect(() => {
    fetchCategories().then(setCategories).catch(() => {});
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
      // Ekran yopilgandan keyin keladigan javob state'ni o'zgartirmasligi uchun.
      latestRequestId.current += 1;
    };
  }, []);

  const loadForRegion = useCallback(
    async (region, categoryId) => {
      lastRegion.current = region;
      const requestId = ++latestRequestId.current;
      setLoading(true);
      try {
        const box = regionToBoundingBox(region);
        const data = await fetchMapListings({ ...box, categoryId: categoryId || undefined });
        // Xarita tez-tez siljiganda eski so'rovning natijasi yangisini bosib ketmasin.
        if (requestId !== latestRequestId.current) return;
        setListings(data.listings);
        setTruncated(data.truncated);
      } catch (err) {
        if (requestId === latestRequestId.current) console.warn(getErrorMessage(err));
      } finally {
        if (requestId === latestRequestId.current) setLoading(false);
      }
    },
    []
  );

  function handleCategoryPress(id) {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    const next = activeCategoryId === id ? null : id;
    setActiveCategoryId(next);
    if (lastRegion.current) loadForRegion(lastRegion.current, next);
  }

  async function handleMyLocation() {
    setLocating(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      mapRef.current?.animateToRegion(
        { latitude: pos.coords.latitude, longitude: pos.coords.longitude, latitudeDelta: 0.05, longitudeDelta: 0.05 },
        500
      );
    } catch (err) {
      // Joylashuv olinmasa jim o'tkazamiz - xarita baribir ishlayveradi
    } finally {
      setLocating(false);
    }
  }

  return (
    <View style={styles.container}>
      {Platform.OS === 'android' ? (
        <AndroidOpenMap
          ref={mapRef}
          initialRegion={DEFAULT_REGION}
          markers={listings.map((item) => ({ id: item.id, latitude: item.latitude, longitude: item.longitude, label: formatMarkerPrice(item) }))}
          onMarkerPress={(id) => navigation.navigate('ListingDetail', { listingId: id })}
          onRegionChangeComplete={(region) => {
            if (debounceTimer.current) clearTimeout(debounceTimer.current);
            debounceTimer.current = setTimeout(() => loadForRegion(region, activeCategoryId), 350);
          }}
          onMapError={(message) => console.warn('OpenFreeMap:', message)}
        />
      ) : (
        <MapView ref={mapRef} style={StyleSheet.absoluteFill} initialRegion={DEFAULT_REGION} onRegionChangeComplete={(region) => {
          if (debounceTimer.current) clearTimeout(debounceTimer.current);
          debounceTimer.current = setTimeout(() => loadForRegion(region, activeCategoryId), 350);
        }}>
          {listings.map((item) => (
            <Marker key={item.id} coordinate={{ latitude: item.latitude, longitude: item.longitude }} onPress={() => navigation.navigate('ListingDetail', { listingId: item.id })}>
              <View style={styles.markerBubble}><Ionicons name={getCategoryIcon(item.categoryIcon)} size={12} color={colors.white} /><Text style={styles.markerText}>{formatMarkerPrice(item)}</Text></View>
            </Marker>
          ))}
        </MapView>
      )}

      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.iconButton} hitSlop={10}>
          <Ionicons name="chevron-back" size={24} color={colors.textPrimary} />
        </Pressable>
        {loading && (
          <View style={styles.loadingPill}>
            <ActivityIndicator size="small" color={colors.primary} />
            <Text style={styles.loadingPillText}>Yuklanmoqda…</Text>
          </View>
        )}
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categoryScroll}
        contentContainerStyle={styles.categoryScrollContent}
      >
        {categories.map((cat) => {
          const active = activeCategoryId === cat.id;
          return (
            <Pressable
              key={cat.id}
              style={[styles.categoryChip, active && styles.categoryChipActive]}
              onPress={() => handleCategoryPress(cat.id)}
            >
              <Ionicons name={getCategoryIcon(cat.icon)} size={14} color={active ? colors.white : colors.primary} />
              <Text style={[styles.categoryChipText, active && { color: colors.white }]}>{cat.name_uz}</Text>
            </Pressable>
          );
        })}
      </ScrollView>


      <Pressable style={styles.myLocationButton} onPress={handleMyLocation} disabled={locating}>
        {locating ? <ActivityIndicator size="small" color={colors.primary} /> : <Ionicons name="locate" size={22} color={colors.primary} />}
      </Pressable>

      {truncated && (
        <View style={styles.truncatedBanner}>
          <Ionicons name="information-circle" size={16} color={colors.white} />
          <Text style={styles.truncatedText}>Bu hududda ko'p e'lon bor — barchasini ko'rish uchun yaqinlashtiring</Text>
        </View>
      )}

      {!loading && listings.length === 0 && (
        <View style={styles.emptyBanner}>
          <Text style={styles.emptyText}>Bu hududda ochiq e'lonlar topilmadi</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    position: 'absolute',
    top: 50,
    left: 16,
    right: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  loadingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  loadingPillText: { fontSize: 12.5, color: colors.textSecondary, fontWeight: '600' },
  categoryScroll: { position: 'absolute', top: 104, left: 0, right: 0 },
  categoryScrollContent: { paddingHorizontal: 16, gap: 8 },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 18,
    backgroundColor: colors.surface,
    marginRight: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  categoryChipActive: { backgroundColor: colors.primary },
  categoryChipText: { fontSize: 12.5, fontWeight: '600', color: colors.textPrimary },
  markerBubble: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.accent,
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: colors.white,
  },
  markerText: { color: colors.white, fontSize: 11, fontWeight: '700' },
  mapAttribution: {
    position: 'absolute',
    left: 12,
    bottom: 12,
    backgroundColor: 'rgba(255,255,255,0.88)',
    color: '#334155',
    fontSize: 10,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 4,
  },
  myLocationButton: {
    position: 'absolute',
    right: 16,
    bottom: 40,
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  truncatedBanner: {
    position: 'absolute',
    bottom: 40,
    left: 16,
    right: 74,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(15,38,34,0.9)',
    borderRadius: 14,
    padding: 12,
  },
  truncatedText: { color: colors.white, fontSize: 12, flex: 1, lineHeight: 16 },
  emptyBanner: {
    position: 'absolute',
    top: 160,
    alignSelf: 'center',
    backgroundColor: colors.surface,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 14,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  emptyText: { fontSize: 13, color: colors.textSecondary, fontWeight: '600' },
});
