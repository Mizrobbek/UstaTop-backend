import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import PrimaryButton from '../components/PrimaryButton';
import { fetchMyOrders, fetchMyCommissions, updateOrderStatus, confirmServicePayment, submitReview } from '../api/account';
import { getErrorMessage } from '../api/client';

const STATUS_LABELS = {
  confirmed: 'Tasdiqlangan',
  in_progress: 'Jarayonda',
  completed: 'Yakunlangan',
  cancelled: 'Bekor qilingan',
};
const STATUS_COLORS = {
  confirmed: '#DBEAFE',
  in_progress: '#FEF3C7',
  completed: '#DCFCE7',
  cancelled: '#FEE2E2',
};

export default function MyOrdersScreen({ navigation, route }) {
  const role = route.params?.role || 'client';
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState(null);
  const [reviewOrder, setReviewOrder] = useState(null);
  const [commissions, setCommissions] = useState(null);

  const load = useCallback(async () => {
    try {
      const data = await fetchMyOrders(role);
      setOrders(data);
      if (role === 'provider') setCommissions(await fetchMyCommissions());
      else setCommissions(null);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    }
  }, [role]);

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, [load]);

  async function handleStatusChange(order, status) {
    // Eslatma: Alert.prompt faqat iOS'da ishlaydi. Android uchun keyingi bosqichda
    // maxsus (custom) modal orqali sabab kiritish oynasi qo'shiladi.
    if (status === 'cancelled') {
      Alert.prompt
        ? Alert.prompt('Bekor qilish sababi', 'Nima uchun bekor qilyapsiz?', async (reason) => {
            if (reason) await doStatusChange(order.id, status, reason);
          })
        : await doStatusChange(order.id, status, 'Bekor qilindi');
      return;
    }
    await doStatusChange(order.id, status);
  }

  function handleConfirmServicePayment(order) {
    const isClient = role === 'client';
    Alert.alert(
      isClient ? 'To‘lovni tasdiqlash' : 'To‘lovni olganingizni tasdiqlash',
      isClient
        ? 'Xizmat haqini bevosita ustaga berganingizni tasdiqlaysizmi?'
        : 'Mijoz xizmat haqini berganini tasdiqladi. Pulni olganingizni tasdiqlaysizmi?',
      [
        { text: 'Bekor qilish', style: 'cancel' },
        {
          text: 'Tasdiqlash',
          onPress: async () => {
            setBusyId(order.id);
            try {
              await confirmServicePayment(order.id);
              await load();
            } catch (err) {
              Alert.alert('Xatolik', getErrorMessage(err));
            } finally {
              setBusyId(null);
            }
          },
        },
      ]
    );
  }

  async function doStatusChange(orderId, status, cancelReason) {
    setBusyId(orderId);
    try {
      await updateOrderStatus(orderId, status, cancelReason);
      await load();
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>{role === 'provider' ? 'Ishlarim' : 'Buyurtmalarim'}</Text>
        <View style={{ width: 26 }} />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 20 }}
          ListHeaderComponent={role === 'provider' && commissions ? (
            <View style={styles.paymentWaiting}>
              <Text style={styles.personName}>UstaTop komissiyasi</Text>
              <Text style={styles.price}>Qarzdorlik: {Number(commissions.debt).toLocaleString('ru-RU')} so‘m</Text>
              {commissions.commissions.map(c => (
                <Text key={c.id} style={styles.personName}>
                  {new Date(c.calculatedAt).toLocaleDateString('ru-RU')} · {c.rate}% · {Number(c.amount).toLocaleString('ru-RU')} so‘m · {c.status === 'paid' ? 'To‘langan' : 'To‘lanmagan'}
                </Text>
              ))}
            </View>
          ) : null}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <View style={styles.cardTop}>
                <Text style={styles.listingTitle} numberOfLines={1}>
                  {item.listingTitle}
                </Text>
                <View style={[styles.statusPill, { backgroundColor: STATUS_COLORS[item.status] }]}>
                  <Text style={styles.statusPillText}>{STATUS_LABELS[item.status]}</Text>
                </View>
              </View>
              <Text style={styles.personName}>
                {role === 'provider' ? `Mijoz: ${item.clientName}` : `Usta: ${item.providerName}`}
              </Text>
              <View style={styles.priceRow}>
                <Text style={styles.price}>{Number(item.agreedPrice).toLocaleString('ru-RU')} so'm</Text>
                {item.isPaid ? (
                  <View style={styles.paidBadge}>
                    <Ionicons name="checkmark-circle" size={13} color={colors.success} />
                    <Text style={styles.paidBadgeText}>To'langan</Text>
                  </View>
                ) : (
                  <View style={styles.unpaidBadge}>
                    <Text style={styles.unpaidBadgeText}>To'lanmagan</Text>
                  </View>
                )}
              </View>

              {!item.isPaid && role === 'client' && ['confirmed', 'in_progress', 'completed'].includes(item.status) && (
                item.clientPaymentConfirmedAt ? (
                  <View style={styles.paymentWaiting}>
                    <Text style={styles.paymentWaitingText}>Usta to‘lovni tasdiqlashi kutilmoqda</Text>
                  </View>
                ) : (
                  <PrimaryButton
                    title="To‘lovni ustaga berdim"
                    onPress={() => handleConfirmServicePayment(item)}
                    loading={busyId === item.id}
                    style={{ marginTop: 12 }}
                  />
                )
              )}

              {!item.isPaid && role === 'provider' && ['confirmed', 'in_progress', 'completed'].includes(item.status) && (
                item.clientPaymentConfirmedAt ? (
                  <PrimaryButton
                    title="To‘lovni oldim"
                    onPress={() => handleConfirmServicePayment(item)}
                    loading={busyId === item.id}
                    style={{ marginTop: 12 }}
                  />
                ) : (
                  <View style={styles.paymentWaiting}>
                    <Text style={styles.paymentWaitingText}>Mijoz to‘lovni tasdiqlashi kutilmoqda</Text>
                  </View>
                )
              )}

              {role === 'provider' && item.status === 'confirmed' && (
                <PrimaryButton
                  title="Ishni boshlash"
                  onPress={() => doStatusChange(item.id, 'in_progress')}
                  loading={busyId === item.id}
                  style={{ marginTop: 12 }}
                />
              )}
              {role === 'provider' && item.status === 'in_progress' && (
                <PrimaryButton
                  title="Ishni yakunlash"
                  onPress={() => doStatusChange(item.id, 'completed')}
                  loading={busyId === item.id}
                  style={{ marginTop: 12 }}
                />
              )}
              {role === 'client' && ['confirmed', 'in_progress'].includes(item.status) && (
                <PrimaryButton
                  title="Bekor qilish"
                  variant="outline"
                  onPress={() => handleStatusChange(item, 'cancelled')}
                  loading={busyId === item.id}
                  style={{ marginTop: 12 }}
                />
              )}
              {role === 'client' && item.status === 'completed' && !item.hasReview && (
                <PrimaryButton title="Sharh qoldirish" onPress={() => setReviewOrder(item)} style={{ marginTop: 12 }} />
              )}
              {item.status === 'completed' && item.hasReview && (
                <View style={styles.reviewedBadge}>
                  <Ionicons name="checkmark-circle" size={15} color={colors.success} />
                  <Text style={styles.reviewedText}>Sharh qoldirilgan</Text>
                </View>
              )}
            </View>
          )}
          ListEmptyComponent={<Text style={styles.emptyText}>Hozircha buyurtmalar yo'q</Text>}
        />
      )}

      <ReviewModal
        order={reviewOrder}
        onClose={() => setReviewOrder(null)}
        onSubmitted={() => {
          setReviewOrder(null);
          load();
        }}
      />
    </View>
  );
}

function ReviewModal({ order, onClose, onSubmitted }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (order) {
      setRating(5);
      setComment('');
    }
  }, [order]);

  async function handleSubmit() {
    setSubmitting(true);
    try {
      await submitReview(order.id, { rating, comment: comment.trim() || undefined });
      onSubmitted();
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal visible={!!order} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>Ustaga sharh qoldiring</Text>
          <Text style={styles.modalSubtitle}>{order?.providerName}</Text>

          <View style={styles.starsRow}>
            {[1, 2, 3, 4, 5].map((n) => (
              <Pressable key={n} onPress={() => setRating(n)} hitSlop={6}>
                <Ionicons name={n <= rating ? 'star' : 'star-outline'} size={34} color="#F59E0B" />
              </Pressable>
            ))}
          </View>

          <TextInput
            style={styles.commentInput}
            placeholder="Izoh qoldiring (ixtiyoriy)..."
            placeholderTextColor={colors.placeholder}
            value={comment}
            onChangeText={setComment}
            multiline
            numberOfLines={3}
          />

          <PrimaryButton title="Yuborish" onPress={handleSubmit} loading={submitting} style={{ marginTop: 16 }} />
          <Pressable onPress={onClose} style={{ marginTop: 12 }}>
            <Text style={styles.modalCancel}>Bekor qilish</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 54,
    paddingBottom: 14,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.textPrimary },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 },
  listingTitle: { flex: 1, fontSize: 15, fontWeight: '700', color: colors.textPrimary },
  statusPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  statusPillText: { fontSize: 11, fontWeight: '700', color: colors.textPrimary },
  personName: { fontSize: 13, color: colors.textSecondary, marginTop: 6 },
  priceRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 },
  price: { fontSize: 15, fontWeight: '800', color: colors.accentDark },
  paidBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  paidBadgeText: { fontSize: 12, color: colors.success, fontWeight: '700' },
  unpaidBadge: { backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  unpaidBadgeText: { fontSize: 11, color: '#92400E', fontWeight: '700' },
  paymentWaiting: { marginTop: 12, padding: 10, borderRadius: 10, backgroundColor: '#FEF3C7' },
  paymentWaitingText: { color: '#92400E', fontSize: 12, fontWeight: '600', textAlign: 'center' },
  reviewedBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12 },
  reviewedText: { fontSize: 13, color: colors.success, fontWeight: '600' },
  emptyText: { textAlign: 'center', color: colors.textMuted, marginTop: 40 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  modalTitle: { fontSize: 18, fontWeight: '800', color: colors.textPrimary, textAlign: 'center' },
  modalSubtitle: { fontSize: 13.5, color: colors.textMuted, textAlign: 'center', marginTop: 4, marginBottom: 20 },
  starsRow: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginBottom: 20 },
  commentInput: {
    backgroundColor: colors.background,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 14,
    fontSize: 14,
    color: colors.textPrimary,
    height: 90,
    textAlignVertical: 'top',
  },
  modalCancel: { textAlign: 'center', color: colors.textMuted, fontSize: 14, fontWeight: '600' },
});
