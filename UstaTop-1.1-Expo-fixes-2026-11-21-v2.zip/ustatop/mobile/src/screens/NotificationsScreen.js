import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import { fetchNotifications, markNotificationRead, markAllNotificationsRead } from '../api/account';
import { getErrorMessage } from '../api/client';

const TYPE_ICON = {
  new_offer: 'pricetag-outline',
  offer_accepted: 'checkmark-circle-outline',
  offer_rejected: 'close-circle-outline',
  new_message: 'chatbubble-outline',
  order_status_changed: 'briefcase-outline',
  new_review: 'star-outline',
  system: 'information-circle-outline',
};

function timeAgo(dateStr) {
  const diffMs = Date.now() - new Date(dateStr).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 1) return 'hozirgina';
  if (minutes < 60) return `${minutes} daqiqa oldin`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} soat oldin`;
  return `${Math.floor(hours / 24)} kun oldin`;
}

/**
 * Bildirishnoma bosilganda, turiga qarab tegishli ekranga o'tkazadi. Bu funksiya
 * App.js'dagi push-bosish (notification tap) listener'ida ham qayta ishlatiladi,
 * shuning uchun ro'yxatdagi va push orqali kelgan bildirishnomalar bir xil
 * marshrutlash mantig'iga ega bo'ladi.
 */
export function navigateForNotification(navigation, notification) {
  const { type, data } = notification;
  switch (type) {
    case 'new_offer':
      if (data?.listingId) navigation.navigate('ListingOffers', { listingId: data.listingId });
      break;
    case 'offer_accepted':
      // Backend bu bildirishnomani FAQAT ustaga yuboradi (offer.controller.js) - shuning
      // uchun bu yerda har doim "provider" rolida ochish to'g'ri
      navigation.navigate('MyOrders', { role: 'provider' });
      break;
    case 'order_status_changed':
      // "Ish yakunlandi" - faqat mijozga yuboriladi (order.controller.js); "Bekor qilindi" esa
      // ikkala tarafga ham yuborilishi mumkin, shuning uchun bu yerda aniq rolni bila olmaymiz -
      // mijoz tomoni ko'proq ehtimolli bo'lgani uchun shuni standart qilib qoldiramiz
      navigation.navigate('MyOrders', { role: 'client' });
      break;
    case 'offer_rejected':
      // Faqat ustaga yuboriladi (offer rad etilganda)
      if (data?.listingId) navigation.navigate('ListingDetail', { listingId: data.listingId });
      break;
    case 'new_message':
      if (data?.chatId) navigation.navigate('Chat', { chatId: data.chatId });
      break;
    case 'new_review':
      navigation.navigate('Profile');
      break;
    default:
      // 'system' va boshqa turlar uchun alohida ekran yo'q - shu ro'yxatda qoladi
      break;
  }
}

export default function NotificationsScreen({ navigation }) {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const data = await fetchNotifications();
      setNotifications(data.notifications);
      setUnreadCount(data.unreadCount);
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  async function handlePress(item) {
    if (!item.isRead) {
      setNotifications((prev) => prev.map((n) => (n.id === item.id ? { ...n, isRead: true } : n)));
      setUnreadCount((c) => Math.max(0, c - 1));
      markNotificationRead(item.id).catch(() => {});
    }
    navigateForNotification(navigation, item);
  }

  async function handleMarkAllRead() {
    if (unreadCount === 0) return;
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadCount(0);
    try {
      await markAllNotificationsRead();
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
      load();
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Bildirishnomalar</Text>
        <Pressable onPress={handleMarkAllRead} hitSlop={10} disabled={unreadCount === 0}>
          <Text style={[styles.markAllText, unreadCount === 0 && { opacity: 0.4 }]}>Barchasini o'qish</Text>
        </Pressable>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={colors.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, flexGrow: 1 }}
          renderItem={({ item }) => (
            <Pressable
              style={({ pressed }) => [styles.card, !item.isRead && styles.cardUnread, pressed && { opacity: 0.75 }]}
              onPress={() => handlePress(item)}
            >
              <View style={[styles.iconWrap, !item.isRead && styles.iconWrapUnread]}>
                <Ionicons name={TYPE_ICON[item.type] || 'notifications-outline'} size={19} color={item.isRead ? colors.textMuted : colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.title, !item.isRead && styles.titleUnread]} numberOfLines={1}>
                  {item.title}
                </Text>
                {item.body ? (
                  <Text style={styles.body} numberOfLines={2}>
                    {item.body}
                  </Text>
                ) : null}
                <Text style={styles.time}>{timeAgo(item.createdAt)}</Text>
              </View>
              {!item.isRead && <View style={styles.unreadDot} />}
            </Pressable>
          )}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <Ionicons name="notifications-off-outline" size={44} color={colors.textMuted} />
              <Text style={styles.emptyText}>Hozircha bildirishnomalar yo'q</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 54,
    paddingBottom: 14,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.textPrimary },
  markAllText: { fontSize: 12.5, fontWeight: '700', color: colors.primary },
  card: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardUnread: { borderColor: colors.primaryLight, backgroundColor: '#F0FDFA' },
  iconWrap: {
    width: 36, height: 36, borderRadius: 18, backgroundColor: colors.background,
    alignItems: 'center', justifyContent: 'center',
  },
  iconWrapUnread: { backgroundColor: '#CCFBF1' },
  title: { fontSize: 14, fontWeight: '600', color: colors.textSecondary },
  titleUnread: { color: colors.textPrimary, fontWeight: '700' },
  body: { fontSize: 13, color: colors.textMuted, marginTop: 3, lineHeight: 18 },
  time: { fontSize: 11, color: colors.textMuted, marginTop: 6 },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.accent, marginTop: 4 },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80 },
  emptyText: { fontSize: 14, color: colors.textMuted, marginTop: 12, fontWeight: '600' },
});
