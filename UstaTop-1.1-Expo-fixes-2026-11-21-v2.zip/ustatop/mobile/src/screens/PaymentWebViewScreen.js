import React, { useState, useRef, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, Pressable, ActivityIndicator, Alert } from 'react-native';
import { WebView } from 'react-native-webview';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import PrimaryButton from '../components/PrimaryButton';
import { fetchPaymentStatus } from '../api/account';
import { getErrorMessage } from '../api/client';

const POLL_INTERVAL_MS = 3000;
const MAX_POLL_MINUTES = 15;

/**
 * Ishlatilishi: navigation.navigate('PaymentWebView', { orderId, paymentUrl, amount, provider })
 *
 * Payme/Click sahifasi to'lovdan keyin bizning serverimizga emas, balki o'zining
 * "muvaffaqiyatli" sahifasiga yo'naltiradi - shuning uchun WebView'ning URL o'zgarishini
 * kuzatish o'rniga, backend'dagi haqiqiy holatni (is_paid) muntazam so'rab turamiz (polling).
 * Bu yondashuv ancha ishonchli: foydalanuvchi WebView'ni yopib yuborsa ham, keyinroq
 * "Buyurtmalarim" ekraniga qaytganda to'lov holati baribir to'g'ri ko'rinadi.
 */
export default function PaymentWebViewScreen({ navigation, route }) {
  const { orderId, paymentUrl, amount, provider } = route.params;
  const [loadingPage, setLoadingPage] = useState(true);
  const [checking, setChecking] = useState(false);
  const pollRef = useRef(null);
  const startTimeRef = useRef(Date.now());

  const checkStatus = useCallback(
    async (showSpinner = false) => {
      if (showSpinner) setChecking(true);
      try {
        const { isPaid } = await fetchPaymentStatus(orderId);
        if (isPaid) {
          clearInterval(pollRef.current);
          Alert.alert('To\'lov qabul qilindi! ✅', 'Buyurtmangiz muvaffaqiyatli to\'landi', [
            { text: 'OK', onPress: () => navigation.goBack() },
          ]);
        }
      } catch (err) {
        if (showSpinner) Alert.alert('Xatolik', getErrorMessage(err));
      } finally {
        if (showSpinner) setChecking(false);
      }
    },
    [orderId, navigation]
  );

  useEffect(() => {
    pollRef.current = setInterval(() => {
      const minutesPassed = (Date.now() - startTimeRef.current) / 60000;
      if (minutesPassed > MAX_POLL_MINUTES) {
        clearInterval(pollRef.current);
        return;
      }
      checkStatus(false);
    }, POLL_INTERVAL_MS);

    return () => clearInterval(pollRef.current);
  }, [checkStatus]);

  function handleClose() {
    Alert.alert('To\'lovni bekor qilasizmi?', 'To\'lov sahifasini yopmoqchimisiz?', [
      { text: 'Yo\'q', style: 'cancel' },
      { text: 'Ha, yopish', style: 'destructive', onPress: () => navigation.goBack() },
    ]);
  }

  const providerLabel = provider === 'payme' ? 'Payme' : 'Click';

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={handleClose} hitSlop={10} style={styles.closeButton}>
          <Ionicons name="close" size={24} color={colors.textPrimary} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>{providerLabel} orqali to'lov</Text>
          <Text style={styles.headerSubtitle}>{Number(amount).toLocaleString('ru-RU')} so'm</Text>
        </View>
        <Pressable onPress={() => checkStatus(true)} hitSlop={10} disabled={checking}>
          {checking ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <Ionicons name="refresh" size={22} color={colors.primary} />
          )}
        </Pressable>
      </View>

      {loadingPage && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>To'lov sahifasi yuklanmoqda...</Text>
        </View>
      )}

      <WebView
        source={{ uri: paymentUrl }}
        style={styles.webview}
        onLoadEnd={() => setLoadingPage(false)}
        onError={() => {
          setLoadingPage(false);
          Alert.alert('Xatolik', 'To\'lov sahifasini yuklab bo\'lmadi. Internet aloqasini tekshiring.');
        }}
      />

      <View style={styles.footer}>
        <Text style={styles.footerHint}>To'lovni amalga oshirgach, bu ekran avtomatik yopiladi</Text>
        <PrimaryButton
          title="To'lovni tekshirish"
          variant="outline"
          onPress={() => checkStatus(true)}
          loading={checking}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingTop: 54,
    paddingBottom: 14,
    paddingHorizontal: 16,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  closeButton: { padding: 2 },
  headerTitle: { fontSize: 15, fontWeight: '700', color: colors.textPrimary },
  headerSubtitle: { fontSize: 13, color: colors.accentDark, fontWeight: '700', marginTop: 1 },
  webview: { flex: 1 },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    top: 90,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
    zIndex: 10,
  },
  loadingText: { marginTop: 12, fontSize: 13.5, color: colors.textSecondary },
  footer: {
    padding: 16,
    paddingBottom: 28,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  footerHint: { fontSize: 12, color: colors.textMuted, textAlign: 'center', marginBottom: 10 },
});
