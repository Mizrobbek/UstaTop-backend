import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Image, Alert, ActivityIndicator, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { fetchMyPortfolio, addPortfolioItem, deletePortfolioItem, uploadMedia } from '../api/account';
import { getErrorMessage } from '../api/client';
import colors from '../theme/colors';

export default function PortfolioScreen() {
  const [items,setItems]=useState([]); const [loading,setLoading]=useState(true); const [busy,setBusy]=useState(false); const [description,setDescription]=useState('');
  const load=useCallback(async()=>{ try { setItems(await fetchMyPortfolio()); } catch(e){ Alert.alert('Xatolik',getErrorMessage(e)); } finally { setLoading(false); } },[]);
  useEffect(()=>{load();},[load]);
  async function addMedia(){
    try {
      const permission=await ImagePicker.requestMediaLibraryPermissionsAsync();
      if(!permission.granted) return Alert.alert('Ruxsat kerak','Galereyaga ruxsat bering.');
      const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images','videos'],allowsMultipleSelection:true,selectionLimit:10,quality:0.85});
      if(result.canceled||!result.assets?.length) return;
      setBusy(true);
      const files=await uploadMedia(result.assets.map((a,i)=>({uri:a.uri,name:a.fileName||`portfolio-${Date.now()}-${i}.${a.type==='video'?'mp4':'jpg'}`,type:a.mimeType||(a.type==='video'?'video/mp4':'image/jpeg')})));
      for(const file of files) await addPortfolioItem({mediaUrl:file.url,type:file.type,description:description.trim()});
      setDescription(''); await load();
    } catch(e){Alert.alert('Yuklash xatosi',getErrorMessage(e));} finally{setBusy(false);}
  }
  async function remove(id){ Alert.alert('O‘chirish','Portfolio elementini o‘chirasizmi?',[{text:'Bekor',style:'cancel'},{text:'O‘chirish',style:'destructive',onPress:async()=>{try{await deletePortfolioItem(id);setItems(v=>v.filter(x=>x.id!==id));}catch(e){Alert.alert('Xatolik',getErrorMessage(e));}}}]); }
  return <ScrollView style={s.page} contentContainerStyle={s.content}><Text style={s.title}>Ishlar portfoliom</Text><Text style={s.hint}>Mijozlarga bajargan ishlaringizni rasm yoki video orqali ko‘rsating. Bir martada 10 tagacha fayl tanlash mumkin.</Text><TextInput style={s.input} placeholder="Ish haqida qisqacha izoh (ixtiyoriy)" value={description} onChangeText={setDescription}/><Pressable style={s.add} onPress={addMedia} disabled={busy}><Ionicons name="cloud-upload-outline" size={20} color="#fff"/><Text style={s.addText}>{busy?'Yuklanmoqda...':'Rasm yoki video qo‘shish'}</Text></Pressable>{loading?<ActivityIndicator color={colors.primary}/>:<View style={s.grid}>{items.map(item=><View key={item.id} style={s.card}>{item.type==='image'?<Image source={{uri:item.mediaUrl}} style={s.media}/>:<View style={[s.media,s.video]}><Ionicons name="play-circle" size={42} color="#fff"/><Text style={{color:'#fff'}}>Video</Text></View>}<Text numberOfLines={2} style={s.caption}>{item.description||'Usta ishi'}</Text><Pressable onPress={()=>remove(item.id)} style={s.delete}><Ionicons name="trash-outline" color="#dc2626" size={18}/></Pressable></View>)}</View>}</ScrollView>;
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:colors.background},content:{padding:18,paddingBottom:40},title:{fontSize:22,fontWeight:'800',color:colors.textPrimary},hint:{color:colors.textMuted,lineHeight:20,marginVertical:10},input:{backgroundColor:'#fff',borderWidth:1,borderColor:colors.border,borderRadius:12,padding:12,marginVertical:8},add:{backgroundColor:colors.primary,borderRadius:12,padding:14,flexDirection:'row',justifyContent:'center',alignItems:'center',gap:8},addText:{color:'#fff',fontWeight:'700'},grid:{flexDirection:'row',flexWrap:'wrap',gap:12,marginTop:18},card:{width:'47%',backgroundColor:'#fff',borderRadius:12,padding:8},media:{width:'100%',height:130,borderRadius:8,backgroundColor:colors.border,alignItems:'center',justifyContent:'center'},video:{backgroundColor:'#334155'},caption:{fontSize:12,color:colors.textPrimary,marginTop:6},delete:{alignSelf:'flex-end',padding:6}});
