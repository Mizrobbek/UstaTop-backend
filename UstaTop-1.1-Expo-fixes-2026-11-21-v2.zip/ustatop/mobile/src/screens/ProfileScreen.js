import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, ActivityIndicator, Alert, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import { fetchMe, fetchProviderProfile, fetchProviderReviews } from '../api/account';
import { getErrorMessage, logoutRequest } from '../api/client';

export default function ProfileScreen({ navigation, onLogout }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [providerDetails, setProviderDetails] = useState(null);
  const [providerReviews, setProviderReviews] = useState([]);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', load);
    load();
    return unsubscribe;
  }, [navigation]);

  async function load() {
    try {
      const data = await fetchMe();
      setUser(data);
      const providerRole = data.role === 'provider' || data.role === 'both';
      if (providerRole) {
        try {
          const [details, reviews] = await Promise.all([
            fetchProviderProfile(data.id),
            fetchProviderReviews(data.id),
          ]);
          setProviderDetails(details);
          setProviderReviews(Array.isArray(reviews) ? reviews : []);
        } catch {
          // Profilning asosiy qismi API ishlamasa ham ochilishi kerak.
          setProviderDetails(null);
          setProviderReviews([]);
        }
      } else {
        setProviderDetails(null);
        setProviderReviews([]);
      }
    } catch (err) {
      Alert.alert('Xatolik', getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  async function handleLogout() {
    Alert.alert('Chiqish', 'Hisobingizdan chiqmoqchimisiz?', [
      { text: 'Bekor qilish', style: 'cancel' },
      { text: 'Chiqish', style: 'destructive', onPress: async () => { await logoutRequest(); onLogout?.(); } },
    ]);
  }

  if (loading || !user) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  const isProvider = user.role === 'provider' || user.role === 'both';

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Profil</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <View style={styles.profileCard}>
          <View style={styles.avatar}>{user.avatarUrl ? <Image source={{uri:user.avatarUrl}} style={styles.avatarImage}/> : <Text style={styles.avatarInitial}>{user.fullName?.[0] || '?'}</Text>}</View>
          <Text style={styles.name}>{user.fullName}</Text>
          <Text style={styles.phone}>{user.phone}</Text>
          {user.email && <Text style={styles.email}>{user.email}</Text>}

          {isProvider && user.providerProfile && (
            <View style={styles.ratingRow}>
              <Ionicons name="star" size={16} color="#F59E0B" />
              <Text style={styles.ratingText}>
                {(Number(user.providerProfile.ratingAvg) || 0).toFixed(1)} ({user.providerProfile.ratingCount || 0} sharh) ·{' '}
                {user.providerProfile.completedOrdersCount || 0} ish bajarilgan
              </Text>
            </View>
          )}
          {isProvider && providerDetails && (
            <View style={[styles.verificationBadge, providerDetails?.myIdVerified ? styles.verified : styles.notVerified]}>
              <Ionicons name={providerDetails?.myIdVerified ? 'checkmark-circle' : 'time-outline'} size={16} color={providerDetails?.myIdVerified ? '#15803D' : '#B45309'} />
              <Text style={[styles.verificationText, { color: providerDetails?.myIdVerified ? '#15803D' : '#B45309' }]}>
                {providerDetails?.myIdVerified ? 'MyID orqali shaxsi tasdiqlangan' : 'MyID orqali tasdiqlash kutilmoqda'}
              </Text>
            </View>
          )}
        </View>

        {isProvider && providerDetails && (
          <View style={styles.detailsCard}>
            <Text style={styles.sectionTitle}>Usta anketasi</Text>
            <View style={styles.detailRow}>
              <Ionicons name="time-outline" size={18} color={colors.primary} />
              <Text style={styles.detailText}>Tajriba: {providerDetails.experienceYears || 0} yil</Text>
            </View>
            {providerDetails.bio ? (
              <View style={styles.bioBlock}>
                <Text style={styles.detailLabel}>Men haqimda</Text>
                <Text style={styles.bioText}>{providerDetails.bio}</Text>
              </View>
            ) : (
              <Text style={styles.missingInfo}>Mijozlar sizni yaxshiroq tanishi uchun o‘zingiz haqingizda ma’lumot qo‘shing.</Text>
            )}
            {!!providerDetails.categories?.length && (
              <View style={styles.categoryBlock}>
                <Text style={styles.detailLabel}>Xizmat yo‘nalishlari</Text>
                <View style={styles.categoryWrap}>
                  {providerDetails.categories.map((category) => (
                    <View key={category.id} style={styles.categoryChip}>
                      <Text style={styles.categoryText}>{category.nameUz}</Text>
                    </View>
                  ))}
                </View>
              </View>
            )}
          </View>
        )}

        {isProvider && (
          <View style={styles.detailsCard}>
            <View style={styles.reviewSectionHeader}>
              <Text style={styles.sectionTitle}>Mijozlar sharhlari ({providerReviews.length})</Text>
              <Pressable onPress={() => navigation.navigate('ProviderReviews', { providerId: user.id })} style={styles.allReviewsButton}>
                <Text style={styles.allReviewsText}>Barchasi</Text><Ionicons name="chevron-forward" size={16} color={colors.primary} />
              </Pressable>
            </View>
            {providerReviews.length ? providerReviews.map((review) => (
              <View key={review.id} style={styles.reviewItem}>
                <View style={styles.reviewHeader}>
                  <Text style={styles.reviewName}>{review.reviewerName || 'Mijoz'}</Text>
                  <View style={styles.reviewStars}>
                    {Array.from({ length: 5 }, (_, index) => (
                      <Ionicons key={index} name={index < Number(review.rating) ? 'star' : 'star-outline'} size={13} color="#F59E0B" />
                    ))}
                  </View>
                </View>
                {review.comment ? <Text style={styles.reviewComment}>{review.comment}</Text> : <Text style={styles.reviewNoComment}>Izoh qoldirilmagan</Text>}
                <Text style={styles.reviewDate}>{review.createdAt ? new Date(review.createdAt).toLocaleDateString('uz-UZ') : ''}</Text>
              </View>
            )) : (
              <Text style={styles.missingInfo}>Hozircha mijozlar sharh qoldirishmagan.</Text>
            )}
          </View>
        )}

        <MenuItem icon="create-outline" label="Profilni tahrirlash" onPress={() => navigation.navigate('EditProfile')} />
        {isProvider && <MenuItem icon="images-outline" label="Ishlarim portfoliom" onPress={() => navigation.navigate('Portfolio')} />}
        {isProvider && <MenuItem icon="star-outline" label="Mijozlar sharhlari" onPress={() => navigation.navigate('ProviderReviews', { providerId: user.id })} />}
        <MenuItem
          icon="briefcase-outline"
          label="Buyurtmalarim (mijoz sifatida)"
          onPress={() => navigation.navigate('MyOrders', { role: 'client' })}
        />
        {isProvider && (
          <MenuItem
            icon="construct-outline"
            label="Ishlarim (usta sifatida)"
            onPress={() => navigation.navigate('MyOrders', { role: 'provider' })}
          />
        )}
        <MenuItem icon="chatbubbles-outline" label="Suhbatlar" onPress={() => navigation.navigate('ChatsList')} />

        {!isProvider && (
          <Pressable style={styles.becomeProviderCard} onPress={() => navigation.navigate('BecomeProvider')}>
            <Ionicons name="hammer-outline" size={22} color={colors.white} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.becomeProviderTitle}>Usta bo'lib ishlashni xohlaysizmi?</Text>
              <Text style={styles.becomeProviderSubtitle}>Xizmatlaringizni ko'rsatib, pul ishlang</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.white} />
          </Pressable>
        )}

        <Pressable style={styles.logoutButton} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={20} color={colors.error} />
          <Text style={styles.logoutText}>Chiqish</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

function MenuItem({ icon, label, onPress }) {
  return (
    <Pressable style={({ pressed }) => [styles.menuItem, pressed && { opacity: 0.7 }]} onPress={onPress}>
      <Ionicons name={icon} size={20} color={colors.primary} />
      <Text style={styles.menuLabel}>{label}</Text>
      <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  header: {
    paddingTop: 54,
    paddingBottom: 16,
    paddingHorizontal: 20,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: 20, fontWeight: '800', color: colors.textPrimary },
  profileCard: {
    backgroundColor: colors.surface,
    borderRadius: 18,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: colors.border,
  },
  avatarImage: { width: 76, height: 76, borderRadius: 38 },
  avatar: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: colors.primary,
    alignItems: 'center', justifyContent: 'center', marginBottom: 12,
  },
  avatarInitial: { color: colors.white, fontWeight: '800', fontSize: 28 },
  name: { fontSize: 19, fontWeight: '800', color: colors.textPrimary },
  phone: { fontSize: 13.5, color: colors.textMuted, marginTop: 2 },
  email: { fontSize: 13.5, color: colors.textMuted, marginTop: 1 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 10 },
  ratingText: { fontSize: 13, color: colors.textSecondary, fontWeight: '600' },
  verificationBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20 },
  verified: { backgroundColor: '#DCFCE7' },
  notVerified: { backgroundColor: '#FEF3C7' },
  verificationText: { fontSize: 12.5, fontWeight: '700' },
  detailsCard: { backgroundColor: colors.surface, borderRadius: 16, padding: 18, marginBottom: 16, borderWidth: 1, borderColor: colors.border },
  sectionTitle: { fontSize: 16, fontWeight: '800', color: colors.textPrimary, marginBottom: 14 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 12 },
  detailText: { color: colors.textPrimary, fontSize: 14, fontWeight: '600' },
  bioBlock: { marginBottom: 14 },
  detailLabel: { color: colors.textMuted, fontSize: 12, fontWeight: '700', marginBottom: 6 },
  bioText: { color: colors.textSecondary, fontSize: 14, lineHeight: 21 },
  missingInfo: { color: colors.textMuted, fontSize: 13, lineHeight: 19, marginBottom: 12 },
  reviewSectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  allReviewsButton: { flexDirection: 'row', alignItems: 'center', gap: 2, paddingVertical: 6, paddingLeft: 8 },
  allReviewsText: { color: colors.primary, fontSize: 12, fontWeight: '800' },
  reviewItem: { paddingVertical: 12, borderTopWidth: 1, borderTopColor: colors.border },
  reviewHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  reviewName: { flex: 1, color: colors.textPrimary, fontSize: 13.5, fontWeight: '700' },
  reviewStars: { flexDirection: 'row', gap: 2 },
  reviewComment: { color: colors.textSecondary, fontSize: 13, lineHeight: 19, marginTop: 7 },
  reviewNoComment: { color: colors.textMuted, fontSize: 12, marginTop: 7 },
  reviewDate: { color: colors.textMuted, fontSize: 11, marginTop: 6 },
  categoryBlock: { marginTop: 2 },
  categoryWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  categoryChip: { backgroundColor: colors.primaryLight, borderRadius: 18, paddingHorizontal: 11, paddingVertical: 7 },
  categoryText: { color: colors.primary, fontSize: 12, fontWeight: '700' },
  menuItem: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderRadius: 14, padding: 16, marginBottom: 10,
    borderWidth: 1, borderColor: colors.border,
  },
  menuLabel: { flex: 1, fontSize: 14.5, fontWeight: '600', color: colors.textPrimary },
  becomeProviderCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.accent, borderRadius: 16, padding: 18, marginTop: 8, marginBottom: 10,
  },
  becomeProviderTitle: { color: colors.white, fontWeight: '700', fontSize: 14.5 },
  becomeProviderSubtitle: { color: 'rgba(255,255,255,0.85)', fontSize: 12, marginTop: 2 },
  logoutButton: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    marginTop: 16, paddingVertical: 14,
  },
  logoutText: { color: colors.error, fontWeight: '700', fontSize: 14.5 },
});
