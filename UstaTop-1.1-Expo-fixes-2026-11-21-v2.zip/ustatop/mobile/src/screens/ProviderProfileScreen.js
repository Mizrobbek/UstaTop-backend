import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, ActivityIndicator, Alert, Image, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import { fetchProviderProfile, fetchProviderReviews } from '../api/account';
import { getErrorMessage } from '../api/client';

export default function ProviderProfileScreen({ navigation, route }) {
  const { providerId } = route.params;
  const [provider, setProvider] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    Promise.all([fetchProviderProfile(providerId), fetchProviderReviews(providerId)])
      .then(([profile, items]) => {
        if (!active) return;
        setProvider(profile);
        setReviews(Array.isArray(items) ? items : []);
      })
      .catch((error) => {
        if (active) Alert.alert('Xatolik', getErrorMessage(error));
      })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [providerId]);

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View>;
  if (!provider) return <View style={styles.center}><Text style={styles.muted}>Usta profili yuklanmadi.</Text></View>;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}><Ionicons name="chevron-back" size={26} color={colors.textPrimary} /></Pressable>
        <Text style={styles.headerTitle}>Usta profili</Text>
        <View style={{ width: 26 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.profileCard}>
          {provider.avatarUrl ? <Image source={{ uri: provider.avatarUrl }} style={styles.avatar} /> : <View style={styles.avatarFallback}><Text style={styles.avatarLetter}>{provider.fullName?.[0] || '?'}</Text></View>}
          <Text style={styles.name}>{provider.fullName}</Text>
          <Text style={styles.city}>{provider.city || 'Shahar ko‘rsatilmagan'}</Text>
          <View style={styles.ratingRow}>
            <Ionicons name="star" size={16} color="#F59E0B" />
            <Text style={styles.rating}>{Number(provider.ratingAvg || 0).toFixed(1)} · {provider.ratingCount || 0} sharh</Text>
            <Text style={styles.dot}>·</Text>
            <Text style={styles.rating}>{provider.completedOrdersCount || 0} bajarilgan ish</Text>
          </View>
          <View style={[styles.verifyBadge, provider.myIdVerified ? styles.verified : styles.pending]}>
            <Ionicons name={provider.myIdVerified ? 'checkmark-circle' : 'time-outline'} size={15} color={provider.myIdVerified ? '#15803D' : '#B45309'} />
            <Text style={[styles.verifyText, { color: provider.myIdVerified ? '#15803D' : '#B45309' }]}>{provider.myIdVerified ? 'MyID tasdiqlangan' : 'MyID tasdiqlanmagan'}</Text>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Usta haqida</Text>
          <Text style={styles.body}>{provider.bio || 'Usta hozircha o‘zi haqida ma’lumot kiritmagan.'}</Text>
          <Text style={styles.meta}>Tajriba: {provider.experienceYears || 0} yil</Text>
          {!!provider.categories?.length && <View style={styles.chips}>{provider.categories.map((item) => <Text key={item.id} style={styles.chip}>{item.nameUz}</Text>)}</View>}
        </View>

        {!!provider.portfolio?.length && <View style={styles.card}>
          <Text style={styles.sectionTitle}>Portfolio</Text>
          <View style={styles.portfolioGrid}>{provider.portfolio.map((item) => (
            <Pressable key={item.id} onPress={() => item.mediaUrl && Linking.openURL(item.mediaUrl)}>
              {item.type === 'video' ? <View style={styles.videoTile}><Ionicons name="play-circle" size={32} color={colors.white} /></View> : <Image source={{ uri: item.mediaUrl }} style={styles.portfolioImage} />}
              {!!item.description && <Text style={styles.caption} numberOfLines={2}>{item.description}</Text>}
            </Pressable>
          ))}</View>
        </View>}

        <Pressable style={[styles.card, styles.reviewsLink]} onPress={() => navigation.navigate('ProviderReviews', { providerId })}>
          <View style={{ flex: 1 }}><Text style={styles.sectionTitle}>Mijozlar sharhlari</Text><Text style={styles.muted}>Barcha fikrlar va baholarni ko‘rish</Text></View>
          <Text style={styles.reviewCount}>{reviews.length}</Text><Ionicons name="chevron-forward" size={20} color={colors.textMuted}/>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 54, paddingBottom: 14, paddingHorizontal: 20, backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.textPrimary },
  content: { padding: 16, paddingBottom: 32 },
  profileCard: { alignItems: 'center', padding: 22, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, marginBottom: 14 },
  avatar: { width: 76, height: 76, borderRadius: 38, marginBottom: 10 },
  avatarFallback: { width: 76, height: 76, borderRadius: 38, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  avatarLetter: { color: colors.white, fontSize: 28, fontWeight: '800' },
  name: { color: colors.textPrimary, fontSize: 19, fontWeight: '800' },
  city: { color: colors.textMuted, fontSize: 13, marginTop: 3 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 10, flexWrap: 'wrap', justifyContent: 'center' },
  rating: { color: colors.textSecondary, fontSize: 12.5, fontWeight: '600' },
  dot: { color: colors.textMuted },
  verifyBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 11, paddingVertical: 6, borderRadius: 16, marginTop: 10 },
  verified: { backgroundColor: '#DCFCE7' },
  pending: { backgroundColor: '#FEF3C7' },
  verifyText: { fontSize: 11.5, fontWeight: '700' },
  card: { padding: 16, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, marginBottom: 14 },
  sectionTitle: { fontSize: 15, fontWeight: '800', color: colors.textPrimary, marginBottom: 10 },
  body: { color: colors.textSecondary, fontSize: 13.5, lineHeight: 20 },
  meta: { color: colors.textMuted, fontSize: 12.5, marginTop: 10 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 12 },
  chip: { color: colors.primary, backgroundColor: colors.primaryLight, borderRadius: 14, paddingHorizontal: 10, paddingVertical: 6, fontSize: 11.5, fontWeight: '700' },
  portfolioGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  portfolioImage: { width: 132, height: 110, borderRadius: 9 },
  videoTile: { width: 132, height: 110, borderRadius: 9, backgroundColor: colors.textMuted, alignItems: 'center', justifyContent: 'center' },
  caption: { color: colors.textMuted, fontSize: 11, width: 132, marginTop: 4 },
  reviewsLink: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  reviewCount: { color: colors.primary, fontSize: 16, fontWeight: '800' },
  review: { paddingVertical: 11, borderTopWidth: 1, borderTopColor: colors.border },
  reviewTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  reviewer: { flex: 1, color: colors.textPrimary, fontSize: 13, fontWeight: '700' },
  stars: { flexDirection: 'row', gap: 2 },
  date: { color: colors.textMuted, fontSize: 11, marginTop: 6 },
  muted: { color: colors.textMuted, fontSize: 13 },
});
