import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import { fetchProviderReviews, fetchProviderProfile } from '../api/account';

export default function ProviderReviewsScreen({ navigation, route }) {
  const { providerId } = route.params;
  const [reviews, setReviews] = useState([]);
  const [provider, setProvider] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let active = true;
    Promise.all([fetchProviderReviews(providerId), fetchProviderProfile(providerId)])
      .then(([items, profile]) => { if (active) { setReviews(Array.isArray(items) ? items : []); setProvider(profile); } })
      .catch(() => { if (active) setReviews([]); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [providerId]);
  const average = useMemo(() => reviews.length ? reviews.reduce((sum, item) => sum + Number(item.rating || 0), 0) / reviews.length : Number(provider?.ratingAvg || 0), [reviews, provider]);
  const counts = useMemo(() => [5,4,3,2,1].map(star => reviews.filter(r => Number(r.rating) === star).length), [reviews]);
  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={colors.primary}/></View>;
  return <View style={styles.container}>
    <View style={styles.header}><Pressable onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={26} color="#0F172A"/></Pressable><Text style={styles.headerTitle}>Mijozlar sharhlari</Text><View style={{width:26}}/></View>
    <ScrollView contentContainerStyle={styles.content}>
      <View style={styles.summary}>
        <Text style={styles.summaryLabel}>Umumiy baho</Text>
        <Text style={styles.average}>{average.toFixed(1)}</Text>
        <View style={styles.stars}>{[1,2,3,4,5].map(n => <Ionicons key={n} name={n <= Math.round(average) ? 'star' : 'star-outline'} size={18} color="#F5B51B"/>)}</View>
        <Text style={styles.total}>{reviews.length} ta mijoz sharhi</Text>
        <View style={styles.breakdown}>{[5,4,3,2,1].map((star, i) => <View key={star} style={styles.breakRow}><Text style={styles.starNumber}>{star}</Text><Ionicons name="star" size={12} color="#F5B51B"/><View style={styles.track}><View style={[styles.fill,{width: `${reviews.length ? counts[i] / reviews.length * 100 : 0}%`}]} /></View><Text style={styles.count}>{counts[i]}</Text></View>)}</View>
      </View>
      <Text style={styles.section}>Barcha sharhlar</Text>
      {reviews.length ? reviews.map(item => <View key={item.id} style={styles.reviewCard}>
        <View style={styles.reviewTop}><View style={styles.avatar}><Text style={styles.avatarText}>{(item.reviewerName || 'M')[0].toUpperCase()}</Text></View><View style={{flex:1}}><Text style={styles.reviewer}>{item.reviewerName || 'Mijoz'}</Text><Text style={styles.date}>{item.createdAt ? new Date(item.createdAt).toLocaleDateString('uz-UZ') : ''}</Text></View><View style={styles.rating}><Ionicons name="star" size={13} color="#F5B51B"/><Text style={styles.ratingText}>{Number(item.rating || 0).toFixed(1)}</Text></View></View>
        <Text style={styles.comment}>{item.comment || 'Izoh qoldirilmagan'}</Text>
      </View>) : <View style={styles.empty}><Ionicons name="chatbubble-ellipses-outline" size={34} color="#94A3B8"/><Text style={styles.emptyTitle}>Hozircha sharhlar yo‘q</Text><Text style={styles.emptyText}>Usta xizmatidan foydalangan mijozlarning fikrlari shu yerda ko‘rinadi.</Text></View>}
    </ScrollView>
  </View>;
}
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#F4F7F8'},center:{flex:1,alignItems:'center',justifyContent:'center'},header:{height:94,paddingTop:48,paddingHorizontal:18,backgroundColor:'#fff',flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderBottomWidth:1,borderBottomColor:'#E8EEF0'},headerTitle:{fontSize:17,fontWeight:'800',color:'#102A2A'},content:{padding:16,paddingBottom:36},summary:{backgroundColor:'#fff',borderRadius:22,padding:20,alignItems:'center',borderWidth:1,borderColor:'#E8EEF0'},summaryLabel:{fontSize:13,color:'#64748B',fontWeight:'600'},average:{fontSize:48,fontWeight:'900',color:'#102A2A',marginTop:3},stars:{flexDirection:'row',gap:4,marginTop:2},total:{fontSize:12,color:'#64748B',marginTop:6},breakdown:{width:'100%',marginTop:20,gap:8},breakRow:{flexDirection:'row',alignItems:'center',gap:7},starNumber:{width:12,color:'#475569',fontSize:12},track:{height:7,flex:1,backgroundColor:'#E9EEF0',borderRadius:8,overflow:'hidden'},fill:{height:7,backgroundColor:'#F5B51B',borderRadius:8},count:{width:20,textAlign:'right',fontSize:11,color:'#64748B'},section:{fontSize:17,fontWeight:'800',color:'#102A2A',marginTop:22,marginBottom:10},reviewCard:{backgroundColor:'#fff',borderRadius:18,padding:15,marginBottom:10,borderWidth:1,borderColor:'#E8EEF0'},reviewTop:{flexDirection:'row',alignItems:'center',gap:10},avatar:{width:40,height:40,borderRadius:20,backgroundColor:'#D9F0ED',alignItems:'center',justifyContent:'center'},avatarText:{fontSize:16,fontWeight:'800',color:'#0F766E'},reviewer:{fontSize:13,fontWeight:'800',color:'#102A2A'},date:{fontSize:11,color:'#94A3B8',marginTop:2},rating:{flexDirection:'row',alignItems:'center',gap:3,backgroundColor:'#FFF8E5',paddingHorizontal:8,paddingVertical:5,borderRadius:12},ratingText:{fontSize:12,fontWeight:'800',color:'#8A5A00'},comment:{fontSize:13,color:'#475569',lineHeight:20,marginTop:12},empty:{alignItems:'center',padding:28,backgroundColor:'#fff',borderRadius:18},emptyTitle:{fontSize:15,fontWeight:'800',color:'#334155',marginTop:10},emptyText:{fontSize:12,color:'#94A3B8',textAlign:'center',lineHeight:18,marginTop:5}});
