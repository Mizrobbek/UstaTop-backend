import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Pressable,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';

import colors, { gradients } from '../theme/colors';
import { LogoMark } from '../components/Logo';
import TextField from '../components/TextField';
import PasswordInput from '../components/PasswordInput';
import PrimaryButton from '../components/PrimaryButton';
import { registerRequest, verifyRegistrationCodeRequest, saveSession, getErrorMessage } from '../api/client';
import { toE164Uzbek, isValidUzbekPhone } from '../utils/phone';

export default function RegisterScreen({ navigation, onLoginSuccess }) {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  function validate() {
    const next = {};
    if (!fullName.trim() || fullName.trim().length < 2) next.fullName = 'Ism kamida 2 ta belgidan iborat bo\'lishi kerak';

    const normalizedPhone = toE164Uzbek(phone);
    if (!isValidUzbekPhone(normalizedPhone)) next.phone = 'Telefon raqamni to\'liq kiriting (9 ta raqam)';

    if (otpSent && !/^\d{5}$/.test(otp)) next.otp = 'SMS kodi 5 ta raqamdan iborat bo\'lishi kerak';

    if (password.length < 8) next.password = 'Parol kamida 8 ta belgidan iborat bo\'lishi kerak';
    else if (!/^(?=.*[A-Za-z])(?=.*\d).+$/.test(password))
      next.password = 'Parol kamida bitta harf va bitta raqamdan iborat bo\'lishi kerak';

    if (confirmPassword !== password) next.confirmPassword = 'Parollar bir xil emas';

    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleRegister() {
    if (!otpSent && !validate()) return;
    if (otpSent && !/^\d{5}$/.test(otp)) { setErrors({ otp: 'SMS kodi 5 ta raqamdan iborat bo\'lishi kerak' }); return; }
    setLoading(true);
    try {
      const phoneE164 = toE164Uzbek(phone);
      if (!otpSent) {
        const response = await registerRequest({ fullName: fullName.trim(), phone: phoneE164, password });
        setOtpSent(true);
        Alert.alert('SMS yuborildi', response.debugCode ? `Test SMS kodi: ${response.debugCode}` : 'Telefon raqamingizga kelgan 5 xonali kodni kiriting.');
      } else {
        const data = await verifyRegistrationCodeRequest({ phone: phoneE164, code: otp });
        await saveSession(data);
        onLoginSuccess?.(data.user);
      }
    } catch (err) {
      Alert.alert(otpSent ? 'Kod tasdiqlanmadi' : 'Ro\'yxatdan o\'tib bo\'lmadi', getErrorMessage(err));
    } finally { setLoading(false); }
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <LinearGradient colors={gradients.hero} style={styles.hero}>
        <Pressable style={styles.backButton} onPress={() => navigation.goBack()} hitSlop={10}>
          <Text style={styles.backButtonText}>‹</Text>
        </Pressable>
        <LogoMark size={64} />
        <Text style={styles.heroTitle}>Yangi hisob yaratish</Text>
      </LinearGradient>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.sheet}
        keyboardVerticalOffset={40}
      >
        <ScrollView
          contentContainerStyle={styles.sheetContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <TextField
            label="To'liq ism"
            icon="person-outline"
            placeholder="Aziz Karimov"
            value={fullName}
            onChangeText={(t) => {
              setFullName(t);
              if (errors.fullName) setErrors((e) => ({ ...e, fullName: null }));
            }}
            error={errors.fullName}
            autoCapitalize="words"
            returnKeyType="next"
            editable={!otpSent}
          />

          <TextField
            label="Telefon raqam"
            icon="call-outline"
            prefix="+998"
            placeholder="90 123 45 67"
            value={phone.replace(/\D/g, '').replace(/^998/, '').slice(0, 9)}
            onChangeText={(t) => {
              setPhone(t.replace(/\D/g, '').replace(/^998/, '').slice(0, 9));
              if (errors.phone) setErrors((e) => ({ ...e, phone: null }));
            }}
            error={errors.phone}
            keyboardType="phone-pad"
            returnKeyType="next"
            editable={!otpSent}
          />

          <PasswordInput
            value={password}
            onChangeText={(t) => {
              setPassword(t);
              if (errors.password) setErrors((e) => ({ ...e, password: null }));
            }}
            error={errors.password}
            placeholder="Kamida 8 ta belgi, harf + raqam"
            returnKeyType="next"
            editable={!otpSent}
          />

          <PasswordInput
            label="Parolni tasdiqlang"
            value={confirmPassword}
            onChangeText={(t) => {
              setConfirmPassword(t);
              if (errors.confirmPassword) setErrors((e) => ({ ...e, confirmPassword: null }));
            }}
            error={errors.confirmPassword}
            placeholder="Parolni qayta kiriting"
            returnKeyType="done"
            onSubmitEditing={handleRegister}
            editable={!otpSent}
          />

          {otpSent ? (
            <TextField
              label="SMS tasdiqlash kodi"
              icon="keypad-outline"
              placeholder="5 xonali kod"
              value={otp}
              onChangeText={(t) => setOtp(t.replace(/\D/g, '').slice(0, 5))}
              error={errors.otp}
              keyboardType="number-pad"
              returnKeyType="done"
            />
          ) : null}

          <PrimaryButton
            title={otpSent ? 'Telefonni tasdiqlash' : "SMS kod yuborish"}
            onPress={handleRegister}
            loading={loading}
            style={{ marginTop: 8 }}
          />

          <View style={styles.bottomRow}>
            <Text style={styles.bottomText}>Hisobingiz bormi? </Text>
            <Pressable onPress={() => navigation.navigate('Login')} hitSlop={8}>
              <Text style={styles.bottomLink}>Kirish</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  hero: {
    height: 220,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  backButton: {
    position: 'absolute',
    top: 52,
    left: 20,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backButtonText: { color: colors.white, fontSize: 24, marginTop: -2 },
  heroTitle: { color: colors.white, fontSize: 17, fontWeight: '700', marginTop: 10 },
  sheet: { flex: 1, marginTop: -24 },
  sheetContent: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 24,
    paddingTop: 26,
    paddingBottom: 40,
    flexGrow: 1,
  },
  bottomRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 8 },
  bottomText: { color: colors.textSecondary, fontSize: 14.5 },
  bottomLink: { color: colors.accent, fontWeight: '700', fontSize: 14.5 },
});
