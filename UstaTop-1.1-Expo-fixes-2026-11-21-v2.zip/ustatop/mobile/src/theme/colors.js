/**
 * UstaTop rang palitrasi.
 *
 * G'oya: chuqur teal (ko'k-yashil) — ishonch, professionallik, ustalik ramzi
 * (Profi24 kabi sohadagi yetakchi ilovalar ham shu ranglar oilasidan foydalanadi),
 * unga qarshi issiq amber/apelsin urg'u rangi qo'shildiki, bu "harakat" tugmalarini
 * (Kirish, Ro'yxatdan o'tish) ekranda darhol ko'zga tashlantiradi va bosishga undaydi.
 */
export const colors = {
  // Asosiy teal gamma (brend rangi)
  primary: '#0F766E',
  primaryDark: '#0B4F49',
  primaryLight: '#14B8A6',

  // Gradient uchun (Login/Register fon va logotip)
  gradientStart: '#0F766E',
  gradientMid: '#0E7490',
  gradientEnd: '#155E75',

  // Urg'u (accent) rang - CTA tugmalar uchun, diqqatni tortadi
  accent: '#FF7A30',
  accentDark: '#E8600F',
  accentLight: '#FFA35C',

  // Neytral ranglar
  background: '#F7FAF9',
  surface: '#FFFFFF',
  border: '#E2E8E7',
  textPrimary: '#0F2622',
  textSecondary: '#5B6B69',
  textMuted: '#94A3A1',
  placeholder: '#A6B5B3',

  // Holat ranglari
  success: '#16A34A',
  error: '#DC2626',
  warning: '#D97706',

  white: '#FFFFFF',
  black: '#000000',
};

export const gradients = {
  hero: [colors.gradientStart, colors.gradientMid, colors.gradientEnd],
  button: [colors.accent, colors.accentDark],
};

export default colors;
