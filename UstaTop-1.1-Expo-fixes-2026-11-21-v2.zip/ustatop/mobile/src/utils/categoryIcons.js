/**
 * Backend `categories.icon` ustunidagi qisqa kod nomlarini
 * @expo/vector-icons Ionicons nomlariga moslaydi.
 */
export const CATEGORY_ICON_MAP = {
  plumbing: 'water-outline',
  electrical: 'flash-outline',
  ac: 'snow-outline',
  paint_roller: 'color-palette-outline',
  furniture: 'cube-outline',
  cleaning: 'sparkles-outline',
  moving_box: 'cube-outline',
  window: 'browsers-outline',
  appliance: 'hardware-chip-outline',
  tutor: 'school-outline',
  beauty: 'flower-outline',
  computer: 'laptop-outline',
};

export function getCategoryIcon(iconCode) {
  return CATEGORY_ICON_MAP[iconCode] || 'construct-outline';
}
