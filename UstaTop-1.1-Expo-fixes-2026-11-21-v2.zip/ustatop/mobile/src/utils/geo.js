import Constants from 'expo-constants';

// app.json > expo.extra orqali sozlanadi - backend/src/utils/geo.js dagi UZ_BOUNDS bilan bir xil
export const UZ_BOUNDS = Constants.expoConfig?.extra?.uzbekistanBounds || {
  minLat: 37.1,
  maxLat: 45.7,
  minLng: 55.9,
  maxLng: 73.2,
};

export const DEFAULT_REGION = Constants.expoConfig?.extra?.defaultRegion || {
  latitude: 41.3111,
  longitude: 69.2797,
  latitudeDelta: 0.15,
  longitudeDelta: 0.15,
};

export function isInUzbekistan(lat, lng) {
  return (
    typeof lat === 'number' &&
    typeof lng === 'number' &&
    lat >= UZ_BOUNDS.minLat &&
    lat <= UZ_BOUNDS.maxLat &&
    lng >= UZ_BOUNDS.minLng &&
    lng <= UZ_BOUNDS.maxLng
  );
}

const EARTH_RADIUS_KM = 6371;
const toRad = (deg) => (deg * Math.PI) / 180;

/** Ikki nuqta orasidagi masofa (km) - backend bilan bir xil haversine formulasi */
export function haversineKm(lat1, lng1, lat2, lng2) {
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(a)));
}

/** MapView'ning onRegionChangeComplete natijasidan backend /listings/map so'rovi uchun bounding box hosil qiladi */
export function regionToBoundingBox(region) {
  return {
    minLat: region.latitude - region.latitudeDelta / 2,
    maxLat: region.latitude + region.latitudeDelta / 2,
    minLng: region.longitude - region.longitudeDelta / 2,
    maxLng: region.longitude + region.longitudeDelta / 2,
  };
}
