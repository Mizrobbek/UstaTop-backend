/**
 * Foydalanuvchi "90 123 45 67" yoki "901234567" kabi kiritgan raqamni
 * backend kutayotgan qat'iy formatga o'giradi: +998901234567
 */
export function toE164Uzbek(rawInput) {
  const digits = rawInput.replace(/\D/g, '');
  const withoutCountryCode = digits.startsWith('998') ? digits.slice(3) : digits;
  const last9 = withoutCountryCode.slice(-9);
  return `+998${last9}`;
}

/** Ekranda chiroyli ko'rinishi uchun: +998 90 123 45 67 */
export function formatUzbekPhoneDisplay(rawInput) {
  const digits = rawInput.replace(/\D/g, '').replace(/^998/, '').slice(0, 9);
  const parts = [digits.slice(0, 2), digits.slice(2, 5), digits.slice(5, 7), digits.slice(7, 9)].filter(Boolean);
  return `+998 ${parts.join(' ')}`.trim();
}

export function isValidUzbekPhone(phone) {
  return /^\+998\d{9}$/.test(phone);
}
